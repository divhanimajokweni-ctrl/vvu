# 03 · RIG (HBK-MkII photoreal)

Photoreal HBK-MkII manufacturing loop. Three.js + RoomEnvironment IBL.
5 assembly stations with 6-axis GLB robot arms. Procedural conveyor.
Zookeeper geometry kernel (KCL recipes). Hash-chained WORM ticker
(FNV-1a — see notes). FAIL_TEST button trips fail-closed.

**Mode:** SIM (simulation, labelled [SIM] in the banner)

## Run standalone
Serve the folder over HTTP (the GLB needs a same-origin fetch):
```bash
python3 -m http.server 8000
# open http://localhost:8000/rig.html
```

## Note on the hash chain
This surface has its own internal FNV-1a ticker for display. The shell
upgrades it to canonical SHA-256 + JCS at the aggregation layer.

