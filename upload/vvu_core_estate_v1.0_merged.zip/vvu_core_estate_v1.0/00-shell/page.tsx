// VVU Fused Cockpit Shell Page Component
import React from 'react';
import { verifyChain } from './worm';

export default function CockpitShell() {
  return (
    <div className='vvu-cockpit-shell bg-[#060806] text-[#c8ff00] p-6 font-mono'>
      <h1 className='text-2xl font-bold tracking-widest'>VVU ONE HOUSE: FUSED COCKPIT SHELL</h1>
      <p>Single Route (/) | Hash Workspace Routing | 12 Rooms United</p>
    </div>
  );
}