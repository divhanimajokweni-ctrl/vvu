// Ed25519 / SHA-256 JCS WORM Verification Module
import crypto from 'crypto';
export function computeJcsHash(payload: object): string {
  const serialized = JSON.stringify(payload, Object.keys(payload).sort());
  return crypto.createHash('sha256').update(serialized).digest('hex');
}