// Fused Shell Layout
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang='en'>
      <body className='bg-[#060806] text-[#c8ff00] min-h-screen antialiased'>{children}</body>
    </html>
  );
}