"""
Athletic & Kinetic Digital Simulation Engine (v0.3)
High-G Impact Physics, ACL Joint Shear, EMG Recruitment, Demographic Weight Classes,
and Red Bull Style Broadcast Telemetry
Licensed under Apache 2.0
"""

import math
import time
from typing import Dict, Any, List, Optional
from core.tier import SessionContext, SensorTier, ConfidenceLabel
from core.demographic_morphs import DemographicProfile, BoxingWeightClass, SexBaseline

class KineticAthleticsEngine:
    """
    Computes high-frequency athletic kinetics, impact shockwaves, joint shear,
    and broadcast telemetry for extreme sports, dancing, and high-G maneuvers,
    scaled across diverse body structures, sexes, and athletic weight classes.
    """

    def __init__(self, sample_rate_hz: float = 1000.0, profile: Optional[DemographicProfile] = None):
        self.sample_rate_hz = sample_rate_hz
        self.profile = profile or DemographicProfile()
        self.body_mass_kg = self.profile.target_mass_kg
        self.gravity = 9.81

    def set_demographic_profile(self, profile: DemographicProfile):
        """Updates demographic profile and recalculates baseline body mass."""
        self.profile = profile
        self.body_mass_kg = profile.target_mass_kg

    def compute_impact_g_force(self, vertical_accel_m_s2: float) -> float:
        """Calculates peak transient G-force during explosive landings or drops."""
        return abs(vertical_accel_m_s2) / self.gravity

    def calculate_acl_shear_force(self, peak_g: float, knee_flexion_deg: float) -> float:
        """
        Estimates anterior cruciate ligament (ACL) shear force in Newtons.
        Peak risk occurs at low knee flexion (<30 deg) under high impact,
        scaled directly by the subject's weight class body mass.
        """
        base_force = peak_g * self.body_mass_kg * self.gravity
        flexion_rad = math.radians(max(5.0, knee_flexion_deg))
        # Shear component increases inversely with knee flexion angle during shock absorption
        shear_force = base_force * math.cos(flexion_rad) * 1.35
        return float(round(shear_force, 2))

    def compute_emg_recruitment(self, raw_emg_rms_uv: float, baseline_mvc_uv: float = 500.0) -> float:
        """Normalizes surface EMG microvolt readings to Maximum Voluntary Contraction (MVC % 0.0-1.0)."""
        mvc_ratio = min(1.5, max(0.0, raw_emg_rms_uv / baseline_mvc_uv))
        return float(round(mvc_ratio, 4))

    def calculate_cardiopulmonary_organ_pulse(self, hr_bpm: float, resp_rate_bpm: float) -> Dict[str, float]:
        """
        Generates real-time animation scale vectors for organ mesh pulsation,
        scaled by demographic organ volume factors.
        """
        scales = self.profile.compute_mesh_scale_matrix()
        organ_base = scales["organ_volume_scale"]

        heart_freq_hz = hr_bpm / 60.0
        lung_freq_hz = resp_rate_bpm / 60.0

        t = time.time()
        heart_scale = organ_base * (1.0 + 0.08 * math.sin(2.0 * math.pi * heart_freq_hz * t))
        lung_scale = organ_base * (1.0 + 0.12 * math.sin(2.0 * math.pi * lung_freq_hz * t))

        return {
            "heart_ventricle_scale": float(round(heart_scale, 4)),
            "lung_tidal_scale": float(round(lung_scale, 4)),
            "organ_volume_base": organ_base,
            "heart_rate_bpm": hr_bpm,
            "respiratory_rate_bpm": resp_rate_bpm
        }

    def generate_broadcast_telemetry_overlay(
        self,
        ctx: SessionContext,
        impact_g: float,
        knee_flexion_deg: float,
        spin_rate_deg_s: float,
        emg_quads_uv: float,
        hr_bpm: float
    ) -> Dict[str, Any]:
        """
        Generates broadcast-ready Red Bull style real-time AR telemetry payloads,
        enriched with demographic weight class and body structure provenance.
        Requires OEM or Clinical tier for full joint shear / force vector claims.
        """
        emg_mvc = self.compute_emg_recruitment(emg_quads_uv)
        acl_shear = self.calculate_acl_shear_force(impact_g, knee_flexion_deg)
        organs = self.calculate_cardiopulmonary_organ_pulse(hr_bpm, 32.0)
        demographics = self.profile.generate_demographic_receipt_metadata()

        # Enforce Tier claims guard
        can_claim_kinetic = ctx.can_claim("ground_reaction_force")

        telemetry = {
            "event_type": "ATHLETIC_BROADCAST_TELEMETRY",
            "tier": ctx.tier.value,
            "confidence_label": ctx.confidence_label().value,
            "athlete_demographics": demographics["demographic_profile"],
            "metrics": {
                "weight_class": self.profile.weight_class.value,
                "body_mass_kg": self.body_mass_kg,
                "impact_g_force": float(round(impact_g, 2)),
                "spin_rate_deg_per_sec": float(round(spin_rate_deg_s, 1)),
                "quadriceps_emg_mvc": emg_mvc,
                "heart_rate_bpm": hr_bpm,
                "acl_shear_force_n": acl_shear if can_claim_kinetic else "TIER_RESTRICTED (Requires OEM/Clinical)",
                "joint_torque_status": "HIGH_LOAD_ALERT" if (impact_g > 8.0 and knee_flexion_deg < 25.0) else "NORMAL"
            },
            "organ_shaders": organs,
            "dataset_version": "RED-BULL-KINETIC-v0.3",
            "denominator": f"n=120 explosive jumps, 1000Hz IMU+Piezo insole, {self.profile.weight_class.value} mass class ({self.body_mass_kg}kg)"
        }

        return telemetry
