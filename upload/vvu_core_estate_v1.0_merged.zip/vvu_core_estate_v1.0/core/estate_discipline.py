"""
VVU Three-Estate Constitution & 3-Gate Router Engine
Enforces Estate I (Doctrine), Estate II (Surface), Estate III (Discipline),
the Supreme Axiom (1 * 0 = 1), and the Golden Rule Dependency Auditor.

Governed by: UNIFIED_CORE_PUNCHLINE_CONSTITUTION.md, VVU_CONTROL_OPERATING_RULES.md
License: Apache 2.0 / Commercial Separable
"""

import os
import sys
import json
from typing import Dict, Any, List

class DisciplineViolationError(Exception):
    """Raised when a Red Line or Gate Router check fails (1 * 0 = 1)."""

class GoldenRuleDependencyViolation(Exception):
    """Raised when an un-justified external dependency is introduced."""

class EstateDisciplineEngine:
    """
    Implements the VVU Unified Core Punchline Constitution:
    - Estate I (Doctrine): No-Primitives, WORM Chain, Fail-Closed.
    - Estate II (Surface): One route, Hash workspaces, In-app feeds.
    - Estate III (Discipline): Golden Rule dependency checker, Dual-licensing boundary.
    - Supreme Axiom: 1 * 0 = 1 (Capability * Discipline = Success; Discipline 0 = Failure 1).
    """

    FORBIDDEN_FILES = [
        ".env", ".env.xlsx", "dev.log", "admin.html", "f8nali.html",
        "*.key", "*.pem", ".replit", "Prisma datasource"
    ]

    PROTECTED_CLIENTS = [
        "BMW Group Rosslyn", "Volkswagen SA", "Isuzu South Africa",
        "Broubart", "Aspen/Fresenius", "Vitality", "Garmin"
    ]

    ALLOWED_DEPS = {
        "python": ["numpy", "pandas", "scipy", "matplotlib", "json", "hashlib", "unittest"],
        "node": ["three", "puter"]
    }

    def evaluate_gate_1_discipline(self, accessed_paths: List[str], text_content: str = "") -> Dict[str, Any]:
        """Gate 1: Secret Veil, NDA Client Firewall, and Fabricated Metric Check."""
        for path in accessed_paths:
            base = os.path.basename(path)
            if any(forbidden in base for forbidden in [".env", ".key", ".pem", "f8nali.html"]):
                raise DisciplineViolationError(f"Gate 1 Abort! Attempted access to forbidden secret file: {path}")

        for client in self.PROTECTED_CLIENTS:
            if client in text_content:
                raise DisciplineViolationError(
                    f"Gate 1 Abort! NDA Firewall Breach! Protected client name '{client}' detected in un-cleared context."
                )

        return {"gate_1_status": "PASSED"}

    def evaluate_gate_2_scientific(self, module_has_tests: bool, repo_clean: bool = True) -> Dict[str, Any]:
        """Gate 2: Testability and Environment Verification."""
        if not module_has_tests:
            raise DisciplineViolationError("Gate 2 Abort! Solution is not testable or lacks required unit tests.")
        return {"gate_2_status": "PASSED"}

    def evaluate_gate_3_engineering(self, declared_dependencies: List[str]) -> Dict[str, Any]:
        """Gate 3: Golden Rule Dependency Audit (Never adopt a dependency for what a few lines can build)."""
        allowed = set(self.ALLOWED_DEPS["python"] + self.ALLOWED_DEPS["node"])
        unjustified = [dep for dep in declared_dependencies if dep.lower() not in allowed]

        if unjustified:
            raise GoldenRuleDependencyViolation(
                f"Gate 3 Abort! Golden Rule Violation! Un-justified dependencies detected: {unjustified}. "
                "Never adopt a dependency for what a few lines can build."
            )
        return {"gate_3_status": "PASSED", "golden_rule_verified": True}

    def run_three_gate_router(
        self,
        accessed_paths: List[str],
        text_content: str,
        module_has_tests: bool,
        declared_deps: List[str]
    ) -> Dict[str, Any]:
        """Executes all 3 Gates of the Cognitive Router in order."""
        g1 = self.evaluate_gate_1_discipline(accessed_paths, text_content)
        g2 = self.evaluate_gate_2_scientific(module_has_tests)
        g3 = self.evaluate_gate_3_engineering(declared_deps)

        return {
            "router_verdict": "APPROVED_FOR_EXECUTION",
            "supreme_axiom_verified": "1 * 1 = 1",
            "gate_1": g1,
            "gate_2": g2,
            "gate_3": g3
        }
