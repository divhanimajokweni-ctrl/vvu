"""
VVU WORM chain — spec implementation (core/worm_spec.py)

Implements the chain spec from the VVU Trust OS README:

    source_hash(n) = SHA256( DOMAIN_SOURCE + canonicalize(payload_n) )
    chain_hash(n)  = SHA256( DOMAIN_CHAIN + chain_hash(n-1) + source_hash(n) + seq(n) as uint64 BE )
    GENESIS        = SHA256( DOMAIN_CHAIN + 'GENESIS' )

Signature: Ed25519 over the 32 raw bytes of source_hash, stored in meta.signature (base64).
Identity:  identity.json with base64 SPKI DER public key in "publicKey".

Canonicalisation is RFC 8785 (JCS) for the value types this chain uses:
strings, integers, booleans, null, arrays, objects. Floats are REJECTED
(RFC 8785 number serialisation is not implemented here; failing closed is
safer than emitting a hash an independent JCS verifier would not reproduce).

Verification is fail-closed. Every check that fails returns a reason code.
Unlike the JS reference, a missing signature is a failure when an identity
key is supplied (SIG_MISSING), and a missing hash field is a failure
(MISSING_FIELD), so stripping fields cannot bypass verification.

Zero network access. Standard library + `cryptography` for Ed25519 only.
"""

from __future__ import annotations

import base64
import hashlib
import json
import struct
from typing import Any, Dict, List, Optional

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

DOMAIN_SOURCE = "VVU-SOURCE-v1"
DOMAIN_CHAIN = "VVU-CHAIN-v1"
GENESIS = hashlib.sha256((DOMAIN_CHAIN + "GENESIS").encode("ascii")).hexdigest()

# Fields that are chain metadata, not payload.
_CHAIN_FIELDS = ("source_hash", "chain_hash", "seq", "meta")


class CanonicalizationError(ValueError):
    """Raised for values JCS canonicalisation in this module does not support."""


# ---------------------------------------------------------------------------
# RFC 8785 (JCS) canonicalisation
# ---------------------------------------------------------------------------

def _jcs_string(s: str) -> str:
    out = ['"']
    for ch in s:
        o = ord(ch)
        if ch == '"':
            out.append('\\"')
        elif ch == "\\":
            out.append("\\\\")
        elif ch == "\b":
            out.append("\\b")
        elif ch == "\f":
            out.append("\\f")
        elif ch == "\n":
            out.append("\\n")
        elif ch == "\r":
            out.append("\\r")
        elif ch == "\t":
            out.append("\\t")
        elif o < 0x20:
            out.append("\\u%04x" % o)  # lowercase hex, per RFC 8785 §3.2.2.2
        else:
            out.append(ch)
    out.append('"')
    return "".join(out)


def _es6_number(x: float) -> str:
    """ECMAScript Number::toString (RFC 8785 §3.2.2.3) from Python's shortest round-trip repr."""
    import math
    if math.isnan(x) or math.isinf(x):
        raise CanonicalizationError("NaN and Infinity are not valid JSON numbers")
    if x == 0:
        return "0"
    sign = "-" if x < 0 else ""
    r = repr(abs(x))
    if "e" in r:
        mant, exp_s = r.split("e")
        exp = int(exp_s)
    else:
        mant, exp = r, 0
    if "." in mant:
        int_part, frac = mant.split(".")
    else:
        int_part, frac = mant, ""
    digits = (int_part + frac).lstrip("0")
    # decimal point position n: value = 0.digits * 10**n
    n = len(int_part) + exp - (len(int_part + frac) - len((int_part + frac).lstrip("0")))
    digits = digits.rstrip("0") or "0"
    k = len(digits)
    if k <= n <= 21:
        body = digits + "0" * (n - k)
    elif 0 < n <= 21:
        body = digits[:n] + "." + digits[n:]
    elif -6 < n <= 0:
        body = "0." + "0" * (-n) + digits
    else:
        e = n - 1
        es = ("+" if e >= 0 else "-") + str(abs(e))
        body = (digits if k == 1 else digits[0] + "." + digits[1:]) + "e" + es
    return sign + body


def canonicalize(value: Any) -> str:
    """RFC 8785 canonical JSON text for the supported value types."""
    if value is None:
        return "null"
    if value is True:
        return "true"
    if value is False:
        return "false"
    if isinstance(value, int) and not isinstance(value, bool):
        if abs(value) > 2**53:  # RFC 8785 / I-JSON integer range
            raise CanonicalizationError("integer outside the I-JSON safe range")
        return str(value)
    if isinstance(value, float):
        return _es6_number(value)
    if isinstance(value, str):
        return _jcs_string(value)
    if isinstance(value, (list, tuple)):
        return "[" + ",".join(canonicalize(v) for v in value) + "]"
    if isinstance(value, dict):
        for k in value:
            if not isinstance(k, str):
                raise CanonicalizationError("object keys must be strings")
        # RFC 8785 §3.2.3: sort by UTF-16 code units.
        keys = sorted(value.keys(), key=lambda k: k.encode("utf-16-be"))
        return "{" + ",".join(_jcs_string(k) + ":" + canonicalize(value[k]) for k in keys) + "}"
    raise CanonicalizationError(f"unsupported type: {type(value).__name__}")


# ---------------------------------------------------------------------------
# Hashes
# ---------------------------------------------------------------------------

def payload_of(entry: Dict[str, Any]) -> Dict[str, Any]:
    """The signed payload: the entry with chain metadata fields removed."""
    return {k: v for k, v in entry.items() if k not in _CHAIN_FIELDS}


def source_hash(payload: Dict[str, Any]) -> str:
    return hashlib.sha256((DOMAIN_SOURCE + canonicalize(payload)).encode("utf-8")).hexdigest()


def chain_hash(prev_chain_hash: str, src_hash: str, seq: int) -> str:
    h = hashlib.sha256()
    h.update((DOMAIN_CHAIN + prev_chain_hash + src_hash).encode("ascii"))
    h.update(struct.pack(">Q", seq))  # uint64 big-endian
    return h.hexdigest()


# ---------------------------------------------------------------------------
# Build (signing side — used by the build script, never by an auditor)
# ---------------------------------------------------------------------------

def build_chain(payloads: List[Dict[str, Any]], private_key: Ed25519PrivateKeyLike) -> Dict[str, Any]:
    """Create a spec-format chain over the given payloads, signed with an Ed25519 key."""
    entries: List[Dict[str, Any]] = []
    prev = GENESIS
    for seq, payload in enumerate(payloads):
        src = source_hash(payload)
        ch = chain_hash(prev, src, seq)
        sig = base64.b64encode(private_key.sign(bytes.fromhex(src))).decode("ascii")
        entry = dict(payload)
        entry["seq"] = seq
        entry["source_hash"] = src
        entry["chain_hash"] = ch
        entry["meta"] = {"signature": sig}
        entries.append(entry)
        prev = ch
    return {"genesis": GENESIS, "entries": entries}


# ---------------------------------------------------------------------------
# Verify (auditor side — zero network, zero trust)
# ---------------------------------------------------------------------------

class Verdict(dict):
    @property
    def ok(self) -> bool:
        return self["valid"]


def _fail(seq: Any, reason: str, detail: str) -> Verdict:
    return Verdict(valid=False, at=seq, reason=reason, detail=detail,
                   verdict=f"❌ {reason} at seq {seq}: {detail}")


def load_public_key(identity: Dict[str, Any]) -> Ed25519PublicKey:
    der = base64.b64decode(identity["publicKey"])
    key = serialization.load_der_public_key(der)
    if not isinstance(key, Ed25519PublicKey):
        raise ValueError("identity key is not Ed25519")
    return key


def verify_chain(chain: Dict[str, Any], identity: Optional[Dict[str, Any]] = None) -> Verdict:
    """
    Verify a spec-format chain. Returns a Verdict; never raises on bad data.
    If `identity` is None, signatures cannot be checked and the verdict says so.
    """
    if not isinstance(chain, dict) or "entries" not in chain or "genesis" not in chain:
        return _fail("-", "MALFORMED_CHAIN", "expected an object with 'genesis' and 'entries'")
    if chain["genesis"] != GENESIS:
        return _fail(0, "GENESIS_MISMATCH", f"expected {GENESIS[:16]}..., got {str(chain['genesis'])[:16]}...")

    pub = None
    if identity is not None:
        try:
            pub = load_public_key(identity)
        except Exception as exc:  # fail closed on a bad identity file
            return _fail("-", "IDENTITY_INVALID", str(exc))

    prev = GENESIS
    for expected_seq, entry in enumerate(chain["entries"]):
        if not isinstance(entry, dict):
            return _fail(expected_seq, "MALFORMED_ENTRY", "entry is not an object")
        seq = entry.get("seq")
        if seq != expected_seq:
            return _fail(expected_seq, "SEQ_GAP", f"expected seq {expected_seq}, got {seq!r}")
        for field in ("source_hash", "chain_hash"):
            if not isinstance(entry.get(field), str):
                return _fail(seq, "MISSING_FIELD", f"'{field}' is absent")

        try:
            recomputed_src = source_hash(payload_of(entry))
        except CanonicalizationError as exc:
            return _fail(seq, "UNCANONICALIZABLE", str(exc))
        if recomputed_src != entry["source_hash"]:
            return _fail(seq, "SOURCE_HASH_MISMATCH", "payload was altered after signing")

        recomputed_chain = chain_hash(prev, entry["source_hash"], expected_seq)
        if recomputed_chain != entry["chain_hash"]:
            return _fail(seq, "CHAIN_LINK_BROKEN", "link does not match predecessor")

        if pub is not None:
            sig_b64 = (entry.get("meta") or {}).get("signature")
            if not isinstance(sig_b64, str):
                return _fail(seq, "SIG_MISSING", "entry is unsigned but an identity key was supplied")
            try:
                pub.verify(base64.b64decode(sig_b64), bytes.fromhex(entry["source_hash"]))
            except (InvalidSignature, ValueError):
                return _fail(seq, "SIG_INVALID", "signature does not verify against the identity key")

        prev = entry["chain_hash"]

    n = len(chain["entries"])
    signed = "signatures verified" if pub is not None else "signatures NOT checked (no identity supplied)"
    return Verdict(valid=True, count=n, head=prev, signed=pub is not None,
                   verdict=f"✅ CHAIN INTACT: {n} entries verified ({signed})")


# Typing helper without importing the private key class at module import time.
Ed25519PrivateKeyLike = Any
