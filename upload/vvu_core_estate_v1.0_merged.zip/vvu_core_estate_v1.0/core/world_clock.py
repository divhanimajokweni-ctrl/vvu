"""
VVU World Clock Engine (core/world_clock.py)
Provides the ONE synchronized, monotonic world clock for all entities across all sectors.
Enforces: UNIFIED_CORE_PUNCHLINE_CONSTITUTION.md & Single World Mandate (v0.8)
License: Apache 2.0
"""

import time
import datetime
from typing import Dict, Any

class WorldClockEngine:
    _instance = None

    def __new__(cls, tick_rate_hz: float = 100.0):
        if cls._instance is None:
            cls._instance = super(WorldClockEngine, cls).__new__(cls)
            cls._instance.tick_rate_hz = tick_rate_hz
            cls._instance.start_epoch_time = time.time()
            cls._instance.current_tick = 0
        return cls._instance

    def advance_tick(self) -> int:
        self.current_tick += 1
        return self.current_tick

    def get_world_timestamp_iso(self) -> str:
        # Calculates precise world timestamp based on tick count from start epoch
        elapsed_sec = self.current_tick / self.tick_rate_hz
        current_time = self.start_epoch_time + elapsed_sec
        dt = datetime.datetime.fromtimestamp(current_time, datetime.timezone.utc)
        return dt.isoformat()

    def get_clock_state(self) -> Dict[str, Any]:
        return {
            "world_tick": self.current_tick,
            "tick_rate_hz": self.tick_rate_hz,
            "timestamp_iso": self.get_world_timestamp_iso(),
            "clock_source": "VVU_SINGLE_WORLD_CLOCK_MONOTONIC"
        }
