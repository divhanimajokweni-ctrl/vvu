# Core Bayesian Fusion & Ledger Engine (`core/`)

## Sub-module Overview
This sub-module delivers the mathematical state estimation engine, confidence guard, and tamper-evident audit ledger for the VVU Sensor Fusion Architecture.

## Key Components
- `tier.py`: `SessionContext` and `SensorTier` guards enforcing single-source vs. fused confidence labeling and blocking kinetic/physiological parameter tier inflation.
- `worm.py`: WORM (Write-Once-Read-Many) hash-chained audit ledger enforcing non-repudiation, explicit percentage denominators, and Copyleft asset exclusion.
- `sam_adams.py`: `SamAdamsFusionEngine` for multi-channel Bayesian fusion, conflict detection (`CONFLICT_FLAG`), and `InnovationGatedKalmanFilter` for normalized innovation gating ($\ge 5\times$).
- `adapter_manifest.json`: 6-field adapter metadata registry enforcing measured physical routing path independence.

## Success Criteria
1. Single-channel inputs MUST output `confidence_label: "single_source_estimate"`.
2. Multi-channel inputs with $\ge 2$ independent physical paths MUST output `confidence_label: "fused_posterior"`.
3. Parameter claims outside tier capabilities MUST raise `TierInflationError`.
4. Float accuracy/error metrics missing `dataset_version` or `denominator` MUST raise `UndenominatedPercentageError`.
5. Channel divergence $> 2.5$ MUST emit `conflict_flag: True` and widen posterior variance.
