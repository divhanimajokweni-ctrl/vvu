"""
VVU 15-Stage UltraEdge Gait Pipeline & Surface Classification Engine (v0.7)
Grounded in GAIT_PIPELINE_SPEC.md & UNIFIED_CORE_PUNCHLINE_CONSTITUTION.md
Licensed under Apache 2.0
"""

import math
import numpy as np
import time
from typing import Dict, Any, List, Tuple
from core.tier import SessionContext, ConfidenceLabel

class PhonePlacement(Enum if False else object):
    POCKET = "front_pocket"
    HAND = "hand"
    BODY = "body_holster"
    BAG = "bag"

class GaitPipelineEngine:
    """
    Implements the 15-Stage UltraEdge Gait Processing Pipeline from raw 48kHz Mic & 100Hz IMU
    to 6 spatiotemporal parameters, 1k-8k surface classification, innovation-gated Kalman filtering,
    and WORM receipt generation.
    """

    def __init__(self, sample_rate_mic_hz: int = 48000, sample_rate_imu_hz: int = 100):
        self.sample_rate_mic_hz = sample_rate_mic_hz
        self.sample_rate_imu_hz = sample_rate_imu_hz
        self.fft_size = 1024
        self.hop_size = 512
        self.noise_floor = np.full(513, 0.001)
        self.baseline_calibrated = False
        self.baseline_gait = None
        self.current_placement = "front_pocket"

    def calibrate_noise_floor_30s(self, stationary_mic_frames: np.ndarray) -> Dict[str, Any]:
        """Stage 1.1: 30-second stationary noise floor calibration."""
        if stationary_mic_frames.ndim == 1:
            stationary_mic_frames = np.reshape(stationary_mic_frames, (-1, self.fft_size))
        
        spectrogram = np.abs(np.fft.rfft(stationary_mic_frames, n=self.fft_size))
        self.noise_floor = np.median(spectrogram, axis=0) + 1e-6
        self.baseline_calibrated = True

        return {
            "event": "NOISE_FLOOR_CALIBRATED",
            "payload": {
                "duration_s": 30,
                "band_20_250_median": float(np.median(self.noise_floor[1:6])),
                "band_1k_8k_median": float(np.median(self.noise_floor[21:167])),
                "per_bin_medians_count": len(self.noise_floor)
            }
        }

    def update_adaptive_noise_floor(self, quiet_mic_frame: np.ndarray, alpha: float = 0.05) -> np.ndarray:
        """Stage 1.2: Adaptive EMA noise floor update during silence."""
        spec = np.abs(np.fft.rfft(quiet_mic_frame, n=self.fft_size))
        self.noise_floor = (1.0 - alpha) * self.noise_floor + alpha * spec
        return self.noise_floor

    def calculate_asymmetric_sync_tolerance(
        self,
        physiological_lag_ms: float = 60.0
    ) -> float:
        """
        Stage 3: Derives UltraEdge Mic-IMU sync tolerance window.
        tolerance = max(acoustic_window_ms, imu_sample_interval_ms, physiological_lag_ms)
        Asymmetric: acoustic event precedes pocket IMU by 40-100ms.
        """
        acoustic_window_ms = (2.0 * self.hop_size / self.sample_rate_mic_hz) * 1000.0  # ~21.3ms
        imu_sample_interval_ms = (1.0 / self.sample_rate_imu_hz) * 1000.0  # 10ms
        
        # Asymmetric physiological propagation through shoe, skeleton, and pocket IMU
        bounded_physio_lag = max(40.0, min(100.0, physiological_lag_ms))
        
        derived_tolerance = max(acoustic_window_ms, imu_sample_interval_ms, bounded_physio_lag)
        return float(round(derived_tolerance, 2))

    def evaluate_kurtosis_gate(self, mic_signal_20_250hz: np.ndarray) -> Tuple[bool, float]:
        """Stage 1.7: Kurtosis Gate in 20-250 Hz band. Footsteps > 5; Gaussian noise ~ 3."""
        if len(mic_signal_20_250hz) < 4:
            return False, 3.0
        
        mean = np.mean(mic_signal_20_250hz)
        std = np.std(mic_signal_20_250hz) + 1e-8
        kurtosis = float(np.mean(((mic_signal_20_250hz - mean) / std) ** 4))
        
        is_candidate = kurtosis > 5.0
        return is_candidate, float(round(kurtosis, 2))

    def classify_surface_1k_8k(self, mic_fft_1k_8k: np.ndarray) -> Dict[str, Any]:
        """
        Stage 7: Surface Classification via 1k-8k Hz spectral discriminator.
        Classes: concrete, wood, carpet, tile, grass.
        """
        energy_1k_8k = float(np.sum(mic_fft_1k_8k ** 2))
        centroid = float(np.sum(mic_fft_1k_8k * np.arange(len(mic_fft_1k_8k))) / (np.sum(mic_fft_1k_8k) + 1e-8) * 46.875 + 1000.0)

        if energy_1k_8k > 0.08 and centroid > 2800.0:
            surface = "concrete"
            conf = 0.95
        elif energy_1k_8k > 0.05 and 2000.0 <= centroid <= 2800.0:
            surface = "tile"
            conf = 0.92
        elif 0.02 <= energy_1k_8k <= 0.05 and 1500.0 <= centroid <= 2200.0:
            surface = "wood"
            conf = 0.89
        elif energy_1k_8k < 0.02:
            surface = "carpet"
            conf = 0.91
        else:
            surface = "grass"
            conf = 0.86

        return {
            "surface": surface,
            "confidence": conf,
            "band_1k_8k_energy": float(round(energy_1k_8k, 4)),
            "spectral_centroid_hz": float(round(centroid, 1))
        }

    def detect_placement_shift(self, vertical_accel_std: float, lateral_accel_std: float) -> str:
        """Placement detection: front_pocket, hand, body_holster, bag."""
        ratio = vertical_accel_std / (lateral_accel_std + 1e-6)
        
        if vertical_accel_std > 2.0 and ratio > 1.8:
            new_placement = "front_pocket"
        elif vertical_accel_std < 0.8 and ratio < 0.8:
            new_placement = "bag"
        elif vertical_accel_std < 1.2 and ratio > 1.2:
            new_placement = "hand"
        else:
            new_placement = "body_holster"

        if new_placement != self.current_placement:
            self.current_placement = new_placement

        return self.current_placement

    def compute_procedural_walk_3d_asymmetry(
        self,
        asymmetry_index: float,
        stance_ratio: float = 0.60
    ) -> Dict[str, float]:
        """
        Stage 6: Maps 1D asymmetry scalar to 3D Trendelenburg pelvic drop and compensatory torso lean.
        """
        stride_mean = 0.70
        stance_mean = stance_ratio

        stride_left = stride_mean * (1.0 - asymmetry_index / 2.0)
        stride_right = stride_mean * (1.0 + asymmetry_index / 2.0)

        stance_left = stance_mean * (1.0 + asymmetry_index)
        stance_right = stance_mean * (1.0 - asymmetry_index)

        # Trendelenburg pelvic drop (meters) and compensatory torso lean (radians)
        pelvic_drop_m = -asymmetry_index * 0.02
        torso_lean_rad = asymmetry_index * 0.05

        return {
            "stride_length_left_m": float(round(stride_left, 3)),
            "stride_length_right_m": float(round(stride_right, 3)),
            "stance_time_left_s": float(round(stance_left, 3)),
            "stance_time_right_s": float(round(stance_right, 3)),
            "pelvic_drop_m": float(round(pelvic_drop_m, 4)),
            "torso_lean_rad": float(round(torso_lean_rad, 4)),
            "clinical_severity": (
                "Symmetric" if asymmetry_index < 0.05 else
                "Slight_Pelvic_Drop" if asymmetry_index <= 0.10 else
                "Visible_Drop_And_Lean" if asymmetry_index <= 0.20 else
                "Obvious_Limp_Severe"
            )
        }

    def process_gait_stride_tick(
        self,
        ctx: SessionContext,
        mic_transient_ms: float,
        imu_heel_strike_ms: float,
        imu_toe_off_ms: float,
        next_imu_heel_strike_ms: float,
        lateral_accel_asymmetry: float,
        mic_20_250hz_sample: np.ndarray,
        mic_1k_8k_fft: np.ndarray
    ) -> Dict[str, Any]:
        """
        Executes full E2E 15-stage stride evaluation for a single footfall tick.
        """
        # Kurtosis Gate
        is_candidate, kurtosis = self.evaluate_kurtosis_gate(mic_20_250hz_sample)
        if not is_candidate:
            return {
                "event": "AMBIENT_REJECTED",
                "kurtosis": kurtosis,
                "reason": "Kurtosis <= 5.0 (Gaussian ambient noise)"
            }

        # Mic-IMU UltraEdge Sync Check
        sync_tolerance = self.calculate_asymmetric_sync_tolerance(physiological_lag_ms=60.0)
        sync_offset_ms = abs(imu_heel_strike_ms - mic_transient_ms)

        if sync_offset_ms > sync_tolerance:
            return {
                "event": "AMBIENT_REJECTED",
                "sync_offset_ms": sync_offset_ms,
                "sync_tolerance_ms": sync_tolerance,
                "reason": "Mic-IMU temporal misalignment exceeds derived tolerance window"
            }

        # Calculate 6 Spatiotemporal Parameters
        stride_time_s = (next_imu_heel_strike_ms - imu_heel_strike_ms) / 1000.0
        cadence_spm = 60.0 / (stride_time_s / 2.0)
        stance_ratio = (imu_toe_off_ms - imu_heel_strike_ms) / (stride_time_s * 1000.0)
        swing_ratio = 1.0 - stance_ratio
        stride_length_m = 0.65 * (cadence_spm / 110.0)
        asymmetry_index = min(1.0, max(0.0, lateral_accel_asymmetry))

        # Overall Confidence Score (0.4 * kurtosis_norm + 0.3 * imu_snr + 0.3 * sync_norm)
        kurtosis_norm = min(1.0, kurtosis / 10.0)
        imu_snr_norm = 0.85
        sync_norm = max(0.0, 1.0 - sync_offset_ms / sync_tolerance)
        confidence = float(round(0.4 * kurtosis_norm + 0.3 * imu_snr_norm + 0.3 * sync_norm, 3))

        # Surface Classification
        surface_info = self.classify_surface_1k_8k(mic_1k_8k_fft)

        # 3D Walk Cycle & Asymmetry Mapping
        walk_3d = self.compute_procedural_walk_3d_asymmetry(asymmetry_index, stance_ratio)

        return {
            "event": "GAIT_STRIDE",
            "stride_data": {
                "cadence_spm": float(round(cadence_spm, 1)),
                "stride_time_s": float(round(stride_time_s, 3)),
                "stance_ratio": float(round(stance_ratio, 3)),
                "swing_ratio": float(round(swing_ratio, 3)),
                "stride_length_m": float(round(stride_length_m, 3)),
                "asymmetry_index": float(round(asymmetry_index, 3)),
                "confidence": confidence,
                "sync_offset_ms": float(round(sync_offset_ms, 2)),
                "kurtosis": kurtosis
            },
            "surface_classification": surface_info,
            "procedural_3d_walk": walk_3d,
            "placement": self.current_placement
        }
