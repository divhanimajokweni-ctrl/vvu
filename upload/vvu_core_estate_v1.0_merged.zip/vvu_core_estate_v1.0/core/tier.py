"""
Sensor Tier & Confidence Classification Guard
Enforces strict parameter claimability and prevents tier inflation.
"""
from enum import Enum
from dataclasses import dataclass, field

class SensorTier(Enum):
    CONSUMER = "consumer"    # Phone mic + IMU only
    INSURER = "insurer"      # + Chest strap (HR/HRV)
    OEM = "oem"              # + Insole (pressure/GRF)
    CLINICAL = "clinical"    # + EMG (muscle activation)

class ConfidenceLabel(Enum):
    SINGLE_SOURCE = "single_source_estimate"
    FUSED = "fused_posterior"

ALL_KINETIC_PARAMS = {
    "ground_reaction_force", "load_asymmetry", "joint_load_estimate", "joint_torque_estimate"
}

ALL_PHYSIOLOGICAL_PARAMS = {
    "hr", "hrv_rss", "hrv_recovery_state", "cardiac_load_proxy", "fatigue_proxy",
    "muscle_activation", "emg_rms"
}

TIER_CLAIMS = {
    SensorTier.CONSUMER: {
        "kinematic": ["cadence", "stride_time", "stance_ratio", "swing_ratio", "stride_length", "asymmetry_index", "surface_class", "drift"],
        "kinetic": [],
        "physiological": [],
    },
    SensorTier.INSURER: {
        "kinematic": ["cadence", "stride_time", "stance_ratio", "swing_ratio", "stride_length", "asymmetry_index", "surface_class", "drift"],
        "kinetic": [],
        "physiological": ["hr", "hrv_rss", "hrv_recovery_state", "cardiac_load_proxy", "fatigue_proxy"],
    },
    SensorTier.OEM: {
        "kinematic": ["cadence", "stride_time", "stance_ratio", "swing_ratio", "stride_length", "asymmetry_index", "surface_class", "drift"],
        "kinetic": ["ground_reaction_force", "load_asymmetry", "joint_load_estimate"],
        "physiological": ["hr", "hrv_rss", "hrv_recovery_state", "cardiac_load_proxy", "fatigue_proxy"],
    },
    SensorTier.CLINICAL: {
        "kinematic": ["cadence", "stride_time", "stance_ratio", "swing_ratio", "stride_length", "asymmetry_index", "surface_class", "drift"],
        "kinetic": ["ground_reaction_force", "load_asymmetry", "joint_load_estimate", "joint_torque_estimate"],
        "physiological": ["hr", "hrv_rss", "hrv_recovery_state", "cardiac_load_proxy", "fatigue_proxy", "muscle_activation", "emg_rms"],
    },
}

@dataclass
class SessionContext:
    tier: SensorTier
    registered_adapters: list = field(default_factory=list)

    @property
    def independent_channel_count(self) -> int:
        paths = set()
        count = 0
        for a in self.registered_adapters:
            path = a.get("physical_path")
            if path and path not in paths:
                paths.add(path)
                count += 1
        return count

    def confidence_label(self) -> ConfidenceLabel:
        if self.independent_channel_count < 2:
            return ConfidenceLabel.SINGLE_SOURCE
        return ConfidenceLabel.FUSED

    def can_claim(self, param: str) -> bool:
        claims = TIER_CLAIMS[self.tier]
        for category, params in claims.items():
            if param in params:
                return True
        return False
