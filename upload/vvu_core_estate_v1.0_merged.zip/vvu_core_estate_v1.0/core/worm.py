"""
Write-Once-Read-Many (WORM) Hash-Chained Audit Ledger
Enforces provenance, licensing rules, percentage denomination, and anti-tier-inflation.
"""
import hashlib
import json
import datetime
from core.tier import SessionContext, ConfidenceLabel, ALL_KINETIC_PARAMS, ALL_PHYSIOLOGICAL_PARAMS

class TierInflationError(Exception):
    """Raised when a payload contains claims forbidden for the session tier."""

class UndenominatedPercentageError(Exception):
    """Raised when an accuracy or error float is missing dataset_version and denominator."""

class LicensePropagationError(Exception):
    """Raised when an asset with Copyleft / ShareAlike or NonCommercial license is referenced."""

class WORMLedger:
    def __init__(self):
        self.chain = []
        self.last_hash = "0" * 64
        self.seq = 0

    def compute_hash(self, entry_dict: dict) -> str:
        # RFC 8785 (JCS) canonical form, same as core/worm_spec.py and the offline verifier.
        from core.worm_spec import canonicalize
        return hashlib.sha256(canonicalize(entry_dict).encode("utf-8")).hexdigest()

    def append_event(self, ctx: SessionContext, event_type: str, payload: dict, mesh_licenses: dict = None) -> dict:
        mesh_licenses = mesh_licenses or {}

        # Rule 1: Prevent Tier Inflation
        for key in payload:
            if (key in ALL_KINETIC_PARAMS or key in ALL_PHYSIOLOGICAL_PARAMS) and not ctx.can_claim(key):
                raise TierInflationError(
                    f"Parameter '{key}' cannot be claimed under tier '{ctx.tier.value}'."
                )

        # Rule 2: Force Single-Source vs Fused Confidence Label
        label = ctx.confidence_label()
        payload["confidence_label"] = label.value

        # Rule 3: Block Copyleft Asset Propagation
        if "anatomy_mesh_id" in payload:
            mesh_id = payload["anatomy_mesh_id"]
            lic = mesh_licenses.get(mesh_id, "CC BY 4.0")
            if "SA" in lic or "NC" in lic:
                raise LicensePropagationError(
                    f"Mesh '{mesh_id}' carries copyleft/restricted license '{lic}'. Copyleft asset propagation blocked."
                )

        # Rule 4: Require Named Denominator for Accuracy/Error Percentages
        for key, val in payload.items():
            if isinstance(val, float) and 0.0 <= val <= 1.0 and ("error" in key or "accuracy" in key):
                if "dataset_version" not in payload or "denominator" not in payload:
                    raise UndenominatedPercentageError(
                        f"Metric '{key}'={val} is missing required 'dataset_version' and 'denominator' fields."
                    )

        self.seq += 1
        entry = {
            "seq": self.seq,
            "timestamp": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "event_type": event_type,
            "payload": payload,
            "tier": ctx.tier.value,
            "confidence_label": label.value,
            "sensors": [a.get("id") for a in ctx.registered_adapters],
            "prev_hash": self.last_hash
        }
        
        entry_hash = self.compute_hash(entry)
        entry["hash"] = entry_hash
        self.last_hash = entry_hash
        self.chain.append(entry)
        return entry
