"""
SamAdams Bayesian Fusion Engine & Innovation-Gated Kalman Filter
Provides fail-closed multi-sensor state estimation, conflict emission, and innovation validation.
"""
import math
import numpy as np
from core.tier import SessionContext, ConfidenceLabel

class UncalibratedAdapterError(Exception):
    """Raised when attempting fusion with uncalibrated or unregistered adapters."""

class SamAdamsFusionEngine:
    def __init__(self, divergence_threshold: float = 2.5, ECE_constant: float = 0.012):
        self.divergence_threshold = divergence_threshold
        self.ECE_constant = ECE_constant

    def fuse_observations(self, ctx: SessionContext, observations: dict) -> dict:
        """
        Fuses multi-channel scalar/vector observations.
        Emits CONFLICT_FLAG if channel divergence > divergence_threshold.
        """
        if ctx.independent_channel_count < 1:
            raise UncalibratedAdapterError("No registered observation channels available.")

        values = list(observations.values())
        if len(values) == 1:
            val = values[0]
            return {
                "mean": float(val),
                "variance": 0.05,
                "conflict_flag": False,
                "confidence_label": ConfidenceLabel.SINGLE_SOURCE.value,
                "ece": self.ECE_constant
            }

        # Multi-channel fusion & conflict evaluation
        mean_val = float(np.mean(values))
        std_val = float(np.std(values))

        conflict = False
        posterior_var = 0.02 / max(1, len(values))

        if std_val > self.divergence_threshold:
            conflict = True
            posterior_var = float(std_val ** 2)  # Covariance widens on conflict

        label = ctx.confidence_label().value

        return {
            "mean": mean_val,
            "variance": posterior_var,
            "conflict_flag": conflict,
            "confidence_label": label,
            "channel_divergence": std_val,
            "ece": self.ECE_constant
        }

class InnovationGatedKalmanFilter:
    def __init__(self, state_dim: int = 3):
        self.x = np.zeros(state_dim)
        self.P = np.eye(state_dim) * 0.1
        self.consecutive_prediction_frames = 0

    def update(self, z: np.ndarray, H: np.ndarray, R: np.ndarray) -> dict:
        """
        Calculates measurement innovation and normalized innovation.
        Flags innovation jumps >= 5x.
        """
        self.consecutive_prediction_frames = 0
        y = z - H @ self.x
        S = H @ self.P @ H.T + R
        
        # Calculate normalized innovation
        norm_innov = float(np.linalg.norm(y) / math.sqrt(np.trace(S)))

        honest_decay = False
        if norm_innov >= 5.0:
            honest_decay = True
            self.P *= 5.0  # Decays confidence by inflating error covariance

        K = self.P @ H.T @ np.linalg.inv(S)
        self.x = self.x + K @ y
        self.P = (np.eye(len(self.x)) - K @ H) @ self.P

        return {
            "state": self.x.tolist(),
            "covariance_trace": float(np.trace(self.P)),
            "normalized_innovation": norm_innov,
            "honest_decay_flagged": honest_decay
        }

    def predict(self) -> dict:
        self.consecutive_prediction_frames += 1
        self.P += np.eye(len(self.x)) * 0.05  # Covariance grows during prediction
        
        prediction_dominant = self.consecutive_prediction_frames >= 5
        return {
            "state": self.x.tolist(),
            "covariance_trace": float(np.trace(self.P)),
            "prediction_dominant": prediction_dominant,
            "stale_prediction_count": self.consecutive_prediction_frames
        }
