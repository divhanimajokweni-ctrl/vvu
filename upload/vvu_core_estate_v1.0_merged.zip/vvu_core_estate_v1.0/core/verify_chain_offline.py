#!/usr/bin/env python3
"""
VVU Zero-Trust Offline WORM Chain Verifier (verify_chain_offline.py)
Stand-alone zero-dependency verification script for auditors and courtroom validation.

"We hand them the receipt and the script to verify it themselves.
No phone call. No API key. No trust. Just math."

Governed by: UNIFIED_CORE_PUNCHLINE_CONSTITUTION.md (Estate I - Duty to Proof)
License: Apache 2.0
"""

import json
import hashlib
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from typing import List, Dict, Any

class ChainTamperedError(Exception):
    """Raised when SHA-256 hash chain verification fails at any block."""

def compute_jcs_canonical_hash(entry: Dict[str, Any]) -> str:
    """SHA-256 over the RFC 8785 (JCS) canonical form of a WORM entry, excluding its hash field."""
    from core.worm_spec import canonicalize  # real RFC 8785, not json.dumps
    entry_copy = dict(entry)
    entry_copy.pop("hash", None)
    return hashlib.sha256(canonicalize(entry_copy).encode('utf-8')).hexdigest()

def verify_worm_chain(chain_entries: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Verifies an append-only WORM ledger chain offline:
    1. Recomputes canonical SHA-256 hash for each entry.
    2. Verifies prev_hash links between sequential entries.
    3. Rejects broken links or mutated payloads.
    """
    if not chain_entries:
        return {"status": "EMPTY_CHAIN", "entries_verified": 0}

    last_hash = "0" * 64

    for i, entry in enumerate(chain_entries):
        prev_hash = entry.get("prev_hash", "0" * 64)
        if i == 0:
            if prev_hash != "0" * 64:
                raise ChainTamperedError(f"Block {i} (seq={entry.get('seq')}) Genesis prev_hash mismatch: expected '0'*64, got '{prev_hash}'.")
        else:
            if prev_hash != last_hash:
                raise ChainTamperedError(f"Block {i} (seq={entry.get('seq')}) Chain Link Broken! prev_hash '{prev_hash}' != calculated previous hash '{last_hash}'.")

        expected_hash = compute_jcs_canonical_hash(entry)
        stored_hash = entry.get("hash")
        if stored_hash is None:
            # Fail closed: an entry with its hash stripped must not pass.
            raise ChainTamperedError(f"Block {i} (seq={entry.get('seq')}) MISSING_FIELD: 'hash' is absent.")

        if stored_hash != expected_hash:
            raise ChainTamperedError(f"Block {i} (seq={entry.get('seq')}) Payload Tampered! Stored hash '{stored_hash}' != recalculated hash '{expected_hash}'.")

        last_hash = stored_hash or expected_hash

    return {
        "status": "CHAIN_INTACT",
        "verdict": f"✅ CHAIN INTACT: {len(chain_entries)} entries verified offline.",
        "entries_verified": len(chain_entries),
        "head_hash": last_hash
    }

if __name__ == "__main__":
    if len(sys.argv) > 1:
        path = sys.argv[1]
        if os.path.exists(path):
            with open(path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            entries = data.get("chain", data) if isinstance(data, dict) else data
            res = verify_worm_chain(entries)
            print(res["verdict"])
        else:
            print(f"Error: file '{path}' not found.")
            sys.exit(1)
    else:
        print("VVU Zero-Trust Offline Chain Verifier Ready. Usage: python3 verify_chain_offline.py <chain.json>")
