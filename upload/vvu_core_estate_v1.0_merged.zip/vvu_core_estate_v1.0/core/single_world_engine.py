"""
VVU Single World Engine (core/single_world_engine.py)
Implements the ONE Single World StateVector Bus, 4 3D Sectors, Fail-Closed 500ms Timeout,
and Master Digital Twin Data Table Generation.

Governed by: UNIFIED_CORE_PUNCHLINE_CONSTITUTION.md & Single World Mandate (v0.8)
License: Apache 2.0
"""

import os
import csv
import json
import math
import time
from typing import Dict, Any, List, Optional
from core.world_clock import WorldClockEngine
from core.tier import SessionContext, SensorTier
from core.worm import WORMLedger

class SingleWorldEngine:
    SECTORS = {
        "sector_1_urban": "Urban Transit & Free City Fleet",
        "sector_2_industrial": "Industrial Manufacturing Bay 3",
        "sector_3_biomechanical": "Biomechanical Athletic Arena",
        "sector_4_geospatial": "SkySense Earth Observation Grid"
    }

    def __init__(self, max_stale_ms: float = 500.0):
        self.clock = WorldClockEngine()
        self.ledger = WORMLedger()
        self.max_stale_ms = max_stale_ms
        self.entities: Dict[str, Dict[str, Any]] = {}
        self._initialize_entities()

    def _initialize_entities(self):
        # Register entities across 4 sectors with initial proven coordinates
        initial_setup = [
            # Sector 1: Urban
            {"id": "T01", "name": "Free City Delivery Truck", "sector": "sector_1_urban", "type": "vehicle", "asset": "free_city_truck_v2.glb", "x": 12.5, "z": -45.0, "source_mode": "$$SIM$$"},
            {"id": "V01", "name": "ISUZU D-Max Utility Vehicle", "sector": "sector_1_urban", "type": "vehicle", "asset": "isuzu_dmax_v1.glb", "x": 18.2, "z": -38.4, "source_mode": "$$SIM$$"},
            {"id": "V03", "name": "BMW M5 F90 Performance", "sector": "sector_1_urban", "type": "vehicle", "asset": "bmw_m5_f90.glb", "x": 5.0, "z": -50.0, "source_mode": "$$SIM$$"},
            {"id": "V04", "name": "Autonomous Robo Bike", "sector": "sector_1_urban", "type": "vehicle", "asset": "robo_bike_v1.glb", "x": 2.1, "z": -42.0, "source_mode": "$$SIM$$"},

            # Sector 2: Industrial
            {"id": "R01", "name": "Fanuc 6-DOF Welding Manipulator", "sector": "sector_2_industrial", "type": "robot", "asset": "robotic_arm_6dof.glb", "x": 102.0, "z": 15.0, "source_mode": "$$SIM$$"},
            {"id": "R02", "name": "Anodized High-Speed Gearbox", "sector": "sector_2_industrial", "type": "machinery", "asset": "gearbox_drivetrain.glb", "x": 108.5, "z": 12.0, "source_mode": "$$SIM$$"},
            {"id": "R03", "name": "Hydraulic Power Unit (HPU)", "sector": "sector_2_industrial", "type": "machinery", "asset": "hydraulic_hpu_core.glb", "x": 115.0, "z": 8.5, "source_mode": "$$SIM$$"},
            {"id": "V02", "name": "EV Chassis Battery Conveyor", "sector": "sector_2_industrial", "type": "machinery", "asset": "ev_chassis_conveyor.glb", "x": 98.0, "z": 22.0, "source_mode": "$$SIM$$"},

            # Sector 3: Biomechanical
            {"id": "H01", "name": "BodyParts3D Heavyweight Male", "sector": "sector_3_biomechanical", "type": "anatomical_twin", "asset": "bodyparts3d_male_hw.glb", "x": -85.0, "z": 110.0, "source_mode": "$$SIM$$"},
            {"id": "H02", "name": "BodyParts3D Middleweight Female", "sector": "sector_3_biomechanical", "type": "anatomical_twin", "asset": "bodyparts3d_female_mw.glb", "x": -78.0, "z": 105.0, "source_mode": "$$SIM$$"},
            {"id": "P01", "name": "PILOT Room Avatar", "sector": "sector_3_biomechanical", "type": "anatomical_twin", "asset": "pilot_avatar_v1.glb", "x": -90.0, "z": 115.0, "source_mode": "$$SIM$$"},

            # Sector 4: Geospatial
            {"id": "S01", "name": "SkySense Swin-H Geospatial Satellite", "sector": "sector_4_geospatial", "type": "satellite", "asset": "sentinel2_swin_h.tif", "x": 0.0, "z": 0.0, "source_mode": "$$SIM$$"}
        ]

        for item in initial_setup:
            self.entities[item["id"]] = {
                "id": item["id"],
                "name": item["name"],
                "sector": item["sector"],
                "type": item["type"],
                "asset": item["asset"],
                "x": item["x"],
                "z": item["z"],
                "last_proven_x": item["x"],
                "last_proven_z": item["z"],
                "last_updated_time": time.time(),
                "confidence": 0.98,
                "status": "NOMINAL",
                "source_mode": item["source_mode"]
            }

    def update_entity_telemetry(self, entity_id: str, new_x: float, new_z: float, confidence: float = 0.95):
        if entity_id in self.entities:
            ent = self.entities[entity_id]
            ent["x"] = new_x
            ent["z"] = new_z
            ent["last_proven_x"] = new_x
            ent["last_proven_z"] = new_z
            ent["last_updated_time"] = time.time()
            ent["confidence"] = confidence
            ent["status"] = "NOMINAL"

    def execute_world_tick(self, ctx: SessionContext) -> Dict[str, Any]:
        """Executes a single World Clock tick across all entities in all 4 sectors."""
        tick_id = self.clock.advance_tick()
        timestamp_iso = self.clock.get_world_timestamp_iso()
        now = time.time()

        sector_states = {sec: [] for sec in self.SECTORS}
        active_payloads = []

        for ent_id, ent in self.entities.items():
            stale_ms = (now - ent["last_updated_time"]) * 1000.0

            # Fail-Closed 500ms Rule (ONE Fail-Closed Rule)
            if stale_ms > self.max_stale_ms:
                ent["status"] = "RED_WIREFRAME_ABSENCE"
                ent["confidence"] = 0.0
                curr_x = None
                curr_z = None
            else:
                curr_x = ent["x"]
                curr_z = ent["z"]

            entity_state = {
                "entity_id": ent["id"],
                "name": ent["name"],
                "sector": ent["sector"],
                "type": ent["type"],
                "asset": ent["asset"],
                "x": curr_x,
                "z": curr_z,
                "last_proven_x": ent["last_proven_x"],
                "last_proven_z": ent["last_proven_z"],
                "confidence": ent["confidence"],
                "status": ent["status"],
                "source_mode": ent["source_mode"],
                "stale_ms": round(stale_ms, 1)
            }

            sector_states[ent["sector"]].append(entity_state)
            active_payloads.append(entity_state)

        # Append single world tick state to global WORM ledger
        worm_event = self.ledger.append_event(
            ctx=ctx,
            event_type="SINGLE_WORLD_STATE_TICK",
            payload={
                "world_tick": tick_id,
                "timestamp_iso": timestamp_iso,
                "entities_count": len(active_payloads),
                "dataset_version": "GAIT-BENCH-v1.1",
                "denominator": "n=12 active entities across 4 sectors",
                "source_mode": "$$SIM$$"
            }
        )

        return {
            "world_tick": tick_id,
            "timestamp_iso": timestamp_iso,
            "sectors": sector_states,
            "worm_receipt_hash": worm_event["hash"],
            "prev_hash": worm_event["prev_hash"]
        }

    def generate_digital_twin_data_table(self, output_dir: Optional[str] = None) -> Dict[str, str]:
        """Generates Master DIGITAL_TWIN_DATA_TABLE.csv and DIGITAL_TWIN_DATA_TABLE.json."""
        if output_dir is None:
            output_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))

        os.makedirs(output_dir, exist_ok=True)
        timestamp_iso = self.clock.get_world_timestamp_iso()
        tick_id = self.clock.current_tick

        rows = []
        for ent_id, ent in self.entities.items():
            rows.append({
                "Entity_ID": ent["id"],
                "Name": ent["name"],
                "Sector": ent["sector"],
                "Sector_Description": self.SECTORS[ent["sector"]],
                "Timestamp_ISO": timestamp_iso,
                "World_Clock_Tick": tick_id,
                "Source_Mode": ent["source_mode"],
                "Last_Proven_X": ent["last_proven_x"],
                "Last_Proven_Z": ent["last_proven_z"],
                "Current_X": ent["x"] if ent["status"] != "RED_WIREFRAME_ABSENCE" else "null",
                "Current_Z": ent["z"] if ent["status"] != "RED_WIREFRAME_ABSENCE" else "null",
                "Confidence": ent["confidence"],
                "Fail_Closed_Status": ent["status"],
                "Asset_Model": ent["asset"],
                "Rule_Evaluated": "RULE_SINGLE_WORLD_FAILCLOSED",
                "Validation_Result": "PASS" if ent["status"] == "NOMINAL" else "FAIL_ABSENCE"
            })

        csv_path = os.path.join(output_dir, "DIGITAL_TWIN_DATA_TABLE.csv")
        json_path = os.path.join(output_dir, "DIGITAL_TWIN_DATA_TABLE.json")

        headers = list(rows[0].keys())
        with open(csv_path, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=headers)
            writer.writeheader()
            writer.writerows(rows)

        with open(json_path, "w", encoding="utf-8") as f:
            json.dump({"digital_twin_master_table": rows, "generated_at": timestamp_iso}, f, indent=2)

        return {"csv_path": csv_path, "json_path": json_path}
