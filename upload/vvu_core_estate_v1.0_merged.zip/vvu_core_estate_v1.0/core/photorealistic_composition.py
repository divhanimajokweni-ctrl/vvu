"""
Photorealistic Twin Composition Engine (Layer 0-5 Stack)
Governed by PHOTOREALISTIC_TWIN_COMPOSITION.md (Canonical Spec v1.0.0)
Enforces 5-Layer Composition Stack, Render Loop Invariants, Per-Dimension Fidelity Vector,
Fail-Closed Chain Authorization, Anti-Tier-Inflation, Multi-Tenant Isolation, and Asset Integrity.

Author: VVU Sensor Fusion & World Engine Team
License: Apache 2.0
"""

import hashlib
import json
import time
from enum import Enum
from dataclasses import dataclass, field, asdict
from typing import Dict, List, Any, Optional
from core.tier import SessionContext, ConfidenceLabel

class FidelityTier(Enum):
    T0 = "T0"  # Phone / Consumer / Simplified
    T1 = "T1"  # Multi-view RGB / Mid-tier / CAD
    T2 = "T2"  # Full capture rig / Photogrammetry / Laser scan

class TierInflationError(Exception):
    """Raised when marketing attempts to claim 'photorealistic digital twin' on a non-T2 vector."""

class MultiTenantIsolationError(Exception):
    """Raised when a tenant attempts to load another tenant's environment geometry or binding."""

class AssetIntegrityError(Exception):
    """Raised when a 3D asset hash does not match the ledger-anchored hash."""

class UnauthorizedRenderError(Exception):
    """Raised when attempting to render an entity without current-tick ledger authorization."""

@dataclass
class FidelityVector:
    environment_geometry: FidelityTier = FidelityTier.T1
    environment_materials: FidelityTier = FidelityTier.T1
    lighting: FidelityTier = FidelityTier.T1
    entity_body: FidelityTier = FidelityTier.T1
    entity_face: FidelityTier = FidelityTier.T0
    animation: FidelityTier = FidelityTier.T1
    shadows: FidelityTier = FidelityTier.T1
    post_processing: FidelityTier = FidelityTier.T1

    def is_fully_t2_photorealistic(self) -> bool:
        """Returns True ONLY IF all 8 fidelity dimensions are T2."""
        return all(getattr(self, field.name) == FidelityTier.T2 for field in self.__dataclass_fields__.values())

    def to_dict(self) -> Dict[str, str]:
        return {k: v.value for k, v in asdict(self).items()}

    def summary_vector_string(self) -> str:
        return ", ".join(f"{k}:{v.value}" for k, v in asdict(self).items())

@dataclass
class RenderBinding:
    environment_id: str
    tenant_id: str
    geometry_version: str
    geometry_hash: str
    materials_version: str
    materials_hash: str
    lighting_version: str
    lighting_hash: str
    lighting_timestamp_epoch: float
    max_lighting_stale_sec: float = 86400.0  # 24 hours
    fidelity: FidelityVector = field(default_factory=FidelityVector)
    appearance_map: Dict[str, Dict[str, Dict[str, str]]] = field(default_factory=dict)
    # appearance_map[entity_type][tier_str] = {"asset_file": ..., "sha256": ...}

class PhotorealisticCompositionEngine:
    """
    Executes Layer 0-5 composition stack for photorealistic 3D visual twins.
    Layer 0: Source (SamAdams Fusion + StateVector)
    Layer 1: World Layer (Geometry, Materials, Lighting)
    Layer 2: Entity Layer (Appearance Assets + Animation)
    Layer 3: Binding Layer (StateVector -> Scene Graph)
    Layer 4: Fail-Closed Gate (Per-tick ledger auth)
    Layer 5: Receipt (Render report + Fidelity vector + State hash)
    """

    def __init__(self, max_stale_ms: float = 500.0):
        self.max_stale_ms = max_stale_ms
        self.registered_bindings: Dict[str, RenderBinding] = {}

    def register_binding(self, binding: RenderBinding):
        key = f"{binding.tenant_id}:{binding.environment_id}"
        self.registered_bindings[key] = binding

    def get_binding(self, tenant_id: str, environment_id: str) -> RenderBinding:
        key = f"{tenant_id}:{environment_id}"
        if key not in self.registered_bindings:
            raise MultiTenantIsolationError(
                f"Tenant '{tenant_id}' is isolated from environment '{environment_id}' or binding does not exist."
            )
        return self.registered_bindings[key]

    def verify_asset_integrity(self, asset_name: str, raw_bytes: bytes, expected_hash: str) -> bool:
        computed = "0x" + hashlib.sha256(raw_bytes).hexdigest()
        if computed != expected_hash:
            raise AssetIntegrityError(
                f"Asset '{asset_name}' hash mismatch! Computed: {computed}, Expected: {expected_hash}"
            )
        return True

    def evaluate_render_tick(
        self,
        tenant_id: str,
        environment_id: str,
        state_vector_entities: List[Dict[str, Any]],
        authorized_entity_ids: List[str],
        tick_id: int,
        stale_ms: float = 0.0,
        single_channel_loss: bool = False,
        partition_asymmetric: bool = False,
        requested_marketing_claim: str = ""
    ) -> Dict[str, Any]:
        """
        Per-tick render loop evaluating the 5-layer stack and fail-closed gate.
        Returns scene graph draw commands and ledger render report payload.
        """
        binding = self.get_binding(tenant_id, environment_id)

        # Anti-Tier Inflation Verification (render_no_tier_inflation)
        if "photorealistic digital twin" in requested_marketing_claim.lower():
            if not binding.fidelity.is_fully_t2_photorealistic():
                raise TierInflationError(
                    f"Refused marketing claim 'photorealistic digital twin'. "
                    f"Current vector is non-photorealistic: {binding.fidelity.summary_vector_string()}"
                )

        # Lighting Freshness Verification (render_lighting_capture_fresh)
        current_time = time.time()
        lighting_age_sec = current_time - binding.lighting_timestamp_epoch
        lighting_stale = lighting_age_sec > binding.max_lighting_stale_sec

        # Determine Global Environment Render Mode (Layers 1 & 4)
        if partition_asymmetric or stale_ms > self.max_stale_ms:
            global_render_mode = "RED_WIREFRAME_ABSENCE"
            global_status = "PARTITION_ASYMMETRY_ALERT"
        elif single_channel_loss:
            global_render_mode = "DEGRADED_TRANSLUCENT_YELLOW"
            global_status = "STALE_WARNING"
        else:
            global_render_mode = "RENDER_PBR_SOLID"
            global_status = "NOMINAL"

        rendered_entities = []
        absent_entities = []
        confidence_counts = {"high": 0, "low": 0, "absent": 0}

        draw_commands = []

        # Iterate Entities through Binding Layer (Layer 3) & Fail-Closed Gate (Layer 4)
        for entity in state_vector_entities:
            entity_id = entity["id"]
            entity_type = entity.get("type", "person")
            confidence = entity.get("confidence", 1.0)
            position = entity.get("position", [0, 0, 0])

            # Invariant 1: Ledger Authorization Gate (render_chain_bound)
            if entity_id not in authorized_entity_ids or global_render_mode == "RED_WIREFRAME_ABSENCE":
                absent_entities.append(entity_id)
                confidence_counts["absent"] += 1
                draw_commands.append({
                    "entity_id": entity_id,
                    "draw_mode": "RED_WIREFRAME_ABSENCE_MARKER",
                    "position": position,
                    "color_hex": "#FF0000",
                    "reason": "REVOKED_OR_UNAUTHORIZED_CHAIN_GATE"
                })
                continue

            # Invariant 2: Per-Dimension Appearance & Tier Mapping (Layer 2)
            tier_str = binding.fidelity.entity_body.value
            appearance_info = binding.appearance_map.get(entity_type, {}).get(tier_str, {
                "asset_file": f"{entity_type}_default.glb",
                "sha256": "0x0000000000000000000000000000000000000000000000000000000000000000"
            })

            # Invariant 3: Visual Band Mapping (render_confidence_visible)
            if single_channel_loss or confidence < 0.60:
                visual_band = "DEGRADED_YELLOW"
                color_hex = "#FFCC00"
                confidence_counts["low"] += 1
            else:
                visual_band = "PBR_SOLID_GREEN"
                color_hex = "#00FF00"
                confidence_counts["high"] += 1

            rendered_entities.append(entity_id)
            draw_commands.append({
                "entity_id": entity_id,
                "draw_mode": visual_band,
                "asset_file": appearance_info["asset_file"],
                "asset_hash": appearance_info["sha256"],
                "position": position,
                "cadence_walk_speed": entity.get("cadence", 1.0),
                "organ_breathing_rate": entity.get("hr", 60.0),
                "color_hex": color_hex
            })

        # Calculate Deterministic Scene Graph Hash (render_binding_deterministic & render_state_hash_verified)
        scene_graph_payload = {
            "environment_id": environment_id,
            "tick_id": tick_id,
            "geometry_hash": binding.geometry_hash,
            "materials_hash": binding.materials_hash,
            "lighting_hash": binding.lighting_hash,
            "draw_commands": draw_commands
        }
        from core.worm_spec import canonicalize  # RFC 8785 (JCS)
        serialized_scene = canonicalize(scene_graph_payload)
        render_state_hash = "0x" + hashlib.sha256(serialized_scene.encode("utf-8")).hexdigest()

        # Build Layer 5 Receipt Report
        render_report = {
            "report_title": f"RENDER REPORT — {environment_id}",
            "environment": environment_id,
            "tenant_id": tenant_id,
            "tick_id": tick_id,
            "geometry_hash": binding.geometry_hash,
            "materials_hash": binding.materials_hash,
            "lighting_hash": binding.lighting_hash,
            "lighting_stale_flag": lighting_stale,
            "fidelity": binding.fidelity.to_dict(),
            "fidelity_summary": binding.fidelity.summary_vector_string(),
            "is_photorealistic": binding.fidelity.is_fully_t2_photorealistic(),
            "entities_rendered": len(rendered_entities),
            "entities_absent": len(absent_entities),
            "confidence_bands": confidence_counts,
            "render_state_hash": render_state_hash,
            "chain_verdict": "VERIFIED" if global_status == "NOMINAL" else global_status
        }

        return {
            "tick_id": tick_id,
            "global_status": global_status,
            "global_render_mode": global_render_mode,
            "draw_commands": draw_commands,
            "render_state_hash": render_state_hash,
            "render_report": render_report
        }
