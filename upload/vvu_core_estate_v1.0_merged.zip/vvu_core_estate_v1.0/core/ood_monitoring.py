"""
Infineon AI Safety & ISO/PAS 8800 Operational Monitoring & OOD Detection Engine
Implements Mahalanobis, Diagonal, HBOS, KDE OOD algorithms and physical fail-closed sanity checks.

Governed by: agents.md, VVU_CONTROL_OPERATING_RULES.md (1 * 0 = 1)
License: Apache 2.0
"""

import math
import numpy as np
from typing import Dict, Any, List, Tuple

class OODThresholdExceededError(Exception):
    """Raised when Out-of-Distribution score exceeds tau threshold."""

class PhysicalSanityCheckFailed(Exception):
    """Raised when Kirchhoff's Law or Trigonometric Identity check fails."""

class OODMonitoringEngine:
    def __init__(self, tau_threshold: float = 2.5):
        self.tau_threshold = tau_threshold

    def compute_mahalanobis_distance(self, sample: np.ndarray, mean: np.ndarray, cov: np.ndarray) -> float:
        """
        Computes Mahalanobis Distance for Series-Shift anomaly detection.
        D_M(x) = sqrt((x - mu)^T * Sigma^(-1) * (x - mu))
        """
        diff = sample - mean
        try:
            inv_cov = np.linalg.pinv(cov)
            dist = math.sqrt(float(max(0.0, diff.T @ inv_cov @ diff)))
        except Exception:
            dist = float(np.linalg.norm(diff))
        return round(dist, 4)

    def compute_diagonal_distance(self, sample: np.ndarray, mean: np.ndarray, std_diag: np.ndarray) -> float:
        """Computes lightweight Diagonal Distance for Gain/Gaussian perturbations."""
        std_diag_safe = np.where(std_diag == 0, 1e-6, std_diag)
        norm_diff = (sample - mean) / std_diag_safe
        dist = float(np.linalg.norm(norm_diff))
        return round(dist, 4)

    def compute_hbos_score(self, sample: np.ndarray, hist_bins: List[np.ndarray], hist_edges: List[np.ndarray]) -> float:
        """Computes Histogram-Based Outlier Score (HBOS) for Bias anomalies."""
        score = 0.0
        for i, val in enumerate(sample):
            if i < len(hist_bins) and i < len(hist_edges):
                bins = hist_bins[i]
                edges = hist_edges[i]
                idx = np.digitize(val, edges) - 1
                idx = max(0, min(idx, len(bins) - 1))
                density = bins[idx] + 1e-6
                score += math.log(1.0 / density)
        return round(score, 4)

    def compute_kde_density_score(self, sample: np.ndarray, reference_samples: np.ndarray, bandwidth: float = 0.5) -> float:
        """Computes Kernel Density Estimation (KDE) log-density score for non-parametric distribution shifts."""
        n, d = reference_samples.shape
        diffs = reference_samples - sample
        sq_dists = np.sum(diffs ** 2, axis=1)
        kernel_vals = np.exp(-sq_dists / (2 * (bandwidth ** 2)))
        density = np.mean(kernel_vals) / ( (2 * math.pi) ** (d / 2.0) * (bandwidth ** d) + 1e-8 )
        neg_log_density = -math.log(max(1e-12, density))
        return round(neg_log_density, 4)

    def verify_kirchhoff_law(self, currents_or_flows: List[float], tolerance: float = 1e-3) -> Dict[str, Any]:
        """
        Physical Sanity Check #1: Kirchhoff's Law Check (sum of currents / flows = 0).
        """
        sum_val = float(np.sum(currents_or_flows))
        is_valid = abs(sum_val) <= tolerance
        if not is_valid:
            raise PhysicalSanityCheckFailed(
                f"Kirchhoff's Law Check Failed! Sum of currents/flows = {sum_val:.6f} exceeds tolerance {tolerance}."
            )
        return {"kirchhoff_valid": True, "residual_sum": round(sum_val, 6)}

    def verify_trigonometric_identity(self, sin_val: float, cos_val: float, tolerance: float = 1e-3) -> Dict[str, Any]:
        """
        Physical Sanity Check #2: Trigonometric Identity Check (sin^2(theta) + cos^2(theta) = 1.0).
        """
        identity_val = (sin_val ** 2) + (cos_val ** 2)
        diff = abs(identity_val - 1.0)
        is_valid = diff <= tolerance
        if not is_valid:
            raise PhysicalSanityCheckFailed(
                f"Trigonometric Identity Check Failed! sin^2 + cos^2 = {identity_val:.6f} != 1.0 (diff={diff:.6f})."
            )
        return {"trig_identity_valid": True, "calculated_identity": round(identity_val, 6), "diff": round(diff, 6)}

    def evaluate_ood_safety_gate(
        self,
        sample: np.ndarray,
        mean: np.ndarray,
        cov: np.ndarray,
        currents: List[float] = None,
        sin_cos_pair: Tuple[float, float] = None
    ) -> Dict[str, Any]:
        """
        Runs OOD metrics and physical sanity checks before approving AI prediction rendering.
        """
        # 1. Physical Sanity Checks
        kirchhoff_res = self.verify_kirchhoff_law(currents) if currents is not None else {"kirchhoff_valid": True}
        trig_res = self.verify_trigonometric_identity(sin_cos_pair[0], sin_cos_pair[1]) if sin_cos_pair is not None else {"trig_identity_valid": True}

        # 2. OOD Mahalanobis Metric
        ood_score = self.compute_mahalanobis_distance(sample, mean, cov)
        is_rejected = ood_score > self.tau_threshold

        status = "REJECTED_OOD_FAIL_CLOSED" if is_rejected else "APPROVED_OOD_SAFE"

        return {
            "status": status,
            "ood_score_mahalanobis": ood_score,
            "tau_threshold": self.tau_threshold,
            "ood_rejected": is_rejected,
            "kirchhoff_sanity": kirchhoff_res,
            "trig_sanity": trig_res
        }
