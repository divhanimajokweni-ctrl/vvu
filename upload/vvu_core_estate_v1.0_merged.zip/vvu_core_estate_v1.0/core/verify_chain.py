#!/usr/bin/env python3
"""
Auditor CLI: verify a spec-format VVU WORM chain offline.

    python3 core/verify_chain.py <chain.json> <identity.json>

Exit 0 and prints "✅ CHAIN INTACT" only if every entry verifies.
Exit 1 on any failure, printing the reason code and sequence number.
No network, no API key, no trust in the vendor.
"""

import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from worm_spec import verify_chain  # noqa: E402


def main(argv):
    if len(argv) != 3:
        print("usage: verify_chain.py <chain.json> <identity.json>")
        return 2
    chain_path, identity_path = argv[1], argv[2]
    try:
        with open(chain_path, "r", encoding="utf-8") as f:
            chain = json.load(f)
        with open(identity_path, "r", encoding="utf-8") as f:
            identity = json.load(f)
    except (OSError, json.JSONDecodeError) as exc:
        print(f"❌ FATAL: {exc}")
        return 1

    verdict = verify_chain(chain, identity)
    print(verdict["verdict"])
    if verdict["valid"]:
        print(f"   Head: {verdict['head']}")
        return 0
    return 1


if __name__ == "__main__":
    sys.exit(main(sys.argv))
