"""
Demographic Phenotype, Ethnicity, & Boxing Weight-Class Modeling Engine (v0.3)
Defines physical body morph matrices, Fitzpatrick PBR skin tone spectrums, sex baselines,
and athletic/boxing weight class scaling vectors for 3D Visual Twins.
Licensed under Apache 2.0
"""

from enum import Enum
from dataclasses import dataclass, field
from typing import Dict, Any, List

class SexBaseline(Enum):
    MALE = "male"
    FEMALE = "female"
    NEUTRAL = "neutral"

class FitzpatrickSkinTone(Enum):
    TYPE_I = "type_i_light_porcelain"       # #F5D6C6
    TYPE_II = "type_ii_fair_beige"          # #E8C39E
    TYPE_III = "type_iii_medium_tan"        # #C68B59
    TYPE_IV = "type_iv_mediterranean_brown" # #B07844
    TYPE_V = "type_v_dark_brown"            # #5C3818
    TYPE_VI = "type_vi_deep_espresso"       # #2B1704

class BoxingWeightClass(Enum):
    STRAWWEIGHT = "strawweight"          # <47.6 kg / 105 lbs
    FLYWEIGHT = "flyweight"              # 50.8 kg / 112 lbs
    BANTAMWEIGHT = "bantamweight"        # 53.5 kg / 118 lbs
    FEATHERWEIGHT = "featherweight"      # 57.2 kg / 126 lbs
    LIGHTWEIGHT = "lightweight"          # 61.2 kg / 135 lbs
    WELTERWEIGHT = "welterweight"        # 66.7 kg / 147 lbs
    MIDDLEWEIGHT = "middleweight"        # 72.6 kg / 160 lbs
    LIGHT_HEAVYWEIGHT = "light_heavyweight" # 79.4 kg / 175 lbs
    CRUISERWEIGHT = "cruiserweight"      # 90.7 kg / 200 lbs
    HEAVYWEIGHT = "heavyweight"          # >90.7 kg / 240+ lbs

class Somatotype(Enum):
    ECTOMORPH = "ectomorph"   # Lean, long bone structure, lower muscle mass percentage
    MESOMORPH = "mesomorph"   # Athletic, high muscle mass density, broad shoulders
    ENDOMORPH = "endomorph"   # Heavy frame, higher body mass index, dense organ/torso volume

# Color Hex Mappings for PBR Skin Shaders
SKIN_TONE_PBR_HEX = {
    FitzpatrickSkinTone.TYPE_I: "#F5D6C6",
    FitzpatrickSkinTone.TYPE_II: "#E8C39E",
    FitzpatrickSkinTone.TYPE_III: "#C68B59",
    FitzpatrickSkinTone.TYPE_IV: "#B07844",
    FitzpatrickSkinTone.TYPE_V: "#5C3818",
    FitzpatrickSkinTone.TYPE_VI: "#2B1704",
}

# Standard Reference Mass per Weight Class (kg)
WEIGHT_CLASS_MASS_KG = {
    BoxingWeightClass.STRAWWEIGHT: 47.6,
    BoxingWeightClass.FLYWEIGHT: 50.8,
    BoxingWeightClass.BANTAMWEIGHT: 53.5,
    BoxingWeightClass.FEATHERWEIGHT: 57.2,
    BoxingWeightClass.LIGHTWEIGHT: 61.2,
    BoxingWeightClass.WELTERWEIGHT: 66.7,
    BoxingWeightClass.MIDDLEWEIGHT: 72.6,
    BoxingWeightClass.LIGHT_HEAVYWEIGHT: 79.4,
    BoxingWeightClass.CRUISERWEIGHT: 90.7,
    BoxingWeightClass.HEAVYWEIGHT: 110.0,
}

@dataclass
class DemographicProfile:
    sex: SexBaseline = SexBaseline.MALE
    skin_tone: FitzpatrickSkinTone = FitzpatrickSkinTone.TYPE_III
    weight_class: BoxingWeightClass = BoxingWeightClass.MIDDLEWEIGHT
    somatotype: Somatotype = Somatotype.MESOMORPH
    custom_height_cm: float = 178.0

    @property
    def target_mass_kg(self) -> float:
        return WEIGHT_CLASS_MASS_KG[self.weight_class]

    def compute_mesh_scale_matrix(self) -> Dict[str, float]:
        """
        Calculates 3D mesh transformation scaling factors for bones, muscles, organs, and bust.
        Ensures biomechanically sound deformation without violating mesh integrity.
        """
        ref_mass = self.target_mass_kg
        mass_scale = (ref_mass / 72.6) ** (1.0 / 3.0)  # Cube-root isometric scaling factor

        height_scale = self.custom_height_cm / 178.0

        # Sex-specific dimorphism adjustments
        if self.sex == SexBaseline.FEMALE:
            pelvic_width_factor = 1.08 * mass_scale
            shoulder_width_factor = 0.92 * mass_scale
            muscle_density_factor = 0.88 * mass_scale
            organ_scale_factor = 0.94 * mass_scale
        else:
            pelvic_width_factor = 0.95 * mass_scale
            shoulder_width_factor = 1.05 * mass_scale
            muscle_density_factor = 1.10 * mass_scale
            organ_scale_factor = 1.02 * mass_scale

        # Somatotype adjustments
        if self.somatotype == Somatotype.ECTOMORPH:
            muscle_density_factor *= 0.85
            bone_thickness = 0.90 * height_scale
        elif self.somatotype == Somatotype.ENDOMORPH:
            organ_scale_factor *= 1.15
            muscle_density_factor *= 1.05
            bone_thickness = 1.10 * mass_scale
        else:  # MESOMORPH
            muscle_density_factor *= 1.20
            bone_thickness = 1.02 * mass_scale

        return {
            "scale_x": round(shoulder_width_factor, 4),
            "scale_y": round(height_scale, 4),
            "scale_z": round(pelvic_width_factor, 4),
            "muscle_mass_scale": round(muscle_density_factor, 4),
            "organ_volume_scale": round(organ_scale_factor, 4),
            "bone_girth_scale": round(bone_thickness, 4),
            "skin_pbr_hex": SKIN_TONE_PBR_HEX[self.skin_tone],
            "target_mass_kg": ref_mass
        }

    def generate_demographic_receipt_metadata(self) -> Dict[str, Any]:
        """Returns provenance-compliant audit metadata for WORM receipt inclusion."""
        scales = self.compute_mesh_scale_matrix()
        return {
            "demographic_profile": {
                "sex": self.sex.value,
                "fitzpatrick_skin_tone": self.skin_tone.value,
                "skin_pbr_color_hex": scales["skin_pbr_hex"],
                "boxing_weight_class": self.weight_class.value,
                "somatotype": self.somatotype.value,
                "height_cm": self.custom_height_cm,
                "target_mass_kg": self.target_mass_kg,
                "mesh_scale_matrix": scales
            }
        }
