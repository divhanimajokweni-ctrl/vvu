# Room Module: FREE CITY (Game) (09-free-city)

- **Sector**: `sector_1_urban`
- **Duty**: Unified house component in One House Architecture
- **Data Table**: `data_table.csv` and `data_table.json`
- **Axiom Compliance**: `1 * 0 = 1` (Fail-closed zero-trust)
