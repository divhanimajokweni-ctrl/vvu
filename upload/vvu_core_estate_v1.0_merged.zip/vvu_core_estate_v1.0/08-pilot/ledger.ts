// Proof Ledger Manager
export const ledger = { seq: 90, status: 'PROOF_VERIFIED' };