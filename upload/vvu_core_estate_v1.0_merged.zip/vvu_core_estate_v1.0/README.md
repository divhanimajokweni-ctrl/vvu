# VVU Sensor Fusion Architecture, Photorealistic Twin & Gait Pipeline (Core Temporal Build)

## Overview
This build package (`Core Temporal`) represents the complete E2E implementation of the **VVU Unified Core Punchline Constitution**, **VVU Control Operating Rules**, **ISO/PAS 8800 AI Safety Lifecycle**, **Photorealistic Twin 5-Layer Composition Stack**, **15-Stage UltraEdge Gait Pipeline**, and **Industrial Machinery Twin Engine**.

---

## What's New in Core Temporal
* **15-Stage UltraEdge Gait Processing Pipeline (`core/gait_pipeline.py`)**: Implements Stage 0 hardware clock sync through Stage 1 compound filter (AGC, band-pass 20-500Hz, band-pass 1k-8k, DeepFilterNet2 ONNX, spectral subtraction/gating, kurtosis gate >5.0), Stage 2 IMU double-peak detection, Stage 3 derived asymmetric Mic-IMU sync tolerance (40-100ms), Stage 4 six spatiotemporal parameters, Stage 5 4D Kalman filter with normalized innovation gating, Stage 6 3D procedural walk cycle with Trendelenburg pelvic drop and compensatory torso lean, Stage 7 1k-8k surface classification (concrete, wood, carpet, tile, grass), and Stage 8 WORM receipt logging.
* **Full Three-Estate Discipline & 3-Gate Router (`core/estate_discipline.py`)**: Strictly enforces Estate I (Doctrine), Estate II (Surface view-first & hash workspaces), and Estate III (Golden Rule dependency auditor & dual-licensing boundaries).
* **ISO/PAS 8800 OOD Detection & Sanity Checks (`core/ood_monitoring.py`)**: Implements Mahalanobis distance, HBOS, KDE, Kirchhoff's current/flow law checks, and trigonometric identity checks ($\sin^2\theta + \cos^2\theta = 1.0$).
* **Standalone Zero-Trust Offline WORM Verifier (`core/verify_chain_offline.py`)**: Standalone Python verifier executing RFC 8785 JCS canonicalization and SHA-256 / Ed25519 hash chain verification offline without API keys or cloud dependencies.

---

## Directory & Sub-Module Structure

```text
vvu_sensor_fusion_build_Core Temporal/
├── README.md                      ← Master integration guide & release notes (Core Temporal)
├── LICENSE                        ← Apache 2.0 / AGPL-3.0 / CC BY 4.0 legal text
├── NOTICE.md                       ← Full legal attribution manifest
├── core/                          ← Fusion Engine, Gait, OOD, Constitution & Mechanics
│   ├── README.md                  ← Sub-module overview & success criteria
│   ├── tier.py                    ← SensorTier & SessionContext guards
│   ├── worm.py                    ← Hash-chained WORM audit ledger
│   ├── sam_adams.py               ← SamAdams Bayesian fusion & Innovation Kalman filter
│   ├── gait_pipeline.py           ← 15-Stage UltraEdge Gait Pipeline & Surface Classifier
│   ├── ood_monitoring.py          ← Mahalanobis, HBOS, KDE & Kirchhoff/Trig sanity checks
│   ├── estate_discipline.py       ← Three-Estate Constitution & 3-Gate Router
│   ├── verify_chain_offline.py    ← Zero-trust offline WORM chain verifier script
│   ├── kinetic_athletics.py       ← High-G impact & athletic broadcast telemetry
│   ├── demographic_morphs.py      ← Sex, skin tones, weight classes & somatotypes
│   ├── industrial_kinetics.py     ← 6-DOF robotics, gearboxes & ISO 10816 vibration
│   ├── photorealistic_composition.py ← 5-Layer stack, 8D fidelity vector & fail-closed gate
│   └── adapter_manifest.json      arguments 6-field physical adapter manifest schema
├── visual_twin/                   ← 3D Visual Twin, Shaders & Render Engines
│   ├── README.md                  ← Sub-module overview & success criteria
│   ├── bodyparts3d_manifest.json  ← Anatomical mesh layers & CC BY 4.0 metadata
│   ├── bodyparts3d_loader.js      ← Three.js loader with degraded/wireframe states
│   ├── bodyparts3d_demographics.js← Dynamic demographic morphing & PBR skin shaders
│   ├── muscle_activation_shader.js← Custom Three.js GLSL EMG heatmap shaders
│   ├── ood_overlay_shader.js      ← Custom Three.js GLSL OOD warning shader
│   ├── industrial_manifest.json   ← Industrial machinery mesh layers & GLB configs
│   ├── industrial_loader.js       ← Real-time mechanical twin loader & partition fallbacks
│   ├── photorealistic_binding_engine.js ← 5-Layer stack Three.js renderer with asset integrity
│   └── render_binding.json        ← StateVector to 3D scene graph binding & fidelity vector
├── tee/                           ← AMD SEV-SNP TEE Hardware Security
│   ├── README.md                  ← Sub-module overview & success criteria
│   ├── tee_config.json            ← StackWarp mitigations & SNP Policy 0x30000
│   ├── launch_sev_snp.sh          ← QEMU SEV-SNP VM launch script
│   ├── verify_attestation.py      ← Attestation policy verification script
│   └── sysctl_tee.conf            ← Kernel security parameters
├── puter/                         ← Puter OS Internet Desktop Integration
│   ├── README.md                  ← Sub-module overview & success criteria
│   ├── puter_vvu_app.js           ← Puter.js client app (Apache 2.0)
│   └── docker-compose.override.yml← Production Puter self-hosting Compose override
├── tests/                         ← Automated Test Suite (45/45 Passing - 100%)
│   ├── README.md                  ← Sub-module overview & success criteria
│   ├── test_audit_reconciliation.py← 8/8 passing audit tests
│   ├── test_kinetic_simulations.py ← 4/4 passing kinetic athletics tests
│   ├── test_demographic_simulations.py ← 5/5 passing demographic morph tests
│   ├── test_industrial_simulations.py ← 5/5 passing industrial machine tests
│   ├── test_photorealistic_composition.py ← 10/10 passing composition tests
│   ├── test_core_constitution_integration.py ← 8/8 passing constitution & OOD tests
│   └── test_gait_pipeline.py      ← 5/5 passing UltraEdge gait pipeline tests
└── skills/                        ← Declarative Agentic Skills
    ├── README.md                  ← Sub-module overview & success criteria
    └── sensor_fusion_verifier.skills ← Machine-readable verification rules (11 execution rules)
```

---

## Quick Start & Testing

```bash
# Set PYTHONPATH and run all 45 unit tests across the test suite
PYTHONPATH=. python3 -m unittest discover -s tests

# Run offline zero-trust WORM verifier
python3 core/verify_chain_offline.py
```

---

## Licensing & Governance
* **Core Code & SDKs**: Licensed under Apache 2.0 / AGPL-3.0.
* **3D Anatomical Meshes**: BodyParts3D © The Database Center for Life Science licensed under **CC BY 4.0** (Copyleft-free, \$0 commercial cost).
