"""
AMD SEV-SNP Attestation Report & StackWarp Configuration Verification Script
"""
import sys
import json
import os

def verify_tee_configuration(config_path: str = None) -> bool:
    if config_path is None:
        base_dir = os.path.dirname(os.path.abspath(__file__))
        config_path = os.path.join(base_dir, "tee_config.json")

    if not os.path.exists(config_path):
        print(f"[TEE Verifier] ERROR: Config file '{config_path}' not found.")
        return False

    with open(config_path, "r") as f:
        config = json.load(f)

    mitigation = config.get("stackwarp_mitigation", {})
    policy = config.get("snp_policy", {})

    print("[TEE Verifier] Verifying AMD SEV-SNP Security Guarantees...")
    print(f"  - Platform: {config.get('tee_platform')}")
    print(f"  - CPU Family: {config.get('cpu_family')}")
    print(f"  - SNP Policy: {policy.get('policy_hex')}")
    print(f"  - SMT Allowed: {policy.get('smt_allowed')}")
    print(f"  - Debug Allowed: {policy.get('debug_allowed')}")
    print(f"  - Minimum Microcode: {mitigation.get('minimum_psp_microcode')}")

    # Assertion checks
    if policy.get("debug_allowed") is not False:
        print("[TEE Verifier] FAIL: Debug mode must be FALSE in production SEV-SNP policy.")
        return False

    if policy.get("policy_hex") != "0x30000":
        print("[TEE Verifier] FAIL: SNP Policy must be explicitly set to 0x30000.")
        return False

    print("[TEE Verifier] PASS: All TEE hardware security assertions satisfied.")
    return True

if __name__ == "__main__":
    success = verify_tee_configuration()
    sys.exit(0 if success else 1)
