# AMD SEV-SNP TEE Hardware Security Engine (`tee/`)

## Sub-module Overview
Establishes the hardware attestation and TEE security configuration for guest virtual machines executing the VVU state fusion engine under AMD SEV-SNP.

## StackWarp Mitigation Strategy
Rather than imposing an uncalibrated `nosmt` kernel parameter (~50% compute degradation), the architecture relies on dedicated per-thread L1/L2 caches on AMD Zen 3+ (EPYC Genoa/Turin) alongside PSP microcode revision assertions (`0x0A001538` or newer) and hypervisor patches.

## Key Files
- `tee_config.json`: Hardware security specification, policy flags (`0x30000`), microcode targets, and audit assertion bindings (`tee_stackwarp_config_audited`).
- `launch_sev_snp.sh`: QEMU SEV-SNP launch script configured with Policy `0x30000` (`debug_allowed: false`, `migration_allowed: false`).
- `verify_attestation.py`: Attestation policy and microcode verification script.
- `sysctl_tee.conf`: Host/Guest kernel security parameter hardening.

## Success Criteria
1. SNP Policy explicitly pinned to `0x30000` (`debug_allowed: false`).
2. Automated pass on `verify_attestation.py`.
3. Recording of PSP microcode revision within hardware attestation report payloads.
