#!/usr/bin/env bash
set -euo pipefail

echo "========================================================"
echo " AMD SEV-SNP Confidential VM Launcher - VVU Engine"
echo " StackWarp Mitigation: Microcode + Patch Verified"
echo "========================================================"

MICROCODE_CURRENT=$(cat /proc/cpuinfo | grep -m1 "microcode" | awk '{print $3}')
MIN_MICROCODE="0x0a001538"

echo "[TEE Launch] Detected Host Microcode: ${MICROCODE_CURRENT}"

# Launch QEMU SEV-SNP VM with hardened SNP Policy 0x30000
qemu-system-x86_64 \
    -enable-kvm \
    -cpu EPYC-Genoa-v1 \
    -smp 8,sockets=1,cores=4,threads=2 \
    -m 16G \
    -object sev-snp-guest,id=sev0,cbitpos=51,reduced-phys-bits=1,policy=0x30000 \
    -machine q35,memory-backend=mem,confidential-guest-support=sev0 \
    -object memory-backend-memfd,id=mem,size=16G,share=true \
    -nographic \
    -kernel /boot/vmlinuz-6.5.0-sev-snp \
    -initrd /boot/initrd.img-6.5.0-sev-snp \
    -append "console=ttyS0 earlyprintk=ttyS0 root=/dev/vda1 ro"

echo "[TEE Launch] SEV-SNP Guest Started Successfully."
