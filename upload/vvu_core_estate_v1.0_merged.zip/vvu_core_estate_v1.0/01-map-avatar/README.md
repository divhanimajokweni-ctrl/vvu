# Room Module: MAP + AVATAR (01-map-avatar)

- **Sector**: `sector_1_urban`
- **Duty**: Unified house component in One House Architecture
- **Data Table**: `data_table.csv` and `data_table.json`
- **Axiom Compliance**: `1 * 0 = 1` (Fail-closed zero-trust)
