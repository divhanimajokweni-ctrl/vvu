# Puter OS Desktop Integration (`puter/`)

## Sub-module Overview
Provides integration scripts and container overrides for deploying the VVU Sensor Fusion Engine & 3D Visual Twin inside the Puter OS open-source internet desktop environment.

## Licensing Considerations
- **Client SDK (`puter_vvu_app.js`)**: Imports `Puter.js`, which is explicitly licensed under **Apache 2.0**. Proprietary VVU client logic remains unencumbered by copyleft.
- **Self-Hosted Core Server**: The underlying Puter server platform is licensed under **AGPL-3.0**. Network-accessible platform modifications to Puter core must be released under AGPL-3.0.

## Key Files
- `puter_vvu_app.js`: Puter.js app wrapper managing Puter Auth, Key-Value database storage, and cloud file system logging for WORM entries.
- `docker-compose.override.yml`: Production Docker Compose override file for deploying Puter alongside local volumes and port bindings (`4100`).

## Success Criteria
1. Seamless client-side execution via Apache 2.0 Puter.js SDK.
2. Successful local container startup on port 4100 via Docker Compose override.
3. Isolated WORM ledger file persistence into Puter cloud storage.
