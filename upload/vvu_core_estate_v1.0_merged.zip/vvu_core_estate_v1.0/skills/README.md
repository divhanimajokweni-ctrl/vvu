# Declarative Agentic Skills (`skills/`)

## Sub-module Overview
Contains declarative `.skills` rules and automated verification specifications for agentic evaluation of the VVU Sensor Fusion Architecture.

## Key Files
- `sensor_fusion_verifier.skills`: Machine-readable skill definition defining execution rules, validation metrics, and licensing boundaries.

## Success Criteria
1. Automated agentic ingestion of skill manifest.
2. Compliance verification against the 6 core execution rules.
