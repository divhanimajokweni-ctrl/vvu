# Room Module: MAP 3D (02-map-3d)

- **Sector**: `sector_1_urban`
- **Duty**: Unified house component in One House Architecture
- **Data Table**: `data_table.csv` and `data_table.json`
- **Axiom Compliance**: `1 * 0 = 1` (Fail-closed zero-trust)
