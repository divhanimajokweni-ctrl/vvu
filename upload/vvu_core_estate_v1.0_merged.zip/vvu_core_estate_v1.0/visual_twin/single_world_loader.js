/**
 * VVU Single World 3D Visual Twin Loader (visual_twin/single_world_loader.js)
 * Implements the Unified 3D Scene holding 4 Sectors (Urban, Industrial, Biomechanical, Geospatial),
 * 1-4 Keyboard Spatial Navigation Hotkeys, Tap-To-Focus Inspector Bridge, and Fail-Closed Red Wireframe Markers.
 * 
 * Governed by: UNIFIED_CORE_PUNCHLINE_CONSTITUTION.md & Single World Mandate (v0.8)
 * License: Apache 2.0
 */

import * as THREE from 'three';

export class SingleWorldVisualTwinLoader {
  constructor(canvasContainerId) {
    this.container = document.getElementById(canvasContainerId);
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x060806); // Near-black ground

    this.camera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.1, 2000);
    this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false });
    this.renderer.setSize(window.innerWidth, window.innerHeight);

    if (this.container) {
      this.container.appendChild(this.renderer.domElement);
    }

    this.sectorCoordinates = {
      'sector_1_urban': { x: 10, y: 25, z: -40, target: { x: 10, y: 0, z: -40 } },
      'sector_2_industrial': { x: 105, y: 30, z: 15, target: { x: 105, y: 0, z: 15 } },
      'sector_3_biomechanical': { x: -82, y: 20, z: 110, target: { x: -82, y: 0, z: 110 } },
      'sector_4_geospatial': { x: 0, y: 150, z: 0, target: { x: 0, y: 0, z: 0 } }
    };

    this.entitiesMeshes = new Map();
    this.activeSector = 'sector_1_urban';

    this.initLightingAndGround();
    this.initKeyboardHotkeys();
  }

  initLightingAndGround() {
    // Ambient + Directional IBL Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.8);
    this.scene.add(ambientLight);

    const dirLight = new THREE.DirectionalLight(0xc8ff00, 1.2); // Lime accent light
    dirLight.position.set(50, 100, 50);
    this.scene.add(dirLight);

    // Procedural Ground Plane tagged $$SIM$$
    const groundGeo = new THREE.PlaneGeometry(1000, 1000);
    const groundMat = new THREE.MeshStandardMaterial({
      color: 0x0c100c,
      wireframe: false,
      roughness: 0.9,
      metalness: 0.1
    });
    const groundMesh = new THREE.Mesh(groundGeo, groundMat);
    groundMesh.rotation.x = -Math.PI / 2;
    this.scene.add(groundMesh);

    // Fly camera to default Sector 1
    this.flyCameraToSector('sector_1_urban');
  }

  initKeyboardHotkeys() {
    // Keys 1-4 for Spatial Sector Navigation
    window.addEventListener('keydown', (e) => {
      if (e.key === '1') this.flyCameraToSector('sector_1_urban');
      if (e.key === '2') this.flyCameraToSector('sector_2_industrial');
      if (e.key === '3') this.flyCameraToSector('sector_3_biomechanical');
      if (e.key === '4') this.flyCameraToSector('sector_4_geospatial');
    });
  }

  flyCameraToSector(sectorKey) {
    if (this.sectorCoordinates[sectorKey]) {
      const coords = this.sectorCoordinates[sectorKey];
      this.camera.position.set(coords.x, coords.y, coords.z + 30);
      this.camera.lookAt(coords.target.x, coords.target.y, coords.target.z);
      this.activeSector = sectorKey;
    }
  }

  updateWorldState(worldTickState) {
    // Ingests single world StateVector tick across all 4 sectors
    for (const [sectorKey, entitiesList] of Object.entries(worldTickState.sectors)) {
      for (const ent of entitiesList) {
        let mesh = this.entitiesMeshes.get(ent.entity_id);

        if (!mesh) {
          // Create 3D representation
          const geo = new THREE.BoxGeometry(2, 2, 2);
          const mat = new THREE.MeshStandardMaterial({ color: 0xc8ff00 });
          mesh = new THREE.Mesh(geo, mat);
          mesh.userData = { entity_id: ent.entity_id, sector: ent.sector };
          this.scene.add(mesh);
          this.entitiesMeshes.set(ent.entity_id, mesh);
        }

        if (ent.status === 'RED_WIREFRAME_ABSENCE') {
          // ONE Fail-Closed Rule: Render Red Wireframe at last proven location
          mesh.material.color.setHex(0xff0000);
          mesh.material.wireframe = true;
          mesh.position.set(ent.last_proven_x, 1, ent.last_proven_z);
        } else {
          // Nominal State
          mesh.material.color.setHex(0x00ff00);
          mesh.material.wireframe = false;
          mesh.position.set(ent.x, 1, ent.z);
        }
      }
    }
  }

  render() {
    this.renderer.render(this.scene, this.camera);
  }
}
