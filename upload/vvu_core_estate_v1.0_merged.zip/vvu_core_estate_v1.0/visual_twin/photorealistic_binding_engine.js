/**
 * Photorealistic Twin Binding Engine (photorealistic_binding_engine.js)
 * Implements 5-Layer Stack Three.js Scene Binding & Per-Tick Fail-Closed Chain Authorization.
 * Governed by PHOTOREALISTIC_TWIN_COMPOSITION.md (Canonical Spec v1.0.0)
 *
 * License: Apache 2.0 / CC BY 4.0
 */

class PhotorealisticBindingEngine {
    constructor(bindingSchemaPath = "visual_twin/render_binding.json") {
        this.bindingSchemaPath = bindingSchemaPath;
        this.binding = null;
        this.activeEntities = new Map();
        this.maxStaleMs = 500.0;
        this.lastTickTime = Date.now();
    }

    async init() {
        try {
            const response = await fetch(this.bindingSchemaPath);
            this.binding = await response.json();
            console.log(`[PhotorealisticEngine] Loaded binding for environment: ${this.binding.environment_id}`);
            console.log(`[PhotorealisticEngine] Fidelity Vector:`, this.binding.fidelity);
        } catch (err) {
            console.warn(`[PhotorealisticEngine] Loading local default binding for offline simulation.`);
            this.binding = this.getDefaultBinding();
        }
    }

    getDefaultBinding() {
        return {
            environment_id: "neave-wh3",
            tenant_id: "tenant_alpha",
            geometry_version: "wh3-scan-v7",
            geometry_hash: "0xe3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
            materials_version: "wh3-pbr-v3",
            materials_hash: "0xf4c9c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b856",
            lighting_version: "wh3-hdr-v2",
            lighting_hash: "0xa1b2c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b857",
            fidelity: {
                environment_geometry: "T2",
                environment_materials: "T2",
                lighting: "T2",
                entity_body: "T1",
                entity_face: "T0",
                animation: "T1",
                shadows: "T1",
                post_processing: "T1"
            },
            appearance_map: {
                person: { T0: { asset_file: "capsule.glb" }, T1: { asset_file: "body_lp.glb" }, T2: { asset_file: "body_smplx.glb" } },
                vehicle: { T0: { asset_file: "box.glb" }, T1: { asset_file: "free_city_truck.glb" }, T2: { asset_file: "truck_cad_hp.glb" } }
            }
        };
    }

    evaluateRenderTick(stateVector, authorizedEntityIds, staleMs = 0.0, singleChannelLoss = false) {
        if (!this.binding) this.binding = this.getDefaultBinding();

        const isPartitioned = staleMs > this.maxStaleMs;
        const renderCommands = [];

        stateVector.entities.forEach(entity => {
            const isAuthorized = authorizedEntityIds.includes(entity.id);

            // Fail-Closed Gate Check (Layer 4)
            if (!isAuthorized || isPartitioned) {
                renderCommands.push({
                    entity_id: entity.id,
                    mode: "RED_WIREFRAME_ABSENCE_MARKER",
                    color_hex: "#FF0000",
                    opacity: 1.0,
                    wireframe: true,
                    position: entity.position || [0, 0, 0]
                });
                return;
            }

            // Visual Band Mapping (render_confidence_visible)
            if (singleChannelLoss || entity.confidence < 0.60) {
                renderCommands.push({
                    entity_id: entity.id,
                    mode: "DEGRADED_YELLOW_TRANSLUCENT",
                    color_hex: "#FFCC00",
                    opacity: 0.45,
                    wireframe: false,
                    position: entity.position || [0, 0, 0],
                    asset_file: this.getAssetForEntity(entity.type, this.binding.fidelity.entity_body)
                });
            } else {
                renderCommands.push({
                    entity_id: entity.id,
                    mode: "PBR_SOLID_GREEN",
                    color_hex: "#00FF00",
                    opacity: 1.0,
                    wireframe: false,
                    position: entity.position || [0, 0, 0],
                    asset_file: this.getAssetForEntity(entity.type, this.binding.fidelity.entity_body)
                });
            }
        });

        return {
            tick_id: Date.now(),
            environment_id: this.binding.environment_id,
            is_partitioned: isPartitioned,
            fidelity_vector: this.binding.fidelity,
            render_commands: renderCommands
        };
    }

    getAssetForEntity(entityType, tier) {
        const typeMap = this.binding.appearance_map[entityType];
        if (typeMap && typeMap[tier]) {
            return typeMap[tier].asset_file;
        }
        return `${entityType}_${tier.toLowerCase()}.glb`;
    }
}

if (typeof module !== 'undefined' && module.exports) {
    module.exports = { PhotorealisticBindingEngine };
}
