/**
 * OOD Detection & Physical Sanity Shader (visual_twin/ood_overlay_shader.js)
 * Renders real-time visual overlays when OOD score exceeds tau or physical checks fail.
 * 
 * Governed by: PHOTOREALISTIC_TWIN_COMPOSITION.md & agents.md
 * License: Apache 2.0
 */

const OODOverlayShader = {
  uniforms: {
    uTime: { value: 0.0 },
    uOODScore: { value: 0.0 },
    uTauThreshold: { value: 2.5 },
    uOODRejected: { value: 0.0 }, // 0.0 = Safe, 1.0 = Rejected
    uKirchhoffFail: { value: 0.0 },
    uTrigFail: { value: 0.0 }
  },

  vertexShader: `
    varying vec2 vUv;
    varying vec3 vNormal;
    void main() {
      vUv = uv;
      vNormal = normalize(normalMatrix * normal);
      gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
    }
  `,

  fragmentShader: `
    uniform float uTime;
    uniform float uOODScore;
    uniform float uTauThreshold;
    uniform float uOODRejected;
    uniform float uKirchhoffFail;
    uniform float uTrigFail;

    varying vec2 vUv;
    varying vec3 vNormal;

    void main() {
      // Base PBR color
      vec3 color = vec3(0.2, 0.8, 0.2); // Green safe

      if (uOODRejected > 0.5 || uKirchhoffFail > 0.5 || uTrigFail > 0.5) {
        // Fail-closed Emergency Pulse
        float pulse = 0.5 + 0.5 * sin(uTime * 10.0);
        color = mix(vec3(1.0, 0.0, 0.0), vec3(1.0, 0.8, 0.0), pulse); // Red/Yellow Warning
      } else if (uOODScore > 1.5) {
        // High Mahalanobis Distance Warning
        color = vec3(1.0, 0.8, 0.0); // Translucent Yellow
      }

      gl_FragColor = vec4(color, 0.85);
    }
  `
};

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { OODOverlayShader };
}
