# 3D Visual Twin & BodyParts3D Integration (`visual_twin/`)

## Sub-module Overview
Manages the 3D Anatomical Visual Twin asset pipeline using unencumbered BodyParts3D (CC BY 4.0) meshes. Integrates Three.js rendering with fail-closed visual state composition.

## Licensing Assurance
- **Source Database**: BodyParts3D © Database Center for Life Science (DBCLS).
- **License**: Creative Commons Attribution 4.0 International (CC BY 4.0).
- **Copyleft / ShareAlike**: **None**.
- **NonCommercial Restrictions**: **None**.
- **Commercial Permissibility**: Fully approved for commercial integration.

## Key Assets
- `bodyparts3d_manifest.json`: JSON manifest detailing the 4 mesh layers (Skeleton, Muscular, Organs, Head/Neck Bust), LOD levels, and SHA-256 hashes.
- `bodyparts3d_loader.js`: Three.js rendering logic featuring per-tick render chain authorization, degraded state rendering (yellow translucent), and red wireframe absence markers on network partition/stale state.
- `render_binding.json`: Declarative mapping connecting SamAdams `StateVector` latent indexes to 3D scene graph bones.

## Success Criteria
1. Full inclusion of mandatory CC BY 4.0 attribution string: `"BodyParts3D, © The Database Center for Life Science licensed under CC Attribution 4.0 International"`.
2. Automatic fallback to `ABSENCE_RED_WIREFRAME` visual state when state vector timestamp staleness exceeds 500 ms.
3. Translucent `DEGRADED_YELLOW` visual state triggered on single-channel loss or divergence conflict emission.
