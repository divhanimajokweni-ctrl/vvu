/**
 * Three.js BodyParts3D 3D Visual Twin Renderer & Network Partition Manager (v0.2)
 * Integrated with MuscleActivationShader & Real-time Athletic Kinetic Telemetry
 * Licensed under CC BY 4.0 / Apache 2.0
 */

import * as THREE from 'three';
import { MuscleActivationShader } from './muscle_activation_shader.js';

export class BodyParts3DVisualTwin {
    constructor(canvasContainer, manifestUrl = './bodyparts3d_manifest.json') {
        this.container = canvasContainer;
        this.manifestUrl = manifestUrl;
        this.lastStateTickMs = Date.now();
        this.MAX_STALE_MS = 500; // Network Partition Timeout
        this.WARN_STALE_MS = 200; // Degraded Yellow Threshold

        this.scene = new THREE.Scene();
        this.materials = {};
        this.muscleShaderMaterial = null;

        this.initShaderMaterials();
    }

    initShaderMaterials() {
        this.muscleShaderMaterial = new THREE.ShaderMaterial({
            uniforms: THREE.UniformsUtils.clone(MuscleActivationShader.uniforms),
            vertexShader: MuscleActivationShader.vertexShader,
            fragmentShader: MuscleActivationShader.fragmentShader,
            transparent: true,
            wireframe: false
        });
    }

    updateKineticTelemetry(telemetryPayload) {
        if (!this.muscleShaderMaterial) return;

        const uniforms = this.muscleShaderMaterial.uniforms;
        const metrics = telemetryPayload.metrics || {};
        const organs = telemetryPayload.organ_shaders || {};

        uniforms.u_time.value = performance.now() / 1000.0;
        uniforms.u_emg_quads.value = metrics.quadriceps_emg_mvc || 0.1;
        uniforms.u_emg_glutes.value = metrics.gluteus_emg_mvc || 0.1;
        uniforms.u_fatigue_index.value = metrics.fatigue_proxy || 0.0;

        // Animate heart organ mesh scale based on real-time HR BPM
        const heartMesh = this.scene.getObjectByName('organ_heart');
        if (heartMesh && organs.heart_ventricle_scale) {
            const s = organs.heart_ventricle_scale;
            heartMesh.scale.set(s, s, s);
        }
    }

    updateRenderState(stateVector) {
        const now = Date.now();
        const staleMs = now - (stateVector.timestamp_ms || now);
        this.lastStateTickMs = now;

        const uniforms = this.muscleShaderMaterial.uniforms;

        // Fail-Closed Visual State Machine
        if (staleMs > this.MAX_STALE_MS || stateVector.partition_asymmetry) {
            // RED WIREFRAME ABSENCE MARKER
            uniforms.u_degraded_state.value = 2;
            this.muscleShaderMaterial.wireframe = true;
            return { mode: 'RED_WIREFRAME_ABSENCE_MARKER', stale_ms: staleMs };
        } else if (staleMs > this.WARN_STALE_MS || stateVector.conflict_flag) {
            // TRANSLUCENT YELLOW DEGRADED STATE
            uniforms.u_degraded_state.value = 1;
            this.muscleShaderMaterial.wireframe = false;
            return { mode: 'DEGRADED_YELLOW_TRANSLUCENT', stale_ms: staleMs };
        } else {
            // FULL PBR SOLID & EMG SHADER ACTIVE
            uniforms.u_degraded_state.value = 0;
            this.muscleShaderMaterial.wireframe = false;
            if (stateVector.telemetry) {
                this.updateKineticTelemetry(stateVector.telemetry);
            }
            return { mode: 'FULL_PBR_EMG_ACTIVE', stale_ms: staleMs };
        }
    }
}
