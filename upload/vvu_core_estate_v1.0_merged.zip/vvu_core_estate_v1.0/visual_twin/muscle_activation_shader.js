/**
 * Three.js GLSL Custom Shaders for Dynamic EMG Muscle Activation & Heatmapping
 * Visual Twin v0.2 Athletic & Kinetic Simulation Suite
 * Licensed under Apache 2.0 / CC BY 4.0 (BodyParts3D Mesh Compatible)
 */

export const MuscleActivationShader = {
    uniforms: {
        u_time: { value: 0.0 },
        u_emg_quads: { value: 0.1 },       // Quadriceps MVC (0.0 to 1.0)
        u_emg_hamstrings: { value: 0.1 },  // Hamstrings MVC
        u_emg_glutes: { value: 0.1 },      // Gluteus Maximus MVC
        u_emg_core: { value: 0.1 },        // Abdominals / Core MVC
        u_emg_calves: { value: 0.1 },      // Gastrocnemius MVC
        u_fatigue_index: { value: 0.0 },   // Lactic / Spectral Shift (0.0 to 1.0)
        u_degraded_state: { value: 0 },    // 0: Normal, 1: Yellow Translucent, 2: Red Wireframe
        u_opacity: { value: 0.85 }
    },

    vertexShader: `
        varying vec3 vPosition;
        varying vec3 vNormal;
        varying vec2 vUv;
        varying float vGroupWeight;

        uniform float u_time;
        uniform float u_emg_quads;
        uniform float u_emg_glutes;

        void main() {
            vUv = uv;
            vNormal = normalize(normalMatrix * normal);
            vPosition = position;

            // Micro-pulsation during explosive muscle contraction
            vec3 newPosition = position;
            float contractionFactor = sin(u_time * 15.0) * 0.003 * u_emg_quads;
            newPosition += normal * contractionFactor;

            vec4 mvPosition = modelViewMatrix * vec4(newPosition, 1.0);
            gl_Position = projectionMatrix * mvPosition;
        }
    `,

    fragmentShader: `
        uniform float u_time;
        uniform float u_emg_quads;
        uniform float u_emg_hamstrings;
        uniform float u_emg_glutes;
        uniform float u_emg_core;
        uniform float u_emg_calves;
        uniform float u_fatigue_index;
        uniform int u_degraded_state;
        uniform float u_opacity;

        varying vec3 vPosition;
        varying vec3 vNormal;
        varying vec2 vUv;

        // Multi-stop EMG Recruitment Color Gradient:
        // 0.0 - 0.2: Deep Translucent Blue (Relaxed)
        // 0.2 - 0.4: Cyan / Green (Light Activation)
        // 0.4 - 0.7: Yellow / Gold (Moderate Recruitment)
        // 0.7 - 0.9: Orange / Red (Heavy Load)
        // 0.9 - 1.0+: Incandescent Pulsing Red (Peak Explosive MVC)
        vec3 getEMGColor(float val, float fatigue) {
            vec3 colRelaxed = vec3(0.05, 0.2, 0.6);
            vec3 colLight = vec3(0.1, 0.8, 0.4);
            vec3 colMod = vec3(0.9, 0.8, 0.1);
            vec3 colHeavy = vec3(0.95, 0.35, 0.05);
            vec3 colPeak = vec3(1.0, 0.05, 0.1);

            vec3 color = colRelaxed;
            if (val < 0.25) {
                color = mix(colRelaxed, colLight, val / 0.25);
            } else if (val < 0.55) {
                color = mix(colLight, colMod, (val - 0.25) / 0.30);
            } else if (val < 0.85) {
                color = mix(colMod, colHeavy, (val - 0.55) / 0.30);
            } else {
                color = mix(colHeavy, colPeak, (val - 0.85) / 0.15);
                // Incandescent pulse at peak recruitment
                float pulse = sin(u_time * 25.0) * 0.15 + 0.15;
                color += vec3(pulse, pulse * 0.2, 0.0);
            }

            // Fatigue shift towards deeper purple/magenta
            color = mix(color, vec3(0.6, 0.1, 0.5), fatigue * 0.4);
            return color;
        }

        void main() {
            // Fail-closed degraded visual states override
            if (u_degraded_state == 1) {
                // Translucent Yellow (Channel Partition Warning)
                gl_FragColor = vec4(1.0, 0.8, 0.0, 0.45);
                return;
            } else if (u_degraded_state == 2) {
                // Red Wireframe Absence Marker
                gl_FragColor = vec4(1.0, 0.0, 0.0, 1.0);
                return;
            }

            // Height-based muscle group approximation for shader demo
            float y = vPosition.y;
            float activeEMG = u_emg_core;
            if (y < -0.3) {
                activeEMG = mix(u_emg_calves, u_emg_hamstrings, smoothstep(-0.8, -0.3, y));
            } else if (y < 0.1) {
                activeEMG = mix(u_emg_quads, u_emg_glutes, smoothstep(-0.3, 0.1, y));
            }

            vec3 baseColor = getEMGColor(activeEMG, u_fatigue_index);

            // Standard Fresnel Rim Lighting for 3D depth
            vec3 viewDir = vec3(0.0, 0.0, 1.0);
            float rim = 1.0 - max(0.0, dot(vNormal, viewDir));
            rim = pow(rim, 3.0);
            vec3 finalColor = baseColor + vec3(rim * 0.3);

            gl_FragColor = vec4(finalColor, u_opacity);
        }
    `
};
