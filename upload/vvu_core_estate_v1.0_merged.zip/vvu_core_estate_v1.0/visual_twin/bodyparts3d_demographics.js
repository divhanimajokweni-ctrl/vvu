/**
 * BodyParts3D Multi-Demographic & Weight Class Mesh Morphing Engine (v0.3)
 * Handles dynamic mesh scaling, bone matrix dimorphism, and Fitzpatrick PBR skin shaders.
 * Licensed under Apache 2.0
 */

class BodyParts3DDemographics {
    constructor() {
        this.fitzpatrickColors = {
            'type_i_light_porcelain': 0xF5D6C6,
            'type_ii_fair_beige': 0xE8C39E,
            'type_iii_medium_tan': 0xC68B59,
            'type_iv_mediterranean_brown': 0xB07844,
            'type_v_dark_brown': 0x5C3818,
            'type_vi_deep_espresso': 0x2B1704
        };

        this.weightClassMasses = {
            'strawweight': 47.6,
            'flyweight': 50.8,
            'bantamweight': 53.5,
            'featherweight': 57.2,
            'lightweight': 61.2,
            'welterweight': 66.7,
            'middleweight': 72.6,
            'light_heavyweight': 79.4,
            'cruiserweight': 90.7,
            'heavyweight': 110.0
        };
    }

    /**
     * Calculates 3D mesh transformation matrix parameters.
     */
    computeScaleMatrix(sex, skinToneKey, weightClassKey, somatotype = 'mesomorph', heightCm = 178) {
        const massKg = this.weightClassMasses[weightClassKey] || 72.6;
        const massScale = Math.pow(massKg / 72.6, 1 / 3);
        const heightScale = heightCm / 178.0;

        let scaleX = massScale;
        let scaleY = heightScale;
        let scaleZ = massScale;
        let muscleScale = massScale;

        if (sex === 'female') {
            scaleX *= 0.92; // Shoulder dimorphism
            scaleZ *= 1.08; // Pelvic dimorphism
            muscleScale *= 0.88;
        } else {
            scaleX *= 1.05;
            scaleZ *= 0.95;
            muscleScale *= 1.10;
        }

        if (somatotype === 'ectomorph') {
            muscleScale *= 0.85;
            scaleX *= 0.95;
        } else if (somatotype === 'endomorph') {
            muscleScale *= 1.05;
            scaleZ *= 1.12;
        } else { // mesomorph
            muscleScale *= 1.20;
        }

        const skinHex = this.fitzpatrickColors[skinToneKey] || 0xC68B59;

        return {
            scaleX: parseFloat(scaleX.toFixed(4)),
            scaleY: parseFloat(scaleY.toFixed(4)),
            scaleZ: parseFloat(scaleZ.toFixed(4)),
            muscleScale: parseFloat(muscleScale.toFixed(4)),
            skinHex: skinHex,
            massKg: massKg
        };
    }

    /**
     * Applies demographic scale factors and skin PBR colors to Three.js scene mesh objects.
     */
    applyDemographicProfile(sceneLayers, profile) {
        const params = this.computeScaleMatrix(
            profile.sex,
            profile.skinTone,
            profile.weightClass,
            profile.somatotype,
            profile.heightCm
        );

        if (sceneLayers.headBust && sceneLayers.headBust.material) {
            sceneLayers.headBust.material.color.setHex(params.skinHex);
            sceneLayers.headBust.scale.set(params.scaleX, params.scaleY, params.scaleZ);
        }

        if (sceneLayers.skeleton) {
            sceneLayers.skeleton.scale.set(params.scaleX, params.scaleY, params.scaleZ);
        }

        if (sceneLayers.muscularSystem) {
            sceneLayers.muscularSystem.scale.set(
                params.scaleX * (params.muscleScale / params.scaleX),
                params.scaleY,
                params.scaleZ * (params.muscleScale / params.scaleZ)
            );
        }

        if (sceneLayers.internalOrgans) {
            sceneLayers.internalOrgans.scale.set(params.scaleX * 0.95, params.scaleY * 0.95, params.scaleZ * 0.95);
        }

        return {
            status: "DEMOGRAPHIC_MORPH_APPLIED",
            paramsApplied: params
        };
    }
}

if (typeof module !== 'undefined' && module.exports) {
    module.exports = { BodyParts3DDemographics };
}
