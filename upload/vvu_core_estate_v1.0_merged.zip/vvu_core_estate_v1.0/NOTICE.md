# LEGAL NOTICES & ATTRIBUTION MANIFEST

## 1. 3D Anatomical Meshes: BodyParts3D
This project incorporates 3D anatomical models and mesh structures derived from **BodyParts3D**, created by the Database Center for Life Science (DBCLS).

- **Asset Identifier**: BodyParts3D 4.0
- **Copyright**: © The Database Center for Life Science (DBCLS)
- **License**: Creative Commons Attribution 4.0 International (CC BY 4.0)
- **Required Attribution**: `"BodyParts3D, © The Database Center for Life Science licensed under CC Attribution 4.0 International"`
- **Copyleft / ShareAlike Status**: **UNENCUMBERED** (No ShareAlike clause).
- **Commercial Usage**: **PERMITTED** for commercial and proprietary software integration.

## 2. Puter OS Desktop Platform
- **Puter.js SDK**: Licensed under Apache-2.0.
- **Puter Core Platform**: Licensed under AGPL-3.0.

## 3. Remote Sensing Foundation Models (RSFM)
- **SatMAE, Prithvi, CROMA, SkySense**: Pre-trained backbones and model weights are subject to their respective open-source licenses (Apache 2.0 / MIT / BSD).
