# Room Module: LAB (05-lab)

- **Sector**: `sector_2_industrial`
- **Duty**: Unified house component in One House Architecture
- **Data Table**: `data_table.csv` and `data_table.json`
- **Axiom Compliance**: `1 * 0 = 1` (Fail-closed zero-trust)
