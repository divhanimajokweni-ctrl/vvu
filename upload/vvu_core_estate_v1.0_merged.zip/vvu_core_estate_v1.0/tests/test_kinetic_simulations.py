"""
Automated Test Suite for Athletic & Kinetic Digital Simulation Suite (v0.2)
Licensed under Apache 2.0
"""

import unittest
from core.tier import SessionContext, SensorTier
from core.kinetic_athletics import KineticAthleticsEngine

class TestKineticAthletics(unittest.TestCase):

    def setUp(self):
        self.engine = KineticAthleticsEngine(sample_rate_hz=1000.0)
        self.oem_ctx = SessionContext(
            tier=SensorTier.OEM,
            registered_adapters=[
                {"id": "imu_foot", "physical_path": "bus_0"},
                {"id": "piezo_insole", "physical_path": "bus_1"}
            ]
        )
        self.consumer_ctx = SessionContext(
            tier=SensorTier.CONSUMER,
            registered_adapters=[
                {"id": "phone_imu", "physical_path": "phone_0"}
            ]
        )

    def test_impact_g_force_calculation(self):
        # 147.15 m/s^2 vertical accel = 15.0 G
        g_force = self.engine.compute_impact_g_force(147.15)
        self.assertAlmostEqual(g_force, 15.0, places=2)

    def test_acl_shear_force_safety_check(self):
        # High G impact at shallow knee flexion angle (15 deg)
        shear = self.engine.calculate_acl_shear_force(peak_g=10.0, knee_flexion_deg=15.0)
        self.assertGreater(shear, 7000.0)  # Heavy force load assertion

    def test_emg_recruitment_normalization(self):
        mvc = self.engine.compute_emg_recruitment(raw_emg_rms_uv=450.0, baseline_mvc_uv=500.0)
        self.assertEqual(mvc, 0.90)

    def test_oem_vs_consumer_broadcast_telemetry_claims(self):
        oem_payload = self.engine.generate_broadcast_telemetry_overlay(
            ctx=self.oem_ctx,
            impact_g=12.5,
            knee_flexion_deg=20.0,
            spin_rate_deg_s=720.0,
            emg_quads_uv=480.0,
            hr_bpm=175.0
        )
        self.assertIsInstance(oem_payload["metrics"]["acl_shear_force_n"], float)

        consumer_payload = self.engine.generate_broadcast_telemetry_overlay(
            ctx=self.consumer_ctx,
            impact_g=12.5,
            knee_flexion_deg=20.0,
            spin_rate_deg_s=720.0,
            emg_quads_uv=480.0,
            hr_bpm=175.0
        )
        self.assertEqual(
            consumer_payload["metrics"]["acl_shear_force_n"],
            "TIER_RESTRICTED (Requires OEM/Clinical)"
        )

if __name__ == "__main__":
    unittest.main()
