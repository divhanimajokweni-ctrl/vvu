"""
Automated Test Suite for Silicon Audit Reconciliation & Sensor Fusion Invariants
"""
import sys
import os
import unittest
import numpy as np

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from core.tier import SessionContext, SensorTier, ConfidenceLabel
from core.worm import WORMLedger, TierInflationError, UndenominatedPercentageError, LicensePropagationError
from core.sam_adams import SamAdamsFusionEngine, InnovationGatedKalmanFilter, UncalibratedAdapterError

class TestAuditReconciliation(unittest.TestCase):

    def setUp(self):
        self.ledger = WORMLedger()
        self.engine = SamAdamsFusionEngine(divergence_threshold=2.5, ECE_constant=0.012)
        
        self.phone_imu = {"id": "adapter_imu_phone_v1", "physical_path": "/dev/bus/usb/001/002"}
        self.phone_mic = {"id": "adapter_mic_phone_v1", "physical_path": "/dev/bus/usb/001/003"}
        self.insole_grf = {"id": "adapter_insole_pressure_v1", "physical_path": "/dev/ttyUSB0"}

    def test_tier_inflation_blocked(self):
        """Consumer tier cannot claim kinetic parameters like ground_reaction_force."""
        ctx = SessionContext(tier=SensorTier.CONSUMER, registered_adapters=[self.phone_imu])
        payload = {
            "cadence": 112.5,
            "ground_reaction_force": 850.0  # Forbidden for Consumer
        }
        with self.assertRaises(TierInflationError):
            self.ledger.append_event(ctx, "STATE_UPDATE", payload)

    def test_single_channel_label(self):
        """Single-channel input yields single_source_estimate label."""
        ctx = SessionContext(tier=SensorTier.CONSUMER, registered_adapters=[self.phone_imu])
        payload = {"cadence": 110.0}
        entry = self.ledger.append_event(ctx, "STATE_UPDATE", payload)
        self.assertEqual(entry["confidence_label"], ConfidenceLabel.SINGLE_SOURCE.value)

    def test_fused_label_on_multi_channel(self):
        """Two independent channels yield fused_posterior label."""
        ctx = SessionContext(tier=SensorTier.OEM, registered_adapters=[self.phone_imu, self.insole_grf])
        payload = {"cadence": 110.0, "ground_reaction_force": 820.0}
        entry = self.ledger.append_event(ctx, "STATE_UPDATE", payload)
        self.assertEqual(entry["confidence_label"], ConfidenceLabel.FUSED.value)

    def test_undenominated_percentage_blocked(self):
        """Error percentage without dataset_version and denominator is blocked."""
        ctx = SessionContext(tier=SensorTier.CONSUMER, registered_adapters=[self.phone_imu])
        payload = {
            "cadence": 110.0,
            "joint_error": 0.04  # 4% error missing denominator
        }
        with self.assertRaises(UndenominatedPercentageError):
            self.ledger.append_event(ctx, "METRIC_REPORT", payload)

    def test_valid_denominated_percentage(self):
        """Error percentage with dataset_version and denominator succeeds."""
        ctx = SessionContext(tier=SensorTier.CONSUMER, registered_adapters=[self.phone_imu])
        payload = {
            "cadence": 110.0,
            "joint_error": 0.04,
            "dataset_version": "GAIT-BENCH-v1.1",
            "denominator": "n=4231 strides"
        }
        entry = self.ledger.append_event(ctx, "METRIC_REPORT", payload)
        self.assertEqual(entry["seq"], 1)
        self.assertIn("hash", entry)

    def test_copyleft_asset_blocked(self):
        """Referencing a ShareAlike or NonCommercial asset raises LicensePropagationError."""
        ctx = SessionContext(tier=SensorTier.CONSUMER, registered_adapters=[self.phone_imu])
        mesh_licenses = {"mesh_z_anatomy_hand": "CC BY-SA 4.0"}
        payload = {
            "cadence": 110.0,
            "anatomy_mesh_id": "mesh_z_anatomy_hand"
        }
        with self.assertRaises(LicensePropagationError):
            self.ledger.append_event(ctx, "RENDER_TICK", payload, mesh_licenses=mesh_licenses)

    def test_bayesian_conflict_flag(self):
        """Divergent channels trigger CONFLICT_FLAG and widen posterior variance."""
        ctx = SessionContext(tier=SensorTier.OEM, registered_adapters=[self.phone_imu, self.insole_grf])
        observations = {"mic_stride": 1.0, "imu_stride": 7.0}  # std = 3.0 > 2.5
        res = self.engine.fuse_observations(ctx, observations)
        self.assertTrue(res["conflict_flag"])
        self.assertGreater(res["variance"], 1.0)

    def test_kalman_innovation_gating(self):
        """Normalized innovation >= 5x triggers honest covariance decay."""
        kf = InnovationGatedKalmanFilter(state_dim=3)
        z = np.array([10.0, 10.0, 10.0])  # Huge spike input
        H = np.eye(3)
        R = np.eye(3) * 0.01
        res = kf.update(z, H, R)
        self.assertTrue(res["honest_decay_flagged"])

if __name__ == "__main__":
    unittest.main()
