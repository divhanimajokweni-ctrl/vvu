"""
Behavioural tests for the WORM chain (core/worm_spec.py) and the shipped receipts.

These check content, not just file presence: RFC 8785 vectors, a build/verify
round trip, every tamper class from the spec, and that each shipped data-table
receipt is the real chain_hash of its row.
"""
import base64
import copy
import json
import os
import sys
import tempfile
import unittest

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, ROOT)

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey  # noqa: E402
from cryptography.hazmat.primitives import serialization  # noqa: E402
from core import worm_spec as ws  # noqa: E402


def _identity(key):
    spki = key.public_key().public_bytes(
        serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo)
    return {"publicKey": base64.b64encode(spki).decode("ascii")}


class TestJCS(unittest.TestCase):
    """RFC 8785 vectors (Appendix B number formatting and §3 object ordering/escaping)."""

    def test_key_order_by_utf16(self):
        self.assertEqual(ws.canonicalize({"b": 2, "a": 1}), '{"a":1,"b":2}')

    def test_no_whitespace(self):
        self.assertEqual(ws.canonicalize({"x": [1, 2]}), '{"x":[1,2]}')

    def test_control_escapes_lowercase(self):
        self.assertEqual(ws.canonicalize("\u000b"), '"\\u000b"')
        self.assertEqual(ws.canonicalize('"\\'), '"\\"\\\\"')

    def test_number_vectors(self):
        cases = {0.0: "0", 1.0: "1", 0.5: "0.5", 100.0: "100", 1e21: "1e+21",
                 1e-7: "1e-7", 2e-3: "0.002", -1.5: "-1.5", 333333333.33333329: "333333333.3333333"}
        for value, expected in cases.items():
            self.assertEqual(ws.canonicalize(value), expected, value)

    def test_rejects_nan_and_unsafe_ints(self):
        with self.assertRaises(ws.CanonicalizationError):
            ws.canonicalize(float("nan"))
        with self.assertRaises(ws.CanonicalizationError):
            ws.canonicalize(2**60)


class TestChainRoundTrip(unittest.TestCase):
    def setUp(self):
        self.key = Ed25519PrivateKey.generate()
        self.ident = _identity(self.key)
        self.payloads = [{"n": i, "label": f"row {i}", "v": i * 0.5} for i in range(6)]
        self.chain = ws.build_chain(self.payloads, self.key)

    def test_valid_chain_verifies(self):
        v = ws.verify_chain(self.chain, self.ident)
        self.assertTrue(v["valid"], v)
        self.assertEqual(v["count"], 6)

    def test_payload_tamper_is_source_hash_mismatch(self):
        c = copy.deepcopy(self.chain)
        c["entries"][2]["label"] = "forged"
        self.assertEqual(ws.verify_chain(c, self.ident)["reason"], "SOURCE_HASH_MISMATCH")

    def test_deleted_entry_is_seq_gap(self):
        c = copy.deepcopy(self.chain)
        del c["entries"][2]
        self.assertEqual(ws.verify_chain(c, self.ident)["reason"], "SEQ_GAP")

    def test_spliced_entry_breaks_link(self):
        c = copy.deepcopy(self.chain)
        other = ws.build_chain([{"n": 99}], self.key)["entries"][0]
        other["seq"] = 2
        c["entries"].insert(2, other)
        for i, e in enumerate(c["entries"]):
            e["seq"] = i
        self.assertFalse(ws.verify_chain(c, self.ident)["valid"])

    def test_chain_hash_forgery_is_link_broken(self):
        c = copy.deepcopy(self.chain)
        c["entries"][3]["chain_hash"] = "0" * 64
        self.assertEqual(ws.verify_chain(c, self.ident)["reason"], "CHAIN_LINK_BROKEN")

    def test_bad_signature_is_sig_invalid(self):
        c = copy.deepcopy(self.chain)
        raw = bytearray(base64.b64decode(c["entries"][1]["meta"]["signature"]))
        raw[0] ^= 0x01
        c["entries"][1]["meta"]["signature"] = base64.b64encode(bytes(raw)).decode()
        self.assertEqual(ws.verify_chain(c, self.ident)["reason"], "SIG_INVALID")

    def test_stripped_signature_is_sig_missing_when_key_given(self):
        c = copy.deepcopy(self.chain)
        c["entries"][1]["meta"] = {}
        self.assertEqual(ws.verify_chain(c, self.ident)["reason"], "SIG_MISSING")

    def test_wrong_identity_fails(self):
        other = _identity(Ed25519PrivateKey.generate())
        self.assertEqual(ws.verify_chain(self.chain, other)["reason"], "SIG_INVALID")

    def test_genesis_mismatch(self):
        c = copy.deepcopy(self.chain)
        c["genesis"] = "0" * 64
        self.assertEqual(ws.verify_chain(c, self.ident)["reason"], "GENESIS_MISMATCH")

    def test_missing_hash_field_fails(self):
        c = copy.deepcopy(self.chain)
        del c["entries"][4]["chain_hash"]
        self.assertEqual(ws.verify_chain(c, self.ident)["reason"], "MISSING_FIELD")

    def test_without_identity_says_signatures_not_checked(self):
        v = ws.verify_chain(self.chain, None)
        self.assertTrue(v["valid"])
        self.assertFalse(v["signed"])

    def test_malformed_input_does_not_raise(self):
        self.assertFalse(ws.verify_chain("not a chain", None)["valid"])
        self.assertFalse(ws.verify_chain({"genesis": ws.GENESIS}, None)["valid"])


class TestShippedReceipts(unittest.TestCase):
    """The receipts shipped in the package are real and match their data-table rows."""

    @classmethod
    def setUpClass(cls):
        with open(os.path.join(ROOT, "receipts", "chain.json"), encoding="utf-8") as f:
            cls.chain = json.load(f)
        with open(os.path.join(ROOT, "receipts", "identity.json"), encoding="utf-8") as f:
            cls.ident = json.load(f)

    def test_shipped_chain_verifies_with_signatures(self):
        v = ws.verify_chain(self.chain, self.ident)
        self.assertTrue(v["valid"], v)
        self.assertTrue(v["signed"])

    def test_every_table_row_receipt_is_its_chain_hash(self):
        import glob
        by_hash = {e["chain_hash"]: e for e in self.chain["entries"]}
        checked = 0
        for tj in glob.glob(os.path.join(ROOT, "**", "data_table.json"), recursive=True):
            rel = os.path.relpath(os.path.dirname(tj), ROOT).replace(os.sep, "/")
            with open(tj, encoding="utf-8") as f:
                for row in json.load(f):
                    receipt = row["WORM_Receipt_Hash"]
                    self.assertIn(receipt, by_hash, f"{rel}: receipt not in chain")
                    entry = by_hash[receipt]
                    self.assertEqual(entry["Table_Path"], rel)
                    expected = {k: v for k, v in row.items() if k != "WORM_Receipt_Hash"}
                    expected["Table_Path"] = rel
                    actual = {k: v for k, v in entry.items() if k not in ws._CHAIN_FIELDS}
                    self.assertEqual(actual, expected)
                    checked += 1
        self.assertEqual(checked, len(self.chain["entries"]))


class TestCLI(unittest.TestCase):
    def test_cli_exit_codes(self):
        import subprocess
        cli = os.path.join(ROOT, "core", "verify_chain.py")
        ident = os.path.join(ROOT, "receipts", "identity.json")
        chain = os.path.join(ROOT, "receipts", "chain.json")
        ok = subprocess.run([sys.executable, cli, chain, ident], capture_output=True, text=True)
        self.assertEqual(ok.returncode, 0, ok.stdout)
        self.assertIn("CHAIN INTACT", ok.stdout)
        with open(chain, encoding="utf-8") as f:
            c = json.load(f)
        c["entries"][0]["Validation_Result"] = "FORGED"
        with tempfile.NamedTemporaryFile("w", suffix=".json", delete=False, encoding="utf-8") as tmp:
            json.dump(c, tmp)
        bad = subprocess.run([sys.executable, cli, tmp.name, ident], capture_output=True, text=True)
        os.unlink(tmp.name)
        self.assertEqual(bad.returncode, 1)
        self.assertIn("SOURCE_HASH_MISMATCH", bad.stdout)


if __name__ == "__main__":
    unittest.main()
