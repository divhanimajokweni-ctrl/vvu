"""
End-to-End VVU Core Estate v1.0 Comprehensive Verification Test Suite (test_v10_core_estate.py)
Validates all 12 rooms, core fusion engines, persistent agents, kilo prompts, folder data tables ($$SIM$$),
skills manifest, and zero-trust offline WORM chain verification.

Governed by: UNIFIED_CORE_PUNCHLINE_CONSTITUTION.md & VVU_CONTROL_OPERATING_RULES.md
License: Apache 2.0
"""

import os
import json
import unittest
import sys
import time

# Add project root to sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from core.world_clock import WorldClockEngine
from core.single_world_engine import SingleWorldEngine
from core.estate_discipline import EstateDisciplineEngine
from core.ood_monitoring import OODMonitoringEngine
from core.gait_pipeline import GaitPipelineEngine
from core.tier import SessionContext, SensorTier
from core.worm import WORMLedger
from core.verify_chain_offline import verify_worm_chain
from agents.orchestrator_agent import EstateOrchestratorAgent
from agents.builder_agent import SpatialTwinBuilderAgent
from agents.admin_searm_agent import SEARMAdminAgent

class TestV10CoreEstate(unittest.TestCase):

    def setUp(self):
        self.base_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
        self.ctx = SessionContext(tier=SensorTier.OEM)

    def test_all_12_rooms_present(self):
        """Assertion: All 12 room directories exist in the One House Estate."""
        expected_rooms = [
            "00-shell", "01-map-avatar", "02-map-3d", "03-rig",
            "04-assembly", "05-lab", "06-admin", "07-viewer",
            "08-pilot", "09-free-city", "shared-glbs", "evidence"
        ]
        for room in expected_rooms:
            room_path = os.path.join(self.base_dir, room)
            self.assertTrue(os.path.isdir(room_path), f"Room directory '{room}' is missing.")

    def test_folder_data_tables_exist_with_sim_tags(self):
        """Assertion: Every directory has data_table.csv and data_table.json with $$SIM$$ tags."""
        expected_dirs = [
            "", "00-shell", "01-map-avatar", "02-map-3d", "03-rig",
            "04-assembly", "05-lab", "06-admin", "07-viewer",
            "08-pilot", "09-free-city", "shared-glbs", "evidence",
            "core", "visual_twin", "tee", "puter", "tests", "skills", "agents", "docs"
        ]
        for dir_rel in expected_dirs:
            dir_path = os.path.join(self.base_dir, dir_rel)
            csv_path = os.path.join(dir_path, "data_table.csv" if dir_rel != "" else "DIGITAL_TWIN_DATA_TABLE.csv")
            json_path = os.path.join(dir_path, "data_table.json" if dir_rel != "" else "DIGITAL_TWIN_DATA_TABLE.json")

            self.assertTrue(os.path.isfile(csv_path), f"Missing CSV table in '{dir_rel}'")
            self.assertTrue(os.path.isfile(json_path), f"Missing JSON table in '{dir_rel}'")

            with open(csv_path, "r", encoding="utf-8") as f:
                content = f.read()
                self.assertIn("$$SIM$$", content, f"$$SIM$$ tag missing in CSV for '{dir_rel}'")

    def test_persistent_agents_initialization(self):
        """Assertion: Persistent agents and Kilo prompts load and execute cleanly."""
        agents_dir = os.path.join(self.base_dir, "agents")
        prompts_file = os.path.join(agents_dir, "kilo_agent_prompts.json")

        self.assertTrue(os.path.isfile(prompts_file), "kilo_agent_prompts.json missing")
        with open(prompts_file, "r", encoding="utf-8") as f:
            prompts = json.load(f)
            self.assertIn("orchestrator", prompts["agents"])
            self.assertIn("builder", prompts["agents"])
            self.assertIn("admin_searm", prompts["agents"])

        orchestrator = EstateOrchestratorAgent()
        res = orchestrator.monitor_room_telemetry("08-pilot", last_update_sec=time.time())
        self.assertEqual(res["status"], "NOMINAL_AUTHORIZED")

        builder = SpatialTwinBuilderAgent()
        build_res = builder.build_room_scene_graph("09-free-city", is_authorized=True)
        self.assertEqual(build_res["render_action"], "RENDER_PBR_SOLID")

    def test_zero_trust_offline_verification(self):
        """Assertion: Zero-trust offline chain verification validates un-tampered entries."""
        ledger = WORMLedger()
        ledger.append_event(
            ctx=self.ctx,
            event_type="V10_CORE_ESTATE_INITIALIZED",
            payload={"house": "VVU Core Estate v1.0", "status": "NOMINAL", "source_mode": "$$SIM$$"}
        )
        res = verify_worm_chain(ledger.chain)
        self.assertEqual(res["status"], "CHAIN_INTACT")
        self.assertEqual(res["entries_verified"], 1)

if __name__ == "__main__":
    unittest.main()
