# Automated Test Suite (`tests/`)

## Sub-module Overview
Contains automated unit and integration test scripts validating audit reconciliation invariants across tier enforcement, WORM ledger logging, Bayesian fusion conflict detection, and innovation gating.

## Executing Tests
```bash
python3 -m unittest tests/test_audit_reconciliation.py
```

## Success Criteria
- 100% pass rate across all 8 test assertions.
- `TierInflationError` raised when Consumer tier attempts kinetic parameter logging.
- `UndenominatedPercentageError` raised when accuracy/error floats lack dataset version and denominator.
- `LicensePropagationError` raised when CC BY-SA 4.0 or CC BY-NC-SA 4.0 assets are referenced.
- `conflict_flag: true` emitted when channel divergence exceeds threshold ($> 2.5$).
- `honest_decay_flagged: true` emitted when normalized Kalman innovation exceeds $5\times$.
