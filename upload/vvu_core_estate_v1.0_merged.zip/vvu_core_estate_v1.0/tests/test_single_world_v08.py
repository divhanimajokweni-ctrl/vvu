"""
VVU Single World v0.8 Test Suite (tests/test_single_world_v08.py)
Validates ONE World Clock, ONE StateVector Bus across 4 Sectors, ONE Fail-Closed 500ms Rule,
and Data Tables in Every Folder.

Governed by: UNIFIED_CORE_PUNCHLINE_CONSTITUTION.md & Single World Mandate (v0.8)
License: Apache 2.0
"""

import os
import time
import json
import csv
import unittest
from core.world_clock import WorldClockEngine
from core.single_world_engine import SingleWorldEngine
from core.tier import SessionContext, SensorTier
from core.verify_chain_offline import verify_worm_chain

class TestSingleWorldV08(unittest.TestCase):

    def setUp(self):
        self.clock = WorldClockEngine()
        self.engine = SingleWorldEngine(max_stale_ms=500.0)
        self.ctx = SessionContext(tier=SensorTier.OEM, registered_adapters=[
            {"id": "phone_imu_01", "physical_path": "/dev/i2c-0"},
            {"id": "acoustic_sole_01", "physical_path": "/dev/i2c-1"}
        ])

    def test_world_clock_singleton_sync(self):
        """Assertion: ONE World Clock generates monotonic synchronized timestamps."""
        c1 = WorldClockEngine()
        c2 = WorldClockEngine()
        self.assertIs(c1, c2)

        t1 = c1.advance_tick()
        t2 = c2.advance_tick()
        self.assertEqual(t2, t1 + 1)
        self.assertTrue("T" in c1.get_world_timestamp_iso())

    def test_single_world_bus_4_sectors(self):
        """Assertion: Single World StateVector bus manages entities across all 4 sectors."""
        res = self.engine.execute_world_tick(self.ctx)
        sectors = res["sectors"]

        self.assertIn("sector_1_urban", sectors)
        self.assertIn("sector_2_industrial", sectors)
        self.assertIn("sector_3_biomechanical", sectors)
        self.assertIn("sector_4_geospatial", sectors)

        # Check entity count across sectors
        total_entities = sum(len(ent_list) for ent_list in sectors.values())
        self.assertEqual(total_entities, 12)

    def test_fail_closed_500ms_absence(self):
        """Assertion: Un-updated entity feed >500ms triggers RED_WIREFRAME_ABSENCE with x:null, z:null."""
        # Force entity T01 last_updated_time to 1 second ago
        self.engine.entities["T01"]["last_updated_time"] = time.time() - 1.0

        res = self.engine.execute_world_tick(self.ctx)
        t01_state = next(e for e in res["sectors"]["sector_1_urban"] if e["entity_id"] == "T01")

        self.assertEqual(t01_state["status"], "RED_WIREFRAME_ABSENCE")
        self.assertIsNone(t01_state["x"])
        self.assertIsNone(t01_state["z"])
        self.assertEqual(t01_state["last_proven_x"], 12.5)
        self.assertEqual(t01_state["last_proven_z"], -45.0)

    def test_data_table_generated_in_every_folder(self):
        """Assertion: Master table and folder data tables exist and comply with $$SIM$$ tagging."""
        base_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
        self.engine.generate_digital_twin_data_table(output_dir=base_dir)

        folders = ["", "core", "visual_twin", "tee", "puter", "tests", "skills", "docs", "docs/evidence"]

        for folder in folders:
            folder_path = os.path.join(base_dir, folder)
            csv_path = os.path.join(folder_path, "data_table.csv" if folder != "" else "DIGITAL_TWIN_DATA_TABLE.csv")
            json_path = os.path.join(folder_path, "data_table.json" if folder != "" else "DIGITAL_TWIN_DATA_TABLE.json")

            self.assertTrue(os.path.exists(csv_path), f"CSV table missing in '{folder}'")
            self.assertTrue(os.path.exists(json_path), f"JSON table missing in '{folder}'")

            with open(csv_path, "r", encoding="utf-8") as f:
                content = f.read()
                self.assertIn("$$SIM$$", content, f"$$SIM$$ tag missing in CSV for '{folder}'")

    def test_zero_trust_offline_worm_verification(self):
        """Assertion: Zero-trust offline verifier validates single world WORM chain intact."""
        self.engine.execute_world_tick(self.ctx)
        chain = self.engine.ledger.chain
        res = verify_worm_chain(chain)

        self.assertEqual(res["status"], "CHAIN_INTACT")
        self.assertTrue(res["entries_verified"] >= 1)

if __name__ == "__main__":
    unittest.main()
