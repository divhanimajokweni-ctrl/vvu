"""
Automated Unit Test Suite for Photorealistic Twin Composition (v0.5 Build)
Validates all 15 success criteria from PHOTOREALISTIC_TWIN_COMPOSITION.md.

Author: VVU Sensor Fusion & World Engine Team
License: Apache 2.0
"""

import unittest
import time
import json
import hashlib
from core.photorealistic_composition import (
    PhotorealisticCompositionEngine,
    FidelityVector,
    FidelityTier,
    RenderBinding,
    TierInflationError,
    MultiTenantIsolationError,
    AssetIntegrityError,
    UnauthorizedRenderError
)

class TestPhotorealisticComposition(unittest.TestCase):

    def setUp(self):
        self.engine = PhotorealisticCompositionEngine(max_stale_ms=500.0)
        self.fidelity_t1_t0 = FidelityVector(
            environment_geometry=FidelityTier.T2,
            environment_materials=FidelityTier.T2,
            lighting=FidelityTier.T2,
            entity_body=FidelityTier.T1,
            entity_face=FidelityTier.T0,
            animation=FidelityTier.T1,
            shadows=FidelityTier.T1,
            post_processing=FidelityTier.T1
        )
        self.fidelity_full_t2 = FidelityVector(
            environment_geometry=FidelityTier.T2,
            environment_materials=FidelityTier.T2,
            lighting=FidelityTier.T2,
            entity_body=FidelityTier.T2,
            entity_face=FidelityTier.T2,
            animation=FidelityTier.T2,
            shadows=FidelityTier.T2,
            post_processing=FidelityTier.T2
        )
        self.binding_a = RenderBinding(
            environment_id="neave-wh3",
            tenant_id="tenant_alpha",
            geometry_version="wh3-scan-v7",
            geometry_hash="0xe3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
            materials_version="wh3-pbr-v3",
            materials_hash="0xf4c9c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b856",
            lighting_version="wh3-hdr-v2",
            lighting_hash="0xa1b2c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b857",
            lighting_timestamp_epoch=time.time(),
            max_lighting_stale_sec=3600.0,
            fidelity=self.fidelity_t1_t0,
            appearance_map={
                "person": {
                    "T1": {"asset_file": "body_lp.glb", "sha256": "0x2222222222222222222222222222222222222222222222222222222222222222"}
                }
            }
        )
        self.engine.register_binding(self.binding_a)

    def test_render_chain_bound(self):
        """Assertion: Every drawn entity's ID appears in the current-tick authorized set."""
        entities = [{"id": "E1", "type": "person", "confidence": 0.95, "position": [1, 2, 3]}]
        authorized = ["E1"]
        res = self.engine.evaluate_render_tick("tenant_alpha", "neave-wh3", entities, authorized, tick_id=101)
        cmd = res["draw_commands"][0]
        self.assertEqual(cmd["draw_mode"], "PBR_SOLID_GREEN")
        self.assertEqual(cmd["entity_id"], "E1")

    def test_render_fidelity_recorded(self):
        """Assertion: All 8 fidelity dimensions present in receipt report."""
        entities = [{"id": "E1", "type": "person", "confidence": 0.95}]
        res = self.engine.evaluate_render_tick("tenant_alpha", "neave-wh3", entities, ["E1"], tick_id=102)
        fidelity_dict = res["render_report"]["fidelity"]
        self.assertEqual(len(fidelity_dict), 8)
        self.assertIn("entity_face", fidelity_dict)
        self.assertEqual(fidelity_dict["entity_face"], "T0")

    def test_render_no_tier_inflation(self):
        """Assertion: Generator refuses marketing claim 'photorealistic digital twin' when vector is non-T2."""
        entities = [{"id": "E1", "type": "person", "confidence": 0.95}]
        with self.assertRaises(TierInflationError):
            self.engine.evaluate_render_tick(
                "tenant_alpha", "neave-wh3", entities, ["E1"], tick_id=103,
                requested_marketing_claim="Our Photorealistic Digital Twin Product"
            )

    def test_render_absence_failclosed(self):
        """Assertion: Un-authorized or revoked entity renders as RED_WIREFRAME_ABSENCE_MARKER."""
        entities = [{"id": "E1", "type": "person", "confidence": 0.95}, {"id": "E2", "type": "person", "confidence": 0.95}]
        authorized = ["E1"]  # E2 unauthorized
        res = self.engine.evaluate_render_tick("tenant_alpha", "neave-wh3", entities, authorized, tick_id=104)
        cmd_e2 = res["draw_commands"][1]
        self.assertEqual(cmd_e2["draw_mode"], "RED_WIREFRAME_ABSENCE_MARKER")
        self.assertEqual(cmd_e2["color_hex"], "#FF0000")

    def test_render_channel_loss_distinct(self):
        """Assertion: Single channel loss renders degraded translucent yellow, not green or red."""
        entities = [{"id": "E1", "type": "person", "confidence": 0.95}]
        res = self.engine.evaluate_render_tick("tenant_alpha", "neave-wh3", entities, ["E1"], tick_id=105, single_channel_loss=True)
        cmd = res["draw_commands"][0]
        self.assertEqual(cmd["draw_mode"], "DEGRADED_YELLOW")
        self.assertEqual(cmd["color_hex"], "#FFCC00")
        self.assertEqual(res["global_render_mode"], "DEGRADED_TRANSLUCENT_YELLOW")

    def test_render_partition_asymmetry(self):
        """Assertion: Client-server partition asymmetry forces red wireframe on all entities."""
        entities = [{"id": "E1", "type": "person", "confidence": 0.95}]
        res = self.engine.evaluate_render_tick("tenant_alpha", "neave-wh3", entities, ["E1"], tick_id=106, partition_asymmetric=True)
        self.assertEqual(res["global_render_mode"], "RED_WIREFRAME_ABSENCE")
        self.assertEqual(res["draw_commands"][0]["draw_mode"], "RED_WIREFRAME_ABSENCE_MARKER")

    def test_render_multi_tenant_isolated(self):
        """Assertion: Tenant B attempting to access Tenant A's binding raises MultiTenantIsolationError."""
        entities = [{"id": "E1", "type": "person", "confidence": 0.95}]
        with self.assertRaises(MultiTenantIsolationError):
            self.engine.evaluate_render_tick("tenant_beta", "neave-wh3", entities, ["E1"], tick_id=107)

    def test_render_binding_deterministic(self):
        """Assertion: Identical StateVector input produces byte-identical render_state_hash."""
        entities = [{"id": "E1", "type": "person", "confidence": 0.95, "position": [1.0, 2.0, 3.0]}]
        res1 = self.engine.evaluate_render_tick("tenant_alpha", "neave-wh3", entities, ["E1"], tick_id=108)
        res2 = self.engine.evaluate_render_tick("tenant_alpha", "neave-wh3", entities, ["E1"], tick_id=108)
        self.assertEqual(res1["render_state_hash"], res2["render_state_hash"])

    def test_render_asset_integrity(self):
        """Assertion: Tampered asset bytes trigger AssetIntegrityError."""
        raw_bytes = b"valid_asset_data_glb"
        expected = "0x" + hashlib.sha256(raw_bytes).hexdigest()
        self.assertTrue(self.engine.verify_asset_integrity("body_lp.glb", raw_bytes, expected))

        tampered_bytes = b"corrupted_asset_data"
        with self.assertRaises(AssetIntegrityError):
            self.engine.verify_asset_integrity("body_lp.glb", tampered_bytes, expected)

    def test_render_lighting_capture_fresh(self):
        """Assertion: Stale HDR lighting probe flags LIGHTING_STALE in report."""
        binding_stale = RenderBinding(
            environment_id="neave-wh3",
            tenant_id="tenant_alpha",
            geometry_version="wh3-scan-v7",
            geometry_hash="0xe3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
            materials_version="wh3-pbr-v3",
            materials_hash="0xf4c9c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b856",
            lighting_version="wh3-hdr-v2",
            lighting_hash="0xa1b2c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b857",
            lighting_timestamp_epoch=time.time() - 100000.0,  # > max 86400s
            max_lighting_stale_sec=86400.0,
            fidelity=self.fidelity_t1_t0
        )
        self.engine.register_binding(binding_stale)
        entities = [{"id": "E1", "type": "person", "confidence": 0.95}]
        res = self.engine.evaluate_render_tick("tenant_alpha", "neave-wh3", entities, ["E1"], tick_id=109)
        self.assertTrue(res["render_report"]["lighting_stale_flag"])

if __name__ == "__main__":
    unittest.main()
