"""
Unit Test Suite for Industrial & Mechanical Kinetics (v0.4)
"""

import unittest
from core.industrial_kinetics import IndustrialMachineEngine
from core.tier import SessionContext, SensorTier
from core.worm import WORMLedger

class TestIndustrialSimulations(unittest.TestCase):

    def setUp(self):
        self.engine = IndustrialMachineEngine(sample_rate_hz=2000.0)
        self.ledger = WORMLedger()

    def test_forward_kinematics_6dof(self):
        """Tests end-effector spatial coordinates calculation for a 6-DOF robotic manipulator."""
        joints = [0.0, 30.0, 45.0, 0.0, 0.0, 0.0]
        arm_lengths = [0.5, 0.4, 0.3]
        res = self.engine.compute_forward_kinematics_6dof(joints, arm_lengths)

        self.assertIn("end_effector_x_m", res)
        self.assertIn("end_effector_z_m", res)
        self.assertGreater(res["reach_radius_m"], 0.5)

    def test_gear_train_dynamics(self):
        """Tests output speed, torque, and power loss calculations across industrial gearboxes."""
        res = self.engine.compute_gear_train_dynamics(input_rpm=1500.0, gear_ratio=10.0, input_torque_nm=50.0, efficiency=0.95)

        self.assertEqual(res["output_rpm"], 150.0)
        self.assertEqual(res["output_torque_nm"], 475.0)
        self.assertGreater(res["heat_dissipation_kw"], 0.0)

    def test_bearing_vibration_iso10816(self):
        """Tests ISO 10816 vibration severity classification and bearing fault detection."""
        normal_vibe = self.engine.evaluate_bearing_vibration_anomaly(raw_vibration_rms_mms=0.8, peak_g=0.2)
        self.assertEqual(normal_vibe["iso_10816_severity"], "GOOD")
        self.assertFalse(normal_vibe["bearing_fault_flag"])

        critical_vibe = self.engine.evaluate_bearing_vibration_anomaly(raw_vibration_rms_mms=5.2, peak_g=3.5)
        self.assertEqual(critical_vibe["iso_10816_severity"], "CRITICAL_ALARM")
        self.assertTrue(critical_vibe["bearing_fault_flag"])

    def test_hydraulic_system_state(self):
        """Tests hydraulic power, cavitation risk, and oil temperature degradation monitoring."""
        hpu = self.engine.compute_hydraulic_system_state(pressure_bar=180.0, flow_rate_lpm=50.0, oil_temp_c=80.0)

        self.assertEqual(hpu["hydraulic_power_kw"], 15.0)
        self.assertTrue(hpu["thermal_degradation_alert"])
        self.assertFalse(hpu["cavitation_warning"])

    def test_industrial_telemetry_receipt_and_tier_claims(self):
        """Tests industrial telemetry generation and WORM ledger hash chaining."""
        ctx_consumer = SessionContext(tier=SensorTier.CONSUMER, registered_adapters=[{"id": "vib_0", "physical_path": "bus_0"}])
        ctx_oem = SessionContext(tier=SensorTier.OEM, registered_adapters=[{"id": "vib_0", "physical_path": "bus_0"}, {"id": "temp_0", "physical_path": "bus_1"}])

        rec_consumer = self.engine.generate_industrial_telemetry_receipt(
            ctx_consumer, [0.0, 0.0, 0.0, 0.0, 0.0, 0.0], 1500.0, 5.0, 1.2, 45.0, 150.0
        )
        self.assertEqual(rec_consumer["drivetrain"], "TIER_RESTRICTED (Requires OEM/Clinical)")

        rec_oem = self.engine.generate_industrial_telemetry_receipt(
            ctx_oem, [0.0, 0.0, 0.0, 0.0, 0.0, 0.0], 1500.0, 5.0, 1.2, 45.0, 150.0
        )
        self.assertIsInstance(rec_oem["drivetrain"], dict)

        entry = self.ledger.append_event(ctx_oem, "INDUSTRIAL_OPERATION_TELEMETRY", {
            "robotic_reach_m": 0.95,
            "vibration_rms": 1.2,
            "dataset_version": "ISO-10816-IND-v0.4",
            "denominator": "n=24000 cycles, industrial bench test"
        })
        self.assertIsNotNone(entry["hash"])

if __name__ == "__main__":
    unittest.main()
