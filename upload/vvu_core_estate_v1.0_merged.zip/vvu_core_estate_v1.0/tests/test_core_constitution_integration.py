"""
Automated Test Suite: Core Constitution & OOD Integration (v0.6)
Tests Infineon ISO/PAS 8800 OOD detection, physical sanity checks, 3-Gate Router,
and Zero-Trust offline WORM chain verification.

License: Apache 2.0
"""

import unittest
import numpy as np
import json
from core.ood_monitoring import (
    OODMonitoringEngine,
    OODThresholdExceededError,
    PhysicalSanityCheckFailed
)
from core.estate_discipline import (
    EstateDisciplineEngine,
    DisciplineViolationError,
    GoldenRuleDependencyViolation
)
from core.verify_chain_offline import (
    verify_worm_chain,
    compute_jcs_canonical_hash,
    ChainTamperedError
)
from core.worm import WORMLedger
from core.tier import SessionContext, SensorTier

class TestCoreConstitutionIntegration(unittest.TestCase):
    def setUp(self):
        self.ood_engine = OODMonitoringEngine(tau_threshold=2.5)
        self.discipline_engine = EstateDisciplineEngine()
        self.worm_ledger = WORMLedger()

    def test_mahalanobis_ood_distance(self):
        """Assertion: Mahalanobis Distance detects series-shift anomalies."""
        mean = np.array([0.0, 0.0, 0.0])
        cov = np.eye(3)
        nominal_sample = np.array([0.1, -0.2, 0.1])
        ood_sample = np.array([4.5, -5.2, 3.8])

        dist_nominal = self.ood_engine.compute_mahalanobis_distance(nominal_sample, mean, cov)
        dist_ood = self.ood_engine.compute_mahalanobis_distance(ood_sample, mean, cov)

        self.assertTrue(dist_nominal < 2.5)
        self.assertTrue(dist_ood > 2.5)

    def test_hbos_and_kde_scores(self):
        """Assertion: HBOS and KDE evaluate bias and distribution shifts."""
        sample = np.array([1.0, 2.0])
        ref_samples = np.array([[1.0, 2.0], [1.1, 2.1], [0.9, 1.9]])
        kde_score = self.ood_engine.compute_kde_density_score(sample, ref_samples)
        self.assertIsInstance(kde_score, float)

    def test_kirchhoff_law_sanity_check(self):
        """Assertion: Kirchhoff's Law check validates sum of currents = 0."""
        balanced_currents = [5.2, -3.1, -2.1]
        res = self.ood_engine.verify_kirchhoff_law(balanced_currents)
        self.assertTrue(res["kirchhoff_valid"])

        unbalanced_currents = [5.2, -3.1, 10.0]
        with self.assertRaises(PhysicalSanityCheckFailed):
            self.ood_engine.verify_kirchhoff_law(unbalanced_currents)

    def test_trigonometric_identity_check(self):
        """Assertion: Trigonometric identity check validates sin^2 + cos^2 = 1.0."""
        theta = 0.785398 # 45 degrees
        sin_v, cos_v = np.sin(theta), np.cos(theta)
        res = self.ood_engine.verify_trigonometric_identity(sin_v, cos_v)
        self.assertTrue(res["trig_identity_valid"])

        with self.assertRaises(PhysicalSanityCheckFailed):
            self.ood_engine.verify_trigonometric_identity(0.9, 0.9)

    def test_gate_1_secret_and_nda_firewall(self):
        """Assertion: Gate 1 aborts on secret file access or NDA client name exposure."""
        res = self.discipline_engine.evaluate_gate_1_discipline(["/path/to/sensor.py"], "Clean text")
        self.assertEqual(res["gate_1_status"], "PASSED")

        with self.assertRaises(DisciplineViolationError):
            self.discipline_engine.evaluate_gate_1_discipline(["/path/to/.env"], "Clean text")

        with self.assertRaises(DisciplineViolationError):
            self.discipline_engine.evaluate_gate_1_discipline(["/path/to/sensor.py"], "BMW Group Rosslyn")

    def test_gate_3_golden_rule_audit(self):
        """Assertion: Gate 3 blocks un-justified external dependencies."""
        res = self.discipline_engine.evaluate_gate_3_engineering(["numpy", "pandas", "three"])
        self.assertTrue(res["golden_rule_verified"])

        with self.assertRaises(GoldenRuleDependencyViolation):
            self.discipline_engine.evaluate_gate_3_engineering(["unjustified_bloat_package"])

    def test_offline_worm_chain_verifier_intact(self):
        """Assertion: Zero-trust offline verifier validates un-tampered WORM chain."""
        ctx = SessionContext(tier=SensorTier.CONSUMER, registered_adapters=[{"id": "imu_1", "physical_path": "/dev/i2c-1"}])
        self.worm_ledger.append_event(ctx, "TICK_1", {"cadence": 165.0, "dataset_version": "v1.1", "denominator": "n=100"})
        self.worm_ledger.append_event(ctx, "TICK_2", {"cadence": 166.0, "dataset_version": "v1.1", "denominator": "n=100"})

        chain_data = self.worm_ledger.chain
        res = verify_worm_chain(chain_data)
        self.assertEqual(res["status"], "CHAIN_INTACT")
        self.assertTrue("✅ CHAIN INTACT" in res["verdict"])

    def test_offline_worm_chain_verifier_tampered(self):
        """Assertion: Offline verifier detects payload tampering and raises ChainTamperedError."""
        ctx = SessionContext(tier=SensorTier.CONSUMER, registered_adapters=[{"id": "imu_1", "physical_path": "/dev/i2c-1"}])
        self.worm_ledger.append_event(ctx, "TICK_1", {"cadence": 165.0, "dataset_version": "v1.1", "denominator": "n=100"})
        self.worm_ledger.append_event(ctx, "TICK_2", {"cadence": 166.0, "dataset_version": "v1.1", "denominator": "n=100"})

        # Tamper with block 1 payload
        self.worm_ledger.chain[1]["payload"]["cadence"] = 999.0

        with self.assertRaises(ChainTamperedError):
            verify_worm_chain(self.worm_ledger.chain)

if __name__ == "__main__":
    unittest.main()
