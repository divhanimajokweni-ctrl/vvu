"""
Automated Unit Tests for 15-Stage UltraEdge Gait Pipeline & Surface Classification
Verifies GAIT_PIPELINE_SPEC.md assertions and success metrics.
Licensed under Apache 2.0
"""

import unittest
import numpy as np
from core.gait_pipeline import GaitPipelineEngine
from core.tier import SessionContext, SensorTier

class TestGaitPipeline(unittest.TestCase):

    def setUp(self):
        self.engine = GaitPipelineEngine(sample_rate_mic_hz=48000, sample_rate_imu_hz=100)
        self.ctx = SessionContext(
            tier=SensorTier.INSURER,
            registered_adapters=[
                {"id": "phone_mic_01", "physical_path": "/dev/audio0"},
                {"id": "phone_imu_01", "physical_path": "/dev/i2c0"}
            ]
        )

    def test_sync_tolerance_derived(self):
        """Assertion: Tolerance computed from FFT hop + IMU rate + physiological lag, not constant."""
        tol = self.engine.calculate_asymmetric_sync_tolerance(physiological_lag_ms=60.0)
        self.assertGreaterEqual(tol, 60.0)
        self.assertLessEqual(tol, 100.0)

    def test_kurtosis_gate_impulsive_vs_gaussian(self):
        """Assertion: Kurtosis gate accepts impulsive footstep (>5) and rejects Gaussian noise (<=5)."""
        # Impulsive footstep
        impulsive_signal = np.array([0.01, 0.01, 0.01, 12.0, 0.01, 0.01, 0.01, 0.01, 0.01])
        is_candidate, kurt = self.engine.evaluate_kurtosis_gate(impulsive_signal)
        self.assertTrue(is_candidate)
        self.assertGreater(kurt, 5.0)

        # Gaussian noise
        gaussian_signal = np.random.normal(0, 1, 1000)
        is_candidate_g, kurt_g = self.engine.evaluate_kurtosis_gate(gaussian_signal)
        self.assertFalse(is_candidate_g)
        self.assertLessEqual(kurt_g, 5.0)

    def test_surface_classification_1k_8k(self):
        """Assertion: Surface model classifies concrete, carpet, tile, wood, grass correctly."""
        # High energy + high centroid -> concrete
        concrete_fft = np.full(100, 0.05)
        res_concrete = self.engine.classify_surface_1k_8k(concrete_fft)
        self.assertEqual(res_concrete["surface"], "concrete")

        # Low energy -> carpet
        carpet_fft = np.full(100, 0.001)
        res_carpet = self.engine.classify_surface_1k_8k(carpet_fft)
        self.assertEqual(res_carpet["surface"], "carpet")

    def test_procedural_3d_walk_asymmetry(self):
        """Assertion: 1D asymmetry scalar drives Trendelenburg pelvic drop and compensatory torso lean."""
        res_asym = self.engine.compute_procedural_walk_3d_asymmetry(asymmetry_index=0.15)
        self.assertLess(res_asym["pelvic_drop_m"], 0)
        self.assertGreater(res_asym["torso_lean_rad"], 0)
        self.assertEqual(res_asym["clinical_severity"], "Visible_Drop_And_Lean")

    def test_full_gait_stride_tick_execution(self):
        """Assertion: Executes full E2E 15-stage stride tick evaluation."""
        impulsive_sample = np.array([0.01, 0.01, 0.01, 12.0, 0.01, 0.01, 0.01, 0.01, 0.01])
        mic_fft = np.full(100, 0.04)

        res = self.engine.process_gait_stride_tick(
            ctx=self.ctx,
            mic_transient_ms=1000.0,
            imu_heel_strike_ms=1015.0,
            imu_toe_off_ms=1615.0,
            next_imu_heel_strike_ms=2000.0,
            lateral_accel_asymmetry=0.08,
            mic_20_250hz_sample=impulsive_sample,
            mic_1k_8k_fft=mic_fft
        )

        self.assertEqual(res["event"], "GAIT_STRIDE")
        self.assertGreater(res["stride_data"]["confidence"], 0.6)
        self.assertIn("surface", res["surface_classification"])

if __name__ == '__main__':
    unittest.main()
