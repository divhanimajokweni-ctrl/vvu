"""
Demographic Phenotype, Ethnicity, & Weight-Class Simulation Test Suite (v0.3)
Validates multi-demographic body morph matrices, Fitzpatrick skin tone assignments,
boxing weight class ACL joint shear forces, and WORM audit receipts.
Licensed under Apache 2.0
"""

import unittest
from core.tier import SessionContext, SensorTier
from core.demographic_morphs import (
    DemographicProfile, SexBaseline, FitzpatrickSkinTone, BoxingWeightClass, Somatotype, WEIGHT_CLASS_MASS_KG
)
from core.kinetic_athletics import KineticAthleticsEngine
from core.worm import WORMLedger

class TestDemographicSimulations(unittest.TestCase):
    def setUp(self):
        self.ledger = WORMLedger()

    def test_all_boxing_weight_classes_mass_scaling(self):
        """Validates that mass scaling increases monotonically across boxing weight divisions."""
        previous_mass = 0.0
        for wc in BoxingWeightClass:
            profile = DemographicProfile(weight_class=wc)
            mass = profile.target_mass_kg
            self.assertGreaterThan(mass, previous_mass)
            previous_mass = mass

            scales = profile.compute_mesh_scale_matrix()
            self.assertIn("scale_x", scales)
            self.assertIn("skin_pbr_hex", scales)

    def test_sex_dimorphism_mesh_scale_matrices(self):
        """Validates skeletal and muscle scaling variations between male and female baselines."""
        male_profile = DemographicProfile(sex=SexBaseline.MALE, weight_class=BoxingWeightClass.MIDDLEWEIGHT)
        female_profile = DemographicProfile(sex=SexBaseline.FEMALE, weight_class=BoxingWeightClass.MIDDLEWEIGHT)

        m_scales = male_profile.compute_mesh_scale_matrix()
        f_scales = female_profile.compute_mesh_scale_matrix()

        # Females have wider relative pelvic scale_z and male profiles have wider shoulder scale_x
        self.assertGreaterThan(m_scales["scale_x"], f_scales["scale_x"])
        self.assertGreaterThan(f_scales["scale_z"], m_scales["scale_z"])

    def test_fitzpatrick_skin_tone_pbr_mappings(self):
        """Validates that all 6 Fitzpatrick skin tone spectrum types map to valid hex strings."""
        for tone in FitzpatrickSkinTone:
            profile = DemographicProfile(skin_tone=tone)
            scales = profile.compute_mesh_scale_matrix()
            self.assertTrue(scales["skin_pbr_hex"].startswith("#"))
            self.assertEqual(len(scales["skin_pbr_hex"]), 7)

    def test_weight_class_acl_shear_force_scaling(self):
        """Validates that ACL joint shear forces scale proportionally with athlete body mass."""
        flyweight_profile = DemographicProfile(weight_class=BoxingWeightClass.FLYWEIGHT) # ~50.8 kg
        heavyweight_profile = DemographicProfile(weight_class=BoxingWeightClass.HEAVYWEIGHT) # ~110 kg

        engine_fly = KineticAthleticsEngine(profile=flyweight_profile)
        engine_heavy = KineticAthleticsEngine(profile=heavyweight_profile)

        impact_g = 10.0
        knee_flexion = 20.0

        shear_fly = engine_fly.calculate_acl_shear_force(impact_g, knee_flexion)
        shear_heavy = engine_heavy.calculate_acl_shear_force(impact_g, knee_flexion)

        # Heavyweight ACL shear force must be substantially higher under identical G-force & flexion
        self.assertGreaterThan(shear_heavy, shear_fly * 2.0)

    def test_demographic_worm_receipt_provenance(self):
        """Validates that demographic metadata is safely logged into WORM receipts without tier inflation."""
        ctx = SessionContext(tier=SensorTier.OEM)
        profile = DemographicProfile(
            sex=SexBaseline.FEMALE,
            skin_tone=FitzpatrickSkinTone.TYPE_V,
            weight_class=BoxingWeightClass.WELTERWEIGHT,
            somatotype=Somatotype.MESOMORPH
        )
        engine = KineticAthleticsEngine(profile=profile)
        telemetry = engine.generate_broadcast_telemetry_overlay(
            ctx=ctx,
            impact_g=12.5,
            knee_flexion_deg=18.0,
            spin_rate_deg_s=720.0,
            emg_quads_uv=480.0,
            hr_bpm=175.0
        )

        receipt = self.ledger.append_event(
            ctx=ctx,
            event_type="DEMOGRAPHIC_ATHLETIC_BROADCAST",
            payload=telemetry
        )

        self.assertEqual(receipt["payload"]["athlete_demographics"]["sex"], "female")
        self.assertEqual(receipt["payload"]["athlete_demographics"]["boxing_weight_class"], "welterweight")
        self.assertEqual(receipt["payload"]["athlete_demographics"]["fitzpatrick_skin_tone"], "type_v_dark_brown")
        self.assertIn("hash", receipt)

    def assertGreaterThan(self, a, b):
        self.assertTrue(a > b, f"{a} is not greater than {b}")

if __name__ == "__main__":
    unittest.main()
