# Room Module: Evidence Note (evidence)

- **Sector**: `sector_4_geospatial`
- **Duty**: Unified house component in One House Architecture
- **Data Table**: `data_table.csv` and `data_table.json`
- **Axiom Compliance**: `1 * 0 = 1` (Fail-closed zero-trust)
