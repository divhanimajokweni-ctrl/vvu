# Review fixes — v1.0.1

## 1. Real WORM receipts
- All 44 data-table rows now carry a real `WORM_Receipt_Hash` (the `chain_hash` of their entry in `receipts/chain.json`). Previously: 2 distinct placeholder values, none reproducible.
- Chain built by `scripts/build_worm_receipts.py`, Ed25519-signed. `receipts/identity.json` is a DEMO public key. The private key is not shipped.
- Each chain payload includes `Table_Path` so each row maps back to its folder.

## 2. Spec-compliant verifier
- `core/worm_spec.py`: RFC 8785 (JCS) canonicalisation, including ECMAScript number formatting; source/chain hashes exactly as the README spec; Ed25519 signature verification; fail-closed reason codes.
- `core/verify_chain.py`: auditor CLI. `python3 core/verify_chain.py receipts/chain.json receipts/identity.json`
- Cross-checked: the JS reference (`canonicalize` npm package) reproduces all 44 `source_hash` and `chain_hash` values with zero mismatches.
- Deviation from the JS reference, on purpose: a missing signature fails (`SIG_MISSING`) when an identity is supplied, and a missing hash field fails (`MISSING_FIELD`). The reference accepts both silently.
- `core/verify_chain_offline.py` and `core/worm.py` now use JCS (previously `json.dumps`). Entries with a stripped `hash` now raise instead of passing.

## Tests
- 76 tests pass (56 original + 20 in `tests/test_worm_spec.py`).
- New tests check RFC 8785 vectors, every tamper class, the CLI exit codes, and that each shipped receipt equals its row.

## Still open (not in this pass)
- ISO 10816 class boundaries in `industrial_kinetics.py` (see review).
- 13 of 17 referenced GLB assets are not shipped; 3 Room 09 / skills files are missing.
- Timing thresholds (500 ms bus gate vs 15 s SENSOR_ABSENT) need documenting.
- SEV-SNP policy `0x30000` meaning needs checking against the AMD ABI.
