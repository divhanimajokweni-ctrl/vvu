# VVU Core Estate Agentic Framework & Persistent Agents (v1.0)

## Overview
This directory houses the persistent agent orchestrators, builders, admin agents, and production Kilo agent prompts that govern the VVU Core Estate.

Governed by: `UNIFIED_CORE_PUNCHLINE_CONSTITUTION.md` & `VVU_CONTROL_OPERATING_RULES.md`
Supreme Axiom: **1 * 0 = 1** (Capability * Discipline = Success; Discipline 0 = Failure 1)

---

## Persistent Agent Roles

### 1. Master Estate Orchestrator (`orchestrator_agent.py`)
* **Role**: Coordinates the 12 rooms of the One House Estate, monitors the StateVector bus across all 4 sectors, and enforces fail-closed timeouts.
* **Duty**: Gatekeeper of state transitions. If telemetry drops >15s, triggers `SENSOR_ABSENT`. If dropped >60s, trips the circuit breaker and revokes draw authorization.

### 2. Spatial Twin Builder Agent (`builder_agent.py`)
* **Role**: Manages 3D asset bindings, Photorealistic 5-Layer Composition Stack, and CesiumJS / Three.js visual twin rendering.
* **Duty**: Asserts 8D fidelity vector bounds (`render_no_tier_inflation`), verifies SHA-256 asset hashes before loading GLB models, and enforces Red Wireframe Absence Markers on un-authorized entities.

### 3. SEARM Admin & Governance Agent (`admin_searm_agent.py`)
* **Role**: Administers zero-trust audit ledgers, hardware AMD SEV-SNP TEE attestation, and courtroom evidence receipts.
* **Duty**: Executes JCS SHA-256 / Ed25519 WORM chain verification offline and enforces NDA / POPIA client firewalls.

---

## Kilo Agent System Prompts (`kilo_agent_prompts.json`)
Contains pre-configured system prompts for Kilo CLI and web runtime integration, enforcing the 3-Gate Cognitive Router (Discipline, Science, Engineering) before any code execution.
