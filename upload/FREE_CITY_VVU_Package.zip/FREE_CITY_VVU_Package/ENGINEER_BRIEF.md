# Engineer Brief — What We Are Building and What Needs Doing

Read this first. It explains the goal, separates what the code supports from what the narrative claims, and lists the work in priority order.

## 1. The goal

VVU is intended to be a verified digital-twin platform. The core idea, from the Sovereign Manifesto:

- **Digital twins that are verified, not asserted.** A twin must show evidence for its state. A test that could not run is recorded as `BLOCKED`, never as `PASS`.
- **Two gates on every action.** An *epistemic* gate (is the claim verified?) and a *constitutional* gate (is the action authorised?). Neither can stand in for the other.
- **An append-only audit trail.** Actions and state changes are written to a WORM (write-once) ledger.
- **Concrete surfaces for people.** A browser-based 3D city/rig/map view, a human anatomy viewer, a wildfire evidence map, and a playable front end.
- **Edge capture.** Local nodes (the HBK Mk-II family) collect sensor data and feed the twin. The BMW X6 scenario is the worked example: a local node detects a deviation, the twin shows it, and a human confirms before anything is ordered.

The manifesto is the narrative anchor. This brief is the engineering anchor. Where they disagree, the code and tests win.

## 2. What the evidence supports

| Area | Evidence in this package | Confidence |
|---|---|---|
| Verified-state testing (tamper circuit breaker, on-chain revert, Stokvel ROSCA, QR receipts, hydro governance TEE) | 5 test scripts run and passed | **Good** for those specific tests |
| Telemetry code compiles | 63 of 64 Python files compile | **Good**, with one known break |
| Browser front end (Road Run) | Loads and initialises headlessly, no page errors | **Good** for load, **untested** for gameplay |
| Anatomy models | All 10 `.glb` files have valid glTF headers | **Good** for format, **untested** for rendering |
| Wildfire map | All HTML references resolve | **Good** for links, **untested** in browser |
| Release manifest integrity | 14 of 15 declared checksums match; the 15th matches once its filename is corrected (`(1)` suffix) | **Good** |
| Constitutional invariant (`vote=PASS ∧ proof=FAIL ∧ authorization=EXECUTE` is rejected) | Documented in the supplied docs; the enforcing code lives in the ProofBridge Liner repository, which was not supplied | **Documented, not verified here** |
| Chameleon avatar engine, "Constitutional Gate", "Epistemic Gate", "Three Constitutional Immunities" | These names did not appear in the code I searched | **Not found** |
| M0 doctrine-lint | Name appears in 4 source files | **Unverified** whether it enforces anything |
| WORM ledger | Referenced in 212 files | **Referenced**, enforcement not tested here |

## 3. Claims in the manifesto that need code or wording changes

These are the points a technical reviewer will check first:

1. **"Machine-enforced" invariant.** Until the ProofBridge Liner invariant tests are run and passing, describe it as *specified*, not *enforced*.
2. **Named components.** "Chameleon Engine" and "Constitutional/Epistemic Gate" do not appear in the supplied code. Either add them or rename them to what exists.
3. **"[BLOCK] GPU / ROCm" status.** The manifesto treats a blocked hardware test as a success. That is only true if the system actually emits `BLOCKED` with a recorded reason. Confirm that before using it in a pitch.
4. **Anatomy and human-twin claims.** The models load as files; "photorealistic" and "1:1" need a rendering check before being claimed.
5. **Sensing claims.** Detecting a fracture needs baseline data and physical confirmation. See the earlier discussion. Do not claim detection from OBD-II alone.

## 4. Known defects (fix first)

| # | Item | Location | Action |
|---|---|---|---|
| D1 | Syntax error (unterminated f-string, line 34) | `03_telemetry_analytics/smartfarm_all_in_one_installer (2).py` | Fix or remove the duplicate |
| D2 | Hardcoded `/workspace/scratch/...` paths | `test-pwa-field-bundle.py`, `test-sw-meantime-journal.py`, `run_resilience_test_suite.py` | Make paths relative or configurable; check the referenced files exist |
| D3 | Missing dependency `fastapi` | `test-multiview-ui-degradation.py` | Add a requirements file |
| D4 | Test needs a `--receipt` argument with no default | `verify_install.py` | Document usage or add a default |
| D5 | Duplicate files with `(1)`, `(2)` suffixes | Many files in `03_telemetry_analytics/` | Keep one canonical copy per file; a manifest should list it |
| D6 | Unpinned Three.js from CDN | `02_road_run_artifact/index.html` | Pin a version and add a fallback |
| D7 | Stray generated files (`deepseek_*`, `index (13).html`, `borromean-rings.tsx.txt`) | `03_telemetry_analytics/` | Confirm purpose, then remove or move |
| D8 | Anatomy models total ~110 MB | `04_human_twin_models/` | Compress (Draco/meshopt) and generate web-sized variants |
| D9 | Font and other asset paths in `cape_town_wildfire.html` | `05_pools_wildfire/` | Re-test in a browser over HTTP |

## 5. Work in priority order

1. **Make the test suite run anywhere.** Fix D2, D3, D4, then re-run all 10 test scripts. Target: every script exits 0 or reports `BLOCKED` with a reason.
2. **Resolve D1 and D5.** A release should have exactly one copy of each file, listed in a manifest.
3. **Verify the invariant in the ProofBridge Liner repo.** Get its tests running and recorded as `PASS`.
4. **Decide the naming.** Map each manifesto term to a file or delete it from the narrative.
5. **Browser-test the wildfire viewer and the anatomy viewer** over HTTP. Record results.
6. **Optimise the models** (D8) before any web demo.
7. **Pin dependencies** (D6) and run the Road Run game end to end.
8. **Edge node pilot (HBK Mk-II).** Define sensor specs, sample rate, and baseline data before any BMW demo.

## 6. Rules to keep

- A test that cannot execute is `BLOCKED` or `NOT_RUN` with a reason. It is never `PASS`.
- Do not claim an invariant is enforced until its tests run.
- Human confirmation stays in the loop before any part is ordered or any action is executed.
- Keep the original uploads. Work from copies.
