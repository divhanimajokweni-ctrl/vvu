# Package Manifest

Files: 113 · Total: 118.3 MB

Verify: `sha256sum -c` against `06_verification/manifest.json`, or compare the hashes below.

| Path | Bytes | SHA-256 |
|---|---:|---|
| `01_manifesto/MANIFESTO.md` | 4934 | `ec4adde51ea7e143472d7c0588e4e4dff0f723a61e8e3d5125d43bf7ff62aba8` |
| `02_road_run_artifact/index.html` | 3423370 | `c9a89b00b09136c47d2c2c899a27bcd07f3934e30dba86d998ead1d4d4e2723a` |
| `03_telemetry_analytics/6G NTN Waveforms and AIoT Smart Agriculture Technologies - Gemini Notebook` | 2819263 | `641fb4f3e1702e0cc21c5879dadbdcbd73ec0e121b8bb1e88a13816317ef63ce` |
| `03_telemetry_analytics/ProofBridgeLedger_ABI.json` | 4109 | `92e6ed134fef0826ff8ca114ffd9ed64166fed33c61265ef8e9fb6c7ba177f2a` |
| `03_telemetry_analytics/RELEASE_MANIFEST.json` | 3039 | `df1c0d1aa37bc63241735f75951544c48789a0f28719f7f5e612ef299813a613` |
| `03_telemetry_analytics/agri_smartphone_web_bridge.py` | 15027 | `665a093aa234184a0e1810c13bd8d95e8269739a92e2da31e490caf9e7c45b35` |
| `03_telemetry_analytics/amd-rocm-activation-pipeline.py` | 11379 | `985ea69c5b49992ea2ae7501bc223a2bf4a54157da117a44d57f747bb3a7541a` |
| `03_telemetry_analytics/amd-rocm-mi300x-tee-pipeline.py` | 15036 | `2eecacd82fcf1bb93a4c70ae44faf57b0c8a89d378f2f662c7afdfb4c8019bb1` |
| `03_telemetry_analytics/benchmark_gbnf_latency.py` | 3721 | `af6af2bbd76e2d88a13728d464a9e779a621ad55dc09a06d232cf16477c2e936` |
| `03_telemetry_analytics/benchmark_suite_vs_traditional (1).py` | 4903 | `6172970fb297a015a292dd29a1ee3e292ae97904943f7967fb5d126bd0663f94` |
| `03_telemetry_analytics/benchmark_tee_throughput.py` | 4260 | `d9881143b491efcdf8078433c8befeb1b6eb77253924b2dfc8ec811cdd58cbec` |
| `03_telemetry_analytics/borromean-rings.tsx.txt` | 1162 | `6148fd0d1330d035deafcf1cf8f6d1ffb365421d956580621b40eb94f431563d` |
| `03_telemetry_analytics/cape_town_wildfire.html` | 22256 | `a9130d1b0fc63ccabd4807e5d2d5cf6d96b1694ee4dc0bc4a6037af96e9e1366` |
| `03_telemetry_analytics/deepseek_html_20261102_c7b093.html` | 18328 | `d038035634afafc3895de9595a9a30d0d66d2590560bb5f81efa42b1a0fa8966` |
| `03_telemetry_analytics/deepseek_python_20261102_f175d8.py` | 11199 | `10ab8f44fd253efb3f1255ccbb8c52241441a407b78d974da2cbb1f4a717fa35` |
| `03_telemetry_analytics/deploy_proofbridge_ledger.py` | 1790 | `60a84f2f717a0762b333f634474670fe8b2ffec9085fb3c15ab9d1fc74f9a64f` |
| `03_telemetry_analytics/device_tee_simulation.py` | 5976 | `b3eade5052826f97d606275d8bd4d3f1feb24f67b4f52b0da48a4ac05613897a` |
| `03_telemetry_analytics/digital-twin.html` | 1772858 | `aef406a22577be15aeb7a25b3db1df59f23057317db89d1c00a5d72e293c60a5` |
| `03_telemetry_analytics/e2e-integration-benchmark (1).py` | 14267 | `17c39c003e7e350bf0ac6b76dca0a1192400cfddae2dfa341039d1e78dc19e49` |
| `03_telemetry_analytics/e2e-integration-benchmark.py` | 18426 | `70b607972ad4464df67631c8bab97520a4819e536226822b62da1b6359f44e10` |
| `03_telemetry_analytics/e2e-offline-patrol-loop.py` | 13820 | `5e718eb6b93e01d722c996f514aa50d5a7c39a11d860b4630fa8423b7d64f8c5` |
| `03_telemetry_analytics/field_os_yolo_rtsp.py` | 3034 | `b0d399c5dd499d4d3d61671b5912539658f635175da5e45df0e8c6677830d4bc` |
| `03_telemetry_analytics/generate_72hr_audit_certificate_and_experiment (1).py` | 10544 | `58b8c0c6713784215a72852a472ef5ed256a5954a7a899d76d89d780f4b36dd3` |
| `03_telemetry_analytics/generate_72hr_audit_certificate_and_experiment.py` | 10544 | `58b8c0c6713784215a72852a472ef5ed256a5954a7a899d76d89d780f4b36dd3` |
| `03_telemetry_analytics/global_network_registry.json` | 1293 | `c38db89986d42f969a1e83a6ca4f4c3b0f01180e362eb72b0841422fcf90a5db` |
| `03_telemetry_analytics/iec61508_sis_override_sim.py` | 6613 | `393c6822adc75394b9ba0bcf00c8162b094213a1999651afdfbefce18df42b04` |
| `03_telemetry_analytics/index (12).html` | 28440 | `1f8a3b8bcc4f065d451ff02cdaaefefe38dc3c714a3bb40a88911c911f5d58bd` |
| `03_telemetry_analytics/index (13).html` | 23101 | `d1711cfe52ecb5a217e1677de95379f853e3edfe7daaa88469f1986dfbf7c0bb` |
| `03_telemetry_analytics/install_agri_smartfarm.py` | 4973 | `ddf34f6dd33cca814b705bf7452f58737a84c11613e2ed453eb43305af31a5f1` |
| `03_telemetry_analytics/ive_step_parser.py` | 3938 | `a595aeb95c8e00d4bd0fe1b9b2df11e216daadd327489fbb6d3428de4218a695` |
| `03_telemetry_analytics/kr_seoul_node_01_provisioning.json` | 1417 | `a831fdd5d80fbc7c2700041cde8bb7fd4770001d6ced3ff1a64c342a75fc8543` |
| `03_telemetry_analytics/langgraph_opcua_agent_sim.py` | 15153 | `e7ec60ef92f17fbfc5502e7cf1da1a84fc34a8eb6555d5df9f622278968f15b5` |
| `03_telemetry_analytics/master_benchmark_results.json` | 19377 | `7bcef8b1c15841e5d5d4c9c98529eb855895d0ace4eb4ea70fa71d82d12b3720` |
| `03_telemetry_analytics/meantime_calibration_engine.py` | 10250 | `be1f6c06f00d034355b1191ee455f61a6baedaa4e74c214566066d23179e7587` |
| `03_telemetry_analytics/multi-view-contract-api (1).py` | 3712 | `99672f901b9e291ef17d8f13ff26c6c5e0e5295b7e1825e43f39931cf8e3b879` |
| `03_telemetry_analytics/multi-view-contract-api.py` | 16267 | `90e9f7146611fc97dd9602457a9ffe766336ad38b798332d6721174062e45be4` |
| `03_telemetry_analytics/node_config.json` | 651 | `0ab820cb29638298be8de8324bb359b955a35083ca9889b3fe652033a894c1b2` |
| `03_telemetry_analytics/onboarding.html` | 18692 | `d9a24021ede644e86c4c2dff048e826bc2f89934464e197c31f76aa0b4bebfb5` |
| `03_telemetry_analytics/opcua_mcp_plc_dcs_bridge.py` | 10748 | `e7f8108cd3d796530f7111694723164ff739271681c38f5ee3a79c90aa4b5b11` |
| `03_telemetry_analytics/package_release.py` | 4922 | `0f92701dcf44516e127959d57204a0baf1809b658f7089138653b840a5ef2dec` |
| `03_telemetry_analytics/pdp-authority-gate.py` | 17838 | `ff7b5109c4646cba49d0b69c3952d532008cb2bbee5aa752948ba02091b0f869` |
| `03_telemetry_analytics/phase1-capture-inference-foundation.py` | 18418 | `b6a9e8c78f73c18ebe84846c72f3754c52c2bb6fa88be8b90384dffbca96efae` |
| `03_telemetry_analytics/phase3-respond-protect-foundation (1).py` | 11216 | `d6997771bf5bf49c08305fddf0032ecee8cef37210ca2025dba3a2d43359cf6d` |
| `03_telemetry_analytics/phase3-respond-protect-foundation.py` | 11216 | `d6997771bf5bf49c08305fddf0032ecee8cef37210ca2025dba3a2d43359cf6d` |
| `03_telemetry_analytics/plugin_registry.py` | 7068 | `187140f5696e004e2996a637ef29143f9672b6c370c53ccdc9eebedfbadc4af3` |
| `03_telemetry_analytics/proofbridge_ledger_settlement.py` | 6898 | `07d840905aa27d71478d8bb2127bf81b06e670411f04ab8370cac497bfcd9c53` |
| `03_telemetry_analytics/proofbridge_tee_validation.py` | 57 | `c8d9a0c162f6e49677f2881b099c52280a19fa80ad6c80b1d689d46100dd60b7` |
| `03_telemetry_analytics/provision_global_node.py` | 9985 | `f24e33490287101ed8f5e6f16ff3ef7d35e393a6c60ebf2bbc34be3590004175` |
| `03_telemetry_analytics/provision_korea_node.py` | 7416 | `2c87b6902b04175a906e248a9ecc903f1f263d8781e510162e8fe28e14137a27` |
| `03_telemetry_analytics/pwa-field-app-bundle.js` | 9547 | `c5e33d56ea08ccca323712a442e06fb00b93d69c1056388cd82c867d11b704a0` |
| `03_telemetry_analytics/pwa-field-insight-cards.js` | 9660 | `efa185239e1f18f1117c0ee32c52dad37a2e6afa8038ca9b1f89764e0b9e58d8` |
| `03_telemetry_analytics/pwa-mobile-edge-client.js` | 6436 | `2c2413f22fccb933e56a93f50b739c08960e2456bdb66ec818a2bfda0e6eab0a` |
| `03_telemetry_analytics/pwa-qr-peer-receipts.js` | 7208 | `13db4afc6656f8c3cb1309a975f2865dd0bf8c741f87f56e733eb9ac1213141d` |
| `03_telemetry_analytics/pwa-service-worker.js` | 8109 | `a30f93ccf225a05ce507c81a2a67acca0b57d37c4f199e94feaaf773b2b8627f` |
| `03_telemetry_analytics/receipt.py` | 5028 | `00f4c671167a65225b141de40001cf534152bc40aa47501a479c2cd8268f90b6` |
| `03_telemetry_analytics/run_7stage_validation_pipeline.py` | 9591 | `7ee08c99f4c208ba3bb2ee3f6a0764f967bb02fdfaf4b7a46f20a9bac9a925f6` |
| `03_telemetry_analytics/run_all_benchmarks.py` | 3619 | `00f367863b70de95c24d3c943ad08630efbf525e3965c3629e4aff49053019ca` |
| `03_telemetry_analytics/run_resilience_test_suite.py` | 6244 | `1c4252ccd433890a2a017e58a3b3f7317a30df0d433f6d12d326fd7e18625f10` |
| `03_telemetry_analytics/safegrid-phase-contract-spec.md` | 30310 | `968281c21173dd489ee65546174e6d8a435cb2f06d6bdc5724dcd58dcae76de5` |
| `03_telemetry_analytics/smartfarm_all_in_one_installer (1).py` | 62431 | `1fed2fbe8114f22b8a3a41b154e9afa3a0dc989ffaac3da9514fda16e7fcb9ee` |
| `03_telemetry_analytics/smartfarm_all_in_one_installer (2).py` | 62428 | `38b4ae2ff5eab00bb6a4ba73e1f3a524a7bc167ff0e0c5ef69cc705cef035ec4` |
| `03_telemetry_analytics/smartfarm_all_in_one_installer.py` | 78791 | `fe362a186ca38d5db61a7d4528fa49bb3e8398d24480953307df88ae5d5def60` |
| `03_telemetry_analytics/smartphone-edge-receiver (1).py` | 11116 | `9d2a30ff85fb85422656596a49ecbb631e774d56373d4a322848d94064a8ced2` |
| `03_telemetry_analytics/smartphone-edge-receiver (2).py` | 11116 | `9d2a30ff85fb85422656596a49ecbb631e774d56373d4a322848d94064a8ced2` |
| `03_telemetry_analytics/smartphone-edge-receiver.py` | 11116 | `9d2a30ff85fb85422656596a49ecbb631e774d56373d4a322848d94064a8ced2` |
| `03_telemetry_analytics/smartwatch-edge-receiver.py` | 10572 | `55656df47663531182ac5d1c55973087915d2371c7a9411cb102894aea52d40d` |
| `03_telemetry_analytics/tee_device_benchmark.json` | 3088 | `3e099852ca7f36167188e6884b76024beb6a3c38e6afd1001a49e53750dc948f` |
| `03_telemetry_analytics/tee_throughput_benchmark_10k.json` | 1812 | `a7fd5cbb1a076fd2d3a34693cdacf8870ef477b8e36b94f984d439bb9c2fd01b` |
| `03_telemetry_analytics/test-multiview-ui-degradation.py` | 1921 | `eec4066add7f981543019a29d48a420b6de4b994ce1bfc2f7c182ea01ff7ef2f` |
| `03_telemetry_analytics/test-pwa-field-bundle.py` | 1823 | `4ad3babb2de7b6f0297c1a14d658c0eac6a20e34574b3f36cc3699f1ed2f3d1f` |
| `03_telemetry_analytics/test-qr-peer-receipts.py` | 4056 | `8cc6b6369f5abc9f8eb7d87fcdacc61af7b54a893f6497f1f99adb2a19ca3c53` |
| `03_telemetry_analytics/test-sw-meantime-journal.py` | 4125 | `7eedeb860c806a8532048b763d6822ec0bab804617fbc090957eb75b0b597e2b` |
| `03_telemetry_analytics/test_compute_stokvel_rosca.py` | 13653 | `0870a6670448e7af891494e49b2862e2093db5cc282c291bbe1dc1293477c56f` |
| `03_telemetry_analytics/test_onchain_tamper_revert.py` | 3202 | `fb14fdaeb9122e3349e5b0e31358241ad107694b5a478cfc40bd294701bffdab` |
| `03_telemetry_analytics/test_tamper_circuit_breaker.py` | 3699 | `e17ac193f9e58da90551a96a2389aeb2e620c51df7e00d3d529144427d840263` |
| `03_telemetry_analytics/thz_lorawan_langgraph_agent (1).py` | 8950 | `ecd88e9213966aac3c0d7d6b32db3a91b16ad8255028c3c548756cfa10189adc` |
| `03_telemetry_analytics/thz_lorawan_langgraph_agent.py` | 8950 | `ecd88e9213966aac3c0d7d6b32db3a91b16ad8255028c3c548756cfa10189adc` |
| `03_telemetry_analytics/tier2-esp32-receiver (1).py` | 11608 | `4ea365c94976a000288013466f99c4c655ca0e89c2569d9f9e26f9474c959037` |
| `03_telemetry_analytics/tier2-esp32-receiver.py` | 11608 | `4ea365c94976a000288013466f99c4c655ca0e89c2569d9f9e26f9474c959037` |
| `03_telemetry_analytics/twin-cesium-projection.js` | 6817 | `eb52b318afedef6c3281ea14592b2dc4c04fa15af8fe802b09270a6eda69a970` |
| `03_telemetry_analytics/verify_hydro_governance_tee.py` | 12649 | `c6083f36e738f740f7f6829100ba9e5f3360031fdb78a76ee9a45eb1f8a4e519` |
| `03_telemetry_analytics/verify_install.py` | 1755 | `a5a110dc5fe53b731195e12c41d2e8e8d85c65510252511e3e7ed10110decc74` |
| `03_telemetry_analytics/vvu_apk_builder.py` | 4213 | `357b057ede6463601f703469de0559b8087fd773abc55ef60fe5b4bb7b0e6e63` |
| `03_telemetry_analytics/vvu_composite_demo.py` | 7193 | `c4839af6d32d852b6cb8ddf4fba6d7b45a42dc08f2f024e8a8acc7a1e6cc9efb` |
| `03_telemetry_analytics/vvu_installer_suite.py` | 16796 | `157efafabbe9e2e56d9e924e58758bbe6dc4fdf7d67266dadd18b5cc3ae3db59` |
| `03_telemetry_analytics/vvu_launcher.bat` | 476 | `0b64d5f0e661a06d847d49c4576f0a3a4b1d5db4f328e4a972c35493beb0c6fc` |
| `03_telemetry_analytics/vvu_suite_benchmark.json` | 2404 | `f92c784a5c5290cc09696c1b645de6706c2ccbef26b6663f19ae17b2ff91d895` |
| `03_telemetry_analytics/vvu_trust_e2e_installer.py` | 144368 | `73d25c8d111279bb6098146f5cd88a8948c5b7142b3d5e066841eb3669a1dcc3` |
| `03_telemetry_analytics/vvu_zero_friction_installer.py` | 8085 | `a3f856ec13e3fc0985e5bc3ffc3d167d9b84c2a2477bef9dc1af4eb81f9e3112` |
| `03_telemetry_analytics/weekly-telemetry-analytics.py` | 12548 | `4f82f36df5d613a36d13b4835fa4a854c607444b42f31f65214cb33b12b3fae6` |
| `03_telemetry_analytics/yolo_meantime_integration.py` | 7433 | `3ee6e67e1739b8b156d567400a26d7f798dfda0ae026103c42f323d067954428` |
| `04_human_twin_models/blue_bikini_portrait.glb` | 23672872 | `6fbb38fae2f9c51853305cbba4c7e7e41bf00998bf8d209ee0bb536d734e2246` |
| `04_human_twin_models/circulatory-system-figure.glb` | 3330036 | `216e998d762569abd8d1ba9fd2f3a0d2bab1362fd2a8d43192d44947c04b94b3` |
| `04_human_twin_models/digestive_system.glb` | 2585176 | `684848eb922479ad5cf4891876741801d82091464ab511b7c6dce9219c345d88` |
| `04_human_twin_models/female_human_skeleton_full_body_anatomy_3d_model.glb` | 19485868 | `2db3ba7db12286355c7313c7ad0412d208d2ee0b0148adb4aa6a149911edfedf` |
| `04_human_twin_models/front_body_anatomy.glb` | 13799544 | `abe67f970e7a3d25098d044f70a1cfc6004cba477980c17414bd01d3973e2df9` |
| `04_human_twin_models/human_brain_cerebrum__brainstem.glb` | 12230544 | `0f1a1ea20f20dcd39ea78dc913b280177923d0b119fc2479708ce0024a74a9a1` |
| `04_human_twin_models/human_organs.glb` | 2855552 | `97586738b5c6e582f6357aec38ce5898264510797ef23aa0dd45fa91489eea45` |
| `04_human_twin_models/index.html` | 28440 | `1f8a3b8bcc4f065d451ff02cdaaefefe38dc3c714a3bb40a88911c911f5d58bd` |
| `04_human_twin_models/perfect_human_body.glb` | 9391244 | `cd84ec393f0780b903bdb45b1b11d2a559ca38dbab6585e65b1f186d612c96b8` |
| `04_human_twin_models/realistic_human_lungs.glb` | 17147352 | `66ed0f50b8ac6cc7fe648642e7b090dbc42b6beae9d0faee44bf8556e601a22e` |
| `04_human_twin_models/skeleton_animated.glb` | 4517624 | `ed7d1fe4e971e3cb990a480b47e93aee39e4307fe4aa94ee4f5e04c9ade4ef96` |
| `05_pools_wildfire/pools.css` | 7195 | `042795556728c6a21d132ba9e7c1b9af7fe461a3734c56bdb95f086bd72a46ff` |
| `05_pools_wildfire/wildfire/cape_town_wildfire.html` | 23465 | `11f80f66b0d540bac592537ffc79a0543551fcfaf6878c752d56f1299d64f079` |
| `05_pools_wildfire/wildfire/wildfire-evidence.js` | 9927 | `c37f7802a42d84d9b2d8f73d804afff93a2de0f3ea8db8ff529cde3c290bec8f` |
| `05_pools_wildfire/wildfire/wildfire-layers.js` | 20565 | `6475ebde13d66c110faa4f69ce66e391c45b4792dccaf2a64fc5b73ada62d880` |
| `05_pools_wildfire/wildfire/wildfire-mesh-client.js` | 16979 | `c1a4d8d7b4ff7d53c7573a9ad06871cfd2a4c0264a9849f6933ea01c4a08f969` |
| `05_pools_wildfire/wildfire/wildfire-state.js` | 7351 | `9a395a187cfe32004cc0854c0e6285ad02d19e733b0bc8206d5caa7c086d5057` |
| `05_pools_wildfire/wildfire/wildfire-sw.js` | 6288 | `31f668ed53f73c8ef3ffd9470764cc289aa5d07a187d96e07a2d25ded55839c2` |
| `05_pools_wildfire/wildfire/wildfire-view.css` | 8134 | `8f358bcf91498246f25ad66fa519850746f82d9c231e7b8b0e62b6ee1f5a7dd2` |
| `06_verification/TEST_REPORT.md` | 4361 | `9705a992dacfc2af0649fc35d88a8500f7a5f4a213d1804e37e6866b8008391d` |
| `ENGINEER_BRIEF.md` | 6142 | `d605e2f20fc3226b625ff501c5abf1441b2c7498e75a40e0679ad535398fe232` |
| `README.md` | 2914 | `2369726f12b81cbbaa5f1e56c84bd4fa40684f34133e8ae9d0b258cbb19fc7b2` |
