# FREE CITY / VVU — Working Package

This package collects the files supplied for the Venture Vision Ubuntu (VVU) effort, arranged by purpose, with a verification report on each part. **No source file has been modified.** Everything here is a copy of what was uploaded or what the Artifact tool read back.

Start with `ENGINEER_BRIEF.md` for what the project is trying to achieve and what needs doing. Read `06_verification/TEST_REPORT.md` for what was actually run and what passed.

## Layout

| Folder | What it is | Status |
|---|---|---|
| `01_manifesto/` | The Sovereign Manifesto (Genesis Proposition), as supplied | Narrative document. Claims are not all backed by code; see the brief. |
| `02_road_run_artifact/` | "FREE CITY // Road Run" single-file browser game (`index.html`) | Loads and runs headlessly. Depends on an unpinned Three.js CDN load. |
| `03_telemetry_analytics/` | Weekly telemetry analytics, edge receivers, PWA field-app JS, ProofBridge contract ABI, benchmarks, and test scripts (89 files) | Mixed. 63 of 64 Python files compile; 5 tests pass; 4 fail on hardcoded paths or missing dependencies. |
| `04_human_twin_models/` | 10 anatomy `.glb` models (skeleton, brain, organs, lungs, body) | All files have a valid glTF header. Total ~110 MB, not yet optimised for web delivery. |
| `05_pools_wildfire/` | Cape Town wildfire map viewer (HTML/CSS/JS, layers, evidence, service worker) | All HTML references resolve. Not run in a browser in this review. |
| `06_verification/` | Test report and machine-readable checksums | Generated during this review. |

## Quick start

- **Road Run game:** open `02_road_run_artifact/index.html` in a modern browser. It needs internet access for the Three.js script.
- **Telemetry tests that pass without setup:** from `03_telemetry_analytics/`, run `python3 test_tamper_circuit_breaker.py`, `python3 test_onchain_tamper_revert.py`, `python3 test_compute_stokvel_rosca.py`, `python3 test-qr-peer-receipts.py`, `python3 verify_hydro_governance_tee.py`.
- **Wildfire viewer:** open `05_pools_wildfire/wildfire/cape_town_wildfire.html` in a browser (serve over HTTP for best results).
- **Human twin models:** load any `.glb` in a glTF viewer. The files are large; see the brief.

## Integrity

`MANIFEST.md` lists every file with its size and SHA-256. `06_verification/manifest.json` has the same data in machine-readable form. Verify with `sha256sum -c` against that JSON or by comparing against `MANIFEST.md`.

## Known limits of this review

- Only the sandbox was used. Hardware, Ethereum/EVM, ROCm/AMD, Kria, and TEE paths were not exercised.
- Tests were run from a copy, so their hardcoded `/workspace/scratch` paths failed rather than being fixed in place.
- The ProofBridge Liner repository (which holds the Constitutional Invariant text in its README) was not supplied, so the invariant is checked only where it appears in the supplied docs.
