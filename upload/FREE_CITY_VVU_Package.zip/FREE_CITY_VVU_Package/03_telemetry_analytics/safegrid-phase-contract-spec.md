# Safegrid Architectural Phase Contract Specification: OpenAPI 3.1.0 & JSON Schema Blueprint

This specification formalizes the exact data contracts, JSON Schemas, and OpenAPI 3.1.0 definitions governing the three sequential phases of the Safegrid event-driven architecture. Designed for zero-trust edge-to-cloud execution, the system enforces a strict phase interlock: raw physical signals are processed in Phase 1 into unverified candidates, verified and sealed in Phase 2 as immutable legal truth, and executed in Phase 3 within a strict 90-second SLA clock that originates strictly at the evidence seal.

---

## 1. Architectural System Overview & Phase Handoff Protocol

The Safegrid system architecture enforces strict phase boundaries where data transfers occur sequentially over authenticated, encrypted channels. As established in zero-trust microservice frameworks and mutual TLS guidelines, every service-to-service interaction demands bidirectional cryptographic authentication via mTLS (RFC 8705 / TLS 1.3), eliminating long-lived bearer tokens and ensuring mutual identity verification across edge and cloud infrastructure.

```
+-----------------------------------------------------------------------------------+
|                            PHASE 1: CAPTURE & INFERENCE                           |
|  [Sensors & 6-DOF IMUs] --(40 Hz)--> [Signal Conditioning & ZVU]                 |
|                                             |                                     |
|                                   [5-Model Gateway]                               |
|                     (Prithvi-EO-2.0, Mamba, DTC, IRIDE, Vision)                   |
|                                             |                                     |
|                                   [G1: Detection Gate]                            |
|                                             |                                     |
+---------------------------------------------|-------------------------------------+
                                              | candidate_event
                                              v (mTLS WebSocket / gRPC)
+-----------------------------------------------------------------------------------+
|                            PHASE 2: VERIFY & SEAL                                 |
|  [candidate_event] ----------> [arbitration.ts Modality Arbiter]                  |
|                                             |                                     |
|                                    [Site Thresholds]                              |
|                                             |                                     |
|                                 [G2: Human Assessment]                            |
|                                             |                                     |
|                            [G3: WORM Seal & CCT Hash Chain]                       |
+---------------------------------------------|-------------------------------------+
                                              | Incident Evidence Passport
                                              v (SLA Clock Starts at Seal t_seal)
+-----------------------------------------------------------------------------------+
|                            PHASE 3: RESPOND & PROTECT                             |
|  [Incident Evidence Passport] -> [G4: Dispatch Clock <= 90s]                      |
|                                             |                                     |
|                           [Biometric & Contextual Monitoring]                     |
|                              (HRV CapsuleNet, TPH, Lux, PM2.5)                     |
|                                             |                                     |
|                           [Ubuntu Quorum Reconciliation (18/25)]                  |
|                                             |                                     |
|                          [3-Tier SHA-256 Responsibility Chain]                    |
+-----------------------------------------------------------------------------------+
```

### Phase Handoff Contracts & Sequential Boundaries

1. **Phase 1 to Phase 2 Contract (`candidate_event`)**: Emitted over an mTLS-secured WebSocket stream or gRPC channel following G1 Detection Gate approval (false-positive rate <= 8%). Represents a probabilistic detection containing raw IMU telemetry, Zero-Velocity Update (ZVU) drift-compensated state vectors, and model score distributions. It carries **zero operational authority** and cannot trigger dispatches.
2. **Phase 2 to Phase 3 Contract (`Incident Evidence Passport`)**: Produced once a candidate detection passes multi-modality arbitration (`arbitration.ts`), site-specific threshold evaluation, and G2 Human Assessment. Upon approval, the evidence payload is canonicalized and locked into a Write Once Read Many (WORM) vault using a sequential SHA-256 hash chain ($H_n = \text{SHA-256}(H_{n-1} \parallel D_n)$) under Codd–Chen–Theys (CCT) database ledger rules. The G4 SLA clock starts **at the timestamp of the evidence seal ($t_{\text{seal}}$)**.
3. **Phase 3 Operational Execution & Audit (`dispatch_action`)**: Action commands are executed within <= 90 seconds ($t_{\text{seal}} + 90\text{s}$) for general incidents, or <= 60 seconds on highway sectors. Operational dispatches continuously ingest field responder telemetry (HRV CapsuleNet stress models, environmental sensors) and evaluate multi-source truth reconciliation via Ubuntu consensus. Every execution writes a 3-tier SHA-256 responsibility record binding the AI decision, human authorization, and execution logs.

---

## 2. Phase 1 Contract Specification: Candidate Event (`candidate_event`)

The Phase 1 contract captures high-frequency physical telemetry and model inferences from edge processing units (such as NVIDIA Jetson devices). Inertial Navigation Systems (INS) integrate 6-DOF IMU data at 40 Hz, applying Zero-Velocity Updates (ZVU) during detected stance phases to constrain double-integration position drift. In accordance with factor graph optimization principles for pedestrian and asset tracking, ZVU kinematic factors act as pseudo-measurements that bound error growth.

Candidate events are scored across a 5-Model Gateway incorporating geospatial foundation models (e.g., NASA/IBM Prithvi-EO-2.0 using multi-temporal 3D vision transformers), state-space experts (e.g., Mamba selective state-space models for efficient intra-chunk sequence modeling), Decision Tree Classifiers (DTC), IRIDE NIMBUS, and VISION FM SURVEY.

### JSON Schema: `candidate_event.json`

```json
{
  "title": "CandidateEvent",
  "description": "Payload emitted by Phase 1 edge gateway representing candidate sensor detections prior to verification.",
  "type": "object",
  "required": [
    "event_id",
    "timestamp_ns",
    "ingestion_metadata",
    "kinematic_telemetry",
    "model_scores",
    "g1_gate_status",
    "edge_digest"
  ],
  "properties": {
    "event_id": {
      "type": "string",
      "format": "uuid",
      "description": "Globally unique identifier generated at edge capture."
    },
    "timestamp_ns": {
      "type": "integer",
      "minimum": 0,
      "description": "POSIX timestamp in nanoseconds when IMU/sensor chunk was captured."
    },
    "ingestion_metadata": {
      "type": "object",
      "required": ["node_id", "mtls_client_fingerprint", "channel_protocol", "sample_rate_hz"],
      "properties": {
        "node_id": { "type": "string", "example": "edge-node-alpha-04" },
        "mtls_client_fingerprint": { "type": "string" },
        "channel_protocol": { "type": "string", "enum": ["WEBSOCKET_MTLS", "GRPC_MTLS"] },
        "sample_rate_hz": { "type": "number", "enum": [40.0, 60.0, 100.0] }
      }
    },
    "kinematic_telemetry": {
      "type": "object",
      "required": ["imu_6dof", "zvu_applied", "estimated_drift_m"],
      "properties": {
        "imu_6dof": {
          "type": "object",
          "required": ["accel_x", "accel_y", "accel_z", "gyro_x", "gyro_y", "gyro_z"],
          "properties": {
            "accel_x": { "type": "number" },
            "accel_y": { "type": "number" },
            "accel_z": { "type": "number" },
            "gyro_x": { "type": "number" },
            "gyro_y": { "type": "number" },
            "gyro_z": { "type": "number" }
          }
        },
        "zvu_applied": {
          "type": "boolean",
          "description": "True if Zero-Velocity Update kinematic factor was active during stance phase."
        },
        "estimated_drift_m": {
          "type": "number",
          "minimum": 0.0,
          "description": "Residual position uncertainty in meters post-ZVU factor graph optimization."
        }
      }
    },
    "model_scores": {
      "type": "object",
      "required": ["prithvi_eo_2_0", "msfmamba_tiny", "dtc", "iride_nimbus", "vision_fm_survey"],
      "properties": {
        "prithvi_eo_2_0": { "type": "number", "minimum": 0.0, "maximum": 1.0 },
        "msfmamba_tiny": { "type": "number", "minimum": 0.0, "maximum": 1.0 },
        "dtc": { "type": "number", "minimum": 0.0, "maximum": 1.0 },
        "iride_nimbus": { "type": "number", "minimum": 0.0, "maximum": 1.0 },
        "vision_fm_survey": { "type": "number", "minimum": 0.0, "maximum": 1.0 }
      }
    },
    "g1_gate_status": {
      "type": "object",
      "required": ["passed", "estimated_fpr", "status_code"],
      "properties": {
        "passed": { "type": "boolean" },
        "estimated_fpr": {
          "type": "number",
          "maximum": 0.08,
          "description": "False Positive Rate, strictly constrained <= 8%."
        },
        "status_code": {
          "type": "string",
          "enum": ["PASSED", "REJECTED_BELOW_THRESHOLD", "DRIFT_EXCEEDED", "SENSOR_FAULT"]
        }
      }
    },
    "edge_digest": {
      "type": "string",
      "description": "Cryptographic SHA-256 digest of event payload."
    }
  },
  "additionalProperties": false
}
```

---

## 3. Phase 2 Contract Specification: Incident Evidence Passport (`incident_evidence_passport`)

The Phase 2 contract represents the legally binding verification and cryptographic seal of an incident. Candidate events enter `arbitration.ts`, where decisions are determined by multi-modality corroboration count rather than isolated highest-confidence scores:
- **ARM**: At least two independent sensor modalities agree above their site-specific acceptance threshold.
- **HOLD**: Single-modality detection above threshold, requiring mandatory human review (`requires_assessment=true`) and flagged with the `SINGLE-SOURCE · CONFIDENCE UNCORROBORATED` badge.
- **REJECT**: Any armed model falls below its hard floor, resulting in `REJECTED_BELOW_THRESHOLD` and silent logging.

### Cryptographic Evidence Vault & Codd–Chen–Theys (CCT) Ledger Mechanics

Once approved by G2 Assessment, the evidence payload is canonicalized (deterministic column ordering, standardized null handling) and committed to Write Once Read Many (WORM) storage. Grounded in CCT database compliance methodologies, the system enforces a 3-tier hash chain:

$$\text{CurrHash} = \text{SHA-256}(\text{CanonicalData} \parallel \text{PrevHash})$$

This payload is anchored to an S3 Object Lock compliance vault (where administrative overrides and root deletions are disabled at the kernel level) and assigned a sequential CCT global ledger ID ($L_n$). The timestamp of this seal ($t_{\text{seal}}$) establishes the immutable baseline for Phase 3 SLA tracking.

### JSON Schema: `incident_evidence_passport.json`

```json
{
  "title": "IncidentEvidencePassport",
  "description": "Sealed, immutable evidence passport emitted by Phase 2 upon verification and WORM hash chaining.",
  "type": "object",
  "required": [
    "passport_id",
    "candidate_event_ref",
    "arbitration",
    "site_profile",
    "g2_assessment",
    "g3_worm_seal",
    "sla_clock_origin"
  ],
  "properties": {
    "passport_id": {
      "type": "string",
      "format": "uuid"
    },
    "candidate_event_ref": {
      "type": "object",
      "required": ["event_id", "payload_hash"],
      "properties": {
        "event_id": { "type": "string", "format": "uuid" },
        "payload_hash": { "type": "string" }
      }
    },
    "arbitration": {
      "type": "object",
      "required": ["verdict", "agreeing_modalities_count", "modality_breakdown"],
      "properties": {
        "verdict": { "type": "string", "enum": ["ARM", "HOLD", "REJECT"] },
        "agreeing_modalities_count": { "type": "integer", "minimum": 0 },
        "modality_breakdown": {
          "type": "object",
          "properties": {
            "optical_vlm": { "type": "boolean" },
            "radar_sar": { "type": "boolean" },
            "imu_kinematic": { "type": "boolean" },
            "acoustic": { "type": "boolean" }
          }
        }
      }
    },
    "site_profile": {
      "type": "object",
      "required": ["site_id", "site_type", "active_threshold"],
      "properties": {
        "site_id": { "type": "string" },
        "site_type": {
          "type": "string",
          "enum": ["CORPORATE_HQ", "DATA_CENTER", "MINING_OPERATIONS", "RESIDENTIAL", "HIGHWAY_SECTOR"]
        },
        "active_threshold": { "type": "number", "minimum": 0.0, "maximum": 1.0 }
      }
    },
    "g2_assessment": {
      "type": "object",
      "required": ["requires_assessment", "human_verdict", "operator_id", "badge_assigned"],
      "properties": {
        "requires_assessment": { "type": "boolean" },
        "human_verdict": { "type": "string", "enum": ["CONFIRMED_REAL", "OVERRIDDEN_FALSE_POSITIVE", "TIMEOUT_EXPIRED"] },
        "operator_id": { "type": "string" },
        "badge_assigned": {
          "type": "string",
          "enum": ["NONE", "SINGLE-SOURCE · CONFIDENCE UNCORROBORATED", "MULTI-MODAL · CORROBORATED"]
        }
      }
    },
    "g3_worm_seal": {
      "type": "object",
      "required": [
        "previous_head_hash",
        "current_data_hash",
        "combined_seal_hash",
        "cct_global_sequence_id",
        "worm_vault_uri",
        "ml_dsa_certificate"
      ],
      "properties": {
        "previous_head_hash": { "type": "string" },
        "current_data_hash": { "type": "string" },
        "combined_seal_hash": { "type": "string" },
        "cct_global_sequence_id": { "type": "integer", "minimum": 1 },
        "worm_vault_uri": { "type": "string" },
        "ml_dsa_certificate": {
          "type": "object",
          "required": ["algorithm", "signature_hex", "boundary_policy_id"],
          "properties": {
            "algorithm": { "type": "string", "enum": ["ML-DSA-87"] },
            "signature_hex": { "type": "string" },
            "boundary_policy_id": { "type": "string" }
          }
        }
      }
    },
    "sla_clock_origin": {
      "type": "string",
      "format": "date-time",
      "description": "ISO 8601 timestamp marking the exact instant G3 WORM seal was written. SLA clock originates here."
    }
  },
  "additionalProperties": false
}
```

---

## 4. Phase 3 Contract Specification: Dispatch Action (`dispatch_action`)

Phase 3 executes operational response within the SLA window initiated at $t_{\text{seal}}$. The dispatch gateway enforces $t_{\text{execution}} - t_{\text{seal}} \le 90\text{s}$ ($\le 60\text{s}$ for Highway sectors). Simultaneously, Phase 3 manages field responder safety via wearable telemetry and multi-source consensus.

### Biometric Baseline & Responder Protection

Field responders transmit real-time telemetry from wearable sensors (e.g., MākuSafe, Empatica E4, or specialized HRV monitors). Research on biometrics demonstrates that Heart Rate Variability (HRV) combined with deep learning architectures (such as Capsule Networks or ResNet variants) provides objective, real-time stress monitoring with binary stress detection accuracy reaching up to 99.8%.

The biometric state machine maintains individual baselines (e.g., resting HR $65\text{ bpm}$). An acute spike from $65 \rightarrow 95\text{ bpm}$ within 5 seconds triggers an immediate `PHYSIOLOGICAL_STRESS_ALERT` state, even in zero camera coverage. Environmental context—including temperature/humidity/pressure (TPH heat index), PM2.5 particulate levels, and ambient illumination (< 10 Lux activating Low-Light Mode)—is continuously blended into the responder risk model.

### Ubuntu Consensus & 3-Tier Responsibility Chain

To prevent rogue dispatches or false field claims, Ubuntu Consensus cross-references 25 independent field evidence vectors (responder mobile GPS, gate RFID scans, vehicle CAN-bus engine state, supervisor video streams). A consensus threshold of >= 18/25 matching sources is required for full chain settlement. If quorum falls below 18/25, the local envelope queues and retries while flagging state as `INCLUSION_PENDING`.

Every executed action is permanently committed to a 3-tier SHA-256 responsibility chain:
- **Tier 1**: AI decision log ($H_{\text{ai}}$).
- **Tier 2**: Human confirmation log ($H_{\text{human}}$, counter-signed).
- **Tier 3**: System execution log ($H_{\text{exec}}$), where $H_{\text{exec}} = \text{SHA-256}(H_{\text{human}} \parallel \text{ExecutionMetadata})$.

### JSON Schema: `dispatch_action.json`

```json
{
  "title": "DispatchAction",
  "description": "Payload governing operational dispatch execution, responder telemetry monitoring, and 3-tier audit logging.",
  "type": "object",
  "required": [
    "dispatch_id",
    "passport_ref",
    "dispatch_sla",
    "responder_telemetry",
    "environmental_context",
    "ubuntu_consensus",
    "responsibility_chain",
    "execution_status"
  ],
  "properties": {
    "dispatch_id": { "type": "string", "format": "uuid" },
    "passport_ref": {
      "type": "object",
      "required": ["passport_id", "combined_seal_hash"],
      "properties": {
        "passport_id": { "type": "string", "format": "uuid" },
        "combined_seal_hash": { "type": "string" }
      }
    },
    "dispatch_sla": {
      "type": "object",
      "required": ["clock_start_time", "dispatch_time", "elapsed_seconds", "target_max_seconds", "sla_met"],
      "properties": {
        "clock_start_time": { "type": "string", "format": "date-time" },
        "dispatch_time": { "type": "string", "format": "date-time" },
        "elapsed_seconds": { "type": "number" },
        "target_max_seconds": { "type": "number", "enum": [60.0, 90.0] },
        "sla_met": { "type": "boolean" }
      }
    },
    "responder_telemetry": {
      "type": "object",
      "required": ["responder_id", "biometric_state", "social_mode"],
      "properties": {
        "responder_id": { "type": "string" },
        "biometric_state": {
          "type": "object",
          "required": ["heart_rate_bpm", "hrv_rmssd_ms", "physiological_stress_flag", "capsulenet_stress_score"],
          "properties": {
            "heart_rate_bpm": { "type": "integer" },
            "hrv_rmssd_ms": { "type": "number" },
            "physiological_stress_flag": { "type": "boolean" },
            "capsulenet_stress_score": { "type": "number", "minimum": 0.0, "maximum": 1.0 }
          }
        },
        "social_mode": {
          "type": "string",
          "enum": ["SOLO_NORMAL", "PAIR_MUTUAL_VERIFICATION", "ASSET_PROTECTION", "WARNING_ELEVATED_HR"]
        }
      }
    },
    "environmental_context": {
      "type": "object",
      "required": ["heat_index_c", "pm2_5_ug_m3", "ambient_lux", "low_light_mode_active"],
      "properties": {
        "heat_index_c": { "type": "number" },
        "pm2_5_ug_m3": { "type": "number" },
        "ambient_lux": { "type": "number" },
        "low_light_mode_active": { "type": "boolean" }
      }
    },
    "ubuntu_consensus": {
      "type": "object",
      "required": ["matching_sources_count", "total_sources_count", "quorum_reached", "discrepancy_flag"],
      "properties": {
        "matching_sources_count": { "type": "integer", "minimum": 0, "maximum": 25 },
        "total_sources_count": { "type": "integer", "const": 25 },
        "quorum_reached": { "type": "boolean" },
        "discrepancy_flag": { "type": "boolean" }
      }
    },
    "responsibility_chain": {
      "type": "object",
      "required": ["tier1_ai_hash", "tier2_human_hash", "tier3_execution_hash", "sequence_valid"],
      "properties": {
        "tier1_ai_hash": { "type": "string" },
        "tier2_human_hash": { "type": "string" },
        "tier3_execution_hash": { "type": "string" },
        "sequence_valid": { "type": "boolean" }
      }
    },
    "execution_status": {
      "type": "string",
      "enum": ["DISPATCHED_COMPLETED", "INCLUSION_PENDING", "DEGRADED_BUFFERED", "HALTED_WATCHDOG_OVERRUN"]
    }
  },
  "additionalProperties": false
}
```

---

## 5. End-to-End OpenAPI 3.1.0 Interface Blueprint

The complete OpenAPI 3.1.0 specification unifies REST administrative routes, WORM verification endpoints, and WebSocket stream descriptions into a single API contract.

```yaml
openapi: 3.1.0
info:
  title: Safegrid Architectural Phase Contract API
  version: 1.0.0
  description: >
    Production API specification for Safegrid three-phase event processing,
    evidence vault verification, and dispatch execution.
servers:
  - url: /v1
    description: Primary Production API Gateway (mTLS Enforced)
paths:
  /events/candidate/stream:
    get:
      summary: Phase 1 Edge WebSocket Candidate Stream
      description: Real-time WebSocket connection for edge devices streaming candidate events over mTLS.
      responses:
        '101':
          description: Switching Protocols to WebSocket mTLS channel.
        '401':
          description: mTLS Client Certificate Missing or Invalid.

  /passports/seal:
    post:
      summary: Phase 2 Evidence Seal & Passport Generation
      description: Accepts arbitrated candidate events, validates G2 HITL assessment, generates WORM seal and CCT ledger record.
      requestBody:
        required: true
        content:
          application/json:
            schema:
              type: object
              required: [candidate_event, arbitration_verdict, site_profile_id]
              properties:
                candidate_event:
                  $ref: '#/components/schemas/CandidateEvent'
                arbitration_verdict:
                  type: string
                  enum: [ARM, HOLD, REJECT]
                site_profile_id:
                  type: string
      responses:
        '201':
          description: Incident Evidence Passport successfully sealed and locked in WORM storage.
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/IncidentEvidencePassport'
        '422':
          description: Arbitration failure or WORM write closed-fail abort.
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/ErrorResponse'

  /passports/verify/{passport_id}:
    get:
      summary: Verify Cryptographic Integrity of WORM Passport
      description: Recomputes SHA-256 CCT hash chain and verifies ML-DSA signature against on-chain root anchor.
      parameters:
        - name: passport_id
          in: path
          required: true
          schema:
            type: string
            format: uuid
      responses:
        '200':
          description: Cryptographic proof verification result.
          content:
            application/json:
              schema:
                type: object
                required: [passport_id, chain_valid, cct_sequence_id, merkle_proof]
                properties:
                  passport_id: { type: string, format: uuid }
                  chain_valid: { type: boolean }
                  cct_sequence_id: { type: integer }
                  merkle_proof:
                    type: array
                    items: { type: string }

  /dispatches/execute:
    post:
      summary: Phase 3 Operational Response Execution
      description: Initiates responder dispatch subject to G4 SLA clock (<=90s from passport seal).
      requestBody:
        required: true
        content:
          application/json:
            schema:
              type: object
              required: [passport_id, target_unit_id]
              properties:
                passport_id: { type: string, format: uuid }
                target_unit_id: { type: string }
      responses:
        '200':
          description: Response dispatched with biometric monitoring active.
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/DispatchAction'

components:
  schemas:
    CandidateEvent:
      type: object
      required: [event_id, timestamp_ns, ingestion_metadata, kinematic_telemetry, model_scores, g1_gate_status, edge_digest]
      properties:
        event_id: { type: string, format: uuid }
        timestamp_ns: { type: integer }
        ingestion_metadata:
          type: object
          properties:
            node_id: { type: string }
            mtls_client_fingerprint: { type: string }
            channel_protocol: { type: string, enum: [WEBSOCKET_MTLS, GRPC_MTLS] }
            sample_rate_hz: { type: number }
        kinematic_telemetry:
          type: object
          properties:
            imu_6dof:
              type: object
              properties:
                accel_x: { type: number }
                accel_y: { type: number }
                accel_z: { type: number }
                gyro_x: { type: number }
                gyro_y: { type: number }
                gyro_z: { type: number }
            zvu_applied: { type: boolean }
            estimated_drift_m: { type: number }
        model_scores:
          type: object
          properties:
            prithvi_eo_2_0: { type: number }
            msfmamba_tiny: { type: number }
            dtc: { type: number }
            iride_nimbus: { type: number }
            vision_fm_survey: { type: number }
        g1_gate_status:
          type: object
          properties:
            passed: { type: boolean }
            estimated_fpr: { type: number }
            status_code: { type: string }
        edge_digest: { type: string }

    IncidentEvidencePassport:
      type: object
      required: [passport_id, candidate_event_ref, arbitration, site_profile, g2_assessment, g3_worm_seal, sla_clock_origin]
      properties:
        passport_id: { type: string, format: uuid }
        candidate_event_ref:
          type: object
          properties:
            event_id: { type: string, format: uuid }
            payload_hash: { type: string }
        arbitration:
          type: object
          properties:
            verdict: { type: string, enum: [ARM, HOLD, REJECT] }
            agreeing_modalities_count: { type: integer }
        site_profile:
          type: object
          properties:
            site_id: { type: string }
            site_type: { type: string }
            active_threshold: { type: number }
        g2_assessment:
          type: object
          properties:
            requires_assessment: { type: boolean }
            human_verdict: { type: string }
            operator_id: { type: string }
            badge_assigned: { type: string }
        g3_worm_seal:
          type: object
          properties:
            previous_head_hash: { type: string }
            current_data_hash: { type: string }
            combined_seal_hash: { type: string }
            cct_global_sequence_id: { type: integer }
            worm_vault_uri: { type: string }
            ml_dsa_certificate:
              type: object
              properties:
                algorithm: { type: string }
                signature_hex: { type: string }
                boundary_policy_id: { type: string }
        sla_clock_origin: { type: string, format: date-time }

    DispatchAction:
      type: object
      required: [dispatch_id, passport_ref, dispatch_sla, responder_telemetry, environmental_context, ubuntu_consensus, responsibility_chain, execution_status]
      properties:
        dispatch_id: { type: string, format: uuid }
        passport_ref:
          type: object
          properties:
            passport_id: { type: string, format: uuid }
            combined_seal_hash: { type: string }
        dispatch_sla:
          type: object
          properties:
            clock_start_time: { type: string, format: date-time }
            dispatch_time: { type: string, format: date-time }
            elapsed_seconds: { type: number }
            target_max_seconds: { type: number }
            sla_met: { type: boolean }
        responder_telemetry:
          type: object
          properties:
            responder_id: { type: string }
            biometric_state:
              type: object
              properties:
                heart_rate_bpm: { type: integer }
                hrv_rmssd_ms: { type: number }
                physiological_stress_flag: { type: boolean }
                capsulenet_stress_score: { type: number }
            social_mode: { type: string }
        environmental_context:
          type: object
          properties:
            heat_index_c: { type: number }
            pm2_5_ug_m3: { type: number }
            ambient_lux: { type: number }
            low_light_mode_active: { type: boolean }
        ubuntu_consensus:
          type: object
          properties:
            matching_sources_count: { type: integer }
            total_sources_count: { type: integer }
            quorum_reached: { type: boolean }
            discrepancy_flag: { type: boolean }
        responsibility_chain:
          type: object
          properties:
            tier1_ai_hash: { type: string }
            tier2_human_hash: { type: string }
            tier3_execution_hash: { type: string }
            sequence_valid: { type: boolean }
        execution_status: { type: string }

    ErrorResponse:
      type: object
      required: [error_code, message, timestamp]
      properties:
        error_code: { type: string, enum: [REJECTED_BELOW_THRESHOLD, AUTHORIZATION_DENIED, WORM_WRITE_FAILED, SLA_EXCEEDED, QUORUM_FAILED] }
        message: { type: string }
        timestamp: { type: string, format: date-time }
```
