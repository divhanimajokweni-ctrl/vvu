# ProofBridge On-Chain TEE Attestation Validation Script
