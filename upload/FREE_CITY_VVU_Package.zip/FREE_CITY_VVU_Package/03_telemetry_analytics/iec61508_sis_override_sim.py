#!/usr/bin/env python3
"""
IEC 61508 Safety Instrumented System (SIS) & Autonomous Agent Override Simulator
----------------------------------------------------------------------------------
Demonstrates how an independent SIL 3 Safety Instrumented Function (SIF) block
operates deterministically below the DCS and LLM Agent layers, guaranteeing physical
safety trips override both control loop adjustments and AI agent supervisory recommendations.
"""

import time
import json
import hashlib
from datetime import datetime

class IEC61508_SafetyInstrumentedSystem:
    """
    Independent SIL 3 Safety Logic Solver (Hard Interlocks).
    Operates out-of-band from standard DCS/PLC control software and AI agents.
    """
    def __init__(self):
        # Physical SIL 3 Thresholds (Hardware Trips)
        self.HH_TEMP_TRIP_C = 42.0     # High-High Temperature Trip
        self.HH_PRESSURE_TRIP_BAR = 4.0 # High-High Pressure Trip
        
        # Physical Actuator States
        self.esd_valve_closed = False    # Emergency Shutdown Valve (ESD-101)
        self.quench_valve_open = False   # Emergency Quench Valve (XV-102)
        self.sis_tripped = False
        self.trip_reason = None

    def evaluate_safety_function(self, temp_pv: float, pressure_pv: float) -> dict:
        """
        Executes sub-10ms deterministic safety sweep.
        """
        if temp_pv >= self.HH_TEMP_TRIP_C or pressure_pv >= self.HH_PRESSURE_TRIP_BAR:
            self.sis_tripped = True
            self.esd_valve_closed = True
            self.quench_valve_open = True
            
            reasons = []
            if temp_pv >= self.HH_TEMP_TRIP_C:
                reasons.append(f"Temperature {temp_pv:.1f}°C >= HH Trip ({self.HH_TEMP_TRIP_C:.1f}°C)")
            if pressure_pv >= self.HH_PRESSURE_TRIP_BAR:
                reasons.append(f"Pressure {pressure_pv:.2f} bar >= HH Trip ({self.HH_PRESSURE_TRIP_BAR:.2f} bar)")
            
            self.trip_reason = " | ".join(reasons)
            
            return {
                "sis_status": "TRIPPED",
                "sil_level": "SIL 3",
                "esd_valve_101": "0% (HARD_CLOSED)",
                "quench_valve_102": "100% (HARD_OPEN)",
                "trip_reason": self.trip_reason,
                "control_lockout": True
            }
        
        return {
            "sis_status": "PERMISSIVE",
            "sil_level": "SIL 3",
            "esd_valve_101": "OPEN",
            "quench_valve_102": "CLOSED",
            "control_lockout": False
        }


class PlantProcessAndControlSystem:
    """
    Simulates DCS Continuous PID Loop and OPC UA Access Layer.
    """
    def __init__(self, sis: IEC61508_SafetyInstrumentedSystem):
        self.sis = sis
        self.temp_pv = 37.0
        self.temp_sp = 37.0
        self.pressure_pv = 2.0
        self.steam_valve_op = 40.0 # %

    def update_dcs_setpoint(self, new_sp: float, requesting_agent: str) -> dict:
        """
        Attempts to write a setpoint from DCS or LLM Agent via OPC UA.
        """
        # Step 1: Query SIS Hardware Lockout
        sis_state = self.sis.evaluate_safety_function(self.temp_pv, self.pressure_pv)
        
        if sis_state["control_lockout"]:
            return {
                "status": "REJECTED_BY_SIS_HARDWARE",
                "requestor": requesting_agent,
                "reason": f"IEC 61508 SIS Hard Lockout Active! Reason: {sis_state['trip_reason']}",
                "pv": self.temp_pv,
                "sp": self.temp_sp
            }

        # Step 2: Normal Setpoint Update
        old_sp = self.temp_sp
        self.temp_sp = new_sp
        return {
            "status": "ACCEPTED",
            "requestor": requesting_agent,
            "old_sp": old_sp,
            "new_sp": new_sp,
            "pv": self.temp_pv
        }


def run_sis_simulation():
    sis = IEC61508_SafetyInstrumentedSystem()
    dcs = PlantProcessAndControlSystem(sis)
    
    print("=" * 80)
    print("  IEC 61508 SIS (SAFETY INSTRUMENTED SYSTEM) HARDWARE TRIP SIMULATION")
    print("=" * 80)
    
    # -------------------------------------------------------------------------
    # SCENARIO 1: NORMAL OPERATING CONDITIONS (PERMISSIVE STATE)
    # -------------------------------------------------------------------------
    print("\n[SCENARIO 1: NORMAL STEADY-STATE OPERATION]")
    dcs.temp_pv = 37.2
    dcs.pressure_pv = 2.1
    
    sis_status = sis.evaluate_safety_function(dcs.temp_pv, dcs.pressure_pv)
    print(f"• Process Telemetry: Temp = {dcs.temp_pv}°C | Pressure = {dcs.pressure_pv} bar")
    print(f"• SIS Hardware Logic Solver: Status = {sis_status['sis_status']} ({sis_status['sil_level']})")
    
    agent_res1 = dcs.update_dcs_setpoint(36.8, "LangGraph_ProcessAgent")
    print(f"• Agent Setpoint Optimization Request: {agent_res1['status']} (New SP: {agent_res1.get('new_sp')}°C)")

    # -------------------------------------------------------------------------
    # SCENARIO 2: THERMAL RUNAWAY EXCURSION TRIGGERING IEC 61508 SIL 3 TRIP
    # -------------------------------------------------------------------------
    print("\n" + "=" * 80)
    print("[SCENARIO 2: CRITICAL THERMAL RUNAWAY & HARDWARE SIS TRIP]")
    print("=" * 80)
    
    # Excursion event occurs (e.g. cooling failure)
    dcs.temp_pv = 43.8 # Exceeds 42.0°C HH Trip
    dcs.pressure_pv = 4.2 # Exceeds 4.0 bar HH Trip
    
    print(f"\n[!] EXCURSION DETECTED: Temp = {dcs.temp_pv}°C | Pressure = {dcs.pressure_pv} bar")
    
    # SIS Hardware Logic Solver executes (sub-10ms)
    sis_trip_status = sis.evaluate_safety_function(dcs.temp_pv, dcs.pressure_pv)
    print(f"[!] SIS SIL 3 HARDWARE TRIP EXECUTED!")
    print(f"    - Trip State: {sis_trip_status['sis_status']}")
    print(f"    - Trip Reason: {sis_trip_status['trip_reason']}")
    print(f"    - ESD Valve 101: {sis_trip_status['esd_valve_101']}")
    print(f"    - Emergency Quench Valve 102: {sis_trip_status['quench_valve_102']}")
    
    # Now the AI Agent attempts to intervene or reset setpoint
    print("\n[!] AI AGENT SUPERVISORY INTERVENTION ATTEMPT:")
    agent_res2 = dcs.update_dcs_setpoint(35.0, "LangGraph_ProcessAgent")
    print(f"    - Request Status: {agent_res2['status']}")
    print(f"    - Override Reason: {agent_res2['reason']}")

    # Cryptographic Audit Log Block
    audit_payload = json.dumps(sis_trip_status, sort_keys=True)
    block_hash = hashlib.sha256(audit_payload.encode()).hexdigest()
    print(f"\n[+] Immutable Audit Block Generated (SHA-256): {block_hash}")

if __name__ == "__main__":
    run_sis_simulation()
