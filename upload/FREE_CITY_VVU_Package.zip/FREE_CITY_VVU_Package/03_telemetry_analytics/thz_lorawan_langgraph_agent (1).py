import json
import os
import urllib.request
import urllib.error
from typing import Dict, Any, TypedDict, List, Literal

# =====================================================================
# 1. TELEMETRY SCHEMAS & STATE DEFINITION
# =====================================================================

class TelemetryPayload(TypedDict):
    thz_latency_us: float      # 6G THz Wireless Fronthaul Latency (microseconds)
    thz_snr_db: float          # THz Signal-to-Noise Ratio (dB)
    lora_soil_moisture: float # Satellite-LoRaWAN Soil Moisture (%)
    lora_temp_c: float        # Satellite-LoRaWAN Temperature (°C)
    node_id: str

class AgentState(TypedDict):
    telemetry: TelemetryPayload
    anomaly_detected: bool
    anomaly_reason: str
    control_action: Dict[str, Any]
    status: str
    logs: List[str]

# =====================================================================
# 2. LOCAL LLAMA-SERVER HTTP CLIENT (GBNF / GRAMMAR CONSTRAINED)
# =====================================================================

LLAMA_SERVER_URL = os.getenv("LLAMA_SERVER_URL", "http://127.0.0.1:8080/v1/chat/completions")

def query_local_llama(prompt: str, json_schema: Dict[str, Any] = None) -> Dict[str, Any]:
    """
    Queries the local llama-server OpenAI-compatible endpoint.
    If json_schema is provided, enforces structured JSON decoding.
    """
    payload = {
        "model": "local-model",
        "messages": [
            {"role": "system", "content": "You are an autonomous SC3 (Sensing-Communication-Computing-Control) edge telemetry agent. Output strictly valid JSON."},
            {"role": "user", "content": prompt}
        ],
        "temperature": 0.1,
        "max_tokens": 512
    }
    
    if json_schema:
        payload["response_format"] = {
            "type": "json_object",
            "schema": json_schema
        }

    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        LLAMA_SERVER_URL,
        data=data,
        headers={"Content-Type": "application/json"}
    )
    
    try:
        with urllib.request.urlopen(req, timeout=5) as response:
            res_body = response.read().decode("utf-8")
            res_json = json.loads(res_body)
            content = res_json["choices"][0]["message"]["content"]
            return json.loads(content)
    except (urllib.error.URLError, Exception) as e:
        # Fallback heuristic evaluation if local llama-server is offline during simulation
        return None

# =====================================================================
# 3. LANGGRAPH NODE IMPLEMENTATIONS
# =====================================================================

def perceive_telemetry(state: AgentState) -> AgentState:
    """
    Node 1: Ingests 6G THz and Satellite-LoRaWAN telemetry streams.
    """
    telemetry = state["telemetry"]
    log_entry = (
        f"[PERCEIVE] Node {telemetry['node_id']} Ingested: "
        f"THz Latency={telemetry['thz_latency_us']}µs, SNR={telemetry['thz_snr_db']}dB | "
        f"LoRa Soil Moisture={telemetry['lora_soil_moisture']}%, Temp={telemetry['lora_temp_c']}°C"
    )
    state["logs"].append(log_entry)
    state["status"] = "PERCEIVED"
    return state

def evaluate_anomaly(state: AgentState) -> AgentState:
    """
    Node 2: Evaluates telemetry against operational thresholds using local LLM reasoning or fallback rule engine.
    Thresholds: THz Latency > 150µs (Fronthaul Degradation), Soil Moisture < 25.0% (Water Deficit)
    """
    telemetry = state["telemetry"]
    prompt = f"""
    Evaluate the following 6G THz and LoRaWAN telemetry payload:
    {json.dumps(telemetry)}
    
    Thresholds:
    - 6G THz Latency critical threshold: > 150.0 microseconds
    - LoRaWAN Soil Moisture critical threshold: < 25.0 percent
    
    Respond in JSON format:
    {{
        "anomaly_detected": boolean,
        "reason": "string describing the issue or Nominal"
    }}
    """
    
    # Attempt local llama-server query
    llm_res = query_local_llama(prompt)
    
    if llm_res:
        state["anomaly_detected"] = llm_res.get("anomaly_detected", False)
        state["anomaly_reason"] = llm_res.get("reason", "Evaluated by local LLM")
    else:
        # Local Rule-Engine Evaluation (Deterministic Fallback)
        reasons = []
        if telemetry["thz_latency_us"] > 150.0:
            reasons.append(f"THz Fronthaul Latency Spike ({telemetry['thz_latency_us']}µs > 150µs)")
        if telemetry["lora_soil_moisture"] < 25.0:
            reasons.append(f"Critical Soil Moisture Deficit ({telemetry['lora_soil_moisture']}% < 25%)")
            
        if reasons:
            state["anomaly_detected"] = True
            state["anomaly_reason"] = " | ".join(reasons)
        else:
            state["anomaly_detected"] = False
            state["anomaly_reason"] = "Nominal SC3 Operation"

    state["logs"].append(f"[EVALUATE] Anomaly Status: {state['anomaly_detected']} | Reason: {state['anomaly_reason']}")
    state["status"] = "EVALUATED"
    return state

def execute_control_action(state: AgentState) -> AgentState:
    """
    Node 3: Closed-Loop SC3 Control execution (e.g., THz beam switching, automated variable-rate irrigation).
    """
    telemetry = state["telemetry"]
    reason = state["anomaly_reason"]
    actions = []
    
    if "THz" in reason:
        actions.append({
            "subsystem": "6G_OpenRAN_Fronthaul",
            "action": "TRIGGER_AFDM_BEAM_RECONFIGURATION",
            "target_snr_gain_db": +4.5,
            "priority": "HIGH"
        })
    if "Soil" in reason:
        actions.append({
            "subsystem": "Precision_Irrigation",
            "action": "ACTIVATE_VARIABLE_RATE_IRRIGATION",
            "volume_liters_per_m2": 12.5,
            "duration_minutes": 45,
            "priority": "CRITICAL"
        })
        
    state["control_action"] = {"executed_actions": actions}
    state["logs"].append(f"[CONTROL] Closed-loop control executed: {json.dumps(actions)}")
    state["status"] = "CONTROL_EXECUTED"
    return state

def log_stable_state(state: AgentState) -> AgentState:
    """
    Node 4: Logs stable state when no operational intervention is required.
    """
    state["control_action"] = {"executed_actions": []}
    state["logs"].append("[STABLE] Telemetry within nominal SC3 control envelope. No intervention required.")
    state["status"] = "STABLE"
    return state

# =====================================================================
# 4. STATE MACHINE PIPELINE EXECUTION
# =====================================================================

def run_agent_pipeline(telemetry: TelemetryPayload) -> AgentState:
    """
    Executes the perceive -> evaluate -> (control OR stable) agent state machine.
    """
    initial_state: AgentState = {
        "telemetry": telemetry,
        "anomaly_detected": False,
        "anomaly_reason": "",
        "control_action": {},
        "status": "INITIALIZED",
        "logs": []
    }
    
    # Node 1: Perceive
    state = perceive_telemetry(initial_state)
    
    # Node 2: Evaluate
    state = evaluate_anomaly(state)
    
    # Conditional Edge Routing
    if state["anomaly_detected"]:
        state = execute_control_action(state)
    else:
        state = log_stable_state(state)
        
    return state

# =====================================================================
# 5. SIMULATION SUITE
# =====================================================================

if __name__ == "__main__":
    print("=================================================================")
    print("  ON-PREMISE LOCAL AGENT STACK: 6G THz / LoRaWAN TELEMETRY LOOP  ")
    print("=================================================================\n")
    
    # Test Scenario A: Nominal Telemetry
    nominal_payload: TelemetryPayload = {
        "node_id": "SISHEN_NORTH_01",
        "thz_latency_us": 82.4,
        "thz_snr_db": 28.1,
        "lora_soil_moisture": 34.2,
        "lora_temp_c": 24.5
    }
    
    print("--- SCENARIO A: NOMINAL TELEMETRY STREAM ---")
    res_a = run_agent_pipeline(nominal_payload)
    for log in res_a["logs"]:
        print(log)
    print(f"Final Status: {res_a['status']}\n")
    
    # Test Scenario B: Dual Anomaly (THz Latency Spike + Critical Soil Moisture Deficit)
    anomaly_payload: TelemetryPayload = {
        "node_id": "SISHEN_SOUTH_04",
        "thz_latency_us": 194.8,  # > 150.0µs Threshold
        "thz_snr_db": 11.2,
        "lora_soil_moisture": 18.3, # < 25.0% Threshold
        "lora_temp_c": 31.8
    }
    
    print("--- SCENARIO B: DUAL ANOMALY TELEMETRY STREAM ---")
    res_b = run_agent_pipeline(anomaly_payload)
    for log in res_b["logs"]:
        print(log)
    print(f"Executed Control Actions:\n{json.dumps(res_b['control_action'], indent=2)}")
    print(f"Final Status: {res_b['status']}\n")
    print("=================================================================")
