#!/usr/bin/env python3
"""
Safegrid End-to-End Pipeline Integration Benchmark
===================================================
Simulates the complete 3-Phase sequential pipeline execution:
  Phase 1: CAPTURE & INFERENCE  -> candidate_event (Ed25519 signed)
  Phase 2: VERIFY & SEAL        -> IncidentEvidencePassport (WORM sealed)
  Phase 3: RESPOND & PROTECT    -> committed_execution_record (Ubuntu consensus & SLA verified)

Grounding:
- Proof obligations & 5 trust primitives [# The Ideal Package]
- Hardware attestation & ZVU drift elimination [# ◢◣ The Foundation Stone Is Laid]
- WORM chain, multi-modality arbitration, 90s SLA clock at seal, Ubuntu consensus [Safegrid Specs & VVU Trust UI]
"""

import json
import time
import hashlib
import os
import sys
from datetime import datetime, timezone
from typing import Dict, Any, List, Tuple

# Cryptography check
try:
    from cryptography.hazmat.primitives.asymmetric import ed25519
    from cryptography.hazmat.primitives import serialization
    HAS_CRYPTO = True
except ImportError:
    HAS_CRYPTO = False

# ==============================================================================
# PHASE 1: CAPTURE & INFERENCE
# ==============================================================================

class TrustRoot:
    TEE_DEVICE_NODES = [
        "/dev/sev-guest",
        "/sys/devices/virtual/misc/sev_guest",
        "/dev/sgx_enclave",
        "/dev/nsm",
        "/dev/tee0"
    ]

    def __init__(self):
        self.tier, self.device_path = self._probe_tee_tier()
        if HAS_CRYPTO:
            self._private_key = ed25519.Ed25519PrivateKey.generate()
            self._public_key = self._private_key.public_key()
            self.public_key_hex = self._public_key.public_bytes(
                encoding=serialization.Encoding.Raw,
                format=serialization.PublicFormat.Raw
            ).hex()
        else:
            self.public_key_hex = hashlib.sha256(b"T2_HMAC_KEY").hexdigest()

    def _probe_tee_tier(self) -> Tuple[str, str]:
        for node in self.TEE_DEVICE_NODES:
            if os.path.exists(node):
                return "T0 · Ed25519 (Hardware TEE)", node
        return "T1 · Ed25519 (Software)", "none"

    def sign(self, data: bytes) -> str:
        if HAS_CRYPTO:
            return self._private_key.sign(data).hex()
        return hashlib.sha256(data + b"_hmac_key").hexdigest()

    def verify(self, data: bytes, signature_hex: str) -> bool:
        if HAS_CRYPTO:
            try:
                self._public_key.verify(bytes.fromhex(signature_hex), data)
                return True
            except Exception:
                return False
        expected = hashlib.sha256(data + b"_hmac_key").hexdigest()
        return expected == signature_hex

class SignalConditioner:
    """Applies gravity compensation, double Euler integration, and ZVU drift elimination."""
    def condition_imu_sample(self, accel: List[float], gyro: List[float], dt: float = 0.025) -> Tuple[List[float], List[float], bool]:
        accel_comp = [accel[0], accel[1], accel[2] - 9.81]
        accel_mag = sum(a**2 for a in accel_comp)**0.5
        gyro_mag = sum(g**2 for g in gyro)**0.5
        is_stationary = (accel_mag < 0.25) and (gyro_mag < 0.05)
        
        velocity = [0.0, 0.0, 0.0] if is_stationary else [accel_comp[i] * dt for i in range(3)]
        displacement = [velocity[i] * dt for i in range(3)]
        return velocity, displacement, is_stationary

class Phase1Pipeline:
    def __init__(self, trust_root: TrustRoot):
        self.trust_root = trust_root
        self.conditioner = SignalConditioner()
        self.default_model_floors = {
            "DTC": 0.70,
            "PRITHVI_EO_2_0": 0.75,
            "MSFMAMBA_TINY": 0.72,
            "IRIDE_NIMBUS": 0.70,
            "VISION_FM_SURVEY": 0.75
        }

    def process_telemetry(self, raw_telemetry: Dict[str, Any], site_id: str, custom_floors: Dict[str, float] = None) -> Tuple[bool, Dict[str, Any], str]:
        vel, disp, stationary = self.conditioner.condition_imu_sample(
            raw_telemetry["imu_accel"], raw_telemetry["imu_gyro"]
        )

        model_evals = raw_telemetry.get("model_scores", {})
        floors = custom_floors or self.default_model_floors

        failed_floors = []
        for model_name in model_evals.keys():
            floor = floors.get(model_name, 0.70)
            score = model_evals[model_name]
            if score < floor:
                failed_floors.append(f"{model_name} ({score:.2f} < {floor:.2f})")

        if failed_floors:
            return False, {}, f"REJECTED_BELOW_THRESHOLD (Models failed floor: {', '.join(failed_floors)})"

        fpr = raw_telemetry.get("estimated_fpr", 0.05)
        if fpr > 0.08:
            return False, {}, f"REJECTED_BELOW_THRESHOLD (FPR {fpr:.3f} > 0.08 ceiling)"

        avg_confidence = sum(model_evals.values()) / len(model_evals)

        candidate_payload = {
            "event_id": f"EVT-{int(time.time()*1000)}",
            "site_id": site_id,
            "timestamp_iso": datetime.now(timezone.utc).isoformat(),
            "attestation_tier": self.trust_root.tier,
            "kinematic_state": {
                "velocity": vel,
                "displacement": disp,
                "zvu_active": stationary
            },
            "model_evaluations": [
                {"model": m, "score": s, "passed": True, "modality": "IMU" if m in ["DTC", "MSFMAMBA_TINY"] else "OPTICAL"}
                for m, s in model_evals.items()
            ],
            "consensus_confidence": round(avg_confidence, 4),
            "estimated_fpr": fpr,
            "public_key": self.trust_root.public_key_hex
        }

        canonical_bytes = json.dumps(candidate_payload, sort_keys=True).encode("utf-8")
        payload_hash = hashlib.sha256(canonical_bytes).hexdigest()
        signature = self.trust_root.sign(canonical_bytes)

        candidate_event = {
            "payload": candidate_payload,
            "payload_hash": payload_hash,
            "signature": signature
        }

        return True, candidate_event, "CANDIDATE_GENERATED"

# ==============================================================================
# PHASE 2: VERIFY & SEAL (ARBITRATION & WORM EVIDENCE VAULT)
# ==============================================================================

class Phase2Pipeline:
    SITE_THRESHOLDS = {
        "CORPORATE_HQ": {"min_modalities": 2, "single_high_threshold": 0.99},
        "DATA_CENTER": {"min_modalities": 1, "single_high_threshold": 0.99},
        "MINING_OPERATIONS": {"min_modalities": 2, "single_high_threshold": 0.99},
        "HIGHWAY_CORRIDOR": {"min_modalities": 1, "single_high_threshold": 0.90}
    }

    def __init__(self, trust_root: TrustRoot, vault_path: str = "/workspace/scratch/worm_vault.jsonl"):
        self.trust_root = trust_root
        self.vault_path = vault_path
        self.previous_head = "GENESIS_HEAD_00000000000000000000000000000000000000000000000000000000"

    def arbitrate(self, candidate_event: Dict[str, Any]) -> Tuple[str, str]:
        payload = candidate_event["payload"]
        site_id = payload["site_id"]
        evals = payload["model_evaluations"]
        policy = self.SITE_THRESHOLDS.get(site_id, {"min_modalities": 2, "single_high_threshold": 0.99})

        active_modalities = set(item["modality"] for item in evals if item["passed"])
        modality_count = len(active_modalities)
        max_score = max(item["score"] for item in evals)

        if modality_count >= policy["min_modalities"]:
            return "ARM", f"Corroborated across {modality_count} independent modalities ({', '.join(active_modalities)})"
        elif max_score >= policy["single_high_threshold"]:
            return "ARM", f"Single-modality high-confidence override ({max_score:.2f} >= {policy['single_high_threshold']})"
        elif modality_count == 1:
            return "HOLD", "Uncorroborated single-modality detection requires mandatory human review"
        else:
            return "REJECT", "No armed modalities passed threshold"

    def seal_evidence_passport(self, candidate_event: Dict[str, Any], verdict: str, arb_reason: str, force_worm_fail: bool = False) -> Tuple[bool, Dict[str, Any], str]:
        if verdict == "REJECT":
            return False, {}, "EVENT_REJECTED_IN_ARBITRATION"
        
        seal_time = datetime.now(timezone.utc).isoformat()
        
        passport_data = {
            "passport_id": f"PASSPORT-{hashlib.sha256(seal_time.encode()).hexdigest()[:8].upper()}",
            "candidate_event_hash": candidate_event["payload_hash"],
            "site_id": candidate_event["payload"]["site_id"],
            "verdict": verdict,
            "arbitration_reason": arb_reason,
            "badge": "MULTI-MODAL · CORROBORATED" if verdict == "ARM" else "SINGLE-SOURCE · CONFIDENCE UNCORROBORATED",
            "sealed_at_iso": seal_time,
            "sla_clock_origin_iso": seal_time,  # Clock STARTS at seal!
            "previous_head_hash": self.previous_head
        }

        canonical_passport = json.dumps(passport_data, sort_keys=True).encode("utf-8")
        passport_hash = hashlib.sha256(self.previous_head.encode() + canonical_passport).hexdigest()
        signature = self.trust_root.sign(canonical_passport)

        passport_entry = {
            "passport_data": passport_data,
            "passport_hash": passport_hash,
            "signature": signature
        }

        if force_worm_fail:
            return False, {}, "FAIL_CLOSED: WORM Evidence Vault storage write failed. Action aborted."

        try:
            with open(self.vault_path, "a") as f:
                f.write(json.dumps(passport_entry) + "\n")
            self.previous_head = passport_hash
        except Exception as e:
            return False, {}, f"FAIL_CLOSED: WORM write error: {str(e)}"

        return True, passport_entry, "PASSPORT_SEALED"

# ==============================================================================
# PHASE 3: RESPOND & PROTECT (EXECUTION & BIOMETRIC RECONCILIATION)
# ==============================================================================

class Phase3Pipeline:
    def __init__(self, trust_root: TrustRoot):
        self.trust_root = trust_root

    def evaluate_biometric_telemetry(self, baseline_hr: float, current_hr: float, duration_sec: float) -> str:
        hr_delta = current_hr - baseline_hr
        if hr_delta >= 30.0 and duration_sec <= 5.0:
            return "DURESS_DETECTED"
        elif hr_delta >= 15.0:
            return "ELEVATED_STRESS"
        return "NORMAL_BASELINE"

    def reconcile_ubuntu_consensus(self, telemetry_sources: Dict[str, Any]) -> Tuple[str, List[str]]:
        claimed_loc = telemetry_sources.get("guard_claim_loc")
        gps_loc = telemetry_sources.get("phone_gps_loc")
        rfid_gate = telemetry_sources.get("rfid_gate_loc")
        
        discrepancies = []
        if claimed_loc != gps_loc:
            discrepancies.append(f"GPS mismatch: claim={claimed_loc}, gps={gps_loc}")
        if gps_loc != rfid_gate:
            discrepancies.append(f"RFID mismatch: gps={gps_loc}, rfid={rfid_gate}")

        if len(discrepancies) > 0:
            return "AUDIT_TRIGGERED", discrepancies
        return "VERIFIED_CONSENSUS", []

    def execute_dispatch(self, passport_entry: Dict[str, Any], guard_telemetry: Dict[str, Any], execution_quorum: int = 20) -> Tuple[bool, Dict[str, Any], str]:
        passport_data = passport_entry["passport_data"]
        seal_time = datetime.fromisoformat(passport_data["sla_clock_origin_iso"])
        now = datetime.now(timezone.utc)
        elapsed_sec = (now - seal_time).total_seconds()

        max_sla = 60.0 if passport_data["site_id"] == "HIGHWAY_CORRIDOR" else 90.0
        if elapsed_sec > max_sla:
            return False, {}, f"SLA_BREACHED ({elapsed_sec:.2f}s > {max_sla}s max threshold)"

        bio_status = self.evaluate_biometric_telemetry(
            guard_telemetry["baseline_hr"],
            guard_telemetry["current_hr"],
            guard_telemetry["spike_duration_sec"]
        )

        reconcile_status, discrepancies = self.reconcile_ubuntu_consensus(guard_telemetry["sources"])
        inclusion_status = "COMMITTED" if execution_quorum >= 18 else "INCLUSION_PENDING"

        record_data = {
            "execution_id": f"EXEC-{hashlib.sha256(str(time.time()).encode()).hexdigest()[:8].upper()}",
            "passport_hash": passport_entry["passport_hash"],
            "elapsed_sla_sec": round(elapsed_sec, 3),
            "max_sla_allowed_sec": max_sla,
            "sla_compliant": elapsed_sec <= max_sla,
            "biometric_status": bio_status,
            "ubuntu_reconciliation": reconcile_status,
            "discrepancy_details": discrepancies,
            "quorum_count": execution_quorum,
            "inclusion_status": inclusion_status,
            "executed_at_iso": now.isoformat()
        }

        canonical_rec = json.dumps(record_data, sort_keys=True).encode("utf-8")
        rec_hash = hashlib.sha256(canonical_rec).hexdigest()
        signature = self.trust_root.sign(canonical_rec)

        execution_record = {
            "record": record_data,
            "record_hash": rec_hash,
            "signature": signature
        }

        return True, execution_record, "EXECUTION_RECORD_COMMITTED"

# ==============================================================================
# INTEGRATION BENCHMARK SUITE
# ==============================================================================

def run_integration_benchmark():
    print("=" * 80)
    print("SAFEGRID END-TO-END PIPELINE INTEGRATION BENCHMARK")
    print("=" * 80)

    start_perf = time.perf_counter()
    trust_root = TrustRoot()
    p1 = Phase1Pipeline(trust_root)
    p2 = Phase2Pipeline(trust_root)
    p3 = Phase3Pipeline(trust_root)

    print(f"[*] Attestation Tier: {trust_root.tier}")
    print(f"[*] Public Key Hex:   {trust_root.public_key_hex[:32]}...\n")

    # TEST 1: Full Successful Pipeline (Corporate HQ)
    print("[TEST 1] Executing End-to-End Pipeline (Corporate HQ Multi-Modal)...")
    raw_telemetry = {
        "imu_accel": [0.12, -0.05, 9.82],
        "imu_gyro": [0.01, 0.02, -0.01],
        "model_scores": {
            "DTC": 0.88,
            "PRITHVI_EO_2_0": 0.91,
            "MSFMAMBA_TINY": 0.85,
            "IRIDE_NIMBUS": 0.89,
            "VISION_FM_SURVEY": 0.94
        },
        "estimated_fpr": 0.03
    }

    t0_p1 = time.perf_counter()
    ok1, candidate, msg1 = p1.process_telemetry(raw_telemetry, site_id="CORPORATE_HQ")
    dt_p1 = (time.perf_counter() - t0_p1) * 1000.0
    assert ok1, f"P1 failed: {msg1}"
    print(f"  [Phase 1] Candidate Generated in {dt_p1:.2f}ms. Hash: {candidate['payload_hash'][:16]}...")

    t0_p2 = time.perf_counter()
    verdict, arb_reason = p2.arbitrate(candidate)
    assert verdict == "ARM", f"P2 arbitration failed: {verdict}"
    ok2, passport, msg2 = p2.seal_evidence_passport(candidate, verdict, arb_reason)
    dt_p2 = (time.perf_counter() - t0_p2) * 1000.0
    assert ok2, f"P2 seal failed: {msg2}"
    print(f"  [Phase 2] Sealed Evidence Passport in {dt_p2:.2f}ms. Passport ID: {passport['passport_data']['passport_id']}")

    t0_p3 = time.perf_counter()
    guard_telemetry = {
        "baseline_hr": 65.0,
        "current_hr": 78.0,
        "spike_duration_sec": 10.0,
        "sources": {
            "guard_claim_loc": "-25.746, 28.188",
            "phone_gps_loc": "-25.746, 28.188",
            "rfid_gate_loc": "-25.746, 28.188"
        }
    }
    ok3, exec_rec, msg3 = p3.execute_dispatch(passport, guard_telemetry, execution_quorum=22)
    dt_p3 = (time.perf_counter() - t0_p3) * 1000.0
    assert ok3, f"P3 execution failed: {msg3}"
    print(f"  [Phase 3] Execution Record Committed in {dt_p3:.2f}ms. Exec ID: {exec_rec['record']['execution_id']}")
    print("  --> PASS: Full pipeline executed in {:.2f}ms total.\n".format(dt_p1 + dt_p2 + dt_p3))

    # TEST 2: Single-Modality Event Routing to HOLD
    print("[TEST 2] Executing Single-Modality Event at Mining Site (Expecting HOLD)...")
    raw_single_modality = {
        "imu_accel": [0.10, -0.02, 9.80],
        "imu_gyro": [0.01, 0.01, 0.00],
        "model_scores": {
            "DTC": 0.85,
            "MSFMAMBA_TINY": 0.88  # Only IMU modality models present (score < 0.99)
        },
        "estimated_fpr": 0.04
    }

    ok1_single, candidate_single, _ = p1.process_telemetry(
        raw_single_modality, 
        site_id="MINING_OPERATIONS",
        custom_floors={"DTC": 0.70, "MSFMAMBA_TINY": 0.72}
    )
    assert ok1_single
    verdict_single, reason_single = p2.arbitrate(candidate_single)
    assert verdict_single == "HOLD", f"Expected HOLD, got {verdict_single}"
    print(f"  --> PASS: Single-modality detection correctly routed to HOLD badge: '{candidate_single['payload']['site_id']}'\n")

    # TEST 3: WORM Fault Fail-Closed Enforcement
    print("[TEST 3] Testing WORM Storage Fault (Fail-Closed Abort)...")
    ok_worm, _, msg_worm = p2.seal_evidence_passport(candidate, "ARM", "Corroborated", force_worm_fail=True)
    assert not ok_worm
    assert "FAIL_CLOSED" in msg_worm
    print(f"  --> PASS: WORM write fault triggered fail-closed abort: '{msg_worm}'\n")

    # TEST 4: Biometric Duress & Ubuntu Discrepancy Reconciliation
    print("[TEST 4] Testing Responder Duress & Ubuntu Consensus Discrepancy...")
    guard_duress = {
        "baseline_hr": 65.0,
        "current_hr": 98.0,  # +33 bpm spike
        "spike_duration_sec": 4.0,  # in 4s
        "sources": {
            "guard_claim_loc": "GATE_A",
            "phone_gps_loc": "GATE_B",  # Discrepancy!
            "rfid_gate_loc": "GATE_A"
        }
    }
    bio_res = p3.evaluate_biometric_telemetry(guard_duress["baseline_hr"], guard_duress["current_hr"], guard_duress["spike_duration_sec"])
    rec_res, disc_details = p3.reconcile_ubuntu_consensus(guard_duress["sources"])
    assert bio_res == "DURESS_DETECTED"
    assert rec_res == "AUDIT_TRIGGERED"
    print(f"  --> PASS: Biometric Duress ({bio_res}) & Ubuntu Discrepancy Audit ({rec_res}) verified.\n")

    total_perf = (time.perf_counter() - start_perf) * 1000.0
    print("=" * 80)
    print(f"ALL END-TO-END INTEGRATION BENCHMARK TESTS PASSED (4/4 PASS) in {total_perf:.2f}ms")
    print("=" * 80)

if __name__ == "__main__":
    run_integration_benchmark()
