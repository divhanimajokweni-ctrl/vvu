import os
import sys
import json
import hashlib
import hmac
import socket
import subprocess
import shutil
import inspect
from pathlib import Path
from dataclasses import dataclass, field, asdict
from typing import List, Dict, Any, Optional

# ==============================================================================
# VVU SUITE CORE & RESOLVERS
# ==============================================================================

GENESIS = "0x" + "00" * 32
GENESIS_SEED = bytes.fromhex("9c2f7b1a3d5e8f0c1a4b6d8e2f0c3a5b7d9e1f3a5c7b9d1e3f5a7c9b1d3e5f70")

def canonical(obj: Any) -> bytes:
    """Deterministic JSON canonicalization."""
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str).encode("utf-8")

def sha256_hex(data: Any) -> str:
    """Compute SHA-256 hex string with 0x prefix."""
    if not isinstance(data, (bytes, bytearray)):
        data = canonical(data)
    return "0x" + hashlib.sha256(data).hexdigest()

try:
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    from cryptography.hazmat.primitives import serialization as _ser
    _HAVE_ED25519 = True
except ImportError:
    _HAVE_ED25519 = False

def probe_sev_snp() -> str:
    """Honest hardware TEE probe."""
    for p in (Path("/sys/devices/virtual/misc/sev_guest"), Path("/dev/sev-guest")):
        if p.exists():
            return "present"
    return "unsupported"

class KeyRing:
    """Key management supporting T0 Ed25519 and T1 HMAC-SHA256 dev fallback."""
    def __init__(self, keydir: Path):
        self.dir = Path(keydir)
        self.dir.mkdir(parents=True, exist_ok=True)
        sev_status = probe_sev_snp()
        if _HAVE_ED25519:
            self.tier = f"T0 · Ed25519 ({'Hardware TEE' if sev_status == 'present' else 'Software'})"
        else:
            self.tier = "T1 · HMAC-SHA256 (dev)"
        self._load()

    def _load(self):
        if _HAVE_ED25519:
            p = self.dir / "ed25519.priv"
            if p.exists():
                self._priv = Ed25519PrivateKey.from_private_bytes(bytes.fromhex(p.read_text().strip()))
            else:
                self._priv = Ed25519PrivateKey.generate()
                raw = self._priv.private_bytes(
                    encoding=_ser.Encoding.Raw,
                    format=_ser.PrivateFormat.Raw,
                    encryption_algorithm=_ser.NoEncryption()
                )
                p.write_text(raw.hex())
                os.chmod(p, 0o600)
            self._pub = self._priv.public_key().public_bytes(
                encoding=_ser.Encoding.Raw,
                format=_ser.PublicFormat.Raw
            ).hex()
        else:
            p = self.dir / "hmac.key"
            if p.exists():
                self._priv = bytes.fromhex(p.read_text().strip())
            else:
                self._priv = os.urandom(32)
                p.write_text(self._priv.hex())
                os.chmod(p, 0o600)
            self._pub = hashlib.sha256(self._priv).hexdigest()

    @property
    def pubkey(self) -> str:
        return self._pub

    def sign(self, data: bytes) -> str:
        if _HAVE_ED25519:
            return self._priv.sign(data).hex()
        return hmac.new(self._priv, data, hashlib.sha256).hexdigest()

    def verify(self, data: bytes, sig_hex: str) -> bool:
        if _HAVE_ED25519:
            try:
                self._priv.public_key().verify(bytes.fromhex(sig_hex), data)
                return True
            except Exception:
                return False
        expected = hmac.new(self._priv, data, hashlib.sha256).hexdigest()
        return hmac.compare_digest(expected, sig_hex)

class Chain:
    """WORM Hash-Chained Ledger."""
    def __init__(self, path: Path, name: str, signer: Optional[KeyRing] = None):
        self.path = Path(path)
        self.name = name
        self.signer = signer
        self.head = GENESIS
        self.entries: List[dict] = []
        if self.path.exists():
            try:
                doc = json.loads(self.path.read_text())
                self.head = doc.get("head", GENESIS)
                self.entries = doc.get("entries", [])
            except Exception:
                pass

    def _save(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_suffix(self.path.suffix + ".tmp")
        tmp.write_text(json.dumps(
            {"name": self.name, "head": self.head, "entries": self.entries[:1500]},
            indent=2, ensure_ascii=False
        ))
        tmp.replace(self.path)

    def twin_t(self) -> float:
        return float(len(self.entries))

    def append(self, kind: str, payload: dict) -> dict:
        e = {
            "prev": self.head,
            "kind": kind,
            "twin_t": self.twin_t(),
            "chain": self.name,
            "payload": payload
        }
        if self.signer is not None:
            e["sig"] = self.signer.sign(canonical(e))
        e["hash"] = sha256_hex(e)
        self.head = e["hash"]
        self.entries.insert(0, e)
        if len(self.entries) > 3000:
            self.entries = self.entries[:3000]
        self._save()
        return e

    def verify(self) -> bool:
        prev = GENESIS
        for e in reversed(self.entries):
            if e["prev"] != prev:
                return False
            check = {k: v for k, v in e.items() if k != "hash"}
            if sha256_hex(check) != e["hash"]:
                return False
            prev = e["hash"]
        return prev == self.head


# ==============================================================================
# THREE-PHASE STATE TRANSITION INSTALLER CONTRACT
# ==============================================================================

def probe_environment_state(workspace_root: Path) -> dict:
    """Probe host environment state cleanly for before/after comparison."""
    probes = {
        "python_version": sys.version.split()[0],
        "platform": sys.platform,
        "sev_snp": probe_sev_snp(),
        "cryptography_present": _HAVE_ED25519,
        "workspace_exists": workspace_root.exists(),
        "workspace_dirs": sorted([d.name for d in workspace_root.iterdir() if d.is_dir()]) if workspace_root.exists() else [],
        "env_path_hash": sha256_hex(os.environ.get("PATH", "").encode("utf-8"))
    }
    probe_set_keys = sorted(probes.keys())
    probe_set_hash = sha256_hex(probe_set_keys)
    return {
        "probes": probes,
        "probe_set_hash": probe_set_hash
    }

def attest_record(body: dict, keyring: KeyRing, chain_prev: str) -> dict:
    """Attest a probe or installer record with a signature and self_hash."""
    record_for_sig = {**body, "chain_prev": chain_prev}
    sig = keyring.sign(canonical(record_for_sig))
    self_hash = sha256_hex({**record_for_sig, "sig": sig})
    return {
        "self_hash": self_hash,
        "chain_prev": chain_prev,
        "pubkey": keyring.pubkey,
        "sig": sig,
        "tier": keyring.tier
    }

def verify_attested_record(record: dict, keyring: Optional[KeyRing] = None) -> dict:
    """Verify record's internal attestation self_hash and signature."""
    att = record.get("attestation")
    if not att:
        return {"ok": False, "reason": "missing attestation block"}
    
    body = {k: v for k, v in record.items() if k != "attestation"}
    record_for_sig = {**body, "chain_prev": att["chain_prev"]}
    
    if keyring:
        valid_sig = keyring.verify(canonical(record_for_sig), att["sig"])
        if not valid_sig:
            return {"ok": False, "reason": "signature verification failed"}
            
    recomputed_hash = sha256_hex({**record_for_sig, "sig": att["sig"]})
    if recomputed_hash != att["self_hash"]:
        return {"ok": False, "reason": "self_hash mismatch"}
        
    return {"ok": True}

def diff_records(before: dict, after: dict) -> dict:
    """Compute deterministic diff between before and after probe records."""
    b_probes = before.get("probes", {})
    a_probes = after.get("probes", {})
    all_keys = sorted(list(set(b_probes.keys()) | set(a_probes.keys())))
    diff = {}
    for k in all_keys:
        bv = b_probes.get(k)
        av = a_probes.get(k)
        if bv == av:
            diff[k] = {"before": bv, "after": av, "delta": "same"}
        elif bv is None:
            diff[k] = {"before": None, "after": av, "delta": "added"}
        elif av is None:
            diff[k] = {"before": bv, "after": None, "delta": "removed"}
        else:
            diff[k] = {"before": bv, "after": av, "delta": "changed"}
    return diff

def build_install_receipt(
    before_record: dict,
    after_record: dict,
    steps: List[dict],
    installer_version: str,
    platform: str,
    keyring: KeyRing,
    chain: Chain
) -> dict:
    """Build the state transition receipt, sign it, and commit to the chain."""
    diff = diff_records(before_record, after_record)
    diff_hash = sha256_hex(diff)

    b_psh = before_record.get("probe_set_hash")
    a_psh = after_record.get("probe_set_hash")
    comparable = (b_psh is not None and a_psh is not None and b_psh == a_psh)

    body = {
        "receipt_version": "1.0.0",
        "installer_version": installer_version,
        "platform": platform,
        "before": {
            "self_hash": before_record.get("attestation", {}).get("self_hash"),
            "chain_prev": before_record.get("attestation", {}).get("chain_prev"),
            "probe_set_hash": b_psh,
        },
        "after": {
            "self_hash": after_record.get("attestation", {}).get("self_hash"),
            "chain_prev": after_record.get("attestation", {}).get("chain_prev"),
            "probe_set_hash": a_psh,
        },
        "steps": steps,
        "diff_hash": diff_hash,
        "comparable": comparable,
        "n_probes_changed": sum(1 for v in diff.values() if v["delta"] != "same"),
        "n_steps": len(steps),
    }

    att = attest_record(body, keyring, chain.head)
    receipt = {**body, "attestation": att}
    chain.append("install_receipt", receipt)
    return receipt

def verify_install_receipt(
    receipt: dict,
    before_record: dict,
    after_record: dict,
    keyring: Optional[KeyRing] = None
) -> dict:
    """
    Stranger's verification gate:
    1. Verifies receipt's signature & self_hash.
    2. Compares referenced before/after self_hashes against actual records.
    3. Recomputes state diff and verifies diff_hash.
    4. Checks probe set comparability.
    """
    r_att = verify_attested_record(receipt, keyring)
    if not r_att["ok"]:
        return {"ok": False, "reason": "receipt attestation: " + r_att["reason"]}

    b_self = before_record.get("attestation", {}).get("self_hash")
    a_self = after_record.get("attestation", {}).get("self_hash")

    if receipt["before"]["self_hash"] != b_self:
        return {"ok": False, "reason": f"before self_hash mismatch: expected {b_self}, got {receipt['before']['self_hash']}"}
    if receipt["after"]["self_hash"] != a_self:
        return {"ok": False, "reason": f"after self_hash mismatch: expected {a_self}, got {receipt['after']['self_hash']}"}

    b_att = verify_attested_record(before_record, keyring)
    a_att = verify_attested_record(after_record, keyring)
    if not b_att["ok"]:
        return {"ok": False, "reason": "before record attestation invalid: " + b_att["reason"]}
    if not a_att["ok"]:
        return {"ok": False, "reason": "after record attestation invalid: " + a_att["reason"]}

    fresh_diff = diff_records(before_record, after_record)
    if sha256_hex(fresh_diff) != receipt["diff_hash"]:
        return {"ok": False, "reason": "diff_hash mismatch between before and after records"}

    if not receipt.get("comparable", False):
        return {"ok": False, "reason": "records not comparable (probe set hashes differ)"}

    return {
        "ok": True,
        "receipt_version": receipt["receipt_version"],
        "installer_version": receipt["installer_version"],
        "platform": receipt["platform"],
        "n_steps": receipt["n_steps"],
        "n_probes_changed": receipt["n_probes_changed"],
        "self_hash": receipt["attestation"]["self_hash"],
        "tier": receipt["attestation"]["tier"],
    }


# ==============================================================================
# INSTALLATION SUITE DEMONSTRATION & TAMPER VERIFICATION
# ==============================================================================

def run_installation_suite(target_root: Path):
    print("=" * 70)
    print("      VVU SUITE THREE-PHASE STATE TRANSITION INSTALLER DEMO      ")
    print("=" * 70)

    # Setup Installer KeyRing & Chain
    inst_keydir = target_root / "keys"
    inst_chainpath = target_root / "chains" / "installer.json"
    keyring = KeyRing(inst_keydir)
    chain = Chain(inst_chainpath, "installer", keyring)

    print(f"▸ Installer KeyRing Tier: {keyring.tier}")
    print(f"▸ Installer Public Key  : {keyring.pubkey[:32]}…")

    # PHASE 1: Probe Before
    print("\n--- PHASE 1: PROBE-BEFORE ---")
    before_raw = probe_environment_state(target_root)
    before_att = attest_record(before_raw, keyring, chain.head)
    before_record = {**before_raw, "attestation": before_att}
    chain.append("probe_before", before_record)
    print(f"✓ probe-before completed | self_hash: {before_att['self_hash'][:24]}…")

    # PHASE 2: Execute Install Steps
    print("\n--- PHASE 2: INSTALLATION EXECUTION ---")
    steps = []
    
    def execute_step(step_name: str, fn):
        try:
            fn()
            ok = True
        except Exception as ex:
            print(f"  ✗ Step '{step_name}' failed: {ex}")
            ok = False
        step_hash = sha256_hex({"step": step_name, "ok": ok})
        steps.append({"name": step_name, "hash": step_hash, "ok": ok})
        chain.append("install_step", {"name": step_name, "ok": ok, "hash": step_hash})
        print(f"  ✓ Step [{step_name}] -> Hash: {step_hash[:20]}… (Status: {'OK' if ok else 'FAIL'})")

    execute_step("mkdir_chains", lambda: (target_root / "chains").mkdir(parents=True, exist_ok=True))
    execute_step("mkdir_apps", lambda: (target_root / "apps").mkdir(parents=True, exist_ok=True))
    execute_step("mkdir_packs", lambda: (target_root / "packs").mkdir(parents=True, exist_ok=True))
    
    # Initialize 4 VVU chains
    for app_name in ("ive", "study", "field", "harness"):
        app_chain = Chain(target_root / "chains" / f"{app_name}.json", app_name, keyring)
        app_chain.append("genesis", {"status": "INITIALIZED", "app": app_name})

    # PHASE 3: Probe After
    print("\n--- PHASE 3: PROBE-AFTER ---")
    after_raw = probe_environment_state(target_root)
    after_att = attest_record(after_raw, keyring, chain.head)
    after_record = {**after_raw, "attestation": after_att}
    chain.append("probe_after", after_record)
    print(f"✓ probe-after completed  | self_hash: {after_att['self_hash'][:24]}…")

    # PHASE 4: Build State Transition Receipt
    print("\n--- PHASE 4: BUILD INSTALLATION RECEIPT ---")
    receipt = build_install_receipt(
        before_record=before_record,
        after_record=after_record,
        steps=steps,
        installer_version="1.0.0",
        platform=sys.platform,
        keyring=keyring,
        chain=chain
    )
    print(f"✓ install_receipt.json generated and signed | Hash: {receipt['attestation']['self_hash'][:24]}…")

    # PHASE 5: Stranger's Verification Gate
    print("\n--- PHASE 5: STRANGER'S VERIFICATION GATE ---")
    verify_res = verify_install_receipt(receipt, before_record, after_record, keyring)
    print("Verification Result (Untampered State):")
    print(json.dumps(verify_res, indent=2))
    assert verify_res["ok"] is True, "Self-check verification failed!"

    # MANDATORY TAMPER TEST
    print("\n--- MANDATORY TAMPER TEST (FALSIFICATION CHECK) ---")
    print("Simulating adversary tampering with python_version in before_record...")
    tampered_before = json.loads(json.dumps(before_record))
    tampered_before["probes"]["python_version"] = "2.7.0" # Falsify probe data
    
    tamper_res = verify_install_receipt(receipt, tampered_before, after_record, keyring)
    print("Verification Result (Tampered State):")
    print(json.dumps(tamper_res, indent=2))
    assert tamper_res["ok"] is False, "Tamper check failed to catch modification!"
    print(f"✅ SUCCESS: Tamper detected as expected! Reason: '{tamper_res['reason']}'")

    print("\n" + "=" * 70)
    print("  INSTALLATION COMPLETE: All 5 Phases Passed & Falsification Proven.  ")
    print("=" * 70)

if __name__ == "__main__":
    vvu_workspace = Path.home() / ".vvu_production_suite"
    if vvu_workspace.exists():
        shutil.rmtree(vvu_workspace)
    run_installation_suite(vvu_workspace)
