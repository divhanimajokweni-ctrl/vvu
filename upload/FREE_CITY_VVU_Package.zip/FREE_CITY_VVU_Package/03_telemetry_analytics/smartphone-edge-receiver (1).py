#!/usr/bin/env python3
"""
Safegrid Trust Spine — Smartphone Edge Ingestion Receiver (L1 Mobile Boundary)
================================================================================
Acts as a software alternative to hardware ESP32 nodes, enabling smartphones 
to function as trusted multi-modal edge sensors (CCTV frame hash + 6-DOF IMU).

Enforces:
  1. Device Attestation & Hash Continuity (sha256 chain)
  2. Camera Frame Digest & Kinematic Physics Gates
  3. Ed25519 Tier-2 Signature & Atomic WORM Ledger Write

Author: Venture Vision Ubuntu
"""

import hashlib
import json
import os
import time
import threading
from typing import Dict, Any, Tuple
from cryptography.hazmat.primitives.asymmetric import ed25519
from cryptography.hazmat.primitives import serialization

# ==============================================================================
# 1. CRYPTOGRAPHIC KEYRING (Mobile Trust Root)
# ==============================================================================
class MobileTrustRoot:
    def __init__(self, key_dir: str = "/workspace/scratch/keys"):
        os.makedirs(key_dir, exist_ok=True)
        self.key_path = os.path.join(key_dir, "mobile_tier2_ed25519.pem")
        
        if os.path.exists(self.key_path):
            with open(self.key_path, "rb") as f:
                self.private_key = serialization.load_pem_private_key(f.read(), password=None)
        else:
            self.private_key = ed25519.Ed25519PrivateKey.generate()
            pem = self.private_key.private_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PrivateFormat.PKCS8,
                encryption_algorithm=serialization.NoEncryption()
            )
            with open(self.key_path, "wb") as f:
                f.write(pem)
            os.chmod(self.key_path, 0o600)

        self.public_key = self.private_key.public_key()
        self.pubkey_hex = self.public_key.public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw
        ).hex()

    def sign(self, data: bytes) -> str:
        return self.private_key.sign(data).hex()

# ==============================================================================
# 2. LOCAL WORM LEDGER
# ==============================================================================
class SmartphoneWormLedger:
    def __init__(self, filepath: str, trust_root: MobileTrustRoot):
        self.filepath = filepath
        self.trust_root = trust_root
        self.lock = threading.Lock()
        self.head_hash = "GENESIS_MOBILE_SMARTPHONE_00000000000000000000000000000000000"
        
        if not os.path.exists(self.filepath):
            with open(self.filepath, "w") as f:
                f.write("")

    def append(self, device_id: str, payload: Dict[str, Any], status: str, reason: str = "OK") -> Dict[str, Any]:
        with self.lock:
            entry = {
                "timestamp": time.time(),
                "device_id": device_id,
                "payload": payload,
                "status": status,
                "reason": reason,
                "prev_hash": self.head_hash
            }
            
            canonical = json.dumps(entry, sort_keys=True).encode('utf-8')
            entry_hash = hashlib.sha256(canonical).hexdigest()
            signature = self.trust_root.sign(canonical)
            
            block = {
                **entry,
                "hash": entry_hash,
                "mobile_tier2_signature": signature
            }
            
            with open(self.filepath, "a") as f:
                f.write(json.dumps(block) + "\n")
            
            self.head_hash = entry_hash
            return block

# ==============================================================================
# 3. SMARTPHONE KINEMATIC & OPTICAL PHYSICS GATE
# ==============================================================================
class SmartphonePhysicsGate:
    """
    Validates optical frame hashes and 6-DOF IMU telemetry to prevent fake camera video drops
    or impossible acceleration spikes.
    """
    def __init__(self):
        self.last_reading: Dict[str, Dict[str, Any]] = {}

    def validate(self, device_id: str, timestamp: float, imu_accel: list, frame_hash: str) -> Tuple[bool, str]:
        # Validate accel magnitude: sqrt(ax^2 + ay^2 + az^2)
        ax, ay, az = imu_accel
        accel_mag = (ax**2 + ay**2 + az**2) ** 0.5
        
        # Max reasonable phone acceleration (e.g. 50 m/s^2)
        if accel_mag > 50.0:
            return False, f"PHYSICS_VIOLATION: Acceleration magnitude {accel_mag:.1f} m/s^2 exceeds 50.0 m/s^2 ceiling"

        if device_id in self.last_reading:
            last = self.last_reading[device_id]
            time_delta = timestamp - last["timestamp"]
            
            # Reject duplicated camera frames with zero delta
            if frame_hash == last["frame_hash"] and time_delta > 2.0:
                return False, f"OPTICAL_FROZEN: Frame digest unchanged over {time_delta:.1f}s window"

        self.last_reading[device_id] = {
            "timestamp": timestamp,
            "imu_accel": imu_accel,
            "frame_hash": frame_hash
        }
        return True, "PASSED"

# ==============================================================================
# 4. SMARTPHONE INGESTION RECEIVER
# ==============================================================================
class SmartphoneIngestionReceiver:
    def __init__(self):
        self.trust_root = MobileTrustRoot()
        self.ledger = SmartphoneWormLedger("/workspace/scratch/mobile_worm_ledger.jsonl", self.trust_root)
        self.physics_gate = SmartphonePhysicsGate()
        self.device_expected_hash: Dict[str, str] = {}

    def process_telemetry_payload(self, telemetry_json: Dict[str, Any]) -> Dict[str, Any]:
        """
        Processes incoming JSON payload from Smartphone PWA or Native Camera App.
        Format:
          - device_id: str
          - timestamp: float
          - frame_hash: str (SHA-256 of JPEG camera frame)
          - imu_accel: [ax, ay, az]
          - imu_gyro: [gx, gy, gz]
          - prev_hash: str
          - client_sig: str
        """
        device_id = telemetry_json.get("device_id", "UNKNOWN_PHONE")
        timestamp = telemetry_json.get("timestamp", time.time())
        frame_hash = telemetry_json.get("frame_hash", "")
        imu_accel = telemetry_json.get("imu_accel", [0.0, 0.0, 9.81])
        client_prev_hash = telemetry_json.get("prev_hash", "")

        # 1. Hash Continuity Verification
        expected_prev = self.device_expected_hash.get(device_id, "GENESIS_MOBILE_00000000000000000000000000000000")
        
        # Verify continuity payload
        continuity_data = f"{expected_prev}:{device_id}:{timestamp}:{frame_hash}".encode('utf-8')
        expected_next_hash = hashlib.sha256(continuity_data).hexdigest()[:32]

        if client_prev_hash != expected_prev and expected_prev != "GENESIS_MOBILE_00000000000000000000000000000000":
            reason = f"HASH_CONTINUITY_BREACH: Expected {expected_prev[:8]}..., got {client_prev_hash[:8]}..."
            block = self.ledger.append(device_id, telemetry_json, "REJECTED", reason)
            return {"status": "REJECTED", "reason": reason, "block": block}

        # Update node state
        self.device_expected_hash[device_id] = expected_next_hash

        # 2. Physics & Optical Validation
        passed, physics_reason = self.physics_gate.validate(device_id, timestamp, imu_accel, frame_hash)
        if not passed:
            block = self.ledger.append(device_id, telemetry_json, "UNDEFINED", physics_reason)
            return {"status": "UNDEFINED", "reason": physics_reason, "block": block}

        # 3. Append to Local WORM Ledger
        block = self.ledger.append(device_id, telemetry_json, "VALID", "PASSED_HASH_AND_OPTICAL_PHYSICS")
        return {"status": "VALID", "reason": "PASSED", "block": block}

# ==============================================================================
# 5. VERIFICATION SUITE
# ==============================================================================
def run_verification_suite():
    print("=" * 80)
    print("SAFEGRID SMARTPHONE EDGE INGESTION RECEIVER VERIFICATION SUITE")
    print("=" * 80)
    
    receiver = SmartphoneIngestionReceiver()
    print(f"[*] Attestation Tier: T1 · Ed25519 (Software Mobile Key)")
    print(f"[*] Public Key Hex:   {receiver.trust_root.pubkey_hex[:32]}...")
    print(f"[*] WORM Ledger File: /workspace/scratch/mobile_worm_ledger.jsonl\n")

    # TEST 1: Valid Smartphone Multi-Modal Telemetry (CCTV Frame Hash + 6-DOF IMU)
    print("[TEST 1] Processing Valid Smartphone Packet (CCTV Camera Hash + 6-DOF IMU)...")
    device_id = "PHONE-CCTV-001"
    ts = time.time()
    frame_bytes = b"MOCK_JPEG_CAMERA_FRAME_DATA_123"
    frame_hash = hashlib.sha256(frame_bytes).hexdigest()
    
    payload1 = {
        "device_id": device_id,
        "timestamp": ts,
        "frame_hash": frame_hash,
        "imu_accel": [0.1, -0.2, 9.81],
        "imu_gyro": [0.01, 0.02, -0.01],
        "prev_hash": "GENESIS_MOBILE_00000000000000000000000000000000",
        "client_sig": "mock_webauthn_signature_hex"
    }
    
    res1 = receiver.process_telemetry_payload(payload1)
    assert res1["status"] == "VALID", f"Expected VALID, got {res1['status']}"
    print(f"  --> PASS: Smartphone frame & telemetry accepted. Block Hash: {res1['block']['hash'][:16]}...\n")

    # TEST 2: Replay / Hash Continuity Failure
    print("[TEST 2] Testing Tampered Hash Continuity (Simulating Replay/MITM Attack)...")
    payload2 = {
        "device_id": device_id,
        "timestamp": ts + 1.0,
        "frame_hash": hashlib.sha256(b"MOCK_JPEG_FRAME_2").hexdigest(),
        "imu_accel": [0.2, -0.1, 9.80],
        "imu_gyro": [0.0, 0.0, 0.0],
        "prev_hash": "BAD_WRONG_PREV_HASH",
        "client_sig": "mock_sig"
    }
    res2 = receiver.process_telemetry_payload(payload2)
    assert res2["status"] == "REJECTED", f"Expected REJECTED, got {res2['status']}"
    print(f"  --> PASS: Tampered hash continuity rejected correctly: {res2['reason']}\n")

    # TEST 3: Extreme Accelerometer Spike (Physics Gate Violation)
    print("[TEST 3] Testing Impossible Accel Spike (> 50 m/s^2)...")
    payload3 = {
        "device_id": "PHONE-CCTV-002",
        "timestamp": ts,
        "frame_hash": hashlib.sha256(b"MOCK_JPEG_FRAME_3").hexdigest(),
        "imu_accel": [40.0, 40.0, 40.0], # magnitude ~ 69.2 m/s^2
        "imu_gyro": [0.0, 0.0, 0.0],
        "prev_hash": "GENESIS_MOBILE_00000000000000000000000000000000",
        "client_sig": "mock_sig"
    }
    res3 = receiver.process_telemetry_payload(payload3)
    assert res3["status"] == "UNDEFINED", f"Expected UNDEFINED, got {res3['status']}"
    print(f"  --> PASS: Physics gate correctly caught extreme acceleration spike: {res3['reason']}\n")

    print("=" * 80)
    print("ALL SMARTPHONE EDGE INGESTION RECEIVER TESTS PASSED (3/3 PASS)")
    print("=" * 80)

if __name__ == "__main__":
    run_verification_suite()
