import hashlib
import json

def run_tamper_simulation():
    # 1. Genesis & Chain Building
    ive_chain = [
        {"index": 0, "prev_hash": "0"*64, "payload": "STEP_CAD_PART_001_TURBINE_BLADE"},
        {"index": 1, "prev_hash": "", "payload": "TOLERANCE_CHECK_PASS_0.001mm"},
        {"index": 2, "prev_hash": "", "payload": "ATTESTATION_SEAL_T0_HARDWARE"}
    ]

    for i in range(len(ive_chain)):
        if i == 0:
            raw = json.dumps(ive_chain[i], sort_keys=True).encode()
            ive_chain[i]["hash"] = hashlib.sha256(raw).hexdigest()
        else:
            ive_chain[i]["prev_hash"] = ive_chain[i-1]["hash"]
            raw = json.dumps(ive_chain[i], sort_keys=True).encode()
            ive_chain[i]["hash"] = hashlib.sha256(raw).hexdigest()

    study_head = "0334475ca80a9c1370" + "0"*46
    field_head = "32eb0c66942d5a5df6" + "0"*46
    harness_head = "03140e194c5b48682e" + "0"*46

    def compute_composite_anchor(ive_h, study_h, field_h, harness_h):
        payload = f"{ive_h}:{study_h}:{field_h}:{harness_h}".encode()
        return hashlib.sha256(payload).hexdigest()

    original_ive_head = ive_chain[-1]["hash"]
    original_anchor = compute_composite_anchor(original_ive_head, study_head, field_head, harness_head)

    print("====================================================================")
    print("      WORM CHAIN TAMPER & CIRCUIT BREAKER TRIP SIMULATION           ")
    print("====================================================================")
    print("\n--- 1. UNTAMPERED STATE (GENESIS TO HEAD) ---")
    print(f"IVE Entry #0 Hash : {ive_chain[0]['hash']}")
    print(f"IVE Entry #1 Hash : {ive_chain[1]['hash']}")
    print(f"IVE Entry #2 Head : {original_ive_head}")
    print(f"Composite Anchor  : {original_anchor}")
    print("Circuit Breaker   : NORMAL (Chain valid)")

    print("\n--- 2. ADVERSARIAL TAMPERING AT ENTRY #0 ---")
    print("Adversary modifies 1 byte in Entry #0 ('PART_001' -> 'PART_002')...")

    tampered_chain = [
        {"index": 0, "prev_hash": "0"*64, "payload": "STEP_CAD_PART_002_TURBINE_BLADE"}, # 1 byte changed!
        {"index": 1, "prev_hash": "", "payload": "TOLERANCE_CHECK_PASS_0.001mm"},
        {"index": 2, "prev_hash": "", "payload": "ATTESTATION_SEAL_T0_HARDWARE"}
    ]

    for i in range(len(tampered_chain)):
        if i == 0:
            raw = json.dumps(tampered_chain[i], sort_keys=True).encode()
            tampered_chain[i]["hash"] = hashlib.sha256(raw).hexdigest()
        else:
            tampered_chain[i]["prev_hash"] = tampered_chain[i-1]["hash"]
            raw = json.dumps(tampered_chain[i], sort_keys=True).encode()
            tampered_chain[i]["hash"] = hashlib.sha256(raw).hexdigest()

    tampered_ive_head = tampered_chain[-1]["hash"]
    tampered_anchor = compute_composite_anchor(tampered_ive_head, study_head, field_head, harness_head)

    print("\n--- 3. FULL RE-COMPUTATION & MISMATCH DETECTION ---")
    print(f"Original IVE Head  : {original_ive_head}")
    print(f"Recomputed IVE Head: {tampered_ive_head}")
    print(f"Original Anchor    : {original_anchor}")
    print(f"Recomputed Anchor  : {tampered_anchor}")

    print("\n--- 4. CIRCUIT BREAKER EVALUATION ---")
    if original_ive_head != tampered_ive_head:
        print("⚡ [CIRCUIT BREAKER TRIPPED] Status: HALT_EXECUTION")
        print("   • Reason            : WORM_CHAIN_HASH_MISMATCH")
        print("   • Failure Location  : Entry #0 Hash Pointer Drift")
        print("   • Action            : State Root Update Rejected & Alert Emitted")

    print("====================================================================\n")

if __name__ == "__main__":
    run_tamper_simulation()
