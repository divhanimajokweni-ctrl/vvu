#!/usr/bin/env python3
"""
VVU Trust Spine — Multi-View Contract UI & Invariant Verification Suite
=======================================================================
Tests the Multi-View Contract API endpoints and verifies that HTTP 409 Conflict
state degradation triggers on version/chain mismatches.
"""

import sys
import json
import unittest

sys.path.append('/workspace/scratch')
from fastapi.testclient import TestClient
from multi_view_contract_api import app

class TestMultiViewContractUI(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.client = TestClient(app)
        cls.twin_id = "TWIN-SUBSTATION-01"

    def test_01_sealed_state_contract_hud(self):
        """Verify HTTP 200 returns valid sealed state contract for HUD rendering."""
        response = self.client.get(f"/api/v1/twin/{self.twin_id}/state")
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertEqual(data["verification_state"], "SEALED_WORM")
        self.assertIn("head_hash", data)
        self.assertIn("state_version", data)
        self.assertIn("evidence_cutoff", data)
        print(f"  [✓] Test 1: Valid Sealed State Contract verified. Version={data['state_version']}, Hash={data['head_hash'][:16]}...")

    def test_02_409_conflict_visual_degradation(self):
        """Verify HTTP 409 Conflict triggers on non-existent version to force UI degradation."""
        response = self.client.get(f"/api/v1/twin/{self.twin_id}/state?state_version=99999")
        self.assertEqual(response.status_code, 409)
        err = response.json()
        self.assertIn("INVARIANT BREACH", err["detail"])
        print(f"  [✓] Test 2: HTTP 409 Conflict Invariant Breach verified: '{err['detail']}'")

if __name__ == "__main__":
    print("=" * 80)
    print("VVU MULTI-VIEW CONTRACT UI DEGRADATION TEST SUITE")
    print("=" * 80)
    unittest.main(verbosity=2)
