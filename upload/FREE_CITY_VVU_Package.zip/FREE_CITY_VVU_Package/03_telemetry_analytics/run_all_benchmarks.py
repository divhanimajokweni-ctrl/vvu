import sys
import os
import subprocess
import json
import time

candidate_dirs = [
    "/workspace/artifacts",
    "/workspace/scratch",
    os.path.abspath("."),
]

scripts_to_run = [
    ("1. Integrated YOLO Multi-Cam & Meantime Failover Loop", "yolo_meantime_integration.py"),
    ("2. TEE Device Hardware & Platform Comparison", "device_tee_simulation.py"),
    ("3. ProofBridge On-Chain Ledger Settlement", "proofbridge_ledger_settlement.py"),
    ("4. ProofBridge On-Chain TEE Quote Validation", "proofbridge_tee_validation.py"),
    ("5. 5-Phase State-Transition Installer & Tamper Test", "vvu_installer_suite.py"),
    ("6. VVU 4-App Composite Anchor Loop", "vvu_composite_demo.py"),
    ("7. Local WORM Chain Tamper & Circuit Breaker Trip", "test_tamper_circuit_breaker.py"),
    ("8. On-Chain EVM Tamper Reversion & Circuit Breaker", "test_onchain_tamper_revert.py"),
    ("9. Suite Loop vs. Traditional Sector Benchmark", "benchmark_suite_vs_traditional.py"),
    ("10. 10,000-Op TEE Throughput & Latency Stress Test", "benchmark_tee_throughput.py"),
]

def find_script(filename):
    for d in candidate_dirs:
        p = os.path.join(d, filename)
        if os.path.exists(p):
            return p
    return None

print("====================================================================")
print("     MASTER TEST RUNNER: RE-EXECUTING ALL BENCHMARK SUITES          ")
print("====================================================================")

results = []

for title, filename in scripts_to_run:
    script_path = find_script(filename)
    if not script_path:
        print(f"\n▶ RUNNING: {title}... NOT FOUND ({filename})")
        results.append({
            "title": title,
            "filename": filename,
            "status": "NOT_FOUND",
            "elapsed_ms": 0,
            "output": "File not found"
        })
        continue

    print(f"\n▶ RUNNING: {title}\n  Path: {script_path}")
    start_t = time.time()
    res = subprocess.run([sys.executable, script_path], capture_output=True, text=True)
    elapsed = (time.time() - start_t) * 1000.0
    status = "PASS" if res.returncode == 0 else "FAIL"
    
    print(f"  └─ Execution Status: {status} ({elapsed:.2f} ms)")
    if res.stdout:
        lines = [line for line in res.stdout.strip().split("\n") if line]
        for line in lines[:5]:
            print(f"     {line}")
        if len(lines) > 5:
            print(f"     ... ({len(lines)-5} additional lines)")
    if res.returncode != 0:
        print(f"  └─ Error: {res.stderr[:300]}")

    results.append({
        "title": title,
        "filename": filename,
        "path": script_path,
        "status": status,
        "elapsed_ms": round(elapsed, 2),
        "stdout": res.stdout.strip(),
        "stderr": res.stderr.strip()
    })

print("\n====================================================================")
print("                     MASTER EXECUTION SUMMARY                       ")
print("====================================================================")
total_pass = sum(1 for r in results if r["status"] == "PASS")
print(f"Total Test Suites Executed : {len(results)}")
print(f"Passed                      : {total_pass} / {len(results)}")
print(f"Failed                      : {len(results) - total_pass}")
print("====================================================================")

os.makedirs("/workspace/scratch", exist_ok=True)
with open("/workspace/scratch/master_benchmark_results.json", "w") as f:
    json.dump(results, f, indent=2)

print("\nSaved master execution log to /workspace/scratch/master_benchmark_results.json")
