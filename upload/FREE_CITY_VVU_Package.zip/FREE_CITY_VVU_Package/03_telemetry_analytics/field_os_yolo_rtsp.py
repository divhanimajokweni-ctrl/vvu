import hashlib
import json
import time
import random
from typing import Dict, Any, List

class FieldOSYOLOInference:
    """
    Field OS Tactical RTSP Frame Ingestion & YOLOv8 Edge Threat Filter.
    Simulates RTSP video decoding from Hikvision perimeter cameras, runs local YOLOv8 threat
    detection, filters 99% of false alarms on-site, and enforces POPIA Act 4 of 2013 legal consent frames.
    """
    def __init__(self, camera_channel: str, rtsp_url: str):
        self.camera_channel = camera_channel
        self.rtsp_url = rtsp_url
        self.popia_consent_frame_id = f"POPIA-ZA-2013-CONSENT-{hashlib.md5(camera_channel.encode()).hexdigest()[:8]}"

    def process_rtsp_frame(self, frame_id: int) -> Dict[str, Any]:
        timestamp = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        
        # Simulate local YOLOv8 bounding box & class confidence output
        possible_objects = [
            {"class": "tree_sway", "confidence": 0.92, "threat": False},
            {"class": "dog_animal", "confidence": 0.88, "threat": False},
            {"class": "shadow_motion", "confidence": 0.95, "threat": False},
            {"class": "person_intruder", "confidence": 0.94, "threat": True},
            {"class": "unauthorized_vehicle", "confidence": 0.91, "threat": True}
        ]

        # 99% of frames in routine security are benign false alarms
        detected_obj = random.choice(possible_objects) if frame_id % 10 == 0 else possible_objects[0]
        
        is_false_alarm = not detected_obj["threat"]
        alert_dispatched = not is_false_alarm

        # Generate Frame Cryptographic Proof
        frame_data = f"{self.camera_channel}:{frame_id}:{timestamp}:{detected_obj['class']}:{detected_obj['confidence']}"
        frame_hash = hashlib.sha256(frame_data.encode('utf-8')).hexdigest()

        # WORM Log Entry
        worm_entry = {
            "channel": self.camera_channel,
            "frame_id": frame_id,
            "utc_ts": timestamp,
            "yolo_detection": detected_obj,
            "false_alarm_filtered": is_false_alarm,
            "alert_dispatched": alert_dispatched,
            "popia_consent_frame": self.popia_consent_frame_id,
            "frame_hash": frame_hash,
            "promotion_pilot_discount": "25% off monthly / 50% off upfront Active"
        }

        return worm_entry

if __name__ == "__main__":
    yolo_engine = FieldOSYOLOInference("CAM_SISHEN_PERIMETER_04", "rtsp://192.168.10.55:554/stream1")
    
    print("=== FIELD OS RTSP & YOLOV8 THREAT FILTER SIMULATION ===")
    for frame_id in range(101, 106):
        log_entry = yolo_engine.process_rtsp_frame(frame_id)
        status = "🚨 ALERT DISPATCHED" if log_entry["alert_dispatched"] else "🛡️ FALSE ALARM FILTERED (ON-SITE)"
        print(f"Frame #{frame_id} | Class: {log_entry['yolo_detection']['class']} ({log_entry['yolo_detection']['confidence']*100:.1f}%) | {status}")
        print(f"   Hash: {log_entry['frame_hash'][:16]}... | POPIA Tag: {log_entry['popia_consent_frame']}")
