import os
import json
import hashlib
import sys
from datetime import datetime, timezone

def sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

class WORMChain:
    def __init__(self, name: str, storage_dir: str):
        self.name = name
        self.storage_dir = storage_dir
        os.makedirs(self.storage_dir, exist_ok=True)
        self.filepath = os.path.join(self.storage_dir, f"{name}.json")
        self.entries = self._load()

    def _load(self):
        if os.path.exists(self.filepath):
            with open(self.filepath, "r", encoding="utf-8") as f:
                return json.load(f)
        else:
            # Genesis entry
            genesis_data = {
                "index": 0,
                "prev_hash": "0000000000000000000000000000000000000000000000000000000000000000",
                "timestamp": "2026-09-21T00:00:00Z",
                "app": self.name,
                "payload": {"event": "GENESIS_ANCHOR", "status": "INITIALIZED"},
                "twin_t": 0.0
            }
            genesis_bytes = json.dumps(genesis_data, sort_keys=True).encode("utf-8")
            genesis_data["hash"] = sha256_hex(genesis_bytes)
            return [genesis_data]

    def _save(self):
        with open(self.filepath, "w", encoding="utf-8") as f:
            json.dump(self.entries, f, indent=2)

    def append(self, payload: dict) -> str:
        prev_entry = self.entries[-1]
        new_index = len(self.entries)
        entry_data = {
            "index": new_index,
            "prev_hash": prev_entry["hash"],
            "timestamp": "2026-09-21T14:52:00Z", # Fixed deterministic timestamp for replay
            "app": self.name,
            "payload": payload,
            "twin_t": float(new_index)
        }
        entry_bytes = json.dumps(entry_data, sort_keys=True).encode("utf-8")
        entry_data["hash"] = sha256_hex(entry_bytes)
        self.entries.append(entry_data)
        self._save()
        return entry_data["hash"]

    def head_hash(self) -> str:
        return self.entries[-1]["hash"]

    def verify_chain(self) -> bool:
        for i in range(len(self.entries)):
            entry = self.entries[i]
            if i == 0:
                if entry["prev_hash"] != "0000000000000000000000000000000000000000000000000000000000000000":
                    return False
            else:
                if entry["prev_hash"] != self.entries[i-1]["hash"]:
                    return False
            
            # Verify self hash
            calc_data = {k: v for k, v in entry.items() if k != "hash"}
            calc_bytes = json.dumps(calc_data, sort_keys=True).encode("utf-8")
            if sha256_hex(calc_bytes) != entry["hash"]:
                return False
        return True

def run_vvu_demo():
    workspace = "/workspace/scratch/vvu_suite_demo"
    print("=" * 68)
    print("      VVU SUITE DEMO: 4 APPS · 4 WORM CHAINS · COMPOSITE ANCHOR      ")
    print("=" * 68)

    # 1. Initialize 4 WORM Chains
    ive_chain = WORMChain("ive", os.path.join(workspace, "chains"))
    study_chain = WORMChain("study", os.path.join(workspace, "chains"))
    field_chain = WORMChain("field", os.path.join(workspace, "chains"))
    harness_chain = WORMChain("harness", os.path.join(workspace, "chains"))

    print("\n--- 1. EXECUTING APP STATE COMMITMENTS ---")

    # App 1: IVE (Integrated Verification Environment - CAD Canonicalization)
    ive_payload = {
        "event": "CAD_CANONICALIZATION",
        "file": "turbine_blade_v4.stp",
        "entity_count": 14,
        "contentHash": "d5b086e54d7b389a3c4edd7b6c764163263974a3c846d5510b21a3c40f93c92b",
        "receiptHash": "e3ce6b346c3e4f113637ee6ec3ce635f30fa3cd7c0549bd658201895a226298b",
        "tolerance_gate": "PASS"
    }
    ive_head = ive_chain.append(ive_payload)
    print(f"✓ [IVE App]      CAD STEP Tokenized | Head Hash: {ive_head[:18]}... (Gate: PASS)")

    # App 2: Study Studio (Curriculum & Readiness Evaluation)
    study_payload = {
        "event": "READINESS_COMMIT",
        "learner_id": "STUDENT_ZA_8820",
        "curriculum_module": "ProofBridge_Verification_Level_1",
        "flashcard_recall_strength": 0.94,
        "readiness_eval": "PASSED_MASTERY"
    }
    study_head = study_chain.append(study_payload)
    print(f"✓ [Study Studio] Mastery Verified  | Head Hash: {study_head[:18]}... (Readiness: 94%)")

    # App 3: Field OS (Edge RTSP & YOLOv8 Threat Verification)
    field_payload = {
        "event": "YOLO_EDGE_THREAT",
        "camera_id": "CAM_04_SUBSTATION_EAST",
        "threat_class": "UNIDENTIFIED_VEHICLE",
        "confidence": 0.94,
        "popia_consent_tag": "POPIA-ZA-2013-ce7b13b8",
        "action": "DISPATCH_ATLAS_SECURITY"
    }
    field_head = field_chain.append(field_payload)
    print(f"✓ [Field OS]     YOLO Threat Verified| Head Hash: {field_head[:18]}... (POPIA Tagged)")

    # App 4: Harness (Dual-Node Remote TEE Attestation & Settlement)
    harness_payload = {
        "event": "TEE_CROSS_BORDER_SETTLEMENT",
        "node_id": "KR_SEOUL_NODE_01",
        "hardware_tier": "T0_AMD_SEV_SNP",
        "public_key": "486c6608cdd4a2e27d4d961e3139bdcbff44bb0c779de81d645648e235ae8208",
        "contract_address": "0x71C7656EC7ab88b098defB751B7401B5f6d8976F",
        "verdict": "VERIFIED_HARDWARE_ROOT"
    }
    harness_head = harness_chain.append(harness_payload)
    print(f"✓ [Harness App]  TEE Cross-Border   | Head Hash: {harness_head[:18]}... (Tier: T0)")

    print("\n--- 2. GENERATING COMPOSITE Cryptographic ANCHOR ---")
    composite_payload = {
        "ive_head": ive_head,
        "study_head": study_head,
        "field_head": field_head,
        "harness_head": harness_head
    }
    composite_bytes = json.dumps(composite_payload, sort_keys=True).encode("utf-8")
    composite_anchor = sha256_hex(composite_bytes)

    print(f"🔗 COMPOSITE ANCHOR ROOT : 0x{composite_anchor}")
    print(f"   • Composite Payload Bytes: {len(composite_bytes)} bytes")
    print(f"   • Quad-Chain Lock State : ALL 4 HEADS ANCHORED")

    print("\n--- 3. FULL CHAIN INTEGRITY & CIRCUIT BREAKER RE-COMPUTATION ---")
    ive_ok = ive_chain.verify_chain()
    study_ok = study_chain.verify_chain()
    field_ok = field_chain.verify_chain()
    harness_ok = harness_chain.verify_chain()

    print(f"   • IVE WORM Chain Integrity      : {'PASSED (True)' if ive_ok else 'FAILED'}")
    print(f"   • Study Studio Chain Integrity : {'PASSED (True)' if study_ok else 'FAILED'}")
    print(f"   • Field OS WORM Chain Integrity: {'PASSED (True)' if field_ok else 'FAILED'}")
    print(f"   • Harness WORM Chain Integrity : {'PASSED (True)' if harness_ok else 'FAILED'}")

    all_passed = ive_ok and study_ok and field_ok and harness_ok
    print(f"\n======================================================================")
    if all_passed:
        print(f"✅ DEMO COMPLETE: Quad-Chain Composite Root 0x{composite_anchor[:16]}... Locked!")
    else:
        print(f"❌ DEMO FAILED: Chain Verification Fault Detected.")
    print(f"======================================================================\n")

if __name__ == "__main__":
    run_vvu_demo()
