import hashlib
import json
import re
import time
from typing import Dict, Any, List

class IVEStepParser:
    """
    Integrated Verification Environment (IVE) STEP CAD File Parser & Canonicalizer.
    Parses ISO 10303-21 STEP files, extracts boundary representation (B-Rep) entities,
    canonicalizes geometry/topology tokens, and generates deterministic SHA-256 hashes.
    """
    def __init__(self, step_content: str):
        self.step_content = step_content
        self.header_entities = []
        self.data_entities = []

    def parse(self) -> Dict[str, Any]:
        # Extract HEADER and DATA sections
        header_match = re.search(r'HEADER;(.*?)ENDSEC;', self.step_content, re.DOTALL)
        data_match = re.search(r'DATA;(.*?)ENDSEC;', self.step_content, re.DOTALL)

        header_raw = header_match.group(1) if header_match else ""
        data_raw = data_match.group(1) if data_match else ""

        # Parse DATA entities (#10 = CARTESIAN_POINT(...);)
        entity_pattern = re.compile(r'#(\d+)\s*=\s*([A-Z0-9_]+)\s*\((.*)\);')
        parsed_entities = []
        entity_types = {}

        for match in entity_pattern.finditer(data_raw):
            entity_id = int(match.group(1))
            entity_type = match.group(2)
            params_raw = match.group(3)
            
            entity_types[entity_type] = entity_types.get(entity_type, 0) + 1
            parsed_entities.append({
                "id": entity_id,
                "type": entity_type,
                "params": params_raw.strip()
            })

        # Canonicalize by sorting entities by TYPE then PARAMS (deterministic order)
        sorted_entities = sorted(parsed_entities, key=lambda x: (x["type"], x["params"]))
        
        canonical_tokens = [f"{e['type']}({e['params']})" for e in sorted_entities]
        canonical_str = "\n".join(canonical_tokens)
        
        content_hash = hashlib.sha256(canonical_str.encode('utf-8')).hexdigest()
        receipt_hash = hashlib.sha256((content_hash + "2026-09-21T09:45:00Z").encode('utf-8')).hexdigest()

        # Evaluate IVE CAD Tolerance & Quality Gates
        cartesian_points = entity_types.get("CARTESIAN_POINT", 0)
        faces = entity_types.get("ADVANCED_FACE", 0)
        solids = entity_types.get("MANIFOLD_SOLID_BREP", 0)

        gate_status = "PASS" if solids >= 1 and cartesian_points > 0 else "REVIEW"

        return {
            "ive_version": "2.4.0-CAD",
            "total_entities": len(parsed_entities),
            "entity_breakdown": entity_types,
            "canonical_str_snippet": canonical_str[:200] + "...",
            "contentHash": content_hash,
            "receiptHash": receipt_hash,
            "gate_status": gate_status,
            "ui_footer": "computed gates · stubbed gates flagged · strong = suspicious"
        }

# Sample STEP CAD file string for a mechanical bracket
SAMPLE_STEP_CAD = """
ISO-10303-21;
HEADER;
FILE_DESCRIPTION(('IVE CAD Verification File'),'2;1');
FILE_NAME('bracket_v2.stp','2026-09-21T09:45:00Z',('VVU Engineering'),('Sishen Mine'),'IVE CAD Preprocessor','OpenCASCADE','');
FILE_SCHEMA(('AUTOMOTIVE_DESIGN { 1 0 10303 214 1 1 1 1 }'));
ENDSEC;
DATA;
#10 = CLOSED_SHELL('',(#20,#30,#40));
#20 = ADVANCED_FACE('',(#21),#22,.T.);
#21 = FACE_BOUND('',#23,.T.);
#23 = EDGE_LOOP('',(#24));
#24 = ORIENTED_EDGE('',*,*,#25,.T.);
#25 = EDGE_CURVE('',#26,#27,#28,.T.);
#26 = VERTEX_POINT('',#100);
#27 = VERTEX_POINT('',#101);
#28 = LINE('',#100,#102);
#30 = ADVANCED_FACE('',(#31),#32,.T.);
#40 = MANIFOLD_SOLID_BREP('Bracket_Solid',#10);
#100 = CARTESIAN_POINT('Origin',(0.0,0.0,0.0));
#101 = CARTESIAN_POINT('X_Axis',(100.0,0.0,0.0));
#102 = CARTESIAN_POINT('Vector',(1.0,0.0,0.0));
ENDSEC;
END-ISO-10303-21;
"""

if __name__ == "__main__":
    parser = IVEStepParser(SAMPLE_STEP_CAD)
    result = parser.parse()
    print("=== IVE STEP CAD CANONICALIZATION RESULT ===")
    print(json.dumps(result, indent=2))
