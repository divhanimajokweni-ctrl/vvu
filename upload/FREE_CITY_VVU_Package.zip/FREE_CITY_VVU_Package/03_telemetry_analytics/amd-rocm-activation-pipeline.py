#!/usr/bin/env python3
"""
Safegrid / VVU Trust Spine — AMD ROCm GPU Pipeline & Activation Engine
========================================================================
Implements the AMD/ROCm pipeline activation engine, VRAM budget allocation,
automatic resource scrapping for heavy models under memory constraints,
and two-gate activation triggering for dormant smart contracts.

Author: Venture Vision Ubuntu
"""

import os
import sys
import json
import time
import hashlib
import psutil
from typing import Dict, Any, Tuple
from cryptography.hazmat.primitives.asymmetric import ed25519
from cryptography.hazmat.primitives import serialization

# Check PyTorch / ROCm availability if installed
try:
    import torch
    TORCH_AVAILABLE = True
except ImportError:
    TORCH_AVAILABLE = False


# ==============================================================================
# 1. AMD ROCm & VRAM RESOURCE ALLOCATOR
# ==============================================================================
class ROCmVRAMManager:
    """
    Monitors AMD ROCm / PyTorch GPU memory & system RAM.
    Applies aggressive resource scrapping & precision conversion (VRAM quantization)
    to prevent out-of-memory (OOM) crashes and excessive resource consumption.
    """
    def __init__(self, max_vram_mb_target: int = 4096):
        self.max_vram_mb_target = max_vram_mb_target
        self.gpu_device_name = "None"
        self.has_rocm_gpu = False
        self.vram_total_mb = 0
        self.vram_free_mb = 0
        self.system_ram_mb = psutil.virtual_memory().total // (1024 * 1024)
        
        self._detect_gpu_environment()

    def _detect_gpu_environment(self):
        if TORCH_AVAILABLE:
            if torch.cuda.is_available():
                self.has_rocm_gpu = True
                self.gpu_device_name = torch.cuda.get_device_name(0)
                # Check for AMD ROCm HIP backend
                is_hip = getattr(torch.version, 'hip', None) is not None
                if is_hip:
                    self.gpu_device_name += " (AMD ROCm HIP)"
                
                total_bytes = torch.cuda.get_device_properties(0).total_memory
                self.vram_total_mb = total_bytes // (1024 * 1024)
                self.vram_free_mb = self.vram_total_mb # Initial allocation
            else:
                self.gpu_device_name = "CPU Sandbox (No GPU detected)"
        else:
            self.gpu_device_name = "CPU Sandbox (PyTorch absent)"

    def allocate_vram_budget(self, model_name: str, required_vram_mb: int) -> Dict[str, Any]:
        """
        Evaluates model memory demands.
        If required_vram_mb exceeds available VRAM/budget:
        - Scraps heavy models (returns ACTION='SCRAP')
        - Quantizes medium models to FP16/INT8 VRAM (returns ACTION='QUANTIZE_VRAM')
        - Uses CPU deterministic fallback if GPU is absent (returns ACTION='CPU_FALLBACK')
        """
        if not self.has_rocm_gpu:
            return {
                "model": model_name,
                "action": "CPU_FALLBACK",
                "vram_allocated_mb": 0,
                "precision": "FP32_CPU",
                "reason": "GPU/ROCm unavailable; degraded to CPU rule engine"
            }

        if required_vram_mb > self.vram_total_mb:
            return {
                "model": model_name,
                "action": "SCRAP",
                "vram_allocated_mb": 0,
                "precision": "NONE",
                "reason": f"Required VRAM ({required_vram_mb} MB) exceeds physical limit ({self.vram_total_mb} MB). Model scrapped."
            }

        if required_vram_mb > (self.vram_total_mb * 0.5):
            # Quantize down to FP16 to fit into half VRAM
            quantized_mb = required_vram_mb // 2
            return {
                "model": model_name,
                "action": "QUANTIZE_VRAM",
                "vram_allocated_mb": quantized_mb,
                "precision": "FP16_ROCM",
                "reason": f"High memory demand. Quantized from {required_vram_mb}MB to {quantized_mb}MB VRAM."
            }

        return {
            "model": model_name,
            "action": "EXECUTE_FULL",
            "vram_allocated_mb": required_vram_mb,
            "precision": "FP32_ROCM",
            "reason": "VRAM budget sufficient for full precision."
        }


# ==============================================================================
# 2. TWO-GATE ACTIVATION PIPELINE (Article I §1.3 Compliance)
# ==============================================================================
class AMDActivationPipeline:
    """
    Executes the AMD GPU Activation Workflow for dormant smart contracts.
    Enforces Article I §1.3:
    Governance cannot decide that an invalid proof is valid.
    Requires Gate 1 (Epistemic Proof) AND Gate 2 (Constitutional Authorization).
    """
    def __init__(self, key_dir: str = "/workspace/scratch/keys"):
        os.makedirs(key_dir, exist_ok=True)
        self.key_path = os.path.join(key_dir, "pipeline_ed25519.pem")
        
        if os.path.exists(self.key_path):
            with open(self.key_path, "rb") as f:
                self.priv_key = serialization.load_pem_private_key(f.read(), password=None)
        else:
            self.priv_key = ed25519.Ed25519PrivateKey.generate()
            pem = self.priv_key.private_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PrivateFormat.PKCS8,
                encryption_algorithm=serialization.NoEncryption()
            )
            with open(self.key_path, "wb") as f:
                f.write(pem)
            os.chmod(self.key_path, 0o600)

        self.pub_key = self.priv_key.public_key()
        self.pubkey_hex = self.pub_key.public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw
        ).hex()

        self.vram_mgr = ROCmVRAMManager()

    def run_pipeline(
        self,
        git_commit_hash: str,
        epistemic_proof_valid: bool,
        governance_vote_passed: bool,
        heavy_model_vram_mb: int = 16384
    ) -> Dict[str, Any]:
        """
        Runs the GPU smoke -> test -> activate() pipeline.
        """
        start_time = time.time()
        
        # 1. Resource & VRAM Allocation
        resource_plan = self.vram_mgr.allocate_vram_budget("SmolVLA_Vision_Expert", heavy_model_vram_mb)

        # 2. Gate 1 — Epistemic Verification
        gate1_passed = epistemic_proof_valid
        gate1_status = "PASS" if gate1_passed else "FAIL"

        # 3. Gate 2 — Constitutional Governance
        gate2_passed = governance_vote_passed
        gate2_status = "PASS" if gate2_passed else "FAIL"

        # 4. Constitutional Invariant Check (Article I §1.3)
        # Rejects (vote=PASS, proof=FAIL, authorization=EXECUTE)
        if gate2_passed and not gate1_passed:
            return {
                "status": "BLOCKED",
                "error": "CONSTITUTIONAL_VIOLATION_ARTICLE_1_SEC_3",
                "reason": "Governance vote PASS cannot override Epistemic proof FAIL. Activation blocked.",
                "resource_plan": resource_plan,
                "activation_tx": None,
                "elapsed_ms": round((time.time() - start_time) * 1000, 2)
            }

        if not (gate1_passed and gate2_passed):
            return {
                "status": "BLOCKED",
                "error": "TWO_GATE_REQUIREMENT_UNMET",
                "reason": f"Epistemic Gate: {gate1_status}, Constitutional Gate: {gate2_status}",
                "resource_plan": resource_plan,
                "activation_tx": None,
                "elapsed_ms": round((time.time() - start_time) * 1000, 2)
            }

        # 5. Generate Signed Activation Payload
        activation_payload = {
            "action": "activate(bytes32)",
            "git_commit_hash": git_commit_hash,
            "timestamp": int(time.time()),
            "gate1_epistemic": "PASS",
            "gate2_constitutional": "PASS",
            "pubkey": self.pubkey_hex
        }

        canonical_bytes = json.dumps(activation_payload, sort_keys=True).encode('utf-8')
        signature = self.priv_key.sign(canonical_bytes).hex()
        payload_hash = hashlib.sha256(canonical_bytes).hexdigest()

        return {
            "status": "ACTIVATED",
            "git_commit_hash": git_commit_hash,
            "contract_state": "LIVE",
            "activation_tx": {
                "payload": activation_payload,
                "hash": payload_hash,
                "signature": signature
            },
            "resource_plan": resource_plan,
            "elapsed_ms": round((time.time() - start_time) * 1000, 2)
        }


# ==============================================================================
# 3. VERIFICATION TEST SUITE
# ==============================================================================
def run_verification_suite():
    print("=" * 80)
    print("SAFEGRID / VVU AMD ROCm GPU PIPELINE & ACTIVATION ENGINE TEST SUITE")
    print("=" * 80)

    pipeline = AMDActivationPipeline()
    print(f"[*] Hardware Target:   {pipeline.vram_mgr.gpu_device_name}")
    print(f"[*] System Memory:     {pipeline.vram_mgr.system_ram_mb} MB RAM")
    print(f"[*] Trust Root Key:    {pipeline.pubkey_hex[:32]}...")
    print("=" * 80)

    # TEST 1: Valid Two-Gate Activation
    print("\n[TEST 1] Executing Valid Two-Gate Contract Activation (Git Commit: db308fed)...")
    res1 = pipeline.run_pipeline(
        git_commit_hash="db308fed11577887e7a164de218b843706a151a7",
        epistemic_proof_valid=True,
        governance_vote_passed=True,
        heavy_model_vram_mb=8192
    )
    assert res1["status"] == "ACTIVATED", f"Expected ACTIVATED, got {res1['status']}"
    assert res1["contract_state"] == "LIVE"
    print(f"  --> PASS: Contract successfully activated! Tx Hash: {res1['activation_tx']['hash'][:16]}...")
    print(f"      Resource Action: {res1['resource_plan']['action']} ({res1['resource_plan']['reason']})")

    # TEST 2: Constitutional Invariant Violation (Vote=PASS, Proof=FAIL)
    print("\n[TEST 2] Testing Constitutional Violation (Governance Vote=PASS, Epistemic Proof=FAIL)...")
    res2 = pipeline.run_pipeline(
        git_commit_hash="db308fed11577887e7a164de218b843706a151a7",
        epistemic_proof_valid=False, # Proof fails
        governance_vote_passed=True, # Vote passes
        heavy_model_vram_mb=8192
    )
    assert res2["status"] == "BLOCKED"
    assert res2["error"] == "CONSTITUTIONAL_VIOLATION_ARTICLE_1_SEC_3"
    print(f"  --> PASS: Activation correctly blocked by Article I §1.3 invariant safeguard.")
    print(f"      Reason: {res2['reason']}")

    # TEST 3: Heavy Model VRAM Scrapping / Quantization
    print("\n[TEST 3] Testing Automatic Resource Scrapping / Quantization for Heavy Models...")
    plan = pipeline.vram_mgr.allocate_vram_budget("Huge_3D_Mesh_Model", 65536) # 64 GB VRAM request
    assert plan["action"] in ["SCRAP", "CPU_FALLBACK"]
    print(f"  --> PASS: Excessively heavy model request (64 GB) automatically handled.")
    print(f"      Action Taken: {plan['action']} — Reason: {plan['reason']}")

    print("\n" + "=" * 80)
    print("ALL AMD ROCm PIPELINE & VRAM MANAGER PROOF OBLIGATIONS VERIFIED (3/3 PASS)")
    print("=" * 80)


if __name__ == "__main__":
    run_verification_suite()
