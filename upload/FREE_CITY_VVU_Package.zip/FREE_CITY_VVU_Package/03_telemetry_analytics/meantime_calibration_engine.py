import hashlib
import json
import time
import os
from dataclasses import dataclass, asdict
from typing import List, Dict, Any, Optional

# --- 1. CRYPTOGRAPHIC STENOGRAPHER (TAMPER-EVIDENT JOURNALING) ---

@dataclass
class StenographerEntry:
    entry_id: int
    utc_ts: float
    source: str  # "USER_SIDE" or "MAIN_SERVICE"
    action_type: str
    payload: Dict[str, Any]
    prev_hash: str
    content_hash: str = ""
    signature: str = ""

    def compute_hashes(self, secret_key: str = "vvu_meantime_key") -> None:
        """Computes deterministic SHA-256 content hash and chained cryptographic signature."""
        canonical_raw = {
            "entry_id": self.entry_id,
            "utc_ts": self.utc_ts,
            "source": self.source,
            "action_type": self.action_type,
            "payload": self.payload,
            "prev_hash": self.prev_hash
        }
        canonical_json = json.dumps(canonical_raw, sort_keys=True)
        self.content_hash = hashlib.sha256(canonical_json.encode('utf-8')).hexdigest()
        
        # Simulating cryptographic signing (HMAC-SHA256 signature chain)
        sig_input = f"{self.content_hash}:{self.prev_hash}:{secret_key}"
        self.signature = hashlib.sha256(sig_input.encode('utf-8')).hexdigest()


class CryptographicStenographer:
    """Parallel logging engine that records all user and system events to hardened, chained logs."""
    def __init__(self, log_filepath: str = "/workspace/scratch/meantime_journal.jsonl"):
        self.log_filepath = log_filepath
        self.last_hash = "0" * 64
        self.entry_counter = 0
        self._init_journal()

    def _init_journal(self) -> None:
        if not os.path.exists(self.log_filepath):
            with open(self.log_filepath, "w") as f:
                f.write("")  # Create empty file

    def record(self, source: str, action_type: str, payload: Dict[str, Any]) -> StenographerEntry:
        self.entry_counter += 1
        entry = StenographerEntry(
            entry_id=self.entry_counter,
            utc_ts=time.time(),
            source=source,
            action_type=action_type,
            payload=payload,
            prev_hash=self.last_hash
        )
        entry.compute_hashes()
        self.last_hash = entry.content_hash

        # Append to immutable WORM disk log
        with open(self.log_filepath, "a") as f:
            f.write(json.dumps(asdict(entry)) + "\n")

        print(f"  [STENOGRAPHER LOG] #{entry.entry_id} [{source}] {action_type} | Hash: {entry.content_hash[:12]}...")
        return entry

    def verify_integrity(self) -> bool:
        """Verifies the complete hash chain from disk to detect tampering."""
        if not os.path.exists(self.log_filepath):
            return True
        
        current_prev = "0" * 64
        with open(self.log_filepath, "r") as f:
            for line in f:
                if not line.strip():
                    continue
                data = json.loads(line.strip())
                if data["prev_hash"] != current_prev:
                    print(f"❌ [TAMPER DETECTED] Entry #{data['entry_id']} previous hash mismatch!")
                    return False
                
                # Re-verify content hash
                recalc_entry = StenographerEntry(
                    entry_id=data["entry_id"],
                    utc_ts=data["utc_ts"],
                    source=data["source"],
                    action_type=data["action_type"],
                    payload=data["payload"],
                    prev_hash=data["prev_hash"]
                )
                recalc_entry.compute_hashes()
                if recalc_entry.content_hash != data["content_hash"]:
                    print(f"❌ [TAMPER DETECTED] Entry #{data['entry_id']} content hash invalid!")
                    return False
                
                current_prev = data["content_hash"]
        return True


# --- 2. MEANTIME CALIBRATION ENGINE ---

class MeantimeCalibrationEngine:
    """Backup generator engine that handles requests when primary systems drop out."""
    def __init__(self, stenographer: CryptographicStenographer):
        self.stenographer = stenographer
        self.is_active = False

    def activate(self, reason: str) -> None:
        self.is_active = True
        print(f"\n⚡ [MEANTIME ENGINE ACTIVATED] Reason: {reason}")
        self.stenographer.record(
            source="MAIN_SERVICE",
            action_type="FAILOVER_ACTIVATED",
            payload={"reason": reason, "mode": "MEANTIME_CALIBRATION"}
        )

    def deactivate() -> None:
        pass

    def handle_user_request(self, user_id: str, request_data: Dict[str, Any]) -> Dict[str, Any]:
        """Processes user actions during primary outage while cryptographically recording everything."""
        if not self.is_active:
            raise RuntimeError("Meantime engine called while primary is active!")

        # 1. Log incoming user action
        self.stenographer.record(
            source="USER_SIDE",
            action_type="USER_REQUEST_RECEIVED",
            payload={"user_id": user_id, "data": request_data}
        )

        # 2. Local fallback processing
        response_payload = {
            "status": "PROCESSED_IN_MEANTIME",
            "message": "Processed under SLA backup protection.",
            "echo_data": request_data,
            "processed_at": time.time()
        }

        # 3. Log outgoing response
        self.stenographer.record(
            source="MAIN_SERVICE",
            action_type="MEANTIME_RESPONSE_SENT",
            payload={"user_id": user_id, "response": response_payload}
        )

        return response_payload

    def export_and_reconcile(self, primary_window_endpoint: str) -> Dict[str, Any]:
        """Exports cryptographic journal and syncs back to primary window upon restoration."""
        print(f"\n🔄 [EXPORT & RECONCILE] Primary window restored at {primary_window_endpoint}.")
        
        # Verify integrity before sync
        if not self.stenographer.verify_integrity():
            raise ValueError("Reconciliation aborted: Cryptographic journal failed integrity check!")

        # Read all recorded entries
        entries = []
        with open(self.stenographer.log_filepath, "r") as f:
            for line in f:
                if line.strip():
                    entries.append(json.loads(line.strip()))

        export_bundle = {
            "export_ts": time.time(),
            "total_entries": len(entries),
            "journal_head_hash": self.stenographer.last_hash,
            "journal_entries": entries
        }

        # Log reconciliation completion
        self.stenographer.record(
            source="MAIN_SERVICE",
            action_type="RECONCILIATION_EXPORT_COMPLETED",
            payload={"target_endpoint": primary_window_endpoint, "count": len(entries)}
        )

        self.is_active = False
        print(f"✅ [RECONCILIATION SUCCESSFUL] Handed off {len(entries)} cryptographic events to Primary Server Window.")
        return export_bundle


# --- 3. SYSTEM HEALTH MONITOR (TRIGGER) ---

class SystemHealthMonitor:
    """Monitors system metrics (latency, error rate, CPU/VRAM) and triggers failover."""
    def __init__(self, meantime_engine: MeantimeCalibrationEngine, max_latency_ms: float = 200.0, max_error_rate: float = 0.05):
        self.meantime_engine = meantime_engine
        self.max_latency_ms = max_latency_ms
        self.max_error_rate = max_error_rate

    def evaluate_metrics(self, current_latency_ms: float, error_rate: float, maintenance_mode: bool = False) -> bool:
        if maintenance_mode:
            self.meantime_engine.activate("SCHEDULED_SERVER_MAINTENANCE")
            return True
        elif current_latency_ms > self.max_latency_ms:
            self.meantime_engine.activate(f"SLA_LATENCY_BREACH ({current_latency_ms}ms > {self.max_latency_ms}ms)")
            return True
        elif error_rate > self.max_error_rate:
            self.meantime_engine.activate(f"CRITICAL_ERROR_RATE ({error_rate:.2f} > {self.max_error_rate})")
            return True
        return False


# --- DEMO EXECUTION ---

if __name__ == "__main__":
    print("=================================================================")
    print("      MEANTIME CALIBRATION ENGINE & CRYPTOGRAPHIC STENOGRAPHER    ")
    print("=================================================================\n")

    # Clean previous journal
    log_path = "/workspace/scratch/meantime_journal.jsonl"
    if os.path.exists(log_path):
        os.remove(log_path)

    # Instantiate stack
    stenographer = CryptographicStenographer(log_filepath=log_path)
    meantime_engine = MeantimeCalibrationEngine(stenographer=stenographer)
    monitor = SystemHealthMonitor(meantime_engine=meantime_engine, max_latency_ms=150.0)

    # 1. Nominal Operations
    print("--- 1. MONITORING PRIMARY SYSTEM METRICS ---")
    monitor.evaluate_metrics(current_latency_ms=42.0, error_rate=0.01)
    print("Primary system nominal.")

    # 2. SLA Spike & Failover Trigger
    print("\n--- 2. CRITICAL METRIC DETECTED (TRIGGER MEANTIME ENGINE) ---")
    monitor.evaluate_metrics(current_latency_ms=310.5, error_rate=0.02)  # Triggers failover!

    # 3. User Actions in the Meantime
    print("\n--- 3. USER ACTIONS DURING MEANTIME OUTAGE ---")
    res1 = meantime_engine.handle_user_request(
        user_id="USR_ALPHA_01",
        request_data={"action": "SUBMIT_DEPOT_AUDIT", "cost_zar": 24500, "depot": "SISHEN_NORTH"}
    )
    
    res2 = meantime_engine.handle_user_request(
        user_id="USR_BETA_02",
        request_data={"action": "REBALANCE_FRONTHAUL_POWER", "node": "THZ_NODE_04"}
    )

    # 4. Primary System Restored -> Reconciliation Export
    print("\n--- 4. PRIMARY SYSTEM RESTORATION & EXPORT ---")
    bundle = meantime_engine.export_and_reconcile(primary_window_endpoint="https://vvu-enterprise.space-z.ai/api/reconcile")

    print("\n--- 5. CRYPTOGRAPHIC JOURNAL VERIFICATION ---")
    is_valid = stenographer.verify_integrity()
    print(f"Journal Tamper-Check Result: {'PASSED (CHAIN INTACT)' if is_valid else 'FAILED'}")
    print("\n=================================================================")
