#!/usr/bin/env python3
"""
OPC UA MCP Server Bridge: Unifying PLC Discrete Logic & DCS Continuous Control
Demonstrates how a Model Context Protocol (MCP) industrial gateway exposes both
fast PLC discrete safety alarms/interlocks and DCS continuous PID loop parameters
to a local LangGraph autonomous agent.
"""

import json
import time
from typing import Dict, Any, List

class MockOPCUAPlcDcsServer:
    """
    Simulates a unified OPC UA Server exposing both PLC (Discrete)
    and DCS (Continuous PID) nodes under standardized OPC UA NodeIDs.
    """
    def __init__(self):
        self._nodes: Dict[str, Dict[str, Any]] = {
            # -------------------------------------------------------------
            # PLC DOMAIN: Discrete Logic, Interlocks & Hardware Alarms
            # -------------------------------------------------------------
            "ns=2;s=PLC.Alarms.EmergencyStop_Triggered": {
                "name": "PLC_EmergencyStop_Triggered",
                "type": "Boolean",
                "value": False,
                "domain": "PLC_DISCRETE",
                "unit": "state",
                "description": "Hardware physical emergency stop pushbutton status"
            },
            "ns=2;s=PLC.Interlocks.Conveyor_HighSpeed_Interlock": {
                "name": "PLC_Conveyor_Interlock",
                "type": "Boolean",
                "value": True,
                "domain": "PLC_DISCRETE",
                "unit": "state",
                "description": "High-speed conveyor physical safety interlock (True = Permissive)"
            },
            "ns=2;s=PLC.Alarms.Motor_Overload_Trip": {
                "name": "PLC_Motor_Overload_Trip",
                "type": "Boolean",
                "value": False,
                "domain": "PLC_DISCRETE",
                "unit": "state",
                "description": "Slurry pump motor overload thermal trip bit"
            },
            
            # -------------------------------------------------------------
            # DCS DOMAIN: Continuous Process Variables & PID Control Loops
            # -------------------------------------------------------------
            "ns=2;s=DCS.BioReactor.TIC101.PV": {
                "name": "BioReactor_Temp_PV",
                "type": "Double",
                "value": 37.2,
                "domain": "DCS_CONTINUOUS",
                "unit": "°C",
                "description": "Bio-leaching reactor temperature Process Variable"
            },
            "ns=2;s=DCS.BioReactor.TIC101.SP": {
                "name": "BioReactor_Temp_SP",
                "type": "Double",
                "value": 37.0,
                "domain": "DCS_CONTINUOUS",
                "unit": "°C",
                "description": "Bio-leaching reactor temperature Set Point"
            },
            "ns=2;s=DCS.BioReactor.TIC101.OP": {
                "name": "BioReactor_Temp_OP",
                "type": "Double",
                "value": 42.5,
                "domain": "DCS_CONTINUOUS",
                "unit": "%",
                "description": "SMR steam valve output control signal"
            },
            "ns=2;s=DCS.BioReactor.AIC102.PV": {
                "name": "BioReactor_pH_PV",
                "type": "Double",
                "value": 1.32,
                "domain": "DCS_CONTINUOUS",
                "unit": "pH",
                "description": "Acidithiobacillus ferrooxidans slurry pH Process Variable"
            },
            "ns=2;s=DCS.BioReactor.AIC102.SP": {
                "name": "BioReactor_pH_SP",
                "type": "Double",
                "value": 1.30,
                "domain": "DCS_CONTINUOUS",
                "unit": "pH",
                "description": "Slurry acid dosing Set Point"
            },
            "ns=2;s=DCS.SMR.FIC201.PV": {
                "name": "SMR_Steam_Flow_PV",
                "type": "Double",
                "value": 128.5,
                "domain": "DCS_CONTINUOUS",
                "unit": "kg/s",
                "description": "Cogeneration high-pressure steam flow rate"
            }
        }

    def read_node(self, node_id: str) -> Dict[str, Any]:
        if node_id not in self._nodes:
            raise KeyError(f"NodeID '{node_id}' not found in OPC UA Address Space.")
        node = self._nodes[node_id]
        return {
            "node_id": node_id,
            "name": node["name"],
            "value": node["value"],
            "domain": node["domain"],
            "unit": node["unit"],
            "timestamp": time.time()
        }

    def write_node(self, node_id: str, value: Any) -> Dict[str, Any]:
        if node_id not in self._nodes:
            raise KeyError(f"NodeID '{node_id}' not found in OPC UA Address Space.")
        
        node = self._nodes[node_id]
        old_val = node["value"]
        node["value"] = value
        return {
            "status": "SUCCESS",
            "node_id": node_id,
            "name": node["name"],
            "old_value": old_val,
            "new_value": value,
            "timestamp": time.time()
        }

    def browse_unified_address_space(self) -> List[Dict[str, Any]]:
        """Returns all nodes grouped under a unified MCP model context."""
        return [
            {
                "node_id": nid,
                "name": data["name"],
                "domain": data["domain"],
                "value": data["value"],
                "unit": data["unit"],
                "description": data["description"]
            }
            for nid, data in self._nodes.items()
        ]


class OPCUAMcpToolGateway:
    """
    Model Context Protocol (MCP) Tool Wrapper.
    Exposes OPC UA actions as JSON-schema tools callable by LangGraph agents.
    """
    def __init__(self, opc_server: MockOPCUAPlcDcsServer):
        self.server = opc_server

    def get_tool_definitions(self) -> List[Dict[str, Any]]:
        return [
            {
                "name": "read_plant_telemetry",
                "description": "Reads full unified OPC UA telemetry including discrete PLC alarms and continuous DCS PID loops.",
                "parameters": {}
            },
            {
                "name": "write_dcs_setpoint",
                "description": "Adjusts continuous DCS PID controller Set Point (SP). Restricted to DCS domain.",
                "parameters": {
                    "node_id": {"type": "string", "description": "OPC UA NodeID"},
                    "setpoint_value": {"type": "number", "description": "New Set Point target"}
                }
            },
            {
                "name": "acknowledge_plc_alarm",
                "description": "Reset or acknowledge discrete PLC alarm state.",
                "parameters": {
                    "node_id": {"type": "string", "description": "OPC UA NodeID"}
                }
            }
        ]

    def execute_tool(self, tool_name: str, arguments: Dict[str, Any]) -> Dict[str, Any]:
        if tool_name == "read_plant_telemetry":
            return {"telemetry": self.server.browse_unified_address_space()}
        elif tool_name == "write_dcs_setpoint":
            node_id = arguments["node_id"]
            val = arguments["setpoint_value"]
            # Validate domain restriction
            read_data = self.server.read_node(node_id)
            if read_data["domain"] != "DCS_CONTINUOUS":
                return {
                    "status": "REJECTED",
                    "reason": f"Node '{node_id}' belongs to {read_data['domain']}. Setpoints can only be written to DCS loops."
                }
            return self.server.write_node(node_id, float(val))
        else:
            return {"status": "ERROR", "message": f"Unknown tool '{tool_name}'"}


class LangGraphAgentSupervisor:
    """
    Agentic Orchestrator demonstrating dual-domain awareness:
    1. Evaluates PLC discrete bits for immediate safety hazards.
    2. Evaluates DCS continuous trends for adaptive process optimization.
    """
    def __init__(self, mcp_gateway: OPCUAMcpToolGateway):
        self.mcp = mcp_gateway

    def run_cycle(self):
        print("=" * 80)
        print("  LANGGRAPH AGENT SUPERVISORY CYCLE: PLC & DCS DUAL-DOMAIN EVALUATION")
        print("=" * 80)

        # Step 1: Read Unified Telemetry via MCP Tool
        raw_resp = self.mcp.execute_tool("read_plant_telemetry", {})
        telemetry = raw_resp["telemetry"]

        # Separate telemetry by domain
        plc_nodes = [t for t in telemetry if t["domain"] == "PLC_DISCRETE"]
        dcs_nodes = [t for t in telemetry if t["domain"] == "DCS_CONTINUOUS"]

        print("\n[1] PLC DISCRETE DOMAIN STATUS (Sub-10ms Interlocks & Alarms):")
        alarm_detected = False
        for node in plc_nodes:
            status_str = "TRIPPED / ALARM" if (node["value"] is True and "Interlock" not in node["name"]) else "NORMAL"
            if "Interlock" in node["name"]:
                status_str = "PERMISSIVE (OK)" if node["value"] is True else "BLOCKED"
            print(f"  • [{node['name']}] Value: {node['value']} ({status_str})")
            if node["value"] is True and "Alarm" in node["node_id"]:
                alarm_detected = True

        print("\n[2] DCS CONTINUOUS DOMAIN STATUS (Multivariable Process Loops):")
        for node in dcs_nodes:
            print(f"  • [{node['name']}] Value: {node['value']} {node['unit']}")

        # Step 3: Agent Reasoning & Action Dispatch
        print("\n[3] COGNITIVE AGENT REASONING & CLOSED-LOOP ACTION:")
        if alarm_detected:
            print("  ⚠️ [Agent Decision] Discrete PLC alarm detected! Bypassing continuous optimization and executing safety protocol.")
        else:
            # Check BioReactor Temp drift vs SetPoint
            pv_node = next(n for n in dcs_nodes if n["name"] == "BioReactor_Temp_PV")
            sp_node = next(n for n in dcs_nodes if n["name"] == "BioReactor_Temp_SP")
            
            delta = pv_node["value"] - sp_node["value"]
            print(f"  • Temperature Error (PV - SP): +{delta:.2f} °C")
            
            if delta > 0.15:
                print("  • [Agent Decision] Temperature elevated above target. Adjusting DCS PID setpoint via MCP tool...")
                action_res = self.mcp.execute_tool(
                    "write_dcs_setpoint",
                    {"node_id": "ns=2;s=DCS.BioReactor.TIC101.SP", "setpoint_value": 36.8}
                )
                print(f"  • [MCP Actuation Result]: {json.dumps(action_res, indent=2)}")


if __name__ == "__main__":
    opc_server = MockOPCUAPlcDcsServer()
    mcp_gateway = OPCUAMcpToolGateway(opc_server)
    supervisor = LangGraphAgentSupervisor(mcp_gateway)
    supervisor.run_cycle()
