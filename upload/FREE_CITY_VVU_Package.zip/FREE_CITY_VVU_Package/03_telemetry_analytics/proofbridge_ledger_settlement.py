import hashlib
import json
import time
import datetime

class ProofBridgeLedgerContract:
    """
    Simulated EVM Smart Contract (ProofBridgeLedger.sol)
    Implements on-chain WORM ledger settlement, circuit breaker gates, and POPIA tags.
    """
    def __init__(self, contract_address: str = "0x71C7656EC7ab88b098defB751B7401B5f6d8976F"):
        self.contract_address = contract_address
        self.block_height = 18452091
        self.state_root = "0x892a0d938bf7e1082c349a1d520a8d90f231e6b8c9d0124231f82b7194c6521a"
        self.onchain_records = {}
        self.committed_bundles = []
        self.circuit_breaker_tripped = False

    def commit_reconciled_bundle(self, head_hash: str, event_records: list, sender_address: str = "0xNode_Sishen_01"):
        """
        EVM Method: commitReconciledBundle(bytes32 headHash, EventRecord[] records)
        """
        if self.circuit_breaker_tripped:
            raise RuntimeError("CRITICAL: On-Chain Circuit Breaker is ACTIVE. Transactions halted.")

        self.block_height += 1
        tx_hash = "0x" + hashlib.sha256(f"{head_hash}{self.block_height}{time.time()}".encode()).hexdigest()

        # Validate cryptographic continuity
        calculated_head = self._verify_chain_integrity(event_records)
        if calculated_head != head_hash:
            self.circuit_breaker_tripped = True
            raise ValueError(f"Circuit Breaker Tripped! Provided headHash ({head_hash[:10]}...) != Calculated head ({calculated_head[:10]}...).")

        bundle_entry = {
            "block_number": self.block_height,
            "tx_hash": tx_hash,
            "sender": sender_address,
            "head_hash": head_hash,
            "event_count": len(event_records),
            "timestamp_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "gas_used": 142050 + (len(event_records) * 12500)
        }

        # Store individual WORM records on-chain
        for record in event_records:
            receipt_hash = record["hash"]
            self.onchain_records[receipt_hash] = {
                "block_number": self.block_height,
                "tx_hash": tx_hash,
                "camera_id": record["cam_id"],
                "threat_class": record["threat"],
                "popia_consent": record["popia_tag"],
                "timestamp": record["ts"],
                "verified": True
            }

        self.committed_bundles.append(bundle_entry)
        self.state_root = "0x" + hashlib.sha256(f"{self.state_root}{tx_hash}".encode()).hexdigest()

        return {
            "status": "0x1 (SUCCESS)",
            "block_number": self.block_height,
            "tx_hash": tx_hash,
            "gas_used": bundle_entry["gas_used"],
            "logs_emitted": len(event_records),
            "new_state_root": self.state_root
        }

    def verify_record_on_chain(self, receipt_hash: str):
        """
        EVM View Method: verifyRecord(bytes32 receiptHash)
        """
        if receipt_hash in self.onchain_records:
            return {
                "exists": True,
                "record": self.onchain_records[receipt_hash],
                "circuit_breaker": "NORMAL"
            }
        return {"exists": False, "circuit_breaker": "NORMAL"}

    def _verify_chain_integrity(self, records: list) -> str:
        prev_hash = "GENESIS_ANCHOR_SIS_01"
        for r in records:
            payload = f"{prev_hash}|{r['ts']}|{r['cam_id']}|{r['threat']}|{r['popia_tag']}"
            r_hash = hashlib.sha256(payload.encode()).hexdigest()
            prev_hash = r_hash
        return prev_hash


def run_proofbridge_settlement_demo():
    print("====================================================================")
    print("   PROOFBRIDGE SMART CONTRACT LEDGER: ON-CHAIN SETTLEMENT DEMO      ")
    print("====================================================================\n")

    # 1. Initialize Contract
    contract = ProofBridgeLedgerContract()
    print(f"[CONTRACT INITIALIZED] Address: {contract.contract_address}")
    print(f"Current Block: #{contract.block_height} | Initial State Root: {contract.state_root[:18]}...\n")

    # 2. Simulate Reconciled Meantime Threat Events
    print("--- 1. PREPARING RECONCILED MEANTIME THREAT BUNDLE ---")
    genesis_anchor = "GENESIS_ANCHOR_SIS_01"
    
    events = [
        {
            "ts": "2026-09-21T09:52:00Z",
            "cam_id": "CAM_01_NORTH_GATE",
            "threat": "PERSON_RESTRICTED_ZONE",
            "popia_tag": "POPIA-ZA-2013-ef9a97b1"
        },
        {
            "ts": "2026-09-21T09:53:15Z",
            "cam_id": "CAM_04_SUBSTATION_EAST",
            "threat": "UNIDENTIFIED_VEHICLE_HIGH_VOLTAGE",
            "popia_tag": "POPIA-ZA-2013-ce7b13b8"
        },
        {
            "ts": "2026-09-21T09:54:30Z",
            "cam_id": "CAM_01_NORTH_GATE",
            "threat": "PERIMETER_BREACH_ATTEMPT",
            "popia_tag": "POPIA-ZA-2013-a4f89d02"
        }
    ]

    # Compute WORM hash chain
    prev_hash = genesis_anchor
    for e in events:
        payload = f"{prev_hash}|{e['ts']}|{e['cam_id']}|{e['threat']}|{e['popia_tag']}"
        e["hash"] = hashlib.sha256(payload.encode()).hexdigest()
        prev_hash = e["hash"]
    
    head_hash = prev_hash
    print(f"Generated Bundle: {len(events)} Threat Events | WORM Head Hash: {head_hash}\n")

    # 3. Execute On-Chain Settlement
    print("--- 2. EXECUTING ON-CHAIN TRANSACTION (commitReconciledBundle) ---")
    tx_receipt = contract.commit_reconciled_bundle(
        head_hash=head_hash,
        event_records=events,
        sender_address="0xNode_Sishen_Edge_01"
    )

    print("Transaction Receipt:")
    print(json.dumps(tx_receipt, indent=2))
    print()

    # 4. Verify Individual Record On-Chain
    print("--- 3. ON-CHAIN VERIFICATION QUERY (verifyRecord) ---")
    test_hash = events[1]["hash"]
    query_res = contract.verify_record_on_chain(test_hash)
    print(f"Querying Receipt Hash: {test_hash[:16]}...")
    print(json.dumps(query_res, indent=2))
    print()

    # 5. Simulate Circuit Breaker Tamper Prevention
    print("--- 4. TESTING WATCHDOG & CIRCUIT BREAKER TAMPER DEFENSE ---")
    corrupted_head = "0x" + "a" * 64
    print("Attempting to submit corrupted bundle with mismatched head hash...")
    try:
        contract.commit_reconciled_bundle(
            head_hash=corrupted_head,
            event_records=events,
            sender_address="0xNode_Malicious_02"
        )
    except Exception as err:
        print(f"🛡️ [CIRCUIT BREAKER ACTION] Execution Blocked: {err}")

    print("\n====================================================================")
    print("   SETTLEMENT SUMMARY: All Reconciled Threat Events Anchored On-Chain")
    print("====================================================================")

if __name__ == "__main__":
    run_proofbridge_settlement_demo()
