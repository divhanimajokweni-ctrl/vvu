"""
test_compute_stokvel_rosca.py
--------------------------------------------------------------------------------
Comprehensive Test Harness & Off-Chain Logic Simulation for ComputeStokvelROSCA.sol

Simulates the lifecycle of a South African Agricultural/SME Compute Stokvel ROSCA:
1. Pool Creation & Parameters Validation (10% Platform Fee, Target Members)
2. Member Onboarding & Capital Escrow (Target 10 Farmers @ R1,000 / 1 ETH equivalent)
3. Auto-Activation Trigger, Maintainer Fee Distribution & Credit Minting
4. Off-Peak Idle Compute Revenue Ingestion & Dynamic Credit Rewards
5. Ubuntu Hardship Governance (Proposal creation, voting, majority threshold resolution)
6. Off-Grid ProofBridge Compute Credit Burning (agreement_rail_bridge.py integration)
7. Pro-Rata Exit Calculation & Final Ledger Settlement

Author: Divhani Mihle Majokweni
License: MIT
--------------------------------------------------------------------------------
"""

import sys
import json
import time
import hashlib
from datetime import datetime, timezone

class MockComputeStokvelROSCA:
    """
    Python Reference Implementation matching the exact EVM logic and state transitions
    of ComputeStokvelROSCA.sol.
    """
    def __init__(self, pool_name: str, target_member_count: int, target_funding_wei: int, platform_fee_bps: int, maintainer_address: str):
        assert target_member_count > 0, "Target members must be > 0"
        assert target_funding_wei > 0, "Target funding must be > 0"
        assert platform_fee_bps <= 2000, "Platform fee capped at 20%"

        self.platform_maintainer = maintainer_address
        self.pool_name = pool_name
        self.target_member_count = target_member_count
        self.target_funding_amount = target_funding_wei
        self.platform_fee_bps = platform_fee_bps

        self.current_state = "Funding" # Funding, Active, Terminated
        self.total_deposited = 0
        self.total_compute_credits_minted = 0
        self.member_count = 0
        self.proposal_counter = 0

        self.contract_balance = 0
        self.maintainer_balance = 0

        self.member_list = []
        self.members = {}
        self.proposals = {}
        self.event_log = []

    def _emit_event(self, event_name: str, payload: dict):
        event_entry = {
            "event": event_name,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "data": payload
        }
        self.event_log.append(event_entry)

    def join_pool(self, sender_address: str, deposit_value_wei: int):
        assert self.current_state == "Funding", "ROSCA: Invalid pool state for operation"
        assert deposit_value_wei > 0, "ROSCA: Contribution must be > 0"
        assert self.member_count < self.target_member_count, "ROSCA: Target member capacity reached"
        assert sender_address not in self.members or not self.members[sender_address]["is_active"], "ROSCA: Address already a member"

        expected_per_member = self.target_funding_amount // self.target_member_count
        assert deposit_value_wei == expected_per_member, f"ROSCA: Incorrect contribution. Expected {expected_per_member}, got {deposit_value_wei}"

        share_bps = 10000 // self.target_member_count

        self.members[sender_address] = {
            "wallet": sender_address,
            "contributed_amount": deposit_value_wei,
            "share_percentage_bps": share_bps,
            "compute_credits_balance": 0,
            "is_active": True,
            "joined_timestamp": time.time(),
            "deferral_until_timestamp": 0
        }

        self.member_list.append(sender_address)
        self.member_count += 1
        self.total_deposited += deposit_value_wei
        self.contract_balance += deposit_value_wei

        self._emit_event("MemberJoined", {
            "member": sender_address,
            "amount": deposit_value_wei,
            "total_members": self.member_count
        })

        if self.member_count == self.target_member_count and self.total_deposited >= self.target_funding_amount:
            self._activate_pool()

    def _activate_pool(self):
        self.current_state = "Active"

        fee_amount = (self.total_deposited * self.platform_fee_bps) // 10000
        hardware_escrow_amount = self.total_deposited - fee_amount

        # Distribute maintainer fee
        self.contract_balance -= fee_amount
        self.maintainer_balance += fee_amount

        # Mint initial compute credits to members proportional to their shares
        initial_credits_per_member = 1000 * (10**18)
        for m in self.member_list:
            self.members[m]["compute_credits_balance"] += initial_credits_per_member
            self.total_compute_credits_minted += initial_credits_per_member
            self._emit_event("ComputeCreditsMinted", {"member": m, "amount": initial_credits_per_member})

        self._emit_event("PoolActivated", {
            "hardware_escrow_amount": hardware_escrow_amount,
            "platform_fee_amount": fee_amount
        })

    def deposit_idle_compute_revenue(self, sender_address: str, deposit_value_wei: int):
        assert self.current_state == "Active", "ROSCA: Pool not active"
        assert deposit_value_wei > 0, "ROSCA: Revenue deposit must be > 0"

        self.total_deposited += deposit_value_wei
        self.contract_balance += deposit_value_wei

        self._emit_event("IdleComputeRevenueDeposited", {"payer": sender_address, "amount": deposit_value_wei})

        # Distribute bonus credits to active, non-deferred members
        credit_bonus = (deposit_value_wei * 100) // self.member_count
        now = time.time()
        for m in self.member_list:
            if self.members[m]["is_active"] and now >= self.members[m]["deferral_until_timestamp"]:
                self.members[m]["compute_credits_balance"] += credit_bonus
                self.total_compute_credits_minted += credit_bonus
                self._emit_event("ComputeCreditsMinted", {"member": m, "amount": credit_bonus})

    def propose_hardship_deferral(self, sender_address: str, reason: str, duration_seconds: int) -> int:
        assert self.current_state == "Active", "ROSCA: Pool not active"
        assert sender_address in self.members and self.members[sender_address]["is_active"], "ROSCA: Caller is not active member"

        self.proposal_counter += 1
        p_id = self.proposal_counter
        voting_deadline = time.time() + (3 * 86400) # 3 days

        self.proposals[p_id] = {
            "proposal_id": p_id,
            "member_address": sender_address,
            "reason": reason,
            "deferral_duration_seconds": duration_seconds,
            "votes_for": 0,
            "votes_against": 0,
            "voting_deadline": voting_deadline,
            "status": "Pending",
            "voters": set()
        }

        self._emit_event("HardshipProposed", {
            "proposal_id": p_id,
            "member": sender_address,
            "reason": reason,
            "deadline": voting_deadline
        })
        return p_id

    def vote_hardship_deferral(self, sender_address: str, proposal_id: int, approve: bool):
        assert self.current_state == "Active", "ROSCA: Pool not active"
        assert sender_address in self.members and self.members[sender_address]["is_active"], "ROSCA: Caller is not active member"
        assert proposal_id in self.proposals, "ROSCA: Proposal does not exist"

        p = self.proposals[proposal_id]
        assert p["status"] == "Pending", "ROSCA: Proposal not pending"
        assert time.time() <= p["voting_deadline"], "ROSCA: Voting deadline passed"
        assert sender_address not in p["voters"], "ROSCA: Member already voted"

        p["voters"].add(sender_address)
        if approve:
            p["votes_for"] += 1
        else:
            p["votes_against"] += 1

        self._emit_event("HardshipVoted", {"proposal_id": proposal_id, "voter": sender_address, "approve": approve})

        majority_threshold = (self.member_count // 2) + 1
        if p["votes_for"] >= majority_threshold:
            p["status"] = "Approved"
            self.members[p["member_address"]]["deferral_until_timestamp"] = time.time() + p["deferral_duration_seconds"]
            self._emit_event("HardshipResolved", {"proposal_id": proposal_id, "status": "Approved"})
        elif p["votes_against"] >= majority_threshold:
            p["status"] = "Rejected"
            self._emit_event("HardshipResolved", {"proposal_id": proposal_id, "status": "Rejected"})

    def burn_credits_for_compute(self, sender_address: str, member_address: str, credit_amount: int):
        assert sender_address == self.platform_maintainer, "ROSCA: Caller is not maintainer"
        assert self.current_state == "Active", "ROSCA: Pool not active"
        assert member_address in self.members and self.members[member_address]["is_active"], "ROSCA: Inactive member"
        assert self.members[member_address]["compute_credits_balance"] >= credit_amount, "ROSCA: Insufficient credits"

        self.members[member_address]["compute_credits_balance"] -= credit_amount
        self.total_compute_credits_minted -= credit_amount

        self._emit_event("ComputeCreditsBurned", {"member": member_address, "amount": credit_amount})

    def exit_pool(self, sender_address: str) -> int:
        assert sender_address in self.members and self.members[sender_address]["is_active"], "ROSCA: Member not active"

        m = self.members[sender_address]
        m["is_active"] = False
        self.member_count -= 1

        pro_rata_share = (self.contract_balance * m["share_percentage_bps"]) // 10000
        m["compute_credits_balance"] = 0
        self.contract_balance -= pro_rata_share

        self._emit_event("MemberWithdrawn", {"member": sender_address, "refund_amount": pro_rata_share})
        return pro_rata_share


def run_unit_tests():
    print("=" * 80)
    print("  COMPUTE STOKVEL ROSCA (.SOL & MOCK) VERIFICATION TEST SUITE")
    print("=" * 80)

    maintainer = "0xProofBridgeOrchestratorMaintainer0001"
    target_members = 5
    per_member_deposit = 1000 * (10**18) # 1000 Tokens / ETH
    total_target = target_members * per_member_deposit # 5000 Tokens
    platform_fee_bps = 1000 # 10%

    print("\n[TEST 1] Initializing ComputeStokvelROSCA Contract Instance...")
    rosca = MockComputeStokvelROSCA(
        pool_name="SundaysRiverCitrusCoOp_Pool_01",
        target_member_count=target_members,
        target_funding_wei=total_target,
        platform_fee_bps=platform_fee_bps,
        maintainer_address=maintainer
    )
    assert rosca.current_state == "Funding"
    print("  ✓ State: Funding | Target Members: 5 | Target Capital: 5000 Tokens | Fee: 10%")

    print("\n[TEST 2] Member Onboarding & Contribution Escalation...")
    farmers = [f"0xFarmerWallet_0{i+1}" for i in range(target_members)]
    for idx, farmer in enumerate(farmers):
        rosca.join_pool(farmer, per_member_deposit)
        print(f"  + Member {idx+1}/{target_members} joined: {farmer} (Contributed {per_member_deposit // 10**18} Tokens)")

    assert rosca.current_state == "Active"
    print("  ✓ Target capacity satisfied -> Pool auto-activated!")
    print(f"  ✓ Maintainer Fee Collected (10%): {rosca.maintainer_balance // 10**18} Tokens")
    print(f"  ✓ Hardware Escrow Reserved: {rosca.contract_balance // 10**18} Tokens")
    print(f"  ✓ Member 1 Initial Compute Credits Minted: {rosca.members[farmers[0]]['compute_credits_balance'] // 10**18} Credits")

    print("\n[TEST 3] Ingesting Idle Compute Rental Revenue...")
    researcher_deposit = 500 * (10**18) # 500 Tokens from external researcher
    rosca.deposit_idle_compute_revenue("0xResearchLab_Exeter", researcher_deposit)
    print(f"  + Idle Compute Revenue Deposited: {researcher_deposit // 10**18} Tokens")
    print(f"  ✓ Updated Contract Reserve Balance: {rosca.contract_balance // 10**18} Tokens")
    print(f"  ✓ Farmer 1 Bonus Credits Added: {rosca.members[farmers[0]]['compute_credits_balance'] // 10**18} Credits Total")

    print("\n[TEST 4] Ubuntu Hardship Deferral Proposal & Voting...")
    p_id = rosca.propose_hardship_deferral(
        sender_address=farmers[0],
        reason="Severe hail storm damaged citrus crop - requesting 30-day contribution freeze",
        duration_seconds=30 * 86400
    )
    print(f"  + Proposal #{p_id} Created by {farmers[0]}")

    # Members 2, 3, 4 vote YES (3/5 = Majority threshold reached)
    rosca.vote_hardship_deferral(farmers[1], p_id, approve=True)
    rosca.vote_hardship_deferral(farmers[2], p_id, approve=True)
    rosca.vote_hardship_deferral(farmers[3], p_id, approve=True)
    
    assert rosca.proposals[p_id]["status"] == "Approved"
    print(f"  ✓ Proposal #{p_id} Status: APPROVED (Majority 3/5 achieved)")
    print(f"  ✓ Farmer 1 Deferral Lock Active Until: {rosca.members[farmers[0]]['deferral_until_timestamp']}")

    print("\n[TEST 5] Off-Grid Local Compute Job Credit Burn (ProofBridge Bridge)...")
    burn_amount = 200 * (10**18)
    rosca.burn_credits_for_compute(maintainer, farmers[1], burn_amount)
    print(f"  ✓ Burned {burn_amount // 10**18} credits for Farmer 2 local AI crop inference")

    print("\n[TEST 6] Member Pro-Rata Exit Settlement...")
    exit_refund = rosca.exit_pool(farmers[4])
    print(f"  ✓ Farmer 5 exited pool. Received Pro-Rata Settlement: {exit_refund // 10**18} Tokens")
    print(f"  ✓ Remaining Active Members: {rosca.member_count}")

    print("\n" + "=" * 80)
    print("  ALL COMPUTE STOKVEL ROSCA TEST CASES PASSED SUCCESSFULLY!")
    print("=" * 80)

if __name__ == "__main__":
    run_unit_tests()
