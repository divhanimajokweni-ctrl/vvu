"""Install receipt — an attestation over a state transition.

A receipt is not a log. It is a claim: "these files were installed, and the
host's state changed from A to B, and every byte of that change is on the
chain." Verify it with `verify_install_receipt`.
"""
import hashlib
import json
from pathlib import Path
from typing import List, Optional

def canonical(obj) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str).encode("utf-8")

def sha256_hex(data) -> str:
    if not isinstance(data, (bytes, bytearray)):
        data = canonical(data)
    return "0x" + hashlib.sha256(data).hexdigest()

RECEIPT_VERSION = "1.0.0"

def diff_records(before: dict, after: dict) -> dict:
    b_probes = before.get("probes", {})
    a_probes = after.get("probes", {})
    all_keys = sorted(list(set(b_probes.keys()) | set(a_probes.keys())))
    diff = {}
    for k in all_keys:
        bv = b_probes.get(k)
        av = a_probes.get(k)
        if bv == av:
            diff[k] = {"before": bv, "after": av, "delta": "same"}
        elif bv is None:
            diff[k] = {"before": None, "after": av, "delta": "added"}
        elif av is None:
            diff[k] = {"before": bv, "after": None, "delta": "removed"}
        else:
            diff[k] = {"before": bv, "after": av, "delta": "changed"}
    return diff

def build_receipt(
    before_record: dict,
    after_record: dict,
    steps: List[dict],
    installer_version: str,
    platform: str,
    keyring,
    chain,
) -> dict:
    diff = diff_records(before_record, after_record)
    diff_hash = sha256_hex(diff)

    b_psh = before_record.get("probe_set_hash")
    a_psh = after_record.get("probe_set_hash")
    comparable = (b_psh is not None and a_psh is not None and b_psh == a_psh)

    body = {
        "receipt_version": RECEIPT_VERSION,
        "installer_version": installer_version,
        "platform": platform,
        "before": {
            "self_hash": before_record.get("attestation", {}).get("self_hash"),
            "chain_prev": before_record.get("attestation", {}).get("chain_prev"),
            "probe_set_hash": b_psh,
        },
        "after": {
            "self_hash": after_record.get("attestation", {}).get("self_hash"),
            "chain_prev": after_record.get("attestation", {}).get("chain_prev"),
            "probe_set_hash": a_psh,
        },
        "steps": steps,
        "diff_hash": diff_hash,
        "comparable": comparable,
        "n_probes_changed": sum(1 for v in diff.values() if v["delta"] != "same"),
        "n_steps": len(steps),
    }

    record_for_sig = {**body, "chain_prev": chain.head}
    sig = keyring.sign(canonical(record_for_sig))
    self_hash = sha256_hex({**record_for_sig, "sig": sig})
    att = {
        "self_hash": self_hash,
        "chain_prev": chain.head,
        "pubkey": keyring.pubkey,
        "sig": sig,
        "tier": keyring.tier
    }

    receipt = {**body, "attestation": att}
    chain.append("install_receipt", receipt)
    return receipt

def write_receipt(receipt: dict, out_path: Path) -> None:
    out_path.parent.mkdir(parents=True, exist_ok=True)
    tmp = out_path.with_suffix(out_path.suffix + ".tmp")
    tmp.write_text(json.dumps(receipt, indent=2, sort_keys=True, ensure_ascii=False))
    tmp.replace(out_path)

def verify_install_receipt(
    receipt: dict,
    before_record: dict,
    after_record: dict,
    keyring=None,
) -> dict:
    from vvu_installer_suite import verify_attested_record
    
    r = verify_attested_record(receipt, keyring)
    if not r["ok"]:
        return {"ok": False, "reason": "receipt attestation: " + r["reason"]}

    b_self = before_record.get("attestation", {}).get("self_hash")
    a_self = after_record.get("attestation", {}).get("self_hash")
    if receipt["before"]["self_hash"] != b_self:
        return {"ok": False, "reason": "before self_hash mismatch"}
    if receipt["after"]["self_hash"] != a_self:
        return {"ok": False, "reason": "after self_hash mismatch"}

    b = verify_attested_record(before_record, keyring)
    a = verify_attested_record(after_record, keyring)
    if not b["ok"]:
        return {"ok": False, "reason": "before record: " + b["reason"]}
    if not a["ok"]:
        return {"ok": False, "reason": "after record: " + a["reason"]}

    fresh_diff = diff_records(before_record, after_record)
    if sha256_hex(fresh_diff) != receipt["diff_hash"]:
        return {"ok": False, "reason": "diff_hash mismatch"}

    if not receipt.get("comparable", False):
        return {"ok": False, "reason": "records not comparable (probe sets differ)"}

    return {
        "ok": True,
        "receipt_version": receipt["receipt_version"],
        "installer_version": receipt["installer_version"],
        "platform": receipt["platform"],
        "n_steps": receipt["n_steps"],
        "n_probes_changed": receipt["n_probes_changed"],
        "self_hash": receipt["attestation"]["self_hash"],
        "tier": receipt["attestation"]["tier"],
    }
