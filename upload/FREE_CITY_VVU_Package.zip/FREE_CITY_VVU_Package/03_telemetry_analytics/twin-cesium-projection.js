/**
 * VVU Trust Spine — Cesium 3D Digital Twin Projection Module
 * ==========================================================
 * Connects to the Multi-View Contract API and renders 3D physical state assets 
 * on photorealistic Earth tiles.
 * 
 * Enforces the State Invariant Contract:
 *   State Contract = (twin_id, state_version, evidence_cutoff)
 * 
 * On HTTP 409 Conflict (chain break / version mismatch), visually degrades the 3D 
 * scene to 'DISPUTED / STALE' with a dark red globe to prevent rendering false state.
 */

export class CesiumTwinProjection {
    constructor(apiBaseUrl, twinId, containerId) {
        this.apiBaseUrl = apiBaseUrl || "http://127.0.0.1:8000/api/v1";
        this.twinId = twinId || "TWIN-SUBSTATION-01";
        this.containerId = containerId || "cesiumContainer";
        
        this.currentStateVersion = null;
        this.currentEvidenceCutoff = null;
        this.sceneEntities = {};
        this.viewer = null;
    }

    async initialize(googleApiKey = null) {
        if (typeof Cesium === 'undefined') {
            console.error("[VVU Twin] CesiumJS library is required.");
            return;
        }

        this.viewer = new Cesium.Viewer(this.containerId, {
            animation: false,
            timeline: false,
            baseLayerPicker: false,
            geocoder: false,
            homeButton: false,
            navigationHelpButton: false,
            sceneModePicker: false,
            infoBox: true,
            selectionIndicator: true,
            requestRenderMode: true
        });

        this.viewer.scene.globe.show = false;

        if (googleApiKey) {
            try {
                const googleTileset = await Cesium.Cesium3DTileset.fromUrl(
                    `https://tile.googleapis.com/v1/3dtiles/root.json?key=${googleApiKey}`
                );
                this.viewer.scene.primitives.add(googleTileset);
            } catch (err) {
                console.warn("[VVU Twin] Google 3D Tiles failed, falling back to OSM Buildings:", err);
                this.loadOsmFallback();
            }
        } else {
            this.loadOsmFallback();
        }

        // Set camera view over South Africa (Mpumalanga / Gauteng region)
        this.viewer.camera.setView({
            destination: Cesium.Cartesian3.fromDegrees(28.17, -26.22, 1500),
            orientation: {
                heading: Cesium.Math.toRadians(0),
                pitch: Cesium.Math.toRadians(-45),
                roll: 0.0
            }
        });

        this.startSyncLoop();
    }

    async loadOsmFallback() {
        const osmBuildings = await Cesium.createOsmBuildingsAsync();
        this.viewer.scene.primitives.add(osmBuildings);
        this.viewer.scene.globe.show = true;
    }

    async fetchTwinState(requestedVersion = null) {
        let url = `${this.apiBaseUrl}/twin/${this.twinId}/state`;
        const params = new URLSearchParams();
        if (requestedVersion) params.append("state_version", requestedVersion);
        if (this.currentEvidenceCutoff) params.append("evidence_cutoff", this.currentEvidenceCutoff);
        if (params.toString()) url += `?${params.toString()}`;

        try {
            const response = await fetch(url);
            if (response.status === 409) {
                const err = await response.json();
                this.handleInvariantBreach(err.detail);
                return null;
            }
            if (!response.ok) throw new Error(`HTTP ${response.status}`);

            const data = await response.json();
            this.updateHUD(data);
            return data;
        } catch (error) {
            this.handleInvariantBreach(error.message);
            return null;
        }
    }

    updateHUD(data) {
        const hudVer = document.getElementById('hud-state-ver');
        const hudHash = document.getElementById('hud-hash');
        const hudStatus = document.getElementById('hud-status');

        if (hudVer) hudVer.innerText = data.state_version;
        if (hudHash) hudHash.innerText = data.head_hash.substring(0, 16) + "...";
        if (hudStatus) {
            hudStatus.innerText = data.verification_state;
            hudStatus.className = "status-badge status-sealed";
        }
    }

    handleInvariantBreach(reason) {
        console.error(`[🚨 INVARIANT BREACH] ${reason}`);
        const hudStatus = document.getElementById('hud-status');
        if (hudStatus) {
            hudStatus.innerText = "DISPUTED / STALE";
            hudStatus.className = "status-badge status-stale";
        }

        // Visually degrade the scene to dark red globe to signal disputed physical state
        if (this.viewer) {
            this.viewer.scene.globe.show = true;
            this.viewer.scene.globe.baseColor = Cesium.Color.DARKRED;
            Object.values(this.sceneEntities).forEach(e => this.viewer.entities.remove(e));
            this.sceneEntities = {};
        }
    }

    renderTwinState(stateData) {
        const assets = stateData.state_data.assets || [];
        assets.forEach(asset => {
            if (this.sceneEntities[asset.id]) {
                const entity = this.sceneEntities[asset.id];
                entity.position = Cesium.Cartesian3.fromDegrees(asset.lng, asset.lat, asset.alt || 10);
            } else {
                const entity = this.viewer.entities.add({
                    id: asset.id,
                    name: asset.name,
                    position: Cesium.Cartesian3.fromDegrees(asset.lng, asset.lat, asset.alt || 10),
                    point: {
                        pixelSize: 12,
                        color: asset.status === 'ACTIVE' ? Cesium.Color.LIME : Cesium.Color.RED,
                        outlineColor: Cesium.Color.WHITE,
                        outlineWidth: 2
                    },
                    label: {
                        text: asset.name,
                        font: '12px monospace',
                        fillColor: Cesium.Color.WHITE,
                        showBackground: true,
                        backgroundColor: new Cesium.Color(0, 0, 0, 0.7)
                    },
                    properties: {
                        worm_hash: stateData.head_hash,
                        state_version: stateData.state_version
                    }
                });
                this.sceneEntities[asset.id] = entity;
            }
        });
    }

    async startSyncLoop() {
        const data = await this.fetchTwinState();
        if (data && this.currentStateVersion !== data.state_version) {
            this.currentStateVersion = data.state_version;
            this.currentEvidenceCutoff = data.evidence_cutoff;
            this.renderTwinState(data);
        }
        setTimeout(() => this.startSyncLoop(), 2000);
    }
}
