#!/usr/bin/env python3
"""
Safegrid / VVU Trust Spine — Weekly Telemetry & Personal Insights Analytics Engine
==================================================================================
Processes 7-day wearable (smartwatch/mobile) telemetry to derive spatial footprints,
pedestrian inertial navigation metrics, and physiological sleep/stress insights.

Features:
  1. Spatial Footprint & Area Bounding: Calculates total distance (km), step count,
     bounding box area A, and the characteristic length scale sqrt(A) of user motion.
  2. Biometric Sleep & Stress Engine: Analyzes nocturnal PPG heart rate and HRV
     (RMSSD) to detect severe sleep debt (e.g. <4h per week) and heat strain.
  3. Verified Personal Insight Generator: Synthesizes Ed25519-signed "Did You Know?"
     weekly summaries for the Operator PWA UI.

Author: Venture Vision Ubuntu
"""

import os
import sys
import json
import math
import time
import hashlib
from typing import List, Dict, Any, Tuple
from cryptography.hazmat.primitives.asymmetric import ed25519
from cryptography.hazmat.primitives import serialization

# ==============================================================================
# 1. SPATIAL FOOTPRINT & INERTIAL NAVIGATION ANALYZER
# ==============================================================================
class SpatialFootprintAnalyzer:
    """
    Computes spatial coverage, step count, total distance, and area footprint
    derived from pedestrian GPS/IMU telemetry.
    """
    @staticmethod
    def calculate_distance_haversine(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
        """Haversine distance in meters."""
        R = 6371000.0  # Earth radius in meters
        phi1 = math.radians(lat1)
        phi2 = math.radians(lat2)
        dphi = math.radians(lat2 - lat1)
        dlam = math.radians(lon2 - lon1)

        a = math.sin(dphi / 2.0)**2 + math.cos(phi1) * math.cos(phi2) * math.sin(dlam / 2.0)**2
        c = 2.0 * math.atan2(math.sqrt(a), math.sqrt(1.0 - a))
        return R * c

    def analyze_spatial_track(self, gps_points: List[Tuple[float, float]], step_samples: int) -> Dict[str, Any]:
        """
        Processes a list of (lat, lng) tuples and accelerometer step counts.
        Returns total distance, bounding box area, and sqrt(Area).
        """
        if not gps_points or len(gps_points) < 2:
            return {
                "total_distance_km": 0.0,
                "step_count": step_samples,
                "bounding_area_m2": 0.0,
                "sqrt_area_meters": 0.0,
                "bounding_box": {"min_lat": 0, "max_lat": 0, "min_lng": 0, "max_lng": 0}
            }

        lats = [p[0] for p in gps_points]
        lngs = [p[1] for p in gps_points]
        min_lat, max_lat = min(lats), max(lats)
        min_lng, max_lng = min(lngs), max(lngs)

        # Total track distance
        total_dist_m = 0.0
        for i in range(len(gps_points) - 1):
            total_dist_m += self.calculate_distance_haversine(
                gps_points[i][0], gps_points[i][1],
                gps_points[i+1][0], gps_points[i+1][1]
            )

        # Approximate bounding box dimensions in meters
        lat_mid = (min_lat + max_lat) / 2.0
        delta_lat_m = (max_lat - min_lat) * 111000.0
        delta_lng_m = (max_lng - min_lng) * (111000.0 * math.cos(math.radians(lat_mid)))

        bounding_area_m2 = delta_lat_m * delta_lng_m
        sqrt_area_meters = math.sqrt(bounding_area_m2)

        return {
            "total_distance_km": round(total_dist_m / 1000.0, 2),
            "step_count": step_samples,
            "bounding_area_m2": round(bounding_area_m2, 1),
            "sqrt_area_meters": round(sqrt_area_meters, 1),
            "bounding_box": {
                "min_lat": min_lat, "max_lat": max_lat,
                "min_lng": min_lng, "max_lng": max_lng
            }
        }


# ==============================================================================
# 2. BIOMETRIC SLEEP & STRESS ANALYZER
# ==============================================================================
class BiometricSleepStressAnalyzer:
    """
    Evaluates 7-day nocturnal PPG heart rate and HRV telemetry to extract
    sleep duration, sleep debt warnings, and cumulative stress metrics.
    """
    def analyze_weekly_biometrics(
        self,
        daily_sleep_hours: List[float],
        resting_hr_bpm: List[float],
        hrv_rmssd_ms: List[float]
    ) -> Dict[str, Any]:
        
        total_sleep_hours = sum(daily_sleep_hours)
        avg_daily_sleep = total_sleep_hours / len(daily_sleep_hours) if daily_sleep_hours else 0.0
        avg_resting_hr = sum(resting_hr_bpm) / len(resting_hr_bpm) if resting_hr_bpm else 0.0
        avg_hrv = sum(hrv_rmssd_ms) / len(hrv_rmssd_ms) if hrv_rmssd_ms else 0.0

        # Detect severe sleep deprivation threshold (e.g. < 21h per week or < 4h per day)
        sleep_deprived = total_sleep_hours < 28.0  # Under 4h/day baseline average

        # Stress index derived from HRV RMSSD reduction & elevated resting HR
        high_stress_days = sum(1 for hrv, hr in zip(hrv_rmssd_ms, resting_hr_bpm) if hrv < 25.0 and hr > 78.0)

        return {
            "total_weekly_sleep_hours": round(total_sleep_hours, 1),
            "avg_daily_sleep_hours": round(avg_daily_sleep, 1),
            "avg_resting_hr_bpm": round(avg_resting_hr, 1),
            "avg_hrv_rmssd_ms": round(avg_hrv, 1),
            "severe_sleep_debt_flag": sleep_deprived,
            "high_stress_days_count": high_stress_days
        }


# ==============================================================================
# 3. VERIFIED PERSONAL INSIGHT GENERATOR
# ==============================================================================
class PersonalInsightEngine:
    """
    Synthesizes spatial footprints and physiological analysis into signed,
    user-facing "Did You Know?" telemetry cards for the PWA HUD.
    """
    def __init__(self, key_dir: str = "/workspace/scratch/keys"):
        os.makedirs(key_dir, exist_ok=True)
        self.key_path = os.path.join(key_dir, "weekly_analytics_ed25519.pem")
        
        if os.path.exists(self.key_path):
            with open(self.key_path, "rb") as f:
                self.priv_key = serialization.load_pem_private_key(f.read(), password=None)
        else:
            self.priv_key = ed25519.Ed25519PrivateKey.generate()
            pem = self.priv_key.private_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PrivateFormat.PKCS8,
                encryption_algorithm=serialization.NoEncryption()
            )
            with open(self.key_path, "wb") as f:
                f.write(pem)
            os.chmod(self.key_path, 0o600)

        self.pub_key = self.priv_key.public_key()
        self.pubkey_hex = self.pub_key.public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw
        ).hex()

        self.spatial_analyzer = SpatialFootprintAnalyzer()
        self.biometric_analyzer = BiometricSleepStressAnalyzer()

    def generate_weekly_report(
        self,
        user_id: str,
        gps_track: List[Tuple[float, float]],
        total_steps: int,
        daily_sleep_hours: List[float],
        resting_hr_bpm: List[float],
        hrv_rmssd_ms: List[float]
    ) -> Dict[str, Any]:
        
        spatial_metrics = self.spatial_analyzer.analyze_spatial_track(gps_track, total_steps)
        biometric_metrics = self.biometric_analyzer.analyze_weekly_biometrics(
            daily_sleep_hours, resting_hr_bpm, hrv_rmssd_ms
        )

        # Generate "Surprise Insights" that highlight hidden truths
        insights = []

        # 1. Spatial & Footprint Insights
        dist_km = spatial_metrics["total_distance_km"]
        sqrt_a = spatial_metrics["sqrt_area_meters"]
        insights.append({
            "title": "Patrol & Motion Footprint",
            "body": f"You walked {spatial_metrics['step_count']:,} steps ({dist_km} km) this week, covering a linear span of ~{sqrt_a:.0f} meters (sqrt of area)."
        })

        # 2. Sleep & Physiological Insights
        tot_sleep = biometric_metrics["total_weekly_sleep_hours"]
        if biometric_metrics["severe_sleep_debt_flag"]:
            insights.append({
                "title": "⚠️ Severe Sleep Debt Alert",
                "body": f"Did you know? You only logged {tot_sleep:.1f} hours of total sleep over the past week (avg {biometric_metrics['avg_daily_sleep_hours']}h/night). Consider an immediate recovery protocol."
            })
        else:
            insights.append({
                "title": "Sleep & Recovery Status",
                "body": f"You logged {tot_sleep:.1f} hours of sleep this week with an average resting heart rate of {biometric_metrics['avg_resting_hr_bpm']} BPM."
            })

        # 3. Stress & Autonomic Tone
        if biometric_metrics["high_stress_days_count"] > 0:
            insights.append({
                "title": "Autonomic Stress Spikes",
                "body": f"Your smartwatch detected reduced Heart Rate Variability (HRV avg: {biometric_metrics['avg_hrv_rmssd_ms']} ms) across {biometric_metrics['high_stress_days_count']} high-load shifts."
            })

        # Canonicalize payload and sign
        payload = {
            "user_id": user_id,
            "timestamp": int(time.time()),
            "spatial_summary": spatial_metrics,
            "biometric_summary": biometric_metrics,
            "insights": insights,
            "verifier_pubkey": self.pubkey_hex
        }

        canonical_bytes = json.dumps(payload, sort_keys=True).encode('utf-8')
        signature = self.priv_key.sign(canonical_bytes).hex()
        report_hash = hashlib.sha256(canonical_bytes).hexdigest()

        return {
            **payload,
            "report_hash": report_hash,
            "ed25519_signature": signature,
            "verification_state": "SEALED_WORM_INSIGHT"
        }


# ==============================================================================
# 4. VERIFICATION TEST SUITE
# ==============================================================================
def run_verification_suite():
    print("=" * 80)
    print("SAFEGRID / VVU WEEKLY TELEMETRY & PERSONAL INSIGHTS ENGINE VERIFICATION SUITE")
    print("=" * 80)

    engine = PersonalInsightEngine()
    print(f"[*] Verifier Public Key: {engine.pubkey_hex[:32]}...")

    # Mock 7-day GPS track in Mpumalanga / Gauteng area
    mock_gps_track = [
        (-26.2201, 28.1701), (-26.2215, 28.1720), (-26.2240, 28.1750),
        (-26.2280, 28.1790), (-26.2310, 28.1820), (-26.2350, 28.1880)
    ]

    # TEST 1: User with severe sleep debt (e.g. 3 hours per day over 7 days = 21h total)
    print("\n[TEST 1] Processing 7-day Telemetry for Sleep-Deprived Field Operator...")
    report1 = engine.generate_weekly_report(
        user_id="GUARD-MPUMALANGA-07",
        gps_track=mock_gps_track,
        total_steps=42850,
        daily_sleep_hours=[3.2, 2.8, 3.5, 3.0, 2.5, 3.1, 3.4],  # ~21.5h total sleep!
        resting_hr_bpm=[78, 82, 85, 80, 84, 81, 79],
        hrv_rmssd_ms=[22, 19, 18, 21, 20, 24, 23]
    )

    assert report1["biometric_summary"]["severe_sleep_debt_flag"] == True
    assert report1["spatial_summary"]["total_distance_km"] > 0
    print(f"  --> PASS: Severe sleep debt correctly flagged ({report1['biometric_summary']['total_weekly_sleep_hours']}h total sleep).")
    print(f"      Spatial Footprint: {report1['spatial_summary']['total_distance_km']} km walked | sqrt(Area) = {report1['spatial_summary']['sqrt_area_meters']} m.")
    print(f"      Signed Insight Hash: {report1['report_hash'][:16]}...")

    # TEST 2: Normal Patrol User
    print("\n[TEST 2] Processing 7-day Telemetry for Normal Patrol Operator...")
    report2 = engine.generate_weekly_report(
        user_id="FARMER-LIMPOPO-03",
        gps_track=mock_gps_track,
        total_steps=68200,
        daily_sleep_hours=[7.5, 8.0, 7.2, 7.8, 8.1, 7.6, 7.9],
        resting_hr_bpm=[58, 60, 59, 61, 58, 59, 60],
        hrv_rmssd_ms=[48, 52, 49, 51, 55, 50, 53]
    )
    assert report2["biometric_summary"]["severe_sleep_debt_flag"] == False
    print(f"  --> PASS: Normal sleep pattern verified ({report2['biometric_summary']['total_weekly_sleep_hours']}h total).")

    print("\n" + "=" * 80)
    print("ALL WEEKLY TELEMETRY & PERSONAL INSIGHT ENGINE TESTS PASSED (2/2 PASS)")
    print("=" * 80)

if __name__ == "__main__":
    run_verification_suite()
