#!/usr/bin/env python3
"""
Safegrid Trust Spine — Tier-2 Edge Ingestion Receiver (L1 Boundary)
===================================================================
Listens for 32-byte ESP32-S3 state heads, verifies hash continuity, 
applies physics sanity gates, and appends signed records to the local WORM ledger.

Binary Payload Format (32 bytes):
  [0:4]   Node ID (4 bytes, e.g., b'N001')
  [4:8]   Timestamp (4 bytes, Unix epoch)
  [8:32]  Truncated SHA-256 Digest (24 bytes)

Author: Venture Vision Ubuntu
"""

import socket
import struct
import hashlib
import json
import time
import os
import threading
from typing import Dict, Any, Tuple
from cryptography.hazmat.primitives.asymmetric import ed25519
from cryptography.hazmat.primitives import serialization

# ==============================================================================
# 1. CRYPTOGRAPHIC KEYRING (Tier-2 Trust Root)
# ==============================================================================
class Tier2TrustRoot:
    def __init__(self, key_dir: str = "/workspace/scratch/keys"):
        os.makedirs(key_dir, exist_ok=True)
        self.key_path = os.path.join(key_dir, "tier2_ed25519.pem")
        
        if os.path.exists(self.key_path):
            with open(self.key_path, "rb") as f:
                self.private_key = serialization.load_pem_private_key(f.read(), password=None)
        else:
            self.private_key = ed25519.Ed25519PrivateKey.generate()
            pem = self.private_key.private_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PrivateFormat.PKCS8,
                encryption_algorithm=serialization.NoEncryption()
            )
            with open(self.key_path, "wb") as f:
                f.write(pem)
            os.chmod(self.key_path, 0o600)

        self.public_key = self.private_key.public_key()
        self.pubkey_hex = self.public_key.public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw
        ).hex()

    def sign(self, data: bytes) -> str:
        return self.private_key.sign(data).hex()

# ==============================================================================
# 2. LOCAL WORM LEDGER
# ==============================================================================
class LocalWormLedger:
    def __init__(self, filepath: str, trust_root: Tier2TrustRoot):
        self.filepath = filepath
        self.trust_root = trust_root
        self.lock = threading.Lock()
        self.head_hash = "GENESIS_TIER2_000000000000000000000000000000000000000000000000000"
        
        # Ensure file exists
        if not os.path.exists(self.filepath):
            with open(self.filepath, "w") as f:
                f.write("")

    def append(self, node_id: str, raw_payload_hex: str, status: str, reason: str = "OK"):
        with self.lock:
            entry = {
                "timestamp": time.time(),
                "node_id": node_id,
                "payload_hex": raw_payload_hex,
                "status": status,
                "reason": reason,
                "prev_hash": self.head_hash
            }
            
            # Canonicalize and hash
            canonical = json.dumps(entry, sort_keys=True).encode('utf-8')
            entry_hash = hashlib.sha256(canonical).hexdigest()
            
            # Sign the entry with Tier-2 key
            signature = self.trust_root.sign(canonical)
            
            # Final WORM block
            block = {
                **entry,
                "hash": entry_hash,
                "tier2_signature": signature
            }
            
            # Atomic write to JSONL
            with open(self.filepath, "a") as f:
                f.write(json.dumps(block) + "\n")
            
            self.head_hash = entry_hash
            return block

# ==============================================================================
# 3. ZERO-FABRICATION PHYSICS GATE
# ==============================================================================
class PhysicsGate:
    """
    Prevents physically impossible data from entering the trust spine.
    (e.g., a temperature sensor jumping 100°C in 1 second).
    """
    def __init__(self):
        self.last_reading: Dict[str, Tuple[float, float]] = {} # node_id -> (timestamp, temp)
        self.MAX_DELTA_TEMP_PER_SEC = 5.0 # Max 5°C change per second

    def validate(self, node_id: str, timestamp: float, temp_c: float) -> Tuple[bool, str]:
        if node_id in self.last_reading:
            last_ts, last_temp = self.last_reading[node_id]
            time_delta = timestamp - last_ts
            
            if time_delta > 0:
                temp_delta = abs(temp_c - last_temp)
                rate_of_change = temp_delta / time_delta
                
                if rate_of_change > self.MAX_DELTA_TEMP_PER_SEC:
                    return False, f"PHYSICS_VIOLATION: Temp changed {temp_delta:.1f}°C in {time_delta:.1f}s (Max {self.MAX_DELTA_TEMP_PER_SEC}°C/s)"

        self.last_reading[node_id] = (timestamp, temp_c)
        return True, "PASSED"

# ==============================================================================
# 4. ESP32 RECEIVER & HASH CONTINUITY ENGINE
# ==============================================================================
class ESP32Receiver:
    def __init__(self, host: str = "0.0.0.0", port: int = 5005):
        self.host = host
        self.port = port
        self.trust_root = Tier2TrustRoot()
        self.ledger = LocalWormLedger("/workspace/scratch/tier2_worm_ledger.jsonl", self.trust_root)
        self.physics_gate = PhysicsGate()
        
        # Track hash continuity per node
        self.node_expected_hash: Dict[str, bytes] = {}
        
        print("=" * 80)
        print("  SAFEGRID TIER-2 EDGE INGESTION RECEIVER (L1 BOUNDARY)")
        print("=" * 80)
        print(f"[*] Tier-2 Public Key: {self.trust_root.pubkey_hex[:32]}...")
        print(f"[*] WORM Ledger:       /workspace/scratch/tier2_worm_ledger.jsonl")
        print(f"[*] Listening on UDP:  {self.host}:{self.port}")
        print("=" * 80)

    def start(self):
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.bind((self.host, self.port))
        
        try:
            while True:
                data, addr = sock.recvfrom(1024)
                self.process_packet(data, addr)
        except KeyboardInterrupt:
            print("\n[*] Shutting down receiver.")
            sock.close()

    def process_packet(self, data: bytes, addr: tuple):
        if len(data) != 32:
            print(f"[!] Dropped malformed packet from {addr} (Length: {len(data)} != 32)")
            return

        # Unpack 32-byte payload
        # Node ID (4s), Timestamp (I), Hash (24s)
        try:
            node_id_bytes, timestamp, received_hash = struct.unpack('<4sI24s', data)
            node_id = node_id_bytes.decode('utf-8', errors='replace')
        except struct.error:
            print(f"[!] Struct unpack failed for packet from {addr}")
            return

        print(f"\n[>] Received packet from {node_id} at {time.strftime('%H:%M:%S', time.gmtime(timestamp))}")

        # 1. Hash Continuity Check
        # The ESP32 computes hash = sha256(prev_hash + node_id + timestamp)[:24]
        prev_hash = self.node_expected_hash.get(node_id, b'\x00' * 24)
        payload_to_hash = prev_hash + node_id_bytes + struct.pack('<I', timestamp)
        expected_hash = hashlib.sha256(payload_to_hash).digest()[:24]

        if received_hash != expected_hash:
            reason = "HASH_CONTINUITY_BREACH"
            print(f"  [🚨] TAMPER DETECTED: Expected {expected_hash.hex()[:8]}... Got {received_hash.hex()[:8]}...")
            self.ledger.append(node_id, data.hex(), "REJECTED", reason)
            return

        # Update expected hash for next packet
        self.node_expected_hash[node_id] = received_hash
        print(f"  [✓] Hash continuity verified: {received_hash.hex()[:8]}...")

        # 2. Physics Gate (Simulating a temp reading extracted from the payload)
        # For this demo, we mock a temperature value based on the timestamp modulo 100
        # In production, the payload would contain the actual sensor data.
        mock_temp = (timestamp % 100) 
        passed, physics_reason = self.physics_gate.validate(node_id, timestamp, mock_temp)
        
        if not passed:
            print(f"  [🚨] PHYSICS GATE FAILED: {physics_reason}")
            self.ledger.append(node_id, data.hex(), "UNDEFINED", physics_reason)
            return

        # 3. Append to WORM Ledger
        block = self.ledger.append(node_id, data.hex(), "VALID", "PASSED_HASH_AND_PHYSICS")
        print(f"  [✓] Appended to WORM Ledger. Hash: {block['hash'][:16]}...")
        print(f"  [✓] Tier-2 Signature: {block['tier2_signature'][:16]}...")

# ==============================================================================
# 5. TEST HARNESS & SIMULATION
# ==============================================================================
def simulate_esp32_packets():
    """Simulates an ESP32-S3 sending 32-byte state heads over UDP."""
    time.sleep(1) # Wait for receiver to start
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    target = ("127.0.0.1", 5005)
    node_id = b"N001"
    
    # --- TEST 1: Valid Packet ---
    print("\n[TEST 1] Sending Valid Packet (Hash Continuity Intact)...")
    ts = int(time.time())
    prev_hash = b'\x00' * 24
    payload = prev_hash + node_id + struct.pack('<I', ts)
    valid_hash = hashlib.sha256(payload).digest()[:24]
    packet = struct.pack('<4sI24s', node_id, ts, valid_hash)
    sock.sendto(packet, target)
    time.sleep(1)

    # --- TEST 2: Tampered Packet (Broken Hash Chain) ---
    print("\n[TEST 2] Sending Tampered Packet (Simulating Replay/MITM Attack)...")
    ts2 = int(time.time()) + 1
    # Attacker sends a valid hash but doesn't know the previous hash context
    fake_prev_hash = b'\xff' * 24 
    fake_payload = fake_prev_hash + node_id + struct.pack('<I', ts2)
    fake_hash = hashlib.sha256(fake_payload).digest()[:24]
    packet2 = struct.pack('<4sI24s', node_id, ts2, fake_hash)
    sock.sendto(packet2, target)
    time.sleep(1)

    # --- TEST 3: Valid Hash, Physics Violation ---
    print("\n[TEST 3] Sending Valid Hash, but Impossible Physics Jump...")
    ts3 = int(time.time()) + 100 # Jump forward 100 seconds
    prev_hash_3 = valid_hash
    payload3 = prev_hash_3 + node_id + struct.pack('<I', ts3)
    valid_hash_3 = hashlib.sha256(payload3).digest()[:24]
    packet3 = struct.pack('<4sI24s', node_id, ts3, valid_hash_3)
    sock.sendto(packet3, target)
    time.sleep(1)

if __name__ == "__main__":
    receiver = ESP32Receiver()
    
    # Run the receiver in a background thread for the test
    receiver_thread = threading.Thread(target=receiver.start, daemon=True)
    receiver_thread.start()
    
    # Run the simulation
    simulate_esp32_packets()
    
    print("\n" + "=" * 80)
    print("  TIER-2 BOUNDARY VERIFICATION COMPLETE")
    print("  Check /workspace/scratch/tier2_worm_ledger.jsonl for signed proof.")
    print("=" * 80)