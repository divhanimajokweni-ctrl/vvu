"""
Modular Plugin & Dynamic Tool Registry Interface for Local Autonomous Agents.

Enables hot-swapping, versioning, dynamic tool registration, and automatic GBNF/JSON Schema
generation without restarting the main inference server or agent runtime.
"""

import json
import logging
import threading
from typing import Callable, Any, Dict, List, Optional
from dataclasses import dataclass, field

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger("PluginRegistry")


@dataclass
class ToolMetadata:
    name: str
    version: str
    description: str
    parameters_schema: Dict[str, Any]
    handler: Callable[[Dict[str, Any]], Dict[str, Any]]
    active: bool = True


class PluginRegistry:
    """
    Thread-safe Plugin & Dynamic Tool Registry.
    Allows runtime registration, hot-swapping, and schema generation for GBNF decoding.
    """

    def __init__(self):
        self._tools: Dict[str, ToolMetadata] = {}
        self._lock = threading.RLock()

    def register_tool(
        self,
        name: str,
        version: str,
        description: str,
        parameters_schema: Dict[str, Any],
        handler: Callable[[Dict[str, Any]], Dict[str, Any]],
    ) -> None:
        """Register or hot-swap an active tool."""
        with self._lock:
            existing = self._tools.get(name)
            if existing:
                logger.info(f"[HOT-SWAP] Updating tool '{name}' from v{existing.version} -> v{version}")
            else:
                logger.info(f"[REGISTER] Registering new tool '{name}' v{version}")

            self._tools[name] = ToolMetadata(
                name=name,
                version=version,
                description=description,
                parameters_schema=parameters_schema,
                handler=handler,
                active=True,
            )

    def deactivate_tool(self, name: str) -> bool:
        """Deactivate a tool without deleting its definition."""
        with self._lock:
            if name in self._tools:
                self._tools[name].active = False
                logger.info(f"[DEACTIVATE] Tool '{name}' set to inactive.")
                return True
            return False

    def execute(self, tool_name: str, arguments: Dict[str, Any]) -> Dict[str, Any]:
        """Dynamically execute a tool with error isolation."""
        with self._lock:
            tool = self._tools.get(tool_name)

        if not tool:
            return {"status": "ERROR", "error": f"Tool '{tool_name}' not registered."}

        if not tool.active:
            return {"status": "ERROR", "error": f"Tool '{tool_name}' is currently inactive."}

        try:
            logger.info(f"[EXECUTE] Running '{tool.name}' (v{tool.version}) with args: {arguments}")
            result = tool.handler(arguments)
            return {"status": "SUCCESS", "tool": tool.name, "version": tool.version, "result": result}
        except Exception as e:
            logger.error(f"[ERROR] Tool '{tool_name}' failed execution: {str(e)}")
            return {"status": "EXECUTION_FAILURE", "tool": tool_name, "error": str(e)}

    def export_openai_tools_schema(self) -> List[Dict[str, Any]]:
        """Export tool definitions as standard OpenAI Function Call schemas."""
        with self._lock:
            tools_schema = []
            for tool in self._tools.values():
                if tool.active:
                    tools_schema.append({
                        "type": "function",
                        "function": {
                            "name": tool.name,
                            "description": f"{tool.description} (v{tool.version})",
                            "parameters": tool.parameters_schema,
                        }
                    })
            return tools_schema

    def export_gbnf_grammar(self) -> str:
        """Dynamically generate a GBNF grammar string enforcing active tool schemas."""
        with self._lock:
            active_tools = [t for t in self._tools.values() if t.active]

        if not active_tools:
            return "root ::= \"{}\""

        tool_choices = " | ".join([f'"{t.name}"' for t in active_tools])
        gbnf = f"""root ::= "{{" ws "\\"tool\\"" ws ":" ws tool-name ws "," ws "\\"arguments\\"" ws ":" ws tool-args ws "}}"
ws ::= [ \\t\\n]*
tool-name ::= {tool_choices}
tool-args ::= object
object ::= "{{" ws "}}" | "{{" ws string ws ":" ws value (ws "," ws string ws ":" ws value)* ws "}}"
value ::= string | number | object | array | "true" | "false" | "null"
string ::= "\\"" [^"\\\\]* "\\""
number ::= ("-"? [0-9]+ ("." [0-9]+)? ([eE] [+-]? [0-9]+)?)
array ::= "[" ws "]" | "[" ws value (ws "," ws value)* ws "]"
"""
        return gbnf


# --- DEMONSTRATION & TEST SUITE ---
def sample_telemetry_tool_v1(args: Dict[str, Any]) -> Dict[str, Any]:
    node = args.get("node_id", "UNKNOWN")
    return {"node_id": node, "action": "REBALANCE_FRONTHAUL", "status": "COMPLETED"}

def sample_telemetry_tool_v2(args: Dict[str, Any]) -> Dict[str, Any]:
    """Upgraded handler with priority scoring."""
    node = args.get("node_id", "UNKNOWN")
    priority = args.get("priority", "HIGH")
    return {"node_id": node, "action": "REBALANCE_FRONTHAUL_V2", "priority": priority, "latency_gain_ms": 1.2}


if __name__ == "__main__":
    registry = PluginRegistry()

    print("=== 1. INITIAL TOOL REGISTRATION ===")
    registry.register_tool(
        name="rebalance_fronthaul",
        version="1.0.0",
        description="Rebalances 6G OpenRAN THz fronthaul radio unit loads.",
        parameters_schema={
            "type": "object",
            "properties": {"node_id": {"type": "string"}},
            "required": ["node_id"],
        },
        handler=sample_telemetry_tool_v1,
    )

    res1 = registry.execute("rebalance_fronthaul", {"node_id": "SIS_NORTH_01"})
    print("Execution Result (v1):", json.dumps(res1, indent=2))

    print("\n=== 2. HOT-SWAPPING TOOL TO V2 (ZERO RESTART) ===")
    registry.register_tool(
        name="rebalance_fronthaul",
        version="2.0.0",
        description="Enhanced THz fronthaul rebalancer with priority queueing.",
        parameters_schema={
            "type": "object",
            "properties": {
                "node_id": {"type": "string"},
                "priority": {"type": "string", "enum": ["CRITICAL", "HIGH", "LOW"]},
            },
            "required": ["node_id", "priority"],
        },
        handler=sample_telemetry_tool_v2,
    )

    res2 = registry.execute("rebalance_fronthaul", {"node_id": "SIS_NORTH_01", "priority": "CRITICAL"})
    print("Execution Result (v2):", json.dumps(res2, indent=2))

    print("\n=== 3. DYNAMIC GBNF GRAMMAR GENERATION ===")
    gbnf_output = registry.export_gbnf_grammar()
    print("Generated Dynamic GBNF Grammar snippet:\n", gbnf_output[:250], "...\n")

    print("=== 4. OPENAI-COMPATIBLE SCHEMAS ===")
    schemas = registry.export_openai_tools_schema()
    print("OpenAI Tools Schema Count:", len(schemas))
    print(json.dumps(schemas, indent=2))
