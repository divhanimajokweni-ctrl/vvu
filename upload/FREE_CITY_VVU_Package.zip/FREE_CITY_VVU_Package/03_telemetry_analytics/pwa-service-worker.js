/* ============================================================================
   SAFEGRID / VVU TRUST SPINE — OFFLINE SERVICE WORKER (sw.js)
   ============================================================================
   Enforces offline-first caching for the Compiled Sequence (sequence.html),
   IndexedDB Meantime Journaling (meantime_journal.jsonl sync), and 
   self-audit HEAD probe verification under the No-Primitives Law.
   ============================================================================ */

const CACHE_NAME = 'vvu-sequence-cache-v1';
const MEANTIME_DB_NAME = 'vvu_meantime_db';
const MEANTIME_STORE_NAME = 'meantime_journal';

// Sequence Manifest from sequence.html
const SEQUENCE_ASSETS = [
    './sequence.html',
    './index.html',
    './digital-twin.html',
    './cape_town_wildfire.html',
    './index%20(13).html',
    './index%20(12).html',
    './borromean-rings.tsx.txt',
    './pwa-mobile-edge-client.js',
    './pwa-field-insight-cards.js'
];

// ============================================================================
// 1. INSTALL & PRE-CACHE SEQUENCE ARTEFACTS
// ============================================================================
self.addEventListener('install', (event) => {
    console.log('[VVU Service Worker] Installing & Pre-caching Sequence Manifest...');
    event.waitUntil(
        caches.open(CACHE_NAME).then((cache) => {
            return cache.addAll(SEQUENCE_ASSETS).catch((err) => {
                console.warn('[VVU Service Worker] Non-critical pre-cache warning:', err);
            });
        }).then(() => self.skipWaiting())
    );
});

// ============================================================================
// 2. ACTIVATE & CLAIM CLIENTS
// ============================================================================
self.addEventListener('activate', (event) => {
    console.log('[VVU Service Worker] Activating & Purging Old Caches...');
    event.waitUntil(
        caches.keys().then((keys) => {
            return Promise.all(
                keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k))
            );
        }).then(() => self.clients.claim())
    );
});

// ============================================================================
// 3. FETCH & SELF-AUDIT INTERCEPTOR (No-Primitives Law)
// ============================================================================
self.addEventListener('fetch', (event) => {
    const req = event.request;
    const url = new URL(req.url);

    // Handle HEAD probes for sequence.html self-audit
    if (req.method === 'HEAD') {
        event.respondWith(
            caches.match(req).then((cachedResponse) => {
                if (cachedResponse) {
                    return new Response(null, {
                        status: 200,
                        statusText: 'PROVEN (Cached)',
                        headers: { 'X-VVU-Audit-Status': 'PROVEN' }
                    });
                }
                return fetch(req).then((networkResponse) => {
                    return networkResponse;
                }).catch(() => {
                    // Under No-Primitives Law, missing asset returns 404 BLOCKED
                    return new Response(null, {
                        status: 404,
                        statusText: 'BLOCKED_MISSING_ASSET',
                        headers: { 'X-VVU-Audit-Status': 'BLOCKED' }
                    });
                });
            })
        );
        return;
    }

    // Cache-First with Network Fallback for sequence assets
    if (req.method === 'GET') {
        event.respondWith(
            caches.match(req).then((cachedResponse) => {
                if (cachedResponse) return cachedResponse;

                return fetch(req).then((networkResponse) => {
                    // Cache valid network responses dynamically
                    if (networkResponse && networkResponse.status === 200 && networkResponse.type === 'basic') {
                        const responseToCache = networkResponse.clone();
                        caches.open(CACHE_NAME).then((cache) => {
                            cache.put(req, responseToCache);
                        });
                    }
                    return networkResponse;
                }).catch(() => {
                    // Return offline fallback if unverified/offline
                    if (req.headers.get('accept')?.includes('text/html')) {
                        return caches.match('./sequence.html');
                    }
                    return new Response('Offline: Asset Unverified', { status: 503, statusText: 'OFFLINE_UNVERIFIED' });
                });
            })
        );
    }
});

// ============================================================================
// 4. INDEXEDDB MEANTIME JOURNALING ENGINE
// ============================================================================
function openMeantimeDB() {
    return new Promise((resolve, reject) => {
        const request = indexedDB.open(MEANTIME_DB_NAME, 1);
        request.onupgradeneeded = (e) => {
            const db = e.target.result;
            if (!db.objectStoreNames.contains(MEANTIME_STORE_NAME)) {
                db.createObjectStore(MEANTIME_STORE_NAME, { keyPath: 'id', autoIncrement: true });
            }
        };
        request.onsuccess = () => resolve(request.result);
        request.onerror = () => reject(request.error);
    });
}

// Background Sync / Message API for Offline Journal Operations
self.addEventListener('message', async (event) => {
    const { type, payload } = event.data || {};

    if (type === 'JOURNAL_APPEND') {
        try {
            const db = await openMeantimeDB();
            const tx = db.transaction(MEANTIME_STORE_NAME, 'readwrite');
            const store = tx.objectStore(MEANTIME_STORE_NAME);
            
            const record = {
                timestamp: Date.now(),
                event_type: payload.event_type || 'TELEMETRY_SAMPLE',
                payload: payload,
                synced: false
            };
            store.add(record);
            
            event.ports[0].postMessage({ status: 'APPENDED', timestamp: record.timestamp });
        } catch (err) {
            if (event.ports[0]) event.ports[0].postMessage({ status: 'ERROR', error: err.toString() });
        }
    } else if (type === 'JOURNAL_FLUSH') {
        try {
            const db = await openMeantimeDB();
            const tx = db.transaction(MEANTIME_STORE_NAME, 'readwrite');
            const store = tx.objectStore(MEANTIME_STORE_NAME);
            const request = store.getAll();

            request.onsuccess = async () => {
                const records = request.result || [];
                if (records.length === 0) {
                    if (event.ports[0]) event.ports[0].postMessage({ status: 'EMPTY', count: 0 });
                    return;
                }

                // Attempt network sync to backend
                try {
                    const res = await fetch('/api/v1/telemetry/sync', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ journal_entries: records })
                    });

                    if (res.ok) {
                        const clearTx = db.transaction(MEANTIME_STORE_NAME, 'readwrite');
                        clearTx.objectStore(MEANTIME_STORE_NAME).clear();
                        if (event.ports[0]) event.ports[0].postMessage({ status: 'FLUSHED', count: records.length });
                    } else {
                        if (event.ports[0]) event.ports[0].postMessage({ status: 'SYNC_FAILED', code: res.status });
                    }
                } catch (netErr) {
                    if (event.ports[0]) event.ports[0].postMessage({ status: 'OFFLINE_RETAINED', count: records.length });
                }
            };
        } catch (err) {
            if (event.ports[0]) event.ports[0].postMessage({ status: 'ERROR', error: err.toString() });
        }
    }
});
