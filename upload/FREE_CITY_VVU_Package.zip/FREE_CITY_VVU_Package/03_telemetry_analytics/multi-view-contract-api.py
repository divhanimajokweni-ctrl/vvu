#!/usr/bin/env python3
"""
Safegrid Trust Spine — Multi-View Contract API (FastAPI)
=========================================================
Serves the Operator PWA, 3D Digital Twin (Cesium), and Compliance Dashboards.
Enforces the strictly immutable invariant:
  (twin_id, state_version, evidence_cutoff)

No surface or UI renderer can present state that diverges from the 
underlying cryptographic WORM evidence chain.

Author: Venture Vision Ubuntu
"""

import os
import time
import json
import hashlib
from typing import Dict, Any, List, Optional
from fastapi import FastAPI, HTTPException, Query, status
from pydantic import BaseModel, Field
from fastapi.testclient import TestClient

from cryptography.hazmat.primitives.asymmetric import ed25519
from cryptography.hazmat.primitives import serialization

# ==============================================================================
# 1. CRYPTOGRAPHIC TRUST ROOT (L0)
# ==============================================================================
class Keyring:
    def __init__(self, key_dir: str = "/workspace/scratch/keys"):
        os.makedirs(key_dir, exist_ok=True)
        self.key_path = os.path.join(key_dir, "api_ed25519.pem")
        if os.path.exists(self.key_path):
            with open(self.key_path, "rb") as f:
                self.private_key = serialization.load_pem_private_key(f.read(), password=None)
        else:
            self.private_key = ed25519.Ed25519PrivateKey.generate()
            pem = self.private_key.private_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PrivateFormat.PKCS8,
                encryption_algorithm=serialization.NoEncryption()
            )
            with open(self.key_path, "wb") as f:
                f.write(pem)
            os.chmod(self.key_path, 0o600)

        self.public_key = self.private_key.public_key()
        self.pubkey_hex = self.public_key.public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw
        ).hex()

    def sign(self, data: bytes) -> str:
        return self.private_key.sign(data).hex()

    def verify(self, data: bytes, signature_hex: str, pubkey_hex: str) -> bool:
        try:
            pubkey_bytes = bytes.fromhex(pubkey_hex)
            sig_bytes = bytes.fromhex(signature_hex)
            pubkey = ed25519.Ed25519PublicKey.from_public_bytes(pubkey_bytes)
            pubkey.verify(sig_bytes, data)
            return True
        except Exception:
            return False

keyring = Keyring()

# ==============================================================================
# 2. IN-MEMORY WORM EVIDENCE LEDGER & TWIN STATE ENGINE
# ==============================================================================
class WORMChainEntry(BaseModel):
    index: int
    twin_id: str
    state_version: int
    timestamp: float
    prev_hash: str
    payload: Dict[str, Any]
    hash: str
    signature: str

class TwinStateStore:
    def __init__(self):
        self.chains: Dict[str, List[WORMChainEntry]] = {}
        self._seed_initial_twin_data()

    def _seed_initial_twin_data(self):
        # Seed initial twin 'TWIN-SUBSTATION-01' with 3 sealed state transitions
        twin_id = "TWIN-SUBSTATION-01"
        self.chains[twin_id] = []
        
        prev_h = "GENESIS_000000000000000000000000000000000000000000000000000000000000"
        states = [
            {"temperature_c": 24.5, "valve_status": "CLOSED", "heart_rate_bpm": 65, "location": "PERIMETER_GATE_1"},
            {"temperature_c": 26.8, "valve_status": "OPEN", "heart_rate_bpm": 72, "location": "PERIMETER_GATE_1"},
            {"temperature_c": 38.2, "valve_status": "OPEN", "heart_rate_bpm": 96, "location": "TRANSFORMER_BAY_2"}
        ]
        
        base_ts = 1798870000.0
        for i, st in enumerate(states):
            ts = base_ts + (i * 60.0)
            ver = i + 1
            payload = {
                "twin_id": twin_id,
                "state_version": ver,
                "timestamp": ts,
                "data": st
            }
            canonical = json.dumps(payload, sort_keys=True).encode("utf-8")
            h_input = f"{prev_h}:{canonical.hex()}".encode("utf-8")
            block_hash = hashlib.sha256(h_input).hexdigest()
            sig = keyring.sign(canonical)
            
            entry = WORMChainEntry(
                index=i,
                twin_id=twin_id,
                state_version=ver,
                timestamp=ts,
                prev_hash=prev_h,
                payload=payload,
                hash=block_hash,
                signature=sig
            )
            self.chains[twin_id].append(entry)
            prev_h = block_hash

    def get_state_at(self, twin_id: str, state_version: Optional[int] = None, evidence_cutoff: Optional[float] = None) -> Dict[str, Any]:
        if twin_id not in self.chains:
            raise HTTPException(status_code=404, detail=f"Twin ID '{twin_id}' not found.")
        
        chain = self.chains[twin_id]
        filtered = chain
        
        # Apply evidence_cutoff filter
        if evidence_cutoff is not None:
            filtered = [e for e in filtered if e.timestamp <= evidence_cutoff]
            if not filtered:
                raise HTTPException(
                    status_code=400,
                    detail=f"No sealed evidence available for twin '{twin_id}' prior to cutoff {evidence_cutoff}"
                )

        target_entry = filtered[-1]
        
        # Apply state_version invariant check
        if state_version is not None:
            if target_entry.state_version != state_version:
                # Check if requested version exists in the chain at all
                match = [e for e in chain if e.state_version == state_version]
                if not match:
                    raise HTTPException(
                        status_code=409,
                        detail=f"INVARIANT BREACH: Requested state_version={state_version} does not exist."
                    )
                matched_entry = match[0]
                if evidence_cutoff is not None and matched_entry.timestamp > evidence_cutoff:
                    raise HTTPException(
                        status_code=409,
                        detail=f"INVARIANT BREACH: state_version={state_version} occurs AFTER evidence_cutoff={evidence_cutoff}."
                    )
                target_entry = matched_entry

        return {
            "twin_id": twin_id,
            "state_version": target_entry.state_version,
            "evidence_cutoff": evidence_cutoff or target_entry.timestamp,
            "head_hash": target_entry.hash,
            "prev_hash": target_entry.prev_hash,
            "verification_state": "SEALED_WORM",
            "state_data": target_entry.payload["data"],
            "signature": target_entry.signature,
            "pubkey": keyring.pubkey_hex,
            "attestation_tier": "T1 · Ed25519 (Software)"
        }

    def get_chain(self, twin_id: str, evidence_cutoff: Optional[float] = None) -> List[WORMChainEntry]:
        if twin_id not in self.chains:
            raise HTTPException(status_code=404, detail=f"Twin ID '{twin_id}' not found.")
        chain = self.chains[twin_id]
        if evidence_cutoff is not None:
            return [e for e in chain if e.timestamp <= evidence_cutoff]
        return chain

state_store = TwinStateStore()

# ==============================================================================
# 3. FASTAPI APP & CONTRACT ENDPOINTS
# ==============================================================================
app = FastAPI(
    title="Safegrid Multi-View Contract API",
    description="Serves PWA, Cesium 3D Twin, and Compliance Surfaces enforcing (twin_id, state_version, evidence_cutoff) invariants.",
    version="1.0.0"
)

# Request / Response Schemas
class VerificationRequest(BaseModel):
    twin_id: str
    state_version: int
    payload: Dict[str, Any]
    signature: str
    pubkey: str

class SurfaceMetadataResponse(BaseModel):
    surface: str
    description: str
    palette: Dict[str, str]
    compliance_rules: List[str]
    active_state: str

# 8 VVU Surfaces Dictionary
VVU_SURFACES = {
    "FORGE": {
        "description": "The trust verifier. Where receipts are minted and claims become proofs.",
        "palette": {"primary": "#FF5722", "background": "#120B09", "accent": "#FFAB91"},
        "compliance_rules": ["X0-1 Immutable Events", "X0-5 Ed25519 Signatures"],
        "active_state": "READY_TO_MINT"
    },
    "FIRE": {
        "description": "The market. ZAR pools and ROSCA cooperatives operating with cryptographic guarantees.",
        "palette": {"primary": "#F44336", "background": "#1A0808", "accent": "#EF9A9A"},
        "compliance_rules": ["X0-6 Fire Never Emits PROVEN", "ZAR Billing Only"],
        "active_state": "POOL_ACTIVE"
    },
    "PRESS": {
        "description": "The capture. Verified creator reviews and optical evidence.",
        "palette": {"primary": "#9C27B0", "background": "#110815", "accent": "#CE93D8"},
        "compliance_rules": ["X0-4 Hash Chains", "Zero-Fabrication Capture"],
        "active_state": "CAPTURE_ARMED"
    },
    "BENCH": {
        "description": "The license. Node-locked hardware licensing for local software plugins.",
        "palette": {"primary": "#2196F3", "background": "#08101A", "accent": "#90CAF9"},
        "compliance_rules": ["Mathematical Finality", "Node-Locked Keyring"],
        "active_state": "LICENSE_VERIFIED"
    },
    "FIELD": {
        "description": "The resilience. Dual-tier local-first storage for offline rural operations.",
        "palette": {"primary": "#4CAF50", "background": "#081509", "accent": "#A5D6A7"},
        "compliance_rules": ["Local WORM Journal", "Fail-Closed Offline Sync"],
        "active_state": "JOURNAL_SYNCHRONIZED"
    },
    "SPATIAL": {
        "description": "The lemon tree. Every physical asset on a map bound to a receipt chain.",
        "palette": {"primary": "#FFEB3B", "background": "#1A1908", "accent": "#FFF59D"},
        "compliance_rules": ["SHA-256 Badge Alignment", "GIS Spatial Invariant"],
        "active_state": "SPATIAL_MAPPED"
    },
    "SURV": {
        "description": "The feeds. Optical and sensor feeds marked CLEAN or QUARANTINE.",
        "palette": {"primary": "#00BCD4", "background": "#061417", "accent": "#80DEEA"},
        "compliance_rules": ["Frame-by-frame WORM Seal", "Physics Gate Validation"],
        "active_state": "FEED_CLEAN"
    },
    "TWIN": {
        "description": "The hologram. Three.js Fresnel visualizer enforcing triple-invariant state.",
        "palette": {"primary": "#00E676", "background": "#04140B", "accent": "#B9F6CA"},
        "compliance_rules": ["(twin_id, state_version, evidence_cutoff) Invariant"],
        "active_state": "HOLOGRAPHIC_SYNC"
    }
}

@app.get("/api/v1/health")
def get_health():
    return {
        "status": "HEALTHY",
        "attestation_tier": "T1 · Ed25519 (Software)",
        "pubkey": keyring.pubkey_hex,
        "timestamp": time.time(),
        "active_twins": list(state_store.chains.keys())
    }

@app.get("/api/v1/twin/{twin_id}/state")
def get_twin_state(
    twin_id: str,
    state_version: Optional[int] = Query(None, description="Exact state version requested"),
    evidence_cutoff: Optional[float] = Query(None, description="Max timestamp cutoff for state calculation")
):
    """
    Enforces the (twin_id, state_version, evidence_cutoff) invariant.
    Returns the exact verifiable state contract for PWA and Cesium views.
    """
    return state_store.get_state_at(twin_id, state_version, evidence_cutoff)

@app.get("/api/v1/twin/{twin_id}/events")
def get_twin_events(
    twin_id: str,
    evidence_cutoff: Optional[float] = Query(None, description="Optional timestamp cutoff")
):
    """Returns the immutable WORM hash chain for the specified twin."""
    return state_store.get_chain(twin_id, evidence_cutoff)

@app.post("/api/v1/twin/{twin_id}/verify")
def verify_twin_payload(twin_id: str, req: VerificationRequest):
    """Verifies a state payload against an Ed25519 signature."""
    canonical = json.dumps(req.payload, sort_keys=True).encode("utf-8")
    is_valid = keyring.verify(canonical, req.signature, req.pubkey)
    
    if not is_valid:
        raise HTTPException(status_code=400, detail="INVALID_SIGNATURE: Signature verification failed.")

    return {
        "status": "VERIFIED",
        "twin_id": twin_id,
        "state_version": req.state_version,
        "signature_valid": True,
        "verified_at": time.time()
    }

@app.get("/api/v1/surfaces/{surface_name}")
def get_surface_metadata(surface_name: str):
    """Returns metadata, palette, and X0 compliance rules for one of the 8 VVU surfaces."""
    s_upper = surface_name.upper()
    if s_upper not in VVU_SURFACES:
        raise HTTPException(
            status_code=404,
            detail=f"Surface '{surface_name}' invalid. Valid surfaces: {list(VVU_SURFACES.keys())}"
        )
    meta = VVU_SURFACES[s_upper]
    return {
        "surface": s_upper,
        **meta
    }

# ==============================================================================
# 4. STANDALONE VERIFICATION SUITE
# ==============================================================================
def run_verification_suite():
    print("=" * 80)
    print("SAFEGRID MULTI-VIEW CONTRACT API (FASTAPI) VERIFICATION SUITE")
    print("=" * 80)
    
    client = TestClient(app)
    
    # --- TEST 1: Health Check Endpoint ---
    print("\n[TEST 1] Testing /api/v1/health endpoint...")
    resp = client.get("/api/v1/health")
    assert resp.status_code == 200, f"Expected 200, got {resp.status_code}"
    data = resp.json()
    print(f"  --> PASS: API Healthy. Attestation: {data['attestation_tier']}")

    # --- TEST 2: Valid State Contract Query ---
    print("\n[TEST 2] Fetching Twin State for 'TWIN-SUBSTATION-01' (version=2)...")
    resp = client.get("/api/v1/twin/TWIN-SUBSTATION-01/state?state_version=2")
    assert resp.status_code == 200, f"Expected 200, got {resp.status_code}"
    state_contract = resp.json()
    assert state_contract["state_version"] == 2
    assert state_contract["verification_state"] == "SEALED_WORM"
    print(f"  --> PASS: Twin State Verified. Head Hash: {state_contract['head_hash'][:16]}...")
    print(f"      Temperature: {state_contract['state_data']['temperature_c']}°C, Valve: {state_contract['state_data']['valve_status']}")

    # --- TEST 3: Invariant Breach Prevention ---
    print("\n[TEST 3] Testing Invariant Breach (Requesting Non-Existent Version 99)...")
    resp = client.get("/api/v1/twin/TWIN-SUBSTATION-01/state?state_version=99")
    assert resp.status_code == 409, f"Expected 409 Conflict, got {resp.status_code}"
    print(f"  --> PASS: Invariant breach correctly rejected with 409 Conflict: {resp.json()['detail']}")

    # --- TEST 4: Surface Metadata Endpoint ---
    print("\n[TEST 4] Querying Surface Metadata for 'TWIN' and 'FORGE'...")
    resp_twin = client.get("/api/v1/surfaces/TWIN")
    assert resp_twin.status_code == 200
    meta_twin = resp_twin.json()
    print(f"  --> PASS: Surface 'TWIN' Active State: {meta_twin['active_state']}, Palette: {meta_twin['palette']['primary']}")

    # --- TEST 5: Cryptographic Verification Endpoint ---
    print("\n[TEST 5] Testing POST /api/v1/twin/TWIN-SUBSTATION-01/verify...")
    test_payload = {"test": "data", "twin_id": "TWIN-SUBSTATION-01"}
    canonical = json.dumps(test_payload, sort_keys=True).encode("utf-8")
    sig = keyring.sign(canonical)
    
    verify_req = {
        "twin_id": "TWIN-SUBSTATION-01",
        "state_version": 1,
        "payload": test_payload,
        "signature": sig,
        "pubkey": keyring.pubkey_hex
    }
    resp_v = client.post("/api/v1/twin/TWIN-SUBSTATION-01/verify", json=verify_req)
    assert resp_v.status_code == 200
    assert resp_v.json()["status"] == "VERIFIED"
    print(f"  --> PASS: Signature verification endpoint returned VERIFIED.")

    print("\n" + "=" * 80)
    print("ALL MULTI-VIEW CONTRACT API TESTS PASSED SUCCESSFULLY (5/5 PASS)")
    print("=" * 80)

if __name__ == "__main__":
    run_verification_suite()
