"""Verify an install receipt without the host, without the installer.

Usage:
    python3 -m installer.verify_install \
        --receipt receipt.json \
        --before  before.json \
        --after   after.json \
        [--pubkey HEX]           # T0 only; omit if you have the keyring
        [--local-keyring PATH]   # T0 and T1

Exit codes:
    0  receipt verified
    1  verification failed (reason printed as JSON)
    2  invocation problem
"""
import json
import sys
from pathlib import Path

def main(argv):
    args = {}
    i = 0
    while i < len(argv):
        if argv[i].startswith("--") and i + 1 < len(argv):
            args[argv[i][2:]] = argv[i + 1]
            i += 2
        else:
            i += 1
    for k in ("receipt", "before", "after"):
        if k not in args:
            print(f"missing --{k}", file=sys.stderr)
            return 2

    try:
        receipt = json.loads(Path(args["receipt"]).read_text())
        before  = json.loads(Path(args["before"]).read_text())
        after   = json.loads(Path(args["after"]).read_text())
    except FileNotFoundError as e:
        print(f"file not found: {e.filename}", file=sys.stderr)
        return 2
    except Exception as e:
        print(f"parse error: {e}", file=sys.stderr)
        return 2

    sys.path.append("/workspace/scratch")
    keyring = None
    if "local-keyring" in args:
        from vvu_installer_suite import KeyRing
        keyring = KeyRing(Path(args["local-keyring"]))

    from installer.receipt import verify_install_receipt
    result = verify_install_receipt(receipt, before, after, keyring)
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0 if result["ok"] else 1

if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
