/**
 * Safegrid / VVU FIELD Surface Integrated PWA Client Application Bundle
 * ======================================================================
 * Combines:
 *  1. Service Worker & IndexedDB Sync (pwa-service-worker.js)
 *  2. Optical Camera & IMU Telemetry (pwa-mobile-edge-client.js)
 *  3. 7-Day Personal Insight Carousel (pwa-field-insight-cards.js)
 *  4. Offline P2P QR Code Receipt Scanner & Verifier (pwa-qr-peer-receipts.js)
 *
 * Author: Venture Vision Ubuntu
 */

import { MobileEdgeSensorNode } from './pwa-mobile-edge-client.js';
import { FieldWeeklyInsightCards } from './pwa-field-insight-cards.js';
import { PeerReceiptQRScanner } from './pwa-qr-peer-receipts.js';

export class FieldPWAAppBundle {
    constructor(config = {}) {
        this.apiBaseUrl = config.apiBaseUrl || "http://127.0.0.1:8000/api/v1";
        this.operatorId = config.operatorId || "GUARD-07";
        this.containerId = config.containerId || "pwa-app-root";
        
        // Modules
        this.sensorNode = null;
        this.insightCarousel = null;
        this.qrScanner = null;
        
        // State
        this.isOnline = navigator.onLine;
        this.pendingSyncCount = 0;
        this.activeTab = "INSIGHTS"; // INSIGHTS | TELEMETRY | SCANNER
    }

    async init() {
        console.log(`[PWA App] Initializing Field PWA App Bundle for Operator: ${this.operatorId}`);
        
        // 1. Register Service Worker & Bind Offline Sync Listeners
        await this._registerServiceWorker();

        // 2. Instantiate Components
        this.sensorNode = new MobileEdgeSensorNode({
            nodeId: `MOBILE-${this.operatorId}`,
            apiEndpoint: `${this.apiBaseUrl}/mobile/telemetry`
        });

        this.insightCarousel = new FieldWeeklyInsightCards({
            containerId: "insights-carousel-container"
        });

        this.qrScanner = new PeerReceiptQRScanner({
            videoElementId: "qr-video-preview",
            onReceiptScanned: (receiptData) => this.handleScannedPeerReceipt(receiptData)
        });

        // 3. Render Unified Layout
        this.renderUI();

        // 4. Attach Connectivity Listeners
        window.addEventListener('online', () => this.handleNetworkStatusChange(true));
        window.addEventListener('offline', () => this.handleNetworkStatusChange(false));
        
        console.log("[PWA App] Initialization Complete. Operational Mode: LOCAL_FIRST_OFFLINE_READY");
    }

    async _registerServiceWorker() {
        if ('serviceWorker' in navigator) {
            try {
                const reg = await navigator.serviceWorker.register('/pwa-service-worker.js');
                console.log('[PWA App] Service Worker registered with scope:', reg.scope);
                
                // Listen for messages from SW (e.g. meantime sync completions)
                navigator.serviceWorker.addEventListener('message', (event) => {
                    if (event.data && event.data.type === 'MEANTIME_SYNC_COMPLETE') {
                        console.log(`[PWA App] Synced ${event.data.count} meantime records to WORM server.`);
                        this.updateSyncStatusBadge(0);
                    }
                });
            } catch (err) {
                console.warn('[PWA App] Service Worker registration failed:', err);
            }
        }
    }

    handleNetworkStatusChange(online) {
        this.isOnline = online;
        const netBadge = document.getElementById('pwa-net-status');
        if (netBadge) {
            netBadge.innerText = online ? "ONLINE" : "OFFLINE (MEANTIME JOURNALING)";
            netBadge.className = online ? "badge badge-online" : "badge badge-offline";
        }
    }

    handleScannedPeerReceipt(receiptData) {
        console.log("[PWA App] Processing Scanned Peer Receipt:", receiptData);
        const statusElement = document.getElementById('qr-scan-status-output');
        if (statusElement) {
            statusElement.innerHTML = `
                <div class="scanned-card">
                    <h4>Receipt Status: <span class="tag-${receiptData.status.toLowerCase()}">${receiptData.status}</span></h4>
                    <p><strong>Passport Ref:</strong> ${receiptData.receipt.passport_id}</p>
                    <p><strong>Peer Key ID:</strong> ${receiptData.receipt.pubkey.substring(0, 16)}...</p>
                    <p><strong>Verification:</strong> ${receiptData.proof_verified ? "CRYPTOGRAPHIC PROOF VERIFIED (Ed25519)" : "UNVERIFIED"}</p>
                </div>
            `;
        }
    }

    updateSyncStatusBadge(pendingCount) {
        this.pendingSyncCount = pendingCount;
        const badge = document.getElementById('pwa-sync-badge');
        if (badge) {
            badge.innerText = `${this.pendingSyncCount} Pending Journal Entries`;
        }
    }

    switchTab(tabName) {
        this.activeTab = tabName;
        document.querySelectorAll('.tab-content').forEach(el => el.style.display = 'none');
        document.querySelectorAll('.nav-btn').forEach(btn => btn.classList.remove('active'));
        
        const targetView = document.getElementById(`tab-view-${tabName.toLowerCase()}`);
        const targetBtn = document.getElementById(`btn-tab-${tabName.toLowerCase()}`);
        if (targetView) targetView.style.display = 'block';
        if (targetBtn) targetBtn.classList.add('active');

        // Manage active hardware streams based on tab
        if (tabName === 'SCANNER') {
            this.qrScanner.startScanner();
        } else {
            this.qrScanner.stopScanner();
        }
    }

    renderUI() {
        const root = document.getElementById(this.containerId);
        if (!root) return;

        root.innerHTML = `
            <div class="pwa-app-shell">
                <!-- Top HUD Bar -->
                <header class="pwa-header">
                    <div class="header-title">
                        <h2>SAFEGRID FIELD PWA</h2>
                        <span id="pwa-net-status" class="badge ${this.isOnline ? 'badge-online' : 'badge-offline'}">
                            ${this.isOnline ? 'ONLINE' : 'OFFLINE (MEANTIME JOURNALING)'}
                        </span>
                    </div>
                    <div class="header-meta">
                        <span>OPERATOR: ${this.operatorId}</span>
                        <span id="pwa-sync-badge" class="sync-badge">0 Pending Journal Entries</span>
                    </div>
                </header>

                <!-- Navigation Tabs -->
                <nav class="pwa-nav">
                    <button id="btn-tab-insights" class="nav-btn active" onclick="window.fieldApp.switchTab('INSIGHTS')">📊 Weekly Insights</button>
                    <button id="btn-tab-telemetry" class="nav-btn" onclick="window.fieldApp.switchTab('TELEMETRY')">📹 Telemetry Node</button>
                    <button id="btn-tab-scanner" class="nav-btn" onclick="window.fieldApp.switchTab('SCANNER')">📲 QR Peer Scanner</button>
                </nav>

                <!-- Main Content Views -->
                <main class="pwa-content">
                    <!-- Tab 1: Weekly Insights Carousel -->
                    <section id="tab-view-insights" class="tab-content" style="display: block;">
                        <div id="insights-carousel-container"></div>
                    </section>

                    <!-- Tab 2: Optical & Sensor Telemetry Node -->
                    <section id="tab-view-telemetry" class="tab-content" style="display: none;">
                        <div class="telemetry-panel">
                            <h3>Optical & Kinematic Sensor Node</h3>
                            <div class="sensor-preview-box">
                                <video id="optical-camera-stream" autoplay playsinline muted></video>
                                <div class="telemetry-overlay">
                                    <p>IMU ZVU Stance: <span id="zvu-indicator">STATIONARY</span></p>
                                    <p>Frame SHA-256 Digest: <span id="frame-digest-hash">COMPUTING...</span></p>
                                </div>
                            </div>
                            <div class="control-actions">
                                <button class="action-btn" onclick="window.fieldApp.sensorNode.startSensorStream()">▶ Start Telemetry Feed</button>
                                <button class="action-btn danger" onclick="window.fieldApp.sensorNode.stopSensorStream()">⏹ Stop Feed</button>
                            </div>
                        </div>
                    </section>

                    <!-- Tab 3: Offline QR Code Scanner & Exchange -->
                    <section id="tab-view-scanner" class="tab-content" style="display: none;">
                        <div class="qr-scanner-panel">
                            <h3>Offline Peer Receipt Scanner</h3>
                            <div class="video-container">
                                <video id="qr-video-preview" autoplay playsinline muted></video>
                            </div>
                            <div id="qr-scan-status-output" class="scan-output-box">
                                <p class="placeholder-text">Point camera at a peer operator's QR receipt to verify WORM proof...</p>
                            </div>
                        </div>
                    </section>
                </main>
            </div>
        `;

        // Render insight carousel
        this.insightCarousel.init();
    }
}
