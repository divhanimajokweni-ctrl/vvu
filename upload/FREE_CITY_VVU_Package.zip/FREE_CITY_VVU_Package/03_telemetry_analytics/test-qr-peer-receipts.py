#!/usr/bin/env python3
"""
VVU Trust Spine — QR Peer-to-Peer Receipt Exchange Test Suite
============================================================
Verifies offline QR receipt encoding/decoding, Rule X₀-7 (No Silent Trust Upgrades),
and cryptographic verification of mobile-to-mobile offline state receipts.
"""

import os
import sys
import json
import base64
import hashlib
import time
from cryptography.hazmat.primitives.asymmetric import ed25519

def run_test_suite():
    print("=" * 80)
    print("SAFEGRID / VVU QR PEER-TO-PEER RECEIPT EXCHANGE VERIFICATION SUITE")
    print("=" * 80)

    # Generate test keys
    priv_key = ed25519.Ed25519PrivateKey.generate()
    pub_key = priv_key.public_key()
    pubkey_hex = pub_key.public_bytes_raw().hex()

    print(f"[*] Peer Operator Key ID: {pubkey_hex[:32]}...")

    # TEST 1: Serialize Peer WORM Receipt Block
    print("\n[TEST 1] Serializing Peer WORM Receipt for Offline QR Code Generation...")
    receipt_block = {
        "passport_id": "PASSPORT-8F92A1B0",
        "timestamp": int(time.time()),
        "prev_hash": "a1b2c3d4e5f60718293a4b5c6d7e8f90a1b2c3d4e5f60718293a4b5c6d7e8f90",
        "hash": "b2c3d4e5f60718293a4b5c6d7e8f90a1b2c3d4e5f60718293a4b5c6d7e8f90a1",
        "node_id": "GUARD-MOBILE-07",
        "pubkey": pubkey_hex,
        "status": "SEALED_WORM"
    }

    # Sign canonical block
    canonical_data = f"{receipt_block['passport_id']}:{receipt_block['timestamp']}:{receipt_block['prev_hash']}:{receipt_block['hash']}"
    sig_hex = priv_key.sign(canonical_data.encode('utf-8')).hex()
    receipt_block["signature"] = sig_hex

    # Compact JSON Base64 encoding
    compact = {
        "v": 1,
        "id": receipt_block["passport_id"],
        "ts": receipt_block["timestamp"],
        "h": receipt_block["hash"],
        "ph": receipt_block["prev_hash"],
        "sig": sig_hex,
        "pub": pubkey_hex,
        "st": receipt_block["status"]
    }
    encoded_bytes = base64.urlsafe_b64encode(json.dumps(compact).encode('utf-8'))
    encoded_qr = encoded_bytes.decode('utf-8').rstrip('=')
    print(f"  --> PASS: QR Payload Encoded (Length: {len(encoded_qr)} chars): '{encoded_qr[:36]}...'")

    # TEST 2: Scanned Payload Ingestion & Rule X₀-7 Enforcement
    print("\n[TEST 2] Processing Scanned QR Code & Enforcing Rule X₀-7 (No Silent Trust Upgrades)...")
    padded = encoded_qr + '=' * (-len(encoded_qr) % 4)
    decoded_json = json.loads(base64.urlsafe_b64decode(padded.encode('utf-8')).decode('utf-8'))
    
    scanned_receipt = {
        "passport_id": decoded_json["id"],
        "timestamp": decoded_json["ts"],
        "hash": decoded_json["h"],
        "prev_hash": decoded_json["ph"],
        "signature": decoded_json["sig"],
        "pubkey": decoded_json["pub"],
        "status": decoded_json["st"],
        "verification_tag": "MEANTIME_UNVERIFIED_PEER" # Rule X₀-7 Initial Tag
    }
    
    assert scanned_receipt["verification_tag"] == "MEANTIME_UNVERIFIED_PEER"
    print(f"  --> PASS: Scanned peer receipt ingested. Status: {scanned_receipt['verification_tag']}")

    # TEST 3: Cryptographic Verification & Trust Upgrade to PROVEN_PEER_RECEIPT
    print("\n[TEST 3] Re-evaluating Epistemic Proof & Signature Verification...")
    reconstructed = f"{scanned_receipt['passport_id']}:{scanned_receipt['timestamp']}:{scanned_receipt['prev_hash']}:{scanned_receipt['hash']}"
    pub_key_bytes = bytes.fromhex(scanned_receipt["pubkey"])
    verifier = ed25519.Ed25519PublicKey.from_public_bytes(pub_key_bytes)
    
    verifier.verify(bytes.fromhex(scanned_receipt["signature"]), reconstructed.encode('utf-8'))
    scanned_receipt["verification_tag"] = "PROVEN_PEER_RECEIPT"
    
    assert scanned_receipt["verification_tag"] == "PROVEN_PEER_RECEIPT"
    print(f"  --> PASS: Ed25519 signature verified. Trust upgraded to: {scanned_receipt['verification_tag']}")

    print("\n" + "=" * 80)
    print("ALL QR PEER-TO-PEER RECEIPT EXCHANGE TESTS PASSED (3/3 PASS)")
    print("=" * 80)

if __name__ == "__main__":
    run_test_suite()
