#!/usr/bin/env python3
"""
Safegrid Trust Spine — Tier-2 Edge Ingestion Receiver (L1 Boundary)
===================================================================
Listens for 32-byte ESP32-S3 state heads over UDP, verifies hash continuity, 
applies zero-fabrication physics sanity gates, and appends signed records to the local WORM ledger.

Binary Payload Format (32 bytes):
  [0:4]   Node ID (4 bytes, e.g., b'N001')
  [4:8]   Timestamp (4 bytes, Unix epoch)
  [8:32]  Truncated SHA-256 Digest (24 bytes)

Author: Venture Vision Ubuntu
"""

import socket
import struct
import hashlib
import json
import time
import os
import shutil
import threading
from typing import Dict, Any, Tuple
from cryptography.hazmat.primitives.asymmetric import ed25519
from cryptography.hazmat.primitives import serialization

# ==============================================================================
# 1. CRYPTOGRAPHIC KEYRING (Tier-2 Trust Root)
# ==============================================================================
class Tier2TrustRoot:
    def __init__(self, key_dir: str = "/workspace/scratch/keys"):
        os.makedirs(key_dir, exist_ok=True)
        self.key_path = os.path.join(key_dir, "tier2_ed25519.pem")
        
        if os.path.exists(self.key_path):
            with open(self.key_path, "rb") as f:
                self.private_key = serialization.load_pem_private_key(f.read(), password=None)
        else:
            self.private_key = ed25519.Ed25519PrivateKey.generate()
            pem = self.private_key.private_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PrivateFormat.PKCS8,
                encryption_algorithm=serialization.NoEncryption()
            )
            with open(self.key_path, "wb") as f:
                f.write(pem)
            os.chmod(self.key_path, 0o600)

        self.public_key = self.private_key.public_key()
        self.pubkey_hex = self.public_key.public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw
        ).hex()

    def sign(self, data: bytes) -> str:
        return self.private_key.sign(data).hex()

    def verify(self, data: bytes, signature_hex: str) -> bool:
        try:
            self.public_key.verify(bytes.fromhex(signature_hex), data)
            return True
        except Exception:
            return False

# ==============================================================================
# 2. LOCAL WORM LEDGER
# ==============================================================================
class LocalWormLedger:
    def __init__(self, filepath: str, trust_root: Tier2TrustRoot):
        self.filepath = filepath
        self.trust_root = trust_root
        self.lock = threading.Lock()
        self.head_hash = "GENESIS_TIER2_000000000000000000000000000000000000000000000000000"
        
        if not os.path.exists(self.filepath):
            with open(self.filepath, "w") as f:
                f.write("")

    def append(self, node_id: str, raw_payload_hex: str, status: str, reason: str = "OK"):
        with self.lock:
            entry = {
                "timestamp": time.time(),
                "node_id": node_id,
                "payload_hex": raw_payload_hex,
                "status": status,
                "reason": reason,
                "prev_hash": self.head_hash
            }
            
            canonical = json.dumps(entry, sort_keys=True).encode('utf-8')
            entry_hash = hashlib.sha256(canonical).hexdigest()
            signature = self.trust_root.sign(canonical)
            
            block = {
                **entry,
                "hash": entry_hash,
                "tier2_signature": signature
            }
            
            with open(self.filepath, "a") as f:
                f.write(json.dumps(block) + "\n")
            
            self.head_hash = entry_hash
            return block

# ==============================================================================
# 3. ZERO-FABRICATION PHYSICS GATE
# ==============================================================================
class PhysicsGate:
    """
    Prevents physically impossible data from entering the trust spine.
    (e.g., rate of change exceeding physical limits).
    """
    def __init__(self):
        self.last_reading: Dict[str, Tuple[float, float]] = {} # node_id -> (timestamp, temp)
        self.MAX_DELTA_TEMP_PER_SEC = 5.0 # Max 5°C change per second

    def validate(self, node_id: str, timestamp: float, temp_c: float) -> Tuple[bool, str]:
        if node_id in self.last_reading:
            last_ts, last_temp = self.last_reading[node_id]
            time_delta = timestamp - last_ts
            
            if time_delta > 0:
                temp_delta = abs(temp_c - last_temp)
                rate_of_change = temp_delta / time_delta
                
                if rate_of_change > self.MAX_DELTA_TEMP_PER_SEC:
                    return False, f"PHYSICS_VIOLATION: Temp changed {temp_delta:.1f}°C in {time_delta:.1f}s ({rate_of_change:.1f}°C/s > Max {self.MAX_DELTA_TEMP_PER_SEC}°C/s)"

        self.last_reading[node_id] = (timestamp, temp_c)
        return True, "PASSED"

# ==============================================================================
# 4. ESP32 RECEIVER & HASH CONTINUITY ENGINE
# ==============================================================================
class ESP32Receiver:
    def __init__(self, host: str = "127.0.0.1", port: int = 5005):
        self.host = host
        self.port = port
        self.trust_root = Tier2TrustRoot()
        self.ledger = LocalWormLedger("/workspace/scratch/tier2_worm_ledger.jsonl", self.trust_root)
        self.physics_gate = PhysicsGate()
        self.node_expected_hash: Dict[str, bytes] = {}
        self.running = True

    def process_packet(self, data: bytes, override_temp: float = None) -> Dict[str, Any]:
        if len(data) != 32:
            return {"status": "REJECTED", "reason": f"MALFORMED_PACKET_LENGTH_{len(data)}"}

        try:
            node_id_bytes, timestamp, received_hash = struct.unpack('<4sI24s', data)
            node_id = node_id_bytes.decode('utf-8', errors='replace')
        except struct.error:
            return {"status": "REJECTED", "reason": "STRUCT_UNPACK_FAILED"}

        # 1. Hash Continuity Check
        prev_hash = self.node_expected_hash.get(node_id, b'\x00' * 24)
        payload_to_hash = prev_hash + node_id_bytes + struct.pack('<I', timestamp)
        expected_hash = hashlib.sha256(payload_to_hash).digest()[:24]

        if received_hash != expected_hash:
            reason = "HASH_CONTINUITY_BREACH"
            block = self.ledger.append(node_id, data.hex(), "REJECTED", reason)
            return {"status": "REJECTED", "reason": reason, "block": block}

        # Update expected hash for next packet
        self.node_expected_hash[node_id] = received_hash

        # 2. Physics Gate Validation
        mock_temp = override_temp if override_temp is not None else float((timestamp * 10) % 100)
        passed, physics_reason = self.physics_gate.validate(node_id, float(timestamp), mock_temp)
        
        if not passed:
            block = self.ledger.append(node_id, data.hex(), "UNDEFINED", physics_reason)
            return {"status": "UNDEFINED", "reason": physics_reason, "block": block}

        # 3. Append to WORM Ledger
        block = self.ledger.append(node_id, data.hex(), "VALID", "PASSED_HASH_AND_PHYSICS")
        return {"status": "VALID", "reason": "PASSED_HASH_AND_PHYSICS", "block": block}

# ==============================================================================
# 5. VERIFICATION SUITE
# ==============================================================================
def run_verification_suite():
    print("=" * 80)
    print("SAFEGRID TIER-2 EDGE INGESTION RECEIVER VERIFICATION SUITE")
    print("=" * 80)
    
    receiver = ESP32Receiver()
    print(f"[*] Attestation Tier: T1 · Ed25519 (Software)")
    print(f"[*] Public Key Hex:   {receiver.trust_root.pubkey_hex[:32]}...")
    print(f"[*] WORM Ledger File: {receiver.ledger.filepath}\n")

    node_id = b"N001"
    
    # --- TEST 1: Valid 32-Byte Packet ---
    print("[TEST 1] Processing Valid 32-Byte ESP32 Packet (Hash Continuity Intact)...")
    ts1 = int(time.time())
    prev_hash_1 = b'\x00' * 24
    payload_1 = prev_hash_1 + node_id + struct.pack('<I', ts1)
    valid_hash_1 = hashlib.sha256(payload_1).digest()[:24]
    packet_1 = struct.pack('<4sI24s', node_id, ts1, valid_hash_1)
    
    res1 = receiver.process_packet(packet_1, override_temp=25.0)
    assert res1["status"] == "VALID", f"Expected VALID, got {res1['status']}"
    print(f"  --> PASS: Valid packet accepted. Block Hash: {res1['block']['hash'][:16]}...")

    # --- TEST 2: Tampered Hash Continuity ---
    print("\n[TEST 2] Processing Tampered Packet (Simulating Replay/MITM Attack)...")
    ts2 = ts1 + 1
    fake_prev_hash = b'\xff' * 24
    fake_payload = fake_prev_hash + node_id + struct.pack('<I', ts2)
    fake_hash = hashlib.sha256(fake_payload).digest()[:24]
    packet_2 = struct.pack('<4sI24s', node_id, ts2, fake_hash)
    
    res2 = receiver.process_packet(packet_2)
    assert res2["status"] == "REJECTED", f"Expected REJECTED, got {res2['status']}"
    assert res2["reason"] == "HASH_CONTINUITY_BREACH"
    print(f"  --> PASS: Tampered continuity correctly rejected with status REJECTED.")

    # --- TEST 3: Physics Gate Violation ---
    print("\n[TEST 3] Processing Packet with Impossible Rate of Change (Physics Gate)...")
    receiver.node_expected_hash["N002"] = b'\x00' * 24
    node2 = b"N002"
    ts3_a = 1000
    p3_a = b'\x00' * 24 + node2 + struct.pack('<I', ts3_a)
    h3_a = hashlib.sha256(p3_a).digest()[:24]
    packet3_a = struct.pack('<4sI24s', node2, ts3_a, h3_a)
    receiver.process_packet(packet3_a, override_temp=20.0) # Reading 1: 20°C at t=1000s

    ts3_b = 1001
    p3_b = h3_a + node2 + struct.pack('<I', ts3_b)
    h3_b = hashlib.sha256(p3_b).digest()[:24]
    packet3_b = struct.pack('<4sI24s', node2, ts3_b, h3_b)
    
    # Reading 2: 75°C at t=1001s (55°C/s jump > 5°C/s ceiling)
    res3 = receiver.process_packet(packet3_b, override_temp=75.0)
    assert res3["status"] == "UNDEFINED", f"Expected UNDEFINED, got {res3['status']}"
    assert "PHYSICS_VIOLATION" in res3["reason"]
    print(f"  --> PASS: Physics gate correctly flagged impossible temperature jump ({res3['reason']}).")

    # --- TEST 4: WORM Ledger Integrity Verification ---
    print("\n[TEST 4] Verifying WORM Ledger Signature Integrity...")
    with open(receiver.ledger.filepath, "r") as f:
        lines = [json.loads(line) for line in f if line.strip()]
    
    assert len(lines) >= 3, "Expected at least 3 blocks in WORM ledger"
    for block in lines:
        payload_dict = {
            "timestamp": block["timestamp"],
            "node_id": block["node_id"],
            "payload_hex": block["payload_hex"],
            "status": block["status"],
            "reason": block["reason"],
            "prev_hash": block["prev_hash"]
        }
        canonical = json.dumps(payload_dict, sort_keys=True).encode('utf-8')
        assert receiver.trust_root.verify(canonical, block["tier2_signature"]), "Signature verification failed"

    print("  --> PASS: All WORM ledger entries verified against Tier-2 Ed25519 public key.")

    print("\n" + "=" * 80)
    print("ALL TIER-2 EDGE INGESTION RECEIVER PROOF OBLIGATIONS VERIFIED (4/4 PASS)")
    print("=" * 80)

if __name__ == "__main__":
    run_verification_suite()
