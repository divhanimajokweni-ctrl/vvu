#!/usr/bin/env python3
"""
Safegrid / VVU Trust Spine — Service Worker & Meantime Journal Verification
=============================================================================
Verifies offline cache manifest declarations, sequence.html asset coverage,
HEAD self-probe intercept rules, and meantime_journal.jsonl sync invariants.

Author: Venture Vision Ubuntu
"""

import os
import sys
import json
import time
import hashlib
from typing import Dict, Any, List

def run_sw_meantime_verification():
    print("=" * 80)
    print("VVU SERVICE WORKER & MEANTIME JOURNAL VERIFICATION SUITE")
    print("=" * 80)

    sw_path = "/workspace/scratch/pwa-service-worker.js"
    assert os.path.exists(sw_path), "Service Worker file missing!"

    with open(sw_path, "r", encoding="utf-8") as f:
        sw_code = f.read()

    # TEST 1: Cache Manifest & Sequence Assets
    print("\n[TEST 1] Verifying Sequence Manifest & Pre-cache declarations...")
    required_assets = [
        "sequence.html",
        "digital-twin.html",
        "cape_town_wildfire.html",
        "borromean-rings.tsx.txt",
        "pwa-mobile-edge-client.js",
        "pwa-field-insight-cards.js"
    ]
    for asset in required_assets:
        assert asset in sw_code, f"Asset '{asset}' missing from Service Worker cache manifest!"
    print("  --> PASS: All 6 sequence steps and PWA modules present in cache manifest.")

    # TEST 2: Self-Audit HEAD Interceptor
    print("\n[TEST 2] Verifying HEAD Self-Audit Probe Interceptor (No-Primitives Law)...")
    assert "req.method === 'HEAD'" in sw_code, "HEAD method handling missing!"
    assert "BLOCKED_MISSING_ASSET" in sw_code, "Missing asset BLOCKED response missing!"
    assert "PROVEN" in sw_code, "PROVEN audit status missing!"
    print("  --> PASS: HEAD self-probe interceptor correctly enforces PROVEN / BLOCKED status.")

    # TEST 3: Meantime Journaling & Offline Sync
    print("\n[TEST 3] Verifying Meantime Journaling & IndexedDB Sync protocol...")
    assert "JOURNAL_APPEND" in sw_code, "JOURNAL_APPEND message handler missing!"
    assert "JOURNAL_FLUSH" in sw_code, "JOURNAL_FLUSH message handler missing!"
    assert "/api/v1/telemetry/sync" in sw_code, "Telemetry sync API endpoint missing!"
    print("  --> PASS: Offline Meantime Journal append & flush handlers verified.")

    # TEST 4: Python Meantime Journal Integrity Simulation
    print("\n[TEST 4] Simulating Disk-Persistent Meantime Journal (meantime_journal.jsonl)...")
    journal_file = "/workspace/scratch/meantime_journal.jsonl"
    head_hash = "GENESIS_MEANTIME_00000000000000000000000000000000"

    entries = []
    # Write 3 offline telemetry blocks
    for i in range(3):
        rec = {
            "timestamp": time.time() + i,
            "event_type": "OFFLINE_PATROL_IMU",
            "accel_mag": 9.81 + (i * 0.1),
            "hr_bpm": 74 + i,
            "prev_hash": head_hash
        }
        canonical = json.dumps(rec, sort_keys=True).encode('utf-8')
        entry_hash = hashlib.sha256(canonical).hexdigest()
        block = {**rec, "entry_hash": entry_hash}
        entries.append(block)
        head_hash = entry_hash

    with open(journal_file, "w") as f:
        for entry in entries:
            f.write(json.dumps(entry) + "\n")

    # Verify chain integrity
    check_head = "GENESIS_MEANTIME_00000000000000000000000000000000"
    with open(journal_file, "r") as f:
        for line in f:
            data = json.loads(line.strip())
            stored_hash = data.pop("entry_hash")
            assert data["prev_hash"] == check_head, "Meantime hash chain break!"
            recomputed = hashlib.sha256(json.dumps(data, sort_keys=True).encode('utf-8')).hexdigest()
            assert stored_hash == recomputed, "Hash digest mismatch!"
            check_head = stored_hash

    print(f"  --> PASS: 3 offline meantime entries verified against WORM hash chain. Head: {check_head[:16]}...")

    print("\n" + "=" * 80)
    print("ALL SERVICE WORKER & MEANTIME JOURNAL TESTS PASSED SUCCESSFULLY (4/4 PASS)")
    print("=" * 80)

if __name__ == "__main__":
    run_sw_meantime_verification()
