"""
agri_smartphone_web_bridge.py
--------------------------------------------------------------------------------
Mobile-Optimized PWA & WebSocket Bridge for Offline Smart Farm AI Operations
Connects Handheld Smartphones directly to the On-Premise OPC UA MCP Gateway.

Key Features:
- Serves a Progressive Web App (PWA) optimized for iOS & Android mobile browsers.
- Real-time WebSocket telemetry updates at 1 Hz over local Wi-Fi / Hotspot.
- Touch-friendly 1-tap controls for Load-Shedding, VFD Irrigation, & Cold-Chain.
- Generates ASCII and PNG QR codes for instant smartphone pairing.

Author: Divhani Mihle Majokweni
License: MIT
--------------------------------------------------------------------------------
"""

import sys
import os
import json
import socket
import asyncio
from typing import List
from datetime import datetime, timezone

# Import the core OPC UA server and MCP gateway
from opcua_mcp_offline_agri_server import SouthAfricanAgriOPCUAServer, AgriMCPToolGateway

try:
    from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Request
    from fastapi.responses import HTMLResponse, JSONResponse
    import uvicorn
    HAS_FASTAPI = True
except ImportError:
    HAS_FASTAPI = False


def get_local_ip():
    """Detects the workstation's local network IP address (e.g. 192.168.1.50)."""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(('10.255.255.255', 1))
        IP = s.getsockname()[0]
    except Exception:
        IP = '127.0.0.1'
    finally:
        s.close()
    return IP


# Initialize Core Industrial Stack
opcua_server = SouthAfricanAgriOPCUAServer()
mcp_gateway = AgriMCPToolGateway(opcua_server)

# Mobile-Optimized Single-Page Progressive Web App HTML
SMARTPHONE_PWA_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>SmartFarm SA Mobile</title>
    <meta name="theme-color" content="#1b4332">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <style>
        :root {
            --bg-color: #0f2017;
            --card-bg: #1b4332;
            --accent-green: #2d6a4f;
            --highlight: #52b788;
            --alert-red: #d90429;
            --text-light: #f8f9fa;
            --text-dim: #b7e4c7;
        }
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; }
        body { background-color: var(--bg-color); color: var(--text-light); padding: 12px; font-size: 16px; }
        header { background-color: var(--card-bg); padding: 16px; border-radius: 12px; margin-bottom: 12px; display: flex; justify-content: space-between; align-items: center; border-left: 5px solid var(--highlight); }
        h1 { font-size: 1.2rem; font-weight: 700; color: #ffffff; }
        .badge { background: #2d6a4f; color: #e9d8a6; padding: 4px 8px; border-radius: 6px; font-size: 0.75rem; font-weight: bold; }
        .grid { display: grid; grid-template-columns: 1fr; gap: 12px; }
        @media(min-width: 600px) { .grid { grid-template-columns: 1fr 1fr; } }
        .card { background-color: var(--card-bg); border-radius: 12px; padding: 16px; box-shadow: 0 4px 10px rgba(0,0,0,0.3); }
        .card-title { font-size: 0.85rem; text-transform: uppercase; letter-spacing: 1px; color: var(--text-dim); margin-bottom: 8px; display: flex; justify-content: space-between; }
        .metric-value { font-size: 1.8rem; font-weight: 800; color: #ffffff; }
        .metric-unit { font-size: 1rem; color: var(--highlight); font-weight: normal; }
        .btn-group { display: grid; grid-template-columns: repeat(4, 1fr); gap: 6px; margin-top: 10px; }
        .btn { background: #2d6a4f; color: white; border: none; padding: 10px; border-radius: 8px; font-weight: bold; font-size: 0.9rem; cursor: pointer; text-align: center; }
        .btn:active { background: var(--highlight); transform: scale(0.98); }
        .btn-alert { background: var(--alert-red); }
        .slider-container { margin-top: 12px; }
        input[type=range] { width: 100%; height: 35px; accent-color: var(--highlight); }
        .status-dot { height: 10px; width: 10px; background-color: #52b788; border-radius: 50%; display: inline-block; margin-right: 5px; }
        .offline-notice { background: #52b788; color: #081c15; text-align: center; padding: 6px; border-radius: 8px; font-size: 0.8rem; font-weight: bold; margin-bottom: 12px; }
    </style>
</head>
<body>
    <div class="offline-notice">🟢 OFFLINE LOCAL WI-FI ACTIVE &bull; NO CELLULAR DATA NEEDED</div>
    <header>
        <div>
            <h1>🇿🇦 SmartFarm SA</h1>
            <p style="font-size:0.75rem; color:var(--text-dim);">OPC UA Edge Gateway Bridge</p>
        </div>
        <span class="badge" id="conn-status"><span class="status-dot"></span>LIVE</span>
    </header>

    <div class="grid">
        <!-- POWER CARD -->
        <div class="card">
            <div class="card-title">
                <span>Eskom Power & Solar</span>
                <span id="grid-state">GRID OK</span>
            </div>
            <div class="metric-value" id="solar-soc">87.5 <span class="metric-unit">% SoC</span></div>
            <p style="font-size:0.8rem; color:var(--text-dim); margin-top:4px;" id="loadshedding-text">Stage 0 Load-Shedding</p>
            <div style="margin-top:10px;">
                <p style="font-size:0.75rem; color:var(--text-dim);">Set Eskom Load-Shedding Stage:</p>
                <div class="btn-group">
                    <button class="btn" onclick="setLoadShedding(0)">Stg 0</button>
                    <button class="btn" onclick="setLoadShedding(2)">Stg 2</button>
                    <button class="btn" onclick="setLoadShedding(4)">Stg 4</button>
                    <button class="btn btn-alert" onclick="setLoadShedding(6)">Stg 6</button>
                </div>
            </div>
        </div>

        <!-- WATER & IRRIGATION CARD -->
        <div class="card">
            <div class="card-title">
                <span>Irrigation & Borehole</span>
                <span id="soil-status">SOIL IDEAL</span>
            </div>
            <div style="display:flex; justify-content:space-between; align-items:baseline;">
                <div>
                    <div class="metric-value" id="vfd-speed">45.0 <span class="metric-unit">Hz</span></div>
                    <p style="font-size:0.75rem; color:var(--text-dim);">VFD Pump Speed</p>
                </div>
                <div style="text-align:right;">
                    <div class="metric-value" id="soil-tension" style="font-size:1.3rem;">28.4 <span class="metric-unit">cb</span></div>
                    <p style="font-size:0.75rem; color:var(--text-dim);">Soil Tension</p>
                </div>
            </div>
            <div class="slider-container">
                <p style="font-size:0.75rem; color:var(--text-dim);">Manual VFD Pump Override:</p>
                <input type="range" min="0" max="50" value="45" id="vfd-slider" onchange="updateVFD(this.value)">
            </div>
        </div>

        <!-- COLD CHAIN CARD -->
        <div class="card">
            <div class="card-title">
                <span>Packhouse Cold Room</span>
                <span>PPECB Target: 4.0°C</span>
            </div>
            <div class="metric-value" id="cold-temp">4.2 <span class="metric-unit">°C</span></div>
            <p style="font-size:0.8rem; color:var(--text-dim); margin-top:4px;" id="compressor-text">Compressor Load: 32.1 A</p>
        </div>

        <!-- SECURITY CARD -->
        <div class="card">
            <div class="card-title">
                <span>Electric Fence Security</span>
                <span id="fence-status" style="color:var(--highlight);">INTACT</span>
            </div>
            <div class="metric-value" id="fence-kv">7.8 <span class="metric-unit">kV</span></div>
            <p style="font-size:0.8rem; color:var(--text-dim); margin-top:4px;">Minimum Safety Limit: 5.0 kV</p>
        </div>
    </div>

    <script>
        const host = window.location.host;
        const wsProtocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
        let socket;

        function connectWS() {
            socket = new WebSocket(`${wsProtocol}//${host}/ws/telemetry`);
            
            socket.onopen = () => {
                document.getElementById('conn-status').innerHTML = '<span class="status-dot"></span>LIVE';
            };

            socket.onmessage = (event) => {
                const data = JSON.parse(event.data);
                if (data.type === 'telemetry') {
                    updateUI(data.payload);
                }
            };

            socket.onclose = () => {
                document.getElementById('conn-status').innerText = 'OFFLINE';
                setTimeout(connectWS, 2000);
            };
        }

        function updateUI(t) {
            if (t.Solar_Battery_SoC) document.getElementById('solar-soc').innerHTML = `${t.Solar_Battery_SoC.value.toFixed(1)} <span class="metric-unit">% SoC</span>`;
            if (t.LoadShedding_Stage) document.getElementById('loadshedding-text').innerText = `Stage ${t.LoadShedding_Stage.value} Load-Shedding Active`;
            if (t.Eskom_Grid_Available) document.getElementById('grid-state').innerText = t.Eskom_Grid_Available.value ? 'GRID OK' : 'GRID DOWN';
            
            if (t.VFD_Pump_Frequency_Hz) {
                document.getElementById('vfd-speed').innerHTML = `${t.VFD_Pump_Frequency_Hz.value.toFixed(1)} <span class="metric-unit">Hz</span>`;
                document.getElementById('vfd-slider').value = t.VFD_Pump_Frequency_Hz.value;
            }
            if (t.Soil_Tension_Centibar) document.getElementById('soil-tension').innerHTML = `${t.Soil_Tension_Centibar.value.toFixed(1)} <span class="metric-unit">cb</span>`;
            
            if (t.Citrus_ColdRoom_Temp_C) document.getElementById('cold-temp').innerHTML = `${t.Citrus_ColdRoom_Temp_C.value.toFixed(1)} <span class="metric-unit">°C</span>`;
            if (t.Compressor_Current_Amps) document.getElementById('compressor-text').innerText = `Compressor Load: ${t.Compressor_Current_Amps.value.toFixed(1)} A`;
            
            if (t.Electric_Fence_Voltage_kV) document.getElementById('fence-kv').innerHTML = `${t.Electric_Fence_Voltage_kV.value.toFixed(1)} <span class="metric-unit">kV</span>`;
        }

        function setLoadShedding(stage) {
            fetch('/api/loadshedding', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({stage: stage})
            });
        }

        function updateVFD(val) {
            fetch('/api/vfd', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({frequency_hz: parseFloat(val)})
            });
        }

        connectWS();
    </script>
</body>
</html>
"""

if HAS_FASTAPI:
    app = FastAPI(title="SmartFarm SA Offline Mobile Bridge")

    class ConnectionManager:
        def __init__(self):
            self.active_connections: List[WebSocket] = []

        async def connect(self, websocket: WebSocket):
            await websocket.accept()
            self.active_connections.append(websocket)

        def disconnect(self, websocket: WebSocket):
            if websocket in self.active_connections:
                self.active_connections.remove(websocket)

        async def broadcast(self, message: dict):
            for connection in self.active_connections:
                try:
                    await connection.send_json(message)
                except Exception:
                    pass

    manager = ConnectionManager()

    @app.get("/", response_class=HTMLResponse)
    async def get_mobile_pwa():
        return SMARTPHONE_PWA_HTML

    @app.get("/api/telemetry")
    async def get_telemetry():
        data = mcp_gateway.execute_tool("read_farm_telemetry", {"category": "ALL"})
        return JSONResponse(data)

    @app.post("/api/loadshedding")
    async def set_loadshedding(req: Request):
        body = await req.json()
        stage = body.get("stage", 0)
        res = mcp_gateway.execute_tool("optimize_loadshedding_power", {
            "loadshedding_stage": stage,
            "enable_solar_priority": True
        })
        return JSONResponse(res)

    @app.post("/api/vfd")
    async def set_vfd(req: Request):
        body = await req.json()
        freq = body.get("frequency_hz", 45.0)
        res = mcp_gateway.execute_tool("set_vfd_irrigation_speed", {
            "frequency_hz": freq,
            "reason": "Smartphone touch slider manual override"
        })
        return JSONResponse(res)

    @app.websocket("/ws/telemetry")
    async def websocket_telemetry_endpoint(websocket: WebSocket):
        await manager.connect(websocket)
        try:
            while True:
                # Stream real-time telemetry updates to connected smartphones at 1 Hz
                telemetry = mcp_gateway.execute_tool("read_farm_telemetry", {"category": "ALL"})
                await websocket.send_json({
                    "type": "telemetry",
                    "payload": telemetry.get("data", {})
                })
                await asyncio.sleep(1.0)
        except WebSocketDisconnect:
            manager.disconnect(websocket)


def print_qr_code(url: str):
    """Generates and prints a clean ASCII QR code in the terminal for direct phone scanning."""
    try:
        import qrcode
        qr = qrcode.QRCode(border=2)
        qr.add_data(url)
        qr.make(fit=True)
        print("\n[+] SCAN QR CODE BELOW WITH YOUR SMARTPHONE TO ACCESS THE FARM DASHBOARD:")
        qr.print_ascii(invert=True)
        img = qr.make_image(fill_color="black", back_color="white")
        qr_file = "/workspace/scratch/smartphone_access_qr.png"
        img.save(qr_file)
        print(f"  (QR Code image also saved to /workspace/scratch/smartphone_access_qr.png)")
    except ImportError:
        print(f"\n[+] Mobile Web App URL: {url}")


def start_mobile_bridge_server():
    ip = get_local_ip()
    port = 8000
    mobile_url = f"http://{ip}:{port}"

    print("=" * 80)
    print("  SMARTFARM SA - OFFLINE SMARTPHONE PWA & WEBSOCKET GATEWAY")
    print("=" * 80)
    print(f"[+] Workstation Local IP: {ip}")
    print(f"[+] Smartphone Web App Access URL: {mobile_url}")
    
    print_qr_code(mobile_url)

    if HAS_FASTAPI:
        print("\n[+] Launching FastAPI / Uvicorn Server on port 8000...")
        uvicorn.run(app, host="0.0.0.0", port=port, log_level="warning")
    else:
        print("\n[!] FastAPI/Uvicorn not found. Running headless OPC UA simulation mode.")


if __name__ == "__main__":
    start_mobile_bridge_server()
