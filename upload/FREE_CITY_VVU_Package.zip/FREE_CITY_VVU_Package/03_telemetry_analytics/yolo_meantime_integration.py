import time
import json
import hashlib
import random
from datetime import datetime, timezone

class CryptographicStenographer:
    """Parallel cryptographic log journal generating SHA-256 hash chains for failover events."""
    def __init__(self):
        self.journal = []
        self.prev_hash = "0000000000000000000000000000000000000000000000000000000000000000"

    def log_event(self, source: str, event_type: str, payload: dict) -> dict:
        timestamp = datetime.now(timezone.utc).isoformat()
        entry_data = {
            "index": len(self.journal) + 1,
            "prev_hash": self.prev_hash,
            "timestamp": timestamp,
            "source": source,
            "event_type": event_type,
            "payload": payload
        }
        canonical_str = json.dumps(entry_data, sort_keys=True)
        current_hash = hashlib.sha256(canonical_str.encode('utf-8')).hexdigest()
        entry_data["hash"] = current_hash
        self.journal.append(entry_data)
        self.prev_hash = current_hash
        return entry_data

    def verify_integrity(self) -> bool:
        prev = "0000000000000000000000000000000000000000000000000000000000000000"
        for entry in self.journal:
            if entry["prev_hash"] != prev:
                return False
            check_data = {
                "index": entry["index"],
                "prev_hash": entry["prev_hash"],
                "timestamp": entry["timestamp"],
                "source": entry["source"],
                "event_type": entry["event_type"],
                "payload": entry["payload"]
            }
            calc_hash = hashlib.sha256(json.dumps(check_data, sort_keys=True).encode('utf-8')).hexdigest()
            if calc_hash != entry["hash"]:
                return False
            prev = entry["hash"]
        return True

class MeantimeCalibrationEngine:
    """Backup generator handling offline failover telemetry logging with POPIA consent tagging."""
    def __init__(self, stenographer: CryptographicStenographer):
        self.stenographer = stenographer
        self.is_active = False

    def activate_failover(self, reason: str):
        self.is_active = True
        self.stenographer.log_event("MEANTIME_ENGINE", "FAILOVER_ACTIVATED", {"reason": reason})
        print(f"\n⚡ [MEANTIME FAILOVER ENGAGED] Reason: {reason}")
        print("   Local Cryptographic Stenographer is now recording all multi-camera threat feeds locally.")

    def process_camera_event(self, camera_id: str, frame_data: dict) -> dict:
        popia_consent = f"POPIA-ZA-2013-{hashlib.md5(f'{camera_id}_{frame_data.get('frame_id', 0)}'.encode()).hexdigest()[:8]}"
        frame_data["popia_consent_tag"] = popia_consent
        
        # Cryptographically log user/camera side event
        logged_entry = self.stenographer.log_event("CAMERA_RTSP_FEED", "THREAT_DETECTED_MEANTIME", {
            "camera_id": camera_id,
            "frame_data": frame_data
        })
        return {
            "status": "LOGGED_LOCAL_MEANTIME",
            "camera_id": camera_id,
            "popia_tag": popia_consent,
            "entry_hash": logged_entry["hash"]
        }

    def deactivate_and_reconcile(self, primary_window_url: str) -> dict:
        self.stenographer.log_event("MEANTIME_ENGINE", "RECONCILIATION_EXPORT_START", {
            "target_url": primary_window_url
        })
        integrity_ok = self.stenographer.verify_integrity()
        
        if integrity_ok:
            self.is_active = False
            return {
                "status": "RECONCILIATION_SUCCESS",
                "chain_verified": True,
                "exported_events_count": len(self.stenographer.journal),
                "primary_endpoint": primary_window_url,
                "head_hash": self.stenographer.prev_hash
            }
        else:
            return {
                "status": "RECONCILIATION_FAILED",
                "chain_verified": False,
                "error": "TAMPER_DETECTED"
            }

def run_integration_simulation():
    print("=" * 68)
    print("  INTEGRATED MULTI-CAMERA YOLO THREAT FEED & MEANTIME FAILOVER DEMO  ")
    print("=" * 68)

    stenographer = CryptographicStenographer()
    meantime_engine = MeantimeCalibrationEngine(stenographer)

    camera_streams = [
        {"cam_id": "CAM_01_NORTH_GATE", "location": "Perimeter North", "class": "PERSON", "conf": 0.92, "zone": "RESTRICTED_FENCE", "is_threat": True},
        {"cam_id": "CAM_02_SMR_CORE", "location": "SMR Enclosure", "class": "wildlife_springbok", "conf": 0.95, "zone": "OUTER_BUFFER", "is_threat": False},
        {"cam_id": "CAM_03_HAUL_ROAD", "location": "Access Road South", "class": "haul_truck_authorized", "conf": 0.98, "zone": "HAUL_CORRIDOR", "is_threat": False},
        {"cam_id": "CAM_04_SUBSTATION", "location": "Substation Alpha East", "class": "UNIDENTIFIED_VEHICLE", "conf": 0.94, "zone": "HIGH_VOLTAGE", "is_threat": True}
    ]

    print("\n--- PHASE 1: PRIMARY SERVER NOMINAL OPERATION ---")
    print("Primary connection active at 100Gbps THz fronthaul (Latency: 82.4µs).")
    for cam in camera_streams[:2]:
        if cam["is_threat"]:
            print(f"🚨 [PRIMARY LOGGED] {cam['cam_id']} -> Threat: {cam['class']} ({cam['conf']*100:.1f}%)")
        else:
            print(f"🛡️ [EDGE FILTERED] {cam['cam_id']} -> False alarm filtered on-site ({cam['class']})")

    print("\n--- PHASE 2: CRITICAL NETWORK OUTAGE SIMULATED ---")
    print("⚡ Outage Event: THz Wireless Link Severed / Primary Gateway Unreachable!")
    meantime_engine.activate_failover("PRIMARY_GATEWAY_DISCONNECT_SLA_BREACH")

    print("\n--- PHASE 3: MULTI-CAMERA THREAT FEED DURING MEANTIME OUTAGE ---")
    frame_counter = 101
    for cam in camera_streams[2:]:
        frame_counter += 1
        frame_payload = {
            "frame_id": frame_counter,
            "location": cam["location"],
            "detection": cam["class"],
            "confidence": cam["conf"],
            "zone": cam["zone"],
            "is_threat": cam["is_threat"]
        }
        
        if cam["is_threat"]:
            res = meantime_engine.process_camera_event(cam["cam_id"], frame_payload)
            print(f"🚨 [MEANTIME LOGGED] Camera: {cam['cam_id']}")
            print(f"   Threat     : {cam['class']} ({cam['conf']*100:.1f}%) in {cam['zone']}")
            print(f"   POPIA Tag  : {res['popia_tag']}")
            print(f"   WORM Hash  : {res['entry_hash']}")
        else:
            print(f"🛡️ [EDGE FILTERED] Camera: {cam['cam_id']} ({cam['class']}) - No local action required.")

    print("\n--- PHASE 4: PRIMARY CONNECTION RESTORATION & AUTOMATIC RECONCILIATION ---")
    print("🔄 Primary network re-established. Initiating cryptographic reconciliation...")
    rec_result = meantime_engine.deactivate_and_reconcile("https://vvu-enterprise.space-z.ai/api/reconcile")

    print("\n=================== RECONCILIATION RESULT ===================")
    print(f"Status           : {rec_result['status']}")
    print(f"Chain Integrity  : PASSED ({rec_result['chain_verified']})")
    print(f"Events Exported  : {rec_result['exported_events_count']} entries")
    print(f"Primary Window   : {rec_result['primary_endpoint']}")
    print(f"Head Hash Anchor : {rec_result['head_hash']}")
    print("=============================================================")

if __name__ == "__main__":
    run_integration_simulation()
