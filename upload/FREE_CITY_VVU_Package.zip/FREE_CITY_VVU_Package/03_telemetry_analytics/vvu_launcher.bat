@echo off
echo =========================================================
echo    VVU PROOFBRIDGE — ONE-CLICK NODE LAUNCHER
echo =========================================================
echo Node ID    : KR_SEOUL_NODE_01
echo Location   : Seoul
echo Public Key : 486c6608cdd4a2e27d4d961e3139bdcbff44bb0c779de81d645648e235ae8208
echo Opening Pairing Window in your browser...
start http://localhost:8080/pair
echo Node running in background. Close this window to stop.
pause
