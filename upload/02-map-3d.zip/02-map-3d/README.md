# 02 · MAP 3D

MapLibre 3D with OpenFreeMap tiles. GIS spatial truth panel, node array
N01-N06, FSM console (STEADY_LOCKED / LEAK_ACTIVE / WARN / CRITICAL).

**Mode:** SIM (node values are hardcoded literals)

## Run standalone
Open `map-libre.html` in a browser over HTTPS or localhost.

