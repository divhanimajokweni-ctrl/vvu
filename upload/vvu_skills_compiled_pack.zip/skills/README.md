# VVU Core Estate — Unified Skills Agent Pack (v1.0)

## Overview
This directory contains the complete set of declarative skill agent manifests governing the **VVU Core Estate**. Every specialization — from Bayesian sensor fusion and UltraEdge gait processing to AMD SEV-SNP TEE attestation and ISO/PAS 8800 AI safety — is codified into executable skill definitions.

## Specialized Skill Agents
1. : Bayesian fusion calibration & tier guards
2. : 15-Stage UltraEdge gait & surface classifier
3. : 6-DOF robotics & ISO 10816 vibration diagnostics
4. : 5-Layer twin composition & 8D fidelity vector
5. : Infineon ISO/PAS 8800 OOD & physical sanity checks
6. : Anatomical dimorphism & boxing weight classes
7. : Three-Estate Constitution & 3-Gate Router
8. : Single World StateVector bus & World Clock engine
9. : AMD SEV-SNP confidential computing attestation
10. : Zero-trust offline WORM chain verifier

## Compliance Data Tables
* : Folder-level entity and rule mapping tagged with  metadata.
* : Machine-readable JSON representation of the skills data table.
