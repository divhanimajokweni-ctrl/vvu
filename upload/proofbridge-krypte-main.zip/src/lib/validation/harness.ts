/**
 * ProofBridge Validation Dashboard — labelled rebuild.
 *
 * The deterministic fraud-model validation harness. Pure TypeScript +
 * node:crypto. No framework, no node_modules, no wall-clock: the same
 * {seed, n} always produces byte-identical results, including the
 * SHA-256 audit-chain root.
 *
 * Executable inventory (all implemented here, nothing mocked):
 *  - model scoring ladder: rules (fixed production rules) → B′ → flat →
 *    temporal → temporal-calibrated. B′/flat/temporal are real logistic
 *    models trained by seeded full-batch gradient descent on a
 *    deterministic parity split (even indices train, odd holdout) and
 *    evaluated on the holdout — nested feature sets, so the ladder can
 *    only grow by adding real signal.
 *  - ROC AUC (average-rank Mann–Whitney), partial AUC (0–0.1 FPR band),
 *    FNR @ 5% FPR operating point
 *  - Tier-0 controls: label-shuffle, order-shuffle, timing-noise (each
 *    RETRAINS the temporal model from scratch on the perturbed world),
 *    positive control + placebo (null) measurement
 *  - isotonic-style calibration (pool-adjacent-violators, fitted on the
 *    train split, applied to the holdout) with ECE / Brier evaluation
 *  - KS distance, Wasserstein distance, Spearman correlation,
 *    circular statistics (mean hour + mean resultant length)
 *  - P1–P4 behavioural fidelity checks (burst, velocity, graph, drift)
 *  - SHA-256 audit-chain construction: hash_i = SHA-256(prev ‖ tag ‖
 *    payload), genesis anchor "PROOFBRIDGE_GENESIS_v1", one record per
 *    transaction plus a genesis record, end-to-end re-verification
 *  - runValidation({seed, n}) — fully deterministic (mulberry32 PRNG)
 */

import { createHash } from "node:crypto";

import { canonicalJson } from "./format";
import { computeInstrumentation, gauss, generateSamples, mulberry32, seededShuffle } from "./sample";
import type {
  BehavioralMetrics,
  CalibrationMetrics,
  ChainInfo,
  ChainRecord,
  Channel,
  ControlEntry,
  DistributionMetrics,
  LadderEntry,
  ModelName,
  RunSpec,
  Sample,
  SealedRecord,
  ValidationResults,
} from "./types";

// ---------------------------------------------------------------------------
// Audit chain
// ---------------------------------------------------------------------------

export const GENESIS_TAG = "PROOFBRIDGE_GENESIS_v1";
export const GENESIS_RECORD_TAG = "pb.genesis.v1";
export const TX_TAG = "pb.tx.v1";

function sha256Hex(s: string): string {
  return createHash("sha256").update(s, "utf8").digest("hex");
}

/**
 * Seal an append-only chain: hash_i = SHA-256(prev_i ‖ tag_i ‖ payload_i)
 * where prev_1 is the genesis anchor string and prev_{i+1} = hash_i.
 */
export function sealChain(records: readonly ChainRecord[], genesisTag: string): SealedRecord[] {
  let prev = genesisTag;
  const out: SealedRecord[] = [];
  for (const r of records) {
    const hash = sha256Hex(prev + r.tag + canonicalJson(r.payload));
    out.push({ tag: r.tag, payload: r.payload, prev, hash });
    prev = hash;
  }
  return out;
}

/**
 * End-to-end re-verification: recompute every hash from the genesis anchor
 * and check both the hash and the stored prev link.
 */
export function verifyChain(sealed: readonly SealedRecord[], genesisTag: string): { valid: boolean; root: string } {
  let prev = genesisTag;
  let valid = true;
  let root = "";
  for (const r of sealed) {
    const h = sha256Hex(prev + r.tag + canonicalJson(r.payload));
    if (h !== r.hash || r.prev !== prev) valid = false;
    root = h;
    prev = r.hash;
  }
  return { valid, root };
}

// ---------------------------------------------------------------------------
// Core statistics
// ---------------------------------------------------------------------------

/** Average ranks (1-based, ties share the mean rank) of a numeric array. */
function averageRanks(xs: readonly number[]): number[] {
  const n = xs.length;
  const idx = Array.from({ length: n }, (_, k) => k).sort((a, b) => xs[a] - xs[b] || a - b);
  const ranks = new Array<number>(n);
  let i = 0;
  while (i < n) {
    let j = i;
    while (j + 1 < n && xs[idx[j + 1]] === xs[idx[i]]) j++;
    const avg = (i + j + 2) / 2;
    for (let k = i; k <= j; k++) ranks[idx[k]] = avg;
    i = j + 1;
  }
  return ranks;
}

/** ROC AUC via the average-rank Mann–Whitney statistic (ties handled). */
export function rocAuc(scores: readonly number[], labels: readonly number[]): number {
  const n = scores.length;
  let pos = 0;
  for (const y of labels) if (y === 1) pos++;
  const neg = n - pos;
  if (pos === 0 || neg === 0) return 0.5;
  const ranks = averageRanks(scores);
  let posRankSum = 0;
  for (let k = 0; k < n; k++) if (labels[k] === 1) posRankSum += ranks[k];
  return (posRankSum - (pos * (pos + 1)) / 2) / (pos * neg);
}

/**
 * Partial AUC over the low-FPR band [0, fprMax]: trapezoidal integration
 * of the empirical ROC (thresholds = unique scores, descending), clipped
 * at the band edge. Unnormalised (max possible value = fprMax).
 */
export function partialAuc(scores: readonly number[], labels: readonly number[], fprMax = 0.1): number {
  const n = scores.length;
  let pos = 0;
  for (const y of labels) if (y === 1) pos++;
  const neg = n - pos;
  if (pos === 0 || neg === 0) return 0;

  const idx = Array.from({ length: n }, (_, k) => k).sort((a, b) => scores[b] - scores[a] || a - b);

  let tp = 0;
  let fp = 0;
  let prevFpr = 0;
  let prevTpr = 0;
  let area = 0;

  let i = 0;
  let clipped = false;
  while (i < n) {
    let j = i;
    while (j + 1 < n && scores[idx[j + 1]] === scores[idx[i]]) j++;
    let gp = 0;
    let gn = 0;
    for (let k = i; k <= j; k++) {
      if (labels[idx[k]] === 1) gp++;
      else gn++;
    }
    tp += gp;
    fp += gn;
    const fpr = fp / neg;
    const tpr = tp / pos;
    if (fpr > fprMax) {
      // clip the final segment at the band edge (linear interpolation)
      if (fpr > prevFpr) {
        const t = (fprMax - prevFpr) / (fpr - prevFpr);
        const tprAt = prevTpr + t * (tpr - prevTpr);
        area += (fprMax - prevFpr) * ((prevTpr + tprAt) / 2);
      }
      clipped = true;
      break;
    }
    area += (fpr - prevFpr) * ((prevTpr + tpr) / 2);
    prevFpr = fpr;
    prevTpr = tpr;
    i = j + 1;
  }
  if (!clipped && prevFpr < fprMax) {
    // band not exhausted — TPR stays flat to the band edge
    area += (fprMax - prevFpr) * prevTpr;
  }
  return area;
}

/**
 * FNR at a fixed FPR operating point: the deepest threshold whose FPR is
 * still ≤ target (score groups are atomic — equal scores share thresholds).
 */
export function fnrAtFpr(scores: readonly number[], labels: readonly number[], fpr = 0.05): number {
  const n = scores.length;
  let pos = 0;
  for (const y of labels) if (y === 1) pos++;
  const neg = n - pos;
  if (pos === 0 || neg === 0) return 1;

  const idx = Array.from({ length: n }, (_, k) => k).sort((a, b) => scores[b] - scores[a] || a - b);

  let tp = 0;
  let fp = 0;
  let bestTpr = 0; // the (0,0) point is always admissible
  let i = 0;
  while (i < n) {
    let j = i;
    while (j + 1 < n && scores[idx[j + 1]] === scores[idx[i]]) j++;
    let gp = 0;
    let gn = 0;
    for (let k = i; k <= j; k++) {
      if (labels[idx[k]] === 1) gp++;
      else gn++;
    }
    if ((fp + gn) / neg <= fpr + 1e-12) {
      tp += gp;
      fp += gn;
      bestTpr = tp / pos;
      i = j + 1;
    } else {
      break;
    }
  }
  return 1 - bestTpr;
}

/** Expected calibration error (equal-width bins on [0, 1]). */
export function ece(scores: readonly number[], labels: readonly number[], bins = 10): number {
  const n = scores.length;
  if (n === 0) return 0;
  const cnt = new Array<number>(bins).fill(0);
  const pred = new Array<number>(bins).fill(0);
  const obs = new Array<number>(bins).fill(0);
  for (let k = 0; k < n; k++) {
    let b = Math.floor(scores[k] * bins);
    if (b < 0) b = 0;
    if (b >= bins) b = bins - 1;
    cnt[b]++;
    pred[b] += scores[k];
    obs[b] += labels[k];
  }
  let e = 0;
  for (let b = 0; b < bins; b++) {
    if (cnt[b] === 0) continue;
    e += (cnt[b] / n) * Math.abs(pred[b] / cnt[b] - obs[b] / cnt[b]);
  }
  return e;
}

/** Brier score. */
export function brier(scores: readonly number[], labels: readonly number[]): number {
  let s = 0;
  for (let k = 0; k < scores.length; k++) s += (scores[k] - labels[k]) ** 2;
  return scores.length === 0 ? 0 : s / scores.length;
}

// ---------------------------------------------------------------------------
// Isotonic calibration (pool-adjacent-violators), fitted on train, applied
// out-of-sample. Scores are bucketed onto a 1/50 grid (production score
// precision); the fitted map is piecewise-linear between block means, so
// it is monotone non-decreasing and ranking is preserved up to tie merges.
// ---------------------------------------------------------------------------

const SCORE_BUCKET = 50;

export type IsotonicModel = (x: number) => number;

export function fitIsotonic(trainScores: readonly number[], trainLabels: readonly number[]): IsotonicModel {
  const bucket = (x: number): number => Math.round(x * SCORE_BUCKET) / SCORE_BUCKET;
  const map = new Map<number, { sum: number; count: number }>();
  for (let k = 0; k < trainScores.length; k++) {
    const b = bucket(trainScores[k]);
    const e = map.get(b) ?? { sum: 0, count: 0 };
    e.sum += trainLabels[k];
    e.count++;
    map.set(b, e);
  }
  const xs = Array.from(map.keys()).sort((a, b) => a - b);

  // PAV over the aggregated buckets
  const stack: { ySum: number; count: number; width: number }[] = [];
  for (const x of xs) {
    const e = map.get(x)!;
    const blk = { ySum: e.sum, count: e.count, width: 1 };
    while (stack.length > 0 && stack[stack.length - 1].ySum / stack[stack.length - 1].count > blk.ySum / blk.count) {
      const t = stack.pop()!;
      blk.ySum += t.ySum;
      blk.count += t.count;
      blk.width += t.width;
    }
    stack.push(blk);
  }

  // flatten to (block start bucket, block mean) pairs
  const starts: number[] = [];
  const values: number[] = [];
  let si = 0;
  for (const blk of stack) {
    starts.push(xs[si]);
    values.push(blk.ySum / blk.count);
    si += blk.width;
  }

  return (x: number): number => {
    const b = bucket(x);
    if (starts.length === 1) return values[0];
    if (b <= starts[0]) return values[0];
    const last = starts.length - 1;
    if (b >= starts[last]) return values[last];
    // piecewise-linear isotonic: interpolate between adjacent block means
    let lo = 0;
    let hi = last;
    let ans = 0;
    while (lo <= hi) {
      const mid = (lo + hi) >> 1;
      if (starts[mid] <= b) {
        ans = mid;
        lo = mid + 1;
      } else {
        hi = mid - 1;
      }
    }
    const i0 = ans;
    const i1 = Math.min(last, ans + 1);
    const span = starts[i1] - starts[i0];
    if (span <= 0) return values[i0];
    const t = (b - starts[i0]) / span;
    return values[i0] + (values[i1] - values[i0]) * t;
  };
}

/** Two-sample Kolmogorov–Smirnov distance (max ECDF gap). */
export function ksStatistic(a: readonly number[], b: readonly number[]): number {
  if (a.length === 0 || b.length === 0) return 0;
  const sa = a.slice().sort((x, y) => x - y);
  const sb = b.slice().sort((x, y) => x - y);
  const vals = Array.from(new Set(sa.concat(sb))).sort((x, y) => x - y);
  let ia = 0;
  let ib = 0;
  let d = 0;
  for (const v of vals) {
    while (ia < sa.length && sa[ia] <= v) ia++;
    while (ib < sb.length && sb[ib] <= v) ib++;
    const gap = Math.abs(ia / sa.length - ib / sb.length);
    if (gap > d) d = gap;
  }
  return d;
}

/** 1-D Wasserstein distance via empirical quantiles on a fixed grid. */
export function wasserstein(a: readonly number[], b: readonly number[], grid = 512): number {
  if (a.length === 0 || b.length === 0) return 0;
  const sa = a.slice().sort((x, y) => x - y);
  const sb = b.slice().sort((x, y) => x - y);
  const q = (sorted: readonly number[], g: number): number =>
    sorted[Math.min(sorted.length - 1, Math.floor(g * sorted.length))];
  let s = 0;
  for (let g = 1; g <= grid; g++) {
    s += Math.abs(q(sa, g / grid) - q(sb, g / grid));
  }
  return s / grid;
}

/** Spearman rank correlation (average ranks, Pearson on ranks). */
export function spearman(x: readonly number[], y: readonly number[]): number {
  const n = Math.min(x.length, y.length);
  if (n < 2) return 0;
  const rx = averageRanks(x.slice(0, n));
  const ry = averageRanks(y.slice(0, n));
  return pearson(rx, ry);
}

function pearson(x: readonly number[], y: readonly number[]): number {
  const n = x.length;
  let mx = 0;
  let my = 0;
  for (let k = 0; k < n; k++) {
    mx += x[k];
    my += y[k];
  }
  mx /= n;
  my /= n;
  let sxy = 0;
  let sxx = 0;
  let syy = 0;
  for (let k = 0; k < n; k++) {
    const dx = x[k] - mx;
    const dy = y[k] - my;
    sxy += dx * dy;
    sxx += dx * dx;
    syy += dy * dy;
  }
  if (sxx === 0 || syy === 0) return 0;
  return sxy / Math.sqrt(sxx * syy);
}

/** Circular statistics over hour-of-day: mean hour + mean resultant length. */
export function circularStats(hours: readonly number[]): { meanHour: number; r: number } {
  const n = hours.length;
  if (n === 0) return { meanHour: 0, r: 0 };
  let sx = 0;
  let sy = 0;
  for (const h of hours) {
    const t = (h / 24) * 2 * Math.PI;
    sx += Math.cos(t);
    sy += Math.sin(t);
  }
  const r = Math.sqrt(sx * sx + sy * sy) / n;
  let meanHour = ((Math.atan2(sy, sx) / (2 * Math.PI)) * 24) % 24;
  if (meanHour < 0) meanHour += 24;
  return { meanHour, r };
}

// ---------------------------------------------------------------------------
// Feature engineering (label-free) and the fixed production rules
// ---------------------------------------------------------------------------

/** 1 at 03:30 (fraud night centre), 0 at 15:30. */
export function nightAffinity(hour: number): number {
  return 0.5 + 0.5 * Math.cos(((hour - 3.5) / 24) * 2 * Math.PI);
}

export function channelRisk(ch: Channel): number {
  return ch === "cardless" ? 1 : ch === "online" ? 0.55 : 0;
}

/** Short gap since the previous same-account transaction → higher risk. */
export function gapRisk(gapSec: number): number {
  return (6.5 - Math.log(1 + gapSec)) / 2;
}

/**
 * Graph concentration of a merchant: 1 − distinct-accounts / transactions.
 * Ring merchants are revisited by the same (compromised) accounts, so they
 * concentrate; ordinary merchants see mostly unique accounts.
 */
export function merchantConcentration(s: Sample): number {
  return 1 - s.merchantDegree / Math.max(1, s.merchantTxCount);
}

/** Coarse production rules: high-tail amount, deep-night window, channel. */
export function rulesScore(s: Sample): number {
  const r1 = s.amount > 200 ? 0.4 : 0;
  const r2 = s.hour >= 1.5 && s.hour < 4.5 ? 0.35 : 0;
  const r3 = s.channel === "cardless" ? 0.25 : 0;
  return r1 + r2 + r3;
}

/** Nested feature sets — each rung strictly extends the previous one. */
function bprimeFeatures(s: Sample): number[] {
  return [rulesScore(s), Math.log(s.amount), channelRisk(s.channel)];
}

function flatFeatures(s: Sample): number[] {
  return [...bprimeFeatures(s), nightAffinity(s.hour), s.ringMerchant];
}

function temporalFeatures(s: Sample): number[] {
  return [
    ...flatFeatures(s),
    s.burst,
    Math.log(1 + s.velocity),
    gapRisk(s.gapSec),
    merchantConcentration(s),
  ];
}

// ---------------------------------------------------------------------------
// Logistic training (seeded full-batch gradient descent) — deterministic
// ---------------------------------------------------------------------------

export interface LogisticFit {
  w: number[];
  b: number;
  mu: number[];
  sd: number[];
}

const GD_ITERS = 1200;
const GD_LR = 0.6;

/** Train a logistic model on (features, labels); standardises on train. */
export function trainLogistic(xs: readonly (readonly number[])[][], ys: readonly number[]): LogisticFit {
  const m = xs.length;
  const d = m > 0 ? xs[0].length : 0;
  const mu = new Array<number>(d).fill(0);
  const sd = new Array<number>(d).fill(1);
  if (m === 0 || d === 0) return { w: new Array<number>(d).fill(0), b: 0, mu, sd };

  for (let j = 0; j < d; j++) {
    let s = 0;
    for (let k = 0; k < m; k++) s += xs[k][j];
    mu[j] = s / m;
    let v = 0;
    for (let k = 0; k < m; k++) v += (xs[k][j] - mu[j]) ** 2;
    sd[j] = Math.sqrt(v / m) || 1;
  }

  const z: number[][] = xs.map((x) => x.map((v, j) => (v - mu[j]) / sd[j]));
  const w = new Array<number>(d).fill(0);
  let b = 0;

  for (let t = 0; t < GD_ITERS; t++) {
    const gw = new Array<number>(d).fill(0);
    let gb = 0;
    for (let k = 0; k < m; k++) {
      let dot = b;
      for (let j = 0; j < d; j++) dot += w[j] * z[k][j];
      const p = 1 / (1 + Math.exp(-dot));
      const e = p - ys[k];
      gb += e;
      for (let j = 0; j < d; j++) gw[j] += e * z[k][j];
    }
    b -= (GD_LR * gb) / m;
    for (let j = 0; j < d; j++) w[j] -= (GD_LR * gw[j]) / m;
  }

  return { w, b, mu, sd };
}

function sigmoid(x: number): number {
  return 1 / (1 + Math.exp(-x));
}

/** Predicted probabilities for new rows (standardised with the train fit). */
export function predictLogistic(fit: LogisticFit, xs: readonly (readonly number[])[][]): number[] {
  return xs.map((x) => {
    let dot = fit.b;
    for (let j = 0; j < fit.w.length; j++) dot += fit.w[j] * ((x[j] - fit.mu[j]) / fit.sd[j]);
    return sigmoid(dot);
  });
}

/**
 * Production score squash: the deployed system flattens the model logit
 * before emitting a score (underconfident temperature, miscalibration by
 * design); the isotonic layer recovers it. RAW_K < 1 = underconfident.
 */
const RAW_K = 0.6;

function squash(p: number): number {
  // invert the logistic, re-squash: raw = σ(RAW_K · logit(p))
  const eps = 1e-12;
  const clamped = Math.min(Math.max(p, eps), 1 - eps);
  const logit = Math.log(clamped / (1 - clamped));
  return sigmoid(RAW_K * logit);
}

// ---------------------------------------------------------------------------
// Deterministic split
// ---------------------------------------------------------------------------

/** Even stream indices train, odd indices hold out (deterministic). */
function paritySplit(n: number): { trainIdx: number[]; holdIdx: number[] } {
  const trainIdx: number[] = [];
  const holdIdx: number[] = [];
  for (let k = 0; k < n; k++) (k % 2 === 0 ? trainIdx : holdIdx).push(k);
  return { trainIdx, holdIdx };
}

// ---------------------------------------------------------------------------
// Controls (seed-derived independent PRNG streams)
// ---------------------------------------------------------------------------

const TIMING_NOISE_SIGMA = 75; // seconds of event-time jitter
const PERMUTATIONS = 7; // independent permutations per shuffle control

/**
 * Train the temporal model from scratch on the given (possibly perturbed)
 * world and return its holdout AUC.
 */
function evalTrainedModel(
  samples: readonly Sample[],
  labels: readonly number[],
  trainIdx: readonly number[],
  holdIdx: readonly number[],
): number {
  const fit = trainLogistic(
    trainIdx.map((k) => temporalFeatures(samples[k])),
    trainIdx.map((k) => labels[k]),
  );
  const scores = predictLogistic(fit, holdIdx.map((k) => temporalFeatures(samples[k])));
  return rocAuc(scores, holdIdx.map((k) => labels[k]));
}

function labelShuffleControl(
  seed: number,
  samples: readonly Sample[],
  trainIdx: readonly number[],
  holdIdx: readonly number[],
  temporalAuc: number,
): ControlEntry {
  const labels = samples.map((s) => s.label);
  let sum = 0;
  for (let p = 0; p < PERMUTATIONS; p++) {
    // one PRNG stream, drawn forward permutation by permutation
    const rng = mulberry32((seed ^ 0x1abe1) >>> 0);
    for (let q = 0; q < p; q++) seededShuffle(rng, labels);
    const shuffledLabels = seededShuffle(rng, labels);
    sum += evalTrainedModel(samples, shuffledLabels, trainIdx, holdIdx);
  }
  const auc = sum / PERMUTATIONS;
  return { control: "label-shuffle", auc, delta: temporalAuc - auc };
}

function orderShuffleControl(seed: number, samples: readonly Sample[], temporalAuc: number): ControlEntry {
  let sum = 0;
  for (let p = 0; p < PERMUTATIONS; p++) {
    // one PRNG stream, drawn forward permutation by permutation
    const rng = mulberry32((seed ^ 0x0dde5) >>> 0);
    for (let q = 0; q < p; q++) seededShuffle(rng, samples);
    sum += orderShuffleOnce(rng, samples);
  }
  const auc = sum / PERMUTATIONS;
  const delta = temporalAuc - auc;
  return { control: "order-shuffle", auc, delta };
}

function orderShuffleOnce(rng: Rng, samples: readonly Sample[]): number {
  const perm = seededShuffle(rng, samples);
  // re-lay the timeline with arrival gaps REASSIGNED at random across the
  // permuted stream: destroys same-account clustering AND each
  // transaction's own short-gap property, keeps the per-transaction
  // multiset (features, labels, amounts) — the order signal cannot
  // reconstruct itself from the shuffled arrival gaps
  const gaps = seededShuffle(rng, samples.map((s) => s.gapDraw));
  let t = 0;
  const relaid = perm.map((s, j) => {
    t += gaps[j];
    return { ...s, ts: t };
  });
  const reinstr = computeInstrumentation(relaid);
  const labels = reinstr.map((s) => s.label);
  const { trainIdx, holdIdx } = paritySplit(reinstr.length);
  return evalTrainedModel(reinstr, labels, trainIdx, holdIdx);
}

function timingNoiseControl(
  seed: number,
  samples: readonly Sample[],
  temporalAuc: number,
): ControlEntry {
  const rng = mulberry32((seed ^ 0x71e7) >>> 0);
  const jittered = samples.map((s) => ({ ...s, ts: s.ts + gauss(rng) * TIMING_NOISE_SIGMA }));
  const reinstr = computeInstrumentation(jittered);
  const labels = reinstr.map((s) => s.label);
  const { trainIdx, holdIdx } = paritySplit(reinstr.length);
  const auc = evalTrainedModel(reinstr, labels, trainIdx, holdIdx);
  return { control: "timing-noise", auc, delta: temporalAuc - auc };
}

/**
 * Positive control + placebo on one shared PRNG stream: the same
 * instrument (the AUC statistic) must register a planted signal and must
 * NOT hallucinate one on pure noise.
 */
function signalControls(seed: number, labels: readonly number[]): { auc: number; delta: number; nullDelta: number } {
  const rng = mulberry32((seed ^ 0x9051) >>> 0);
  const noise = 0.35;
  const positive = labels.map((y) => Math.min(1, Math.max(0, y + noise * gauss(rng))));
  const placebo = labels.map(() => Math.min(1, Math.max(0, 0.5 + noise * gauss(rng))));
  const auc = rocAuc(positive, labels);
  const aucNull = rocAuc(placebo, labels);
  return { auc, delta: auc - 0.5, nullDelta: aucNull - 0.5 };
}

// ---------------------------------------------------------------------------
// Behavioural fidelity (P1–P4) — label-free stream signals, full set
// ---------------------------------------------------------------------------

function behavioralChecks(samples: readonly Sample[], labels: readonly number[]): BehavioralMetrics {
  const p1 = rocAuc(samples.map((s) => s.burst), labels);
  const p2 = rocAuc(samples.map((s) => Math.log(1 + s.velocity)), labels);
  const p3 = rocAuc(samples.map(merchantConcentration), labels);

  // P4 drift: fraud-rate per timeline quintile, Spearman vs quintile index,
  // mapped to [0.5, 1] via (ρ+1)/2 (0.5 = no detectable drift). Quintiles,
  // not deciles: at n = 450 the decile rates are too noisy to rank stably.
  const n = samples.length;
  const QUINTILES = 5;
  const cnt = new Array<number>(QUINTILES).fill(0);
  const rate = new Array<number>(QUINTILES).fill(0);
  for (let k = 0; k < n; k++) {
    let d = Math.floor((k / n) * QUINTILES);
    if (d >= QUINTILES) d = QUINTILES - 1;
    cnt[d]++;
    rate[d] += labels[k];
  }
  for (let d = 0; d < QUINTILES; d++) rate[d] = cnt[d] === 0 ? 0 : rate[d] / cnt[d];
  const rho = spearman(Array.from({ length: QUINTILES }, (_, d) => d), rate);
  const p4 = (rho + 1) / 2;

  return { p1Burst: p1, p2Velocity: p2, p3Graph: p3, p4Drift: p4, composite: p1 + p2 + p3 + p4 };
}

// ---------------------------------------------------------------------------
// runValidation
// ---------------------------------------------------------------------------

/**
 * The deterministic entry point: generate the seeded world, train and
 * evaluate the ladder on the parity split, run every control, calibrate,
 * measure, and seal the audit chain. Identical {seed, n} ⇒ identical
 * ValidationResults, byte for byte.
 */
export function runValidation(spec: RunSpec): ValidationResults {
  const seed = spec.seed >>> 0;
  const n = Math.max(1, Math.floor(spec.n));
  const samples = generateSamples(seed, n);
  const labels = samples.map((s) => s.label);
  const { trainIdx, holdIdx } = paritySplit(n);

  const trainX = (features: (s: Sample) => number[]) => trainIdx.map((k) => features(samples[k]));
  const trainY = trainIdx.map((k) => labels[k]);
  const all = (features: (s: Sample) => number[]) => samples.map(features);

  // ---- ladder: rules (fixed), then trained rungs with nested features ----
  const bprimeFit = trainLogistic(trainX(bprimeFeatures), trainY);
  const flatFit = trainLogistic(trainX(flatFeatures), trainY);
  const temporalFit = trainLogistic(trainX(temporalFeatures), trainY);

  const scoresAll: Record<Exclude<ModelName, "calibrated">, number[]> = {
    rules: all(rulesScore),
    bprime: predictLogistic(bprimeFit, all(bprimeFeatures)),
    flat: predictLogistic(flatFit, all(flatFeatures)),
    temporal: predictLogistic(temporalFit, all(temporalFeatures)),
  };

  // production squash of the temporal probability → miscalibrated raw score
  const rawHold = holdIdx.map((k) => squash(scoresAll.temporal[k]));

  // Cross-fitted isotonic: the calibration map is fitted on OUT-OF-FOLD
  // train predictions (2-fold within the train split), never on in-sample
  // scores — an in-sample isotonic sees overfit sharpness and transfers
  // badly to the holdout.
  const foldA: number[] = [];
  const foldB: number[] = [];
  trainIdx.forEach((k, j) => (j % 2 === 0 ? foldA : foldB).push(k));
  const fitA = trainLogistic(
    foldA.map((k) => temporalFeatures(samples[k])),
    foldA.map((k) => labels[k]),
  );
  const fitB = trainLogistic(
    foldB.map((k) => temporalFeatures(samples[k])),
    foldB.map((k) => labels[k]),
  );
  const oofScores: number[] = [];
  const oofLabels: number[] = [];
  for (const k of foldB) oofScores.push(squash(predictLogistic(fitA, [temporalFeatures(samples[k])])[0]));
  for (const k of foldA) oofScores.push(squash(predictLogistic(fitB, [temporalFeatures(samples[k])])[0]));
  for (const k of foldB) oofLabels.push(labels[k]);
  for (const k of foldA) oofLabels.push(labels[k]);
  const iso = fitIsotonic(oofScores, oofLabels);
  const calibratedHold = rawHold.map(iso);

  const holdY = holdIdx.map((k) => labels[k]);
  const holdScores: Record<ModelName, number[]> = {
    rules: holdIdx.map((k) => scoresAll.rules[k]),
    bprime: holdIdx.map((k) => scoresAll.bprime[k]),
    flat: holdIdx.map((k) => scoresAll.flat[k]),
    temporal: holdIdx.map((k) => scoresAll.temporal[k]),
    calibrated: calibratedHold,
  };

  const ladder: LadderEntry[] = (
    ["rules", "bprime", "flat", "temporal", "calibrated"] as const
  ).map((model) => {
    const scores = holdScores[model];
    return {
      model,
      auc: rocAuc(scores, holdY),
      partialAuc: partialAuc(scores, holdY, 0.1),
      fnrAtFivePctFpr: fnrAtFpr(scores, holdY, 0.05),
    };
  });

  const temporalAuc = ladder[3].auc;

  // ---- Tier-0 controls (each perturbation retrains the temporal model) ----
  const controls: ControlEntry[] = [
    labelShuffleControl(seed, samples, trainIdx, holdIdx, temporalAuc),
    orderShuffleControl(seed, samples, temporalAuc),
    timingNoiseControl(seed, samples, temporalAuc),
  ];
  const signal = signalControls(seed, labels);
  controls.push({
    control: "positive",
    auc: signal.auc,
    delta: signal.delta,
    nullDelta: signal.nullDelta,
  });

  // ---- calibration quality on the holdout ----
  const calibration: CalibrationMetrics = {
    eceRaw: ece(rawHold, holdY),
    eceCalibrated: ece(calibratedHold, holdY),
    brierRaw: brier(rawHold, holdY),
    brierCalibrated: brier(calibratedHold, holdY),
  };

  // ---- distributional diagnostics on the holdout temporal scores ----
  const fraudScores: number[] = [];
  const legitScores: number[] = [];
  const holdPropensity: number[] = [];
  for (let j = 0; j < holdIdx.length; j++) {
    const k = holdIdx[j];
    if (labels[k] === 1) fraudScores.push(holdScores.temporal[j]);
    else legitScores.push(holdScores.temporal[j]);
    holdPropensity.push(samples[k].propensity);
  }
  const fraudHours: number[] = [];
  const legitHours: number[] = [];
  for (let k = 0; k < n; k++) {
    if (labels[k] === 1) fraudHours.push(samples[k].hour);
    else legitHours.push(samples[k].hour);
  }

  const distribution: DistributionMetrics = {
    ksDistance: ksStatistic(fraudScores, legitScores),
    wasserstein: wasserstein(fraudScores, legitScores),
    spearman: spearman(holdScores.temporal, holdPropensity),
    circularConcentrationFraud: circularStats(fraudHours).r,
    circularConcentrationClean: circularStats(legitHours).r,
  };

  const behavior = behavioralChecks(samples, labels);

  // ---- audit chain: a genesis record + one sealed receipt per transaction ----
  const r6 = (x: number): number => Math.round(x * 1e6) / 1e6;
  const records: ChainRecord[] = [];
  records.push({
    tag: GENESIS_RECORD_TAG,
    payload: {
      genesis: GENESIS_TAG,
      seed,
      n,
      split: "parity:even-train",
      models: ["rules", "bprime", "flat", "temporal", "calibrated"],
      controls: ["label-shuffle", "order-shuffle", "timing-noise", "positive"],
      rules: "amount>200 | night[1.5,4.5) | cardless",
    },
  });
  for (let k = 0; k < n; k++) {
    const s = samples[k];
    records.push({
      tag: TX_TAG,
      payload: {
        i: s.i,
        id: s.id,
        account: s.accountId,
        merchant: s.merchantId,
        ts: Math.round(s.ts * 10) / 10,
        hour: Math.round(s.hour * 1000) / 1000,
        amount: s.amount,
        channel: s.channel,
        label: s.label,
        scores: {
          rules: r6(scoresAll.rules[k]),
          bprime: r6(scoresAll.bprime[k]),
          flat: r6(scoresAll.flat[k]),
          temporal: r6(scoresAll.temporal[k]),
        },
      },
    });
  }

  const sealed = sealChain(records, GENESIS_TAG);
  const verified = verifyChain(sealed, GENESIS_TAG);
  const chain: ChainInfo = {
    genesis: GENESIS_TAG,
    count: sealed.length,
    root: verified.root,
    valid: verified.valid && sealed.length === n + 1,
  };

  const fraudCount = labels.reduce((a, b) => a + b, 0);

  return {
    seed,
    n,
    fraudCount,
    fraudRate: fraudCount / n,
    ladder,
    controls,
    calibration,
    behavior,
    distribution,
    chain,
  };
}
