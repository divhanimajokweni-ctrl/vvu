#!/usr/bin/env python3
"""
VVU ProofBridge Release Attestation Verifier
Verifies SHA256SUMS against Ed25519 signature and individual file digests.
"""

import os
import sys
import hashlib
from pathlib import Path
from cryptography.hazmat.primitives.asymmetric import ed25519

EXPECTED_PUBKEY_HEX = "46c3614833886525b11afef1a20dee6bba25246830158f6e9c5b50f1abc8adb1"

def verify_distribution(target_dir="."):
    base = Path(target_dir)
    sha_file = base / "SHA256SUMS"
    sig_file = base / "SHA256SUMS.sig"

    if not sha_file.exists() or not sig_file.exists():
        print("❌ ERROR: Missing SHA256SUMS or SHA256SUMS.sig in target directory.")
        sys.exit(1)

    sha_content = sha_file.read_bytes()

    # Parse signature hex from SHA256SUMS.sig
    sig_lines = [line.strip() for line in sig_file.read_text().splitlines() if line.strip() and not line.startswith('#')]
    sig_hex = sig_lines[0]
    sig_bytes = bytes.fromhex(sig_hex)

    # 1. Verify Ed25519 Signature over SHA256SUMS
    print("=========================================================")
    print("  VVU SUPPLY-CHAIN TRUST VERIFICATION ENGINE")
    print("=========================================================")
    print(f"▸ Release Public Key : {EXPECTED_PUBKEY_HEX}")
    
    pubkey = ed25519.Ed25519PublicKey.from_public_bytes(bytes.fromhex(EXPECTED_PUBKEY_HEX))
    try:
        pubkey.verify(sig_bytes, sha_content)
        print("✓ Ed25519 Signature Verification : SUCCESS (SHA256SUMS is untampered)")
    except Exception as e:
        print("❌ Ed25519 Signature Verification : FAILED (SHA256SUMS tampered or signature invalid!)")
        sys.exit(1)

    # 2. Verify Individual File Hashes
    print("---------------------------------------------------------")
    print("▸ Checking Individual File Hashes against Manifest:")
    all_passed = True
    for line in sha_content.decode('utf-8').splitlines():
        if not line.strip():
            continue
        expected_hash, fname = line.strip().split(maxsplit=1)
        fpath = base / fname
        if not fpath.exists():
            print(f"  ❌ MISSING : {fname}")
            all_passed = False
            continue
        actual_hash = hashlib.sha256(fpath.read_bytes()).hexdigest()
        if actual_hash == expected_hash:
            print(f"  ✓ VERIFIED : {fname} (SHA-256 match)")
        else:
            print(f"  ❌ MISMATCH : {fname}")
            print(f"      Expected: {expected_hash}")
            print(f"      Actual  : {actual_hash}")
            all_passed = False

    print("=========================================================")
    if all_passed:
        print("✅ ALL FILES VERIFIED & UNTAMPERED — SAFE FOR SANDBOX EXECUTION")
    else:
        print("❌ INTEGRITY VIOLATION DETECTED — DO NOT EXECUTE")
        sys.exit(1)

if __name__ == "__main__":
    target = sys.argv[1] if len(sys.argv) > 1 else "."
    verify_distribution(target)
