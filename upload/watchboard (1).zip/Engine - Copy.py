
import json
import hashlib
from dataclasses import dataclass, asdict
from typing import Dict, Any, List, Optional
from datetime import datetime
import sqlite3
from pathlib import Path

GENESIS_HASH = "0"*64

def canonical_json(obj: Any) -> str:
    """Deterministic JSON: sorted keys, no whitespace, consistent floats"""
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False)

def sha256_hex(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()

@dataclass
class DecisionRecord:
    id: str
    session_id: str
    model_version: str
    model_weights_hash: str
    feature_vector: Dict[str, float]
    intent_score: float
    decision: str  # HOLD / RELEASE / STEP_UP
    threshold: float
    timestamp: str
    prev_hash: str
    hash: str
    chain_index: int

class AuditEngine:
    def __init__(self, db_path: str = "results/audit.db"):
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_db()

    def _init_db(self):
        conn = sqlite3.connect(self.db_path)
        c = conn.cursor()
        c.execute("""
        CREATE TABLE IF NOT EXISTS decisions (
            id TEXT PRIMARY KEY,
            session_id TEXT,
            model_version TEXT,
            model_weights_hash TEXT,
            feature_vector TEXT,
            intent_score REAL,
            decision TEXT,
            threshold REAL,
            timestamp TEXT,
            prev_hash TEXT,
            hash TEXT,
            chain_index INTEGER
        )""")
        conn.commit()
        conn.close()

    def _get_last(self) -> Optional[Dict]:
        conn = sqlite3.connect(self.db_path)
        c = conn.cursor()
        c.execute("SELECT * FROM decisions ORDER BY chain_index DESC LIMIT 1")
        row = c.fetchone()
        conn.close()
        if not row:
            return None
        cols = [d[0] for d in c.description] if c.description else []
        # manual mapping
        return {"hash": row[10], "chain_index": row[11]}

    def compute_hash(self, record_dict: Dict) -> str:
        # Hash over everything except the hash itself, canonical
        payload = {k: v for k, v in record_dict.items() if k != "hash"}
        return sha256_hex(canonical_json(payload))

    def log_decision(self, session_id: str, model_version: str, model_weights_hash: str,
                     feature_vector: Dict[str, float], intent_score: float,
                     decision: str, threshold: float = 0.5) -> DecisionRecord:
        conn = sqlite3.connect(self.db_path)
        c = conn.cursor()
        c.execute("SELECT hash, chain_index FROM decisions ORDER BY chain_index DESC LIMIT 1")
        last = c.fetchone()
        if last:
            prev_hash, last_idx = last[0], last[1]
            chain_index = last_idx + 1
        else:
            prev_hash = GENESIS_HASH
            chain_index = 0

        timestamp = datetime.utcnow().isoformat() + "Z"
        rec_id = sha256_hex(f"{session_id}{timestamp}{chain_index}")[:16]

        # Build record dict for hashing (without hash)
        to_hash = {
            "id": rec_id,
            "session_id": session_id,
            "model_version": model_version,
            "model_weights_hash": model_weights_hash,
            "feature_vector": dict(sorted(feature_vector.items())),
            "intent_score": round(float(intent_score), 6),
            "decision": decision,
            "threshold": threshold,
            "timestamp": timestamp,
            "prev_hash": prev_hash,
            "chain_index": chain_index
        }
        h = self.compute_hash(to_hash)
        to_hash["hash"] = h

        c.execute("""INSERT INTO decisions VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
                  (rec_id, session_id, model_version, model_weights_hash,
                   canonical_json(feature_vector), intent_score, decision, threshold,
                   timestamp, prev_hash, h, chain_index))
        conn.commit()
        conn.close()

        return DecisionRecord(**to_hash)

    def verify_record(self, decision_id: str) -> Dict:
        conn = sqlite3.connect(self.db_path)
        c = conn.cursor()
        c.execute("SELECT * FROM decisions WHERE id=?", (decision_id,))
        row = c.fetchone()
        conn.close()
        if not row:
            return {"found": False}
        # reconstruct
        rec = {
            "id": row[0],
            "session_id": row[1],
            "model_version": row[2],
            "model_weights_hash": row[3],
            "feature_vector": json.loads(row[4]),
            "intent_score": row[5],
            "decision": row[6],
            "threshold": row[7],
            "timestamp": row[8],
            "prev_hash": row[9],
            "chain_index": row[11]
        }
        stored_hash = row[10]
        recomputed = self.compute_hash(rec)
        return {
            "found": True,
            "stored_hash": stored_hash,
            "recomputed_hash": recomputed,
            "match": stored_hash == recomputed,
            "record": rec
        }

    def verify_chain(self) -> Dict:
        conn = sqlite3.connect(self.db_path)
        c = conn.cursor()
        c.execute("SELECT id, prev_hash, hash, chain_index FROM decisions ORDER BY chain_index ASC")
        rows = c.fetchall()
        conn.close()
        breaks = []
        for i, (did, prev_hash, h, idx) in enumerate(rows):
            if i == 0:
                if prev_hash != GENESIS_HASH:
                    breaks.append({"index": idx, "id": did, "reason": "genesis prev_hash mismatch"})
            else:
                prev_expected = rows[i-1][2]  # previous hash
                if prev_hash != prev_expected:
                    breaks.append({"index": idx, "id": did, "reason": f"prev_hash mismatch: expected {prev_expected[:12]} got {prev_hash[:12]}"})
            # also check index monotonic
            if idx != i:
                breaks.append({"index": idx, "id": did, "reason": f"chain_index expected {i} got {idx}"})
        return {
            "valid": len(breaks)==0,
            "total": len(rows),
            "breaks": breaks,
            "root_hash": rows[-1][2] if rows else GENESIS_HASH
        }

    def replay(self, decision_id: str, scoring_fn) -> Dict:
        """scoring_fn(feature_vector, model_version) -> score"""
        conn = sqlite3.connect(self.db_path)
        c = conn.cursor()
        c.execute("SELECT feature_vector, intent_score, model_version FROM decisions WHERE id=?", (decision_id,))
        row = c.fetchone()
        conn.close()
        if not row:
            return {"found": False}
        fv = json.loads(row[0])
        stored_score = row[1]
        model_version = row[2]
        replayed = scoring_fn(fv, model_version)
        delta = abs(replayed - stored_score)
        return {
            "found": True,
            "stored_score": stored_score,
            "replayed_score": replayed,
            "delta": delta,
            "match": delta < 1e-4
        }

    def fetch_chain(self, limit: int = 100):
        conn = sqlite3.connect(self.db_path)
        c = conn.cursor()
        c.execute("SELECT id, session_id, decision, intent_score, timestamp, hash, prev_hash, chain_index, model_version FROM decisions ORDER BY chain_index DESC LIMIT ?", (limit,))
        rows = c.fetchall()
        conn.close()
        return [{"id": r[0], "session_id": r[1], "decision": r[2], "intent_score": r[3], "timestamp": r[4], "hash": r[5], "prev_hash": r[6], "chain_index": r[7], "model_version": r[8]} for r in rows]
