
def score_from_features(fv: dict, model_version: str) -> float:
    """Deterministic replay scoring: contact->ben without review = high risk"""
    # Simple linear combination matching pattern_* bits
    w = {
        "pattern_contact_then_ben": 0.3,
        "pattern_payeeadd_without_review": 0.4,
        "pattern_ben_then_payment_quick": 0.2,
        "pattern_full_coached": 0.5,
        "pattern_remote_within_24h": 0.15
    }
    s = 0.05
    for k, weight in w.items():
        s += fv.get(k, 0.0) * weight
    # clamp to 0-1
    s = max(0.0, min(0.99, s))
    # add small version offset deterministically
    import hashlib
    vh = int(hashlib.md5(model_version.encode()).hexdigest()[:2], 16) / 255.0 * 0.02
    return round(min(0.99, s + vh), 6)
