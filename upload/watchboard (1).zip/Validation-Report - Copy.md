# ProofBridge Validation Report

Seed 42

## Tier 0 – Data Integrity Gates

- Forward-walk split: PASS
- Right-censoring audit: PASS
- Cohort construction audit: PASS

## Tier 0 – Scientific Controls

- Control A (Label shuffle): AUC = 0.608 expected ~0.5 – FAIL
- Control C (Order shuffle): AUC = 0.532 expected collapse – FLAG
- Control B (Timing noise): AUC = 0.598 vs temp 0.552 – diagnostic (order not timing)
- Positive control: Δ with planted signal = 0.500 (flat 0.500→temp 1.000), without = 0.000 – PASS

## Tier 1 – Hypothesis Isolation

- Rules AUC 0.464 FNR@5%FPR 0.935
- B' AUC 0.798 FNR@5%FPR 0.361
- Flat GBM AUC 0.550 FNR@5%FPR 0.968
- Temporal GBM AUC 0.552 FNR@5%FPR 0.972
- Calibrated Temporal AUC 0.553 FNR 0.995
- FN reduction vs B' = -169.2%

### Calibration

- Raw ECE 0.056 Brier 0.077
- Calibrated ECE 0.033 Brier 0.075

## Counterfactual Removal

| Family | AUC drop | FNR inc | AUC after |
|---|---|---|---|
| device | 0.000 | 0.000 | 0.532 |
| navigation | 0.000 | 0.000 | 0.532 |
| session | 0.017 | 0.000 | 0.515 |
| communication | 0.000 | 0.000 | 0.532 |

## Red-Team Attack Results (AUC)

| Attack | Rules | B' | Flat | Temporal |
|---|---|---|---|---|
| structured | 0.599 | 0.896 | 0.345 | 0.343 |
| entropy | 0.590 | 0.898 | 0.353 | 0.352 |
| friction | 0.500 | 0.894 | 0.339 | 0.346 |
| sequence_poisoning | 0.590 | 0.895 | 0.342 | 0.347 |

## Paired Narrative Win-Rate (coached > independent)

| Model | Win Rate |
|---|---|
| rules | 0.000 |
| bprime | 0.000 |
| flat | 0.710 |
| temp | 0.700 |

## Economic Cost Sweep (review_cost=5)

model         Bprime         Temp
fn_cost                          
1         466.325037   384.333821
5         586.383602   691.800878
10        736.456808  1076.134700
25       1186.676428  2229.136164
50       1937.042460  4150.805271
100      3437.774524  7994.143485

Breakeven: Temporal outperforms B' when FN cost > 10 (FP=1, review=5).