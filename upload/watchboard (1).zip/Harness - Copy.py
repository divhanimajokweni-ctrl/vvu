
import numpy as np
import pandas as pd
from .events import generate_customer_timeline, gen_pure_coached, gen_pure_independent
from .features import build_all_features
from .baselines import RulesEngine, BPrimeProxy
from .learner import TemporalLearner
from .metrics import auc_score, fn_rate_at_fpr, compute_ece, brier
from .config import *
import warnings
warnings.filterwarnings("ignore")

def generate_dataset(rng, n_customers=N_CUSTOMERS, null_world=False, plant_signal=False):
    customers=[]
    if null_world and plant_signal:
        for i in range(n_customers):
            label = int(rng.random()<0.5)
            anchor = 100.0 + rng.uniform(0,1)
            tl = gen_pure_coached(rng, anchor) if label==1 else gen_pure_independent(rng, anchor)
            features = build_all_features(tl, anchor)
            customers.append((features,label,anchor))
    elif null_world:
        for i in range(n_customers):
            anchor=100.0+rng.uniform(0,1)
            tl = gen_pure_independent(rng, anchor)
            label = int(rng.random()<0.5)
            features = build_all_features(tl, anchor)
            customers.append((features,label,anchor))
    else:
        for i in range(n_customers):
            is_scam = rng.random() < SCAM_RATE
            long_con = is_scam and rng.random() < LONG_CON_FRACTION
            tl = generate_customer_timeline(rng, i, is_scam, long_con, OBSERVATION_DAYS*24)
            for pay in [e for e in tl if e.event_type=='payment_initiated']:
                label = 1 if is_scam else 0
                features = build_all_features(tl, pay.timestamp)
                customers.append((features,label,pay.timestamp))
    df=pd.DataFrame([f for f,_,_ in customers]); y=np.array([l for _,l,_ in customers]); times=np.array([t for _,_,t in customers])
    return df,y,times

def check_forward_walk(times, train_idx, val_idx, test_idx):
    """Computed check: train times < val times < test times"""
    train_max = np.max(times[train_idx]) if len(train_idx)>0 else -1
    val_min = np.min(times[val_idx]) if len(val_idx)>0 else float('inf')
    val_max = np.max(times[val_idx]) if len(val_idx)>0 else -1
    test_min = np.min(times[test_idx]) if len(test_idx)>0 else float('inf')
    ok = (train_max <= val_min) and (val_max <= test_min)
    return ok, f"train_max={train_max:.1f} <= val_min={val_min:.1f} and val_max={val_max:.1f} <= test_min={test_min:.1f}"

def check_right_censoring(rng, n_samples=500):
    """Computed check: long-con scam payments near end of observation should be censored"""
    # Generate customers with long_con and see if any payment anchor is within 24h of obs end
    # In our generator, scam_time is uniform(14d, obs-24h) so should be safe
    obs_end = OBSERVATION_DAYS*24
    violations=0
    for i in range(n_samples):
        tl = generate_customer_timeline(rng, i, is_scam=True, long_con=True, obs_hours=obs_end)
        pays = [e for e in tl if e.event_type=='payment_initiated']
        for pay in pays:
            if pay.timestamp > obs_end - 24:
                violations+=1
    ok = violations==0
    return ok, f"long_con payments within 24h of obs end: {violations}/{n_samples} (expected 0)"

def check_cohort_construction(y, times, expected_scam_rate=SCAM_RATE, tolerance=0.03):
    """Computed check: overall positive rate close to SCAM_RATE and time-distributed"""
    pos_rate = np.mean(y)
    ok_rate = abs(pos_rate - expected_scam_rate) < tolerance
    # check pos rate not zero and not all time clustered
    time_spread = np.std(times) > 1.0
    ok = ok_rate and time_spread and pos_rate>0 and pos_rate<0.5
    return ok, f"pos_rate={pos_rate:.3f} vs expected {expected_scam_rate:.3f} ±{tolerance}, time_std={np.std(times):.1f}"

def run_harness():
    rng=np.random.default_rng(SEED)
    print("Generating dataset...")
    X,y,times=generate_dataset(rng, N_CUSTOMERS, False, False)
    df=pd.DataFrame(X); df['time']=times; df['y']=y; df.sort_values('time',inplace=True)
    times=df['time'].values; y=df['y'].values; X=df.drop(columns=['time','y'])
    n=len(X); train_idx=np.arange(int(n*TRAIN_FRAC)); val_idx=np.arange(int(n*TRAIN_FRAC), int(n*(TRAIN_FRAC+VAL_FRAC))); test_idx=np.arange(int(n*(TRAIN_FRAC+VAL_FRAC)), n)
    X_train,y_train=X.iloc[train_idx],y[train_idx]
    X_val,y_val=X.iloc[train_idx[0]:val_idx[-1]+1] if len(val_idx)>0 else X.iloc[:0], y[train_idx[0]:val_idx[-1]+1] if len(val_idx)>0 else np.array([])
    X_train,y_train=X.iloc[train_idx],y[train_idx]
    X_val,y_val=X.iloc[val_idx],y[val_idx]
    X_test,y_test=X.iloc[test_idx],y[test_idx]
    print(f"{n} anchors pos train {np.mean(y_train):.3f} test {np.mean(y_test):.3f}")

    # Data integrity gates - COMPUTED
    fw_ok, fw_msg = check_forward_walk(times, train_idx, val_idx, test_idx)
    rc_ok, rc_msg = check_right_censoring(rng)
    cc_ok, cc_msg = check_cohort_construction(y, times)

    rules=RulesEngine(); rules_auc=auc_score(y_test,rules.score(X_test)); rules_fnr,_=fn_rate_at_fpr(y_test,rules.score(X_test),0.05)
    bprime=BPrimeProxy(); bprime.fit(X_train,y_train); bprime.calibrate(X_val,y_val)
    bprime_auc=auc_score(y_test,bprime.predict_proba_calibrated(X_test)); bprime_fnr,_=fn_rate_at_fpr(y_test,bprime.predict_proba_calibrated(X_test),0.05)

    flat=TemporalLearner(use_temporal=False,max_iter=200); flat.fit(X_train,y_train)
    flat_auc=auc_score(y_test,flat.predict_proba(X_test)); flat_fnr,_=fn_rate_at_fpr(y_test,flat.predict_proba(X_test),0.05)

    temp=TemporalLearner(use_temporal=True,max_iter=200); temp.fit(X_train,y_train)
    temp_auc=auc_score(y_test,temp.predict_proba(X_test)); temp_fnr,temp_thresh=fn_rate_at_fpr(y_test,temp.predict_proba(X_test),0.05)

    temp.calibrate_isotonic(X_val,y_val)
    temp_cal_auc=auc_score(y_test,temp.predict_proba_calibrated(X_test))
    temp_cal_fnr,_=fn_rate_at_fpr(y_test,temp.predict_proba_calibrated(X_test),0.05)
    ece_raw=compute_ece(y_test,temp.predict_proba(X_test)); ece_cal=compute_ece(y_test,temp.predict_proba_calibrated(X_test))
    brier_raw=brier(y_test,temp.predict_proba(X_test)); brier_cal=brier(y_test,temp.predict_proba_calibrated(X_test))

    # Control A - FIX 1: use seeded rng.permutation
    y_shuf=rng.permutation(y_train)
    shuf_learner=TemporalLearner(use_temporal=True,max_iter=200); shuf_learner.fit(X_train,y_shuf)
    shuf_auc=auc_score(y_test,shuf_learner.predict_proba(X_test))

    # Control C - FIX 1: use seeded rng for permutations and normal
    temp_cols=[c for c in X.columns if c.startswith('bucket_') or c.startswith('order_') or 'pattern_' in c or c in ['beneficiary_gap_bucket','contact_gap_bucket','review_after_payeeadd']]
    X_os=X.copy()
    for col in temp_cols:
        X_os[col]=rng.permutation(X_os[col].values)
    os_learner=TemporalLearner(use_temporal=True,max_iter=200); os_learner.fit(X_os.iloc[train_idx],y_train)
    order_shuf_auc=auc_score(y_test,os_learner.predict_proba(X_os.iloc[test_idx]))

    # Positive control — pure coached vs pure independent
    print("Positive control pure...")
    X_null,y_null,_=generate_dataset(rng,500,True,False)
    X_sig,y_sig,_=generate_dataset(rng,500,True,True)
    def get_delta(Xd,yd):
        split=int(0.7*len(Xd))
        f=TemporalLearner(use_temporal=False,max_iter=100); f.fit(Xd.iloc[:split],yd[:split])
        t=TemporalLearner(use_temporal=True,max_iter=100); t.fit(Xd.iloc[:split],yd[:split])
        return t.predict_proba(Xd.iloc[split:]), f.predict_proba(Xd.iloc[split:]), yd[split:]
    pt,pf,yt=get_delta(X_sig,y_sig)
    pn,pfn,ytn=get_delta(X_null,y_null)
    delta_sig=auc_score(yt,pt)-auc_score(yt,pf)
    delta_null=auc_score(ytn,pn)-auc_score(ytn,pfn)
    flat_sig=auc_score(yt,pf); temp_sig=auc_score(yt,pt)

    # timing noise - use seeded rng
    X_jit=X.copy()
    for col in temp_cols:
        X_jit[col]=X_jit[col]+rng.normal(0,0.1,size=len(X_jit))
    jit_learner=TemporalLearner(use_temporal=True,max_iter=200); jit_learner.fit(X_jit.iloc[train_idx],y_train)
    timing_noise_auc=auc_score(y_test,jit_learner.predict_proba(X_jit.iloc[test_idx]))

    results={
        'rules_auc':rules_auc,'rules_fnr':rules_fnr,'bprime_auc':bprime_auc,'bprime_fnr':bprime_fnr,
        'flat_auc':flat_auc,'flat_fnr':flat_fnr,'temp_auc':temp_auc,'temp_fnr':temp_fnr,
        'temp_cal_auc':temp_cal_auc,'temp_cal_fnr':temp_cal_fnr,'ece_raw':ece_raw,'ece_cal':ece_cal,
        'brier_raw':brier_raw,'brier_cal':brier_cal,'shuf_auc':shuf_auc,'order_shuf_auc':order_shuf_auc,
        'timing_noise_auc':timing_noise_auc,'temp_thresh':temp_thresh,'delta_null':delta_null,'delta_sig':delta_sig,
        'flat_sig':flat_sig,'temp_sig':temp_sig,
        'fw_ok':fw_ok,'fw_msg':fw_msg,'rc_ok':rc_ok,'rc_msg':rc_msg,'cc_ok':cc_ok,'cc_msg':cc_msg
    }
    return results, X_train, X_val, X_test, y_train, y_val, y_test, temp, flat, bprime
