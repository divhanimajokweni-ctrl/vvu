/**
 * @license
 * VVU EARTH TECH ⚙ - License Validator
 * Copyright (c) 2026 Venture Vision Ubuntu
 *
 * LICENSE: Apache-2.0 (Open Source) OR Commercial (Enterprise)
 * See LICENSE and COMMERCIAL_LICENSE.md for details.
 *
 * This file is part of the VVU EARTH TECH horizontal infrastructure.
 * It contains no product-specific logic (Golden Rule).
 */

import { createPublicKey, createPrivateKey, sign, verify, createHash } from 'crypto';
import type { LicensePayload, SignedLicense, LicenseTier, ConsentEntry } from './license-schema';
import { CONSENT_BYPASS_TIERS } from './license-schema';

// Re-export types so consumers of this module don't need to know the
// canonical home of each type (isolatedModules-safe).
export type { LicensePayload, SignedLicense, LicenseTier, ConsentEntry };

export interface ValidationResult {
  isValid: boolean;
  tier: LicenseTier;
  features: string[];
  organizationName: string;
  expiresAt: string;
  failureReason?: string;
  checks: {
    signatureValid: boolean;
    notExpired: boolean;
    featuresConsistent: boolean;
    hardwareMatch: boolean;
    consentLogIntact: boolean;
    reaEnabled: boolean;
  };
}

/**
 * Hash a consent entry for tamper detection.
 * Canonical form: `target|timestamp|granted` (no IP — IP is metadata, not
 * part of the integrity hash, so an IP correction doesn't invalidate consent).
 */
export function hashConsent(target: string, timestamp: string, granted: boolean): string {
  const canonical = `${target}|${timestamp}|${granted}`;
  return createHash('sha256').update(canonical).digest('hex');
}

/**
 * Check if a specific target has been consented to.
 * Returns the most recent matching entry, or null if none exists.
 */
export function checkConsent(consentLog: ConsentEntry[] | undefined, target: string): ConsentEntry | null {
  if (!consentLog || consentLog.length === 0) return null;
  // Most recent entry for this target wins (allows re-consent or re-deny).
  const matches = consentLog.filter((e) => e.target === target);
  if (matches.length === 0) return null;
  return matches[matches.length - 1]!;
}

/**
 * Validate the integrity of every consent entry in the log.
 * Returns the indices of corrupted entries (should be empty for a valid log).
 */
export function validateConsentLog(consentLog: ConsentEntry[] | undefined): number[] {
  if (!consentLog) return [];
  const corrupted: number[] = [];
  consentLog.forEach((entry, idx) => {
    const expected = hashConsent(entry.target, entry.timestamp, entry.granted);
    if (expected !== entry.signature) corrupted.push(idx);
  });
  return corrupted;
}

/**
 * Create a new consent entry. Caller must append to the payload.consentLog
 * and RE-SIGN the license (the signature covers the consentLog).
 */
export function createConsentEntry(target: string, granted: boolean, ip?: string): ConsentEntry {
  const timestamp = new Date().toISOString();
  return {
    target,
    timestamp,
    granted,
    signature: hashConsent(target, timestamp, granted),
    ...(ip ? { ip } : {}),
  };
}

/**
 * Returns true if this license tier bypasses the per-target consent prompt.
 * Founder (governance tier) and the operator's own dev license skip consent.
 */
export function isConsentBypassTier(tier: LicenseTier): boolean {
  return CONSENT_BYPASS_TIERS.includes(tier);
}

/**
 * Zero-dependency Ed25519 license validator.
 * The public key is injected via environment variable VVU_PUBLIC_KEY_PEM
 * (or passed directly for testing).
 */
export class LicenseValidator {
  private publicKey: ReturnType<typeof createPublicKey> | null = null;

  constructor(publicKeyPem?: string) {
    const pem = publicKeyPem ?? process.env.VVU_PUBLIC_KEY_PEM;
    if (pem) {
      try {
        this.publicKey = createPublicKey(pem);
      } catch {
        this.publicKey = null;
      }
    }
  }

  /**
   * Validate a signed license: verify the Ed25519 signature, check expiry,
   * verify feature consistency with the tier, and check hardware fingerprint
   * if present.
   */
  validate(license: SignedLicense): ValidationResult {
    const checks = {
      signatureValid: false,
      notExpired: false,
      featuresConsistent: false,
      hardwareMatch: true,
      consentLogIntact: true,
      reaEnabled: false,
    };

    // Signature verification
    if (!this.publicKey) {
      return this.fail(license, 'PUBLIC_KEY_NOT_CONFIGURED', checks);
    }

    const canonicalPayload = this.canonicalize(license.payload);
    const signatureBuffer = Buffer.from(license.signature, 'base64');

    try {
      checks.signatureValid = verify(
        null,
        Buffer.from(canonicalPayload, 'utf-8'),
        this.publicKey,
        signatureBuffer,
      );
    } catch {
      checks.signatureValid = false;
    }

    if (!checks.signatureValid) {
      return this.fail(license, 'INVALID_SIGNATURE', checks);
    }

    // Expiry check
    checks.notExpired = new Date() < new Date(license.payload.expiresAt);
    if (!checks.notExpired) {
      return this.fail(license, 'LICENSE_EXPIRED', checks);
    }

    // Feature consistency (features must be a subset of the tier's allowed features)
    checks.featuresConsistent = true; // Trust the issuer; deep validation is a commercial feature

    // Hardware fingerprint check (if the license is bound to hardware)
    if (license.payload.hardwareFingerprint) {
      const currentFp = process.env.VVU_HARDWARE_FINGERPRINT ?? '';
      checks.hardwareMatch = currentFp === license.payload.hardwareFingerprint;
      if (!checks.hardwareMatch) {
        return this.fail(license, 'HARDWARE_MISMATCH', checks);
      }
    }

    // Consent log integrity (tamper detection — every entry's hash must verify)
    const corrupted = validateConsentLog(license.payload.consentLog);
    checks.consentLogIntact = corrupted.length === 0;
    if (!checks.consentLogIntact) {
      return this.fail(license, 'CONSENT_LOG_TAMPERED', checks);
    }

    // REA feature flag
    checks.reaEnabled = license.payload.REA_ENABLED === true;

    return {
      isValid: true,
      tier: license.payload.tier,
      features: license.payload.features,
      organizationName: license.payload.organizationName,
      expiresAt: license.payload.expiresAt,
      checks,
    };
  }

  private canonicalize(payload: LicensePayload): string {
    const keys = Object.keys(payload).sort() as (keyof LicensePayload)[];
    const sorted: Record<string, unknown> = {};
    for (const k of keys) {
      sorted[k] = payload[k];
    }
    return JSON.stringify(sorted);
  }

  private fail(
    license: SignedLicense,
    reason: string,
    checks: ValidationResult['checks'],
  ): ValidationResult {
    return {
      isValid: false,
      tier: 'OPEN_SOURCE',
      features: [],
      organizationName: license.payload.organizationName,
      expiresAt: license.payload.expiresAt,
      failureReason: reason,
      checks,
    };
  }
}

/**
 * Sign a license payload with an Ed25519 private key (for issuing/testing).
 * In production, the private key lives in a secure vault and never touches
 * the application code.
 */
export function signLicense(payload: LicensePayload, privateKeyPem: string): SignedLicense {
  const privateKey = createPrivateKey(privateKeyPem);
  const canonical = JSON.stringify(
    Object.keys(payload).sort().reduce<Record<string, unknown>>((acc, k) => {
      acc[k] = payload[k as keyof LicensePayload];
      return acc;
    }, {}),
  );
  const signature = sign(null, Buffer.from(canonical, 'utf-8'), privateKey);
  return {
    payload,
    signature: signature.toString('base64'),
  };
}
