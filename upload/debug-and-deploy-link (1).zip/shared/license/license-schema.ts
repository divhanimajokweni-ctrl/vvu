/**
 * @license
 * VVU EARTH TECH ⚙ - License Schema
 * Copyright (c) 2026 Venture Vision Ubuntu
 *
 * LICENSE: Apache-2.0 (Open Source) OR Commercial (Enterprise)
 * See LICENSE and COMMERCIAL_LICENSE.md for details.
 *
 * This file is part of the VVU EARTH TECH horizontal infrastructure.
 * It contains no product-specific logic (Golden Rule).
 */

export type LicenseTier = 'OPEN_SOURCE' | 'PRO' | 'ENTERPRISE' | 'GOVERNANCE';

/**
 * A single consent decision — appended to the license's consentLog.
 * Every entry is independently hash-chained so tampering is detectable.
 */
export interface ConsentEntry {
  /** The scan target — a file path, URL, or binary identifier. */
  target: string;
  /** ISO 8601 timestamp of the consent decision. */
  timestamp: string;
  /** true = consent granted, false = explicitly denied. */
  granted: boolean;
  /** SHA-256 hash of `target|timestamp|granted` — tamper detection. */
  signature: string;
  /** Optional: client IP at time of consent (audit trail). */
  ip?: string;
}

export interface LicensePayload {
  licenseId: string;
  tier: LicenseTier;
  organizationId: string;
  organizationName: string;
  issuedAt: string;
  expiresAt: string;
  features: string[];
  hardwareFingerprint?: string;
  maxNodes: number;
  region: string;
  /**
   * Feature flag for the REA (Reverse-Engineering Agent) observe-only plugin.
   * When false, all REA invocations are rejected with a 403 + audit log entry.
   * Founder-tier licenses default to true; B2B pilots default to false until
   * explicitly enabled by the founder.
   */
  REA_ENABLED?: boolean;
  /**
   * Append-only consent log for REA scans. Each entry is hash-chained so
   * tampering is detectable by validateConsentLog(). Founder-tier licenses
   * bypass consent prompts; B2B pilots require explicit per-target consent.
   */
  consentLog?: ConsentEntry[];
}

export interface SignedLicense {
  payload: LicensePayload;
  signature: string;
}

export const TIER_FEATURES: Record<LicenseTier, string[]> = {
  OPEN_SOURCE: ['AIR_KERNEL', 'EPISTEMIC_RUNTIME', 'HBK_ADAPTER_BASIC', 'SAFE_KRYPTE_BASIC'],
  PRO: ['AIR_KERNEL', 'EPISTEMIC_RUNTIME', 'HBK_ADAPTER_BASIC', 'SAFE_KRYPTE_BASIC', 'SAFE_LINER_BASIC', 'MULTI_NODE_BASIC'],
  ENTERPRISE: [
    'AIR_KERNEL', 'EPISTEMIC_RUNTIME', 'HBK_ADAPTER_BASIC', 'SAFE_KRYPTE_BASIC',
    'SAFE_LINER_BASIC', 'MULTI_NODE_BASIC', 'TEE_ATTESTATION', 'ZK_PROVER_GPU',
    'COMPLIANCE_AUTOMATION', 'ENTERPRISE_SSO',
  ],
  GOVERNANCE: [
    'AIR_KERNEL', 'EPISTEMIC_RUNTIME', 'HBK_ADAPTER_BASIC', 'SAFE_KRYPTE_BASIC',
    'SAFE_LINER_BASIC', 'MULTI_NODE_BASIC', 'TEE_ATTESTATION', 'ZK_PROVER_GPU',
    'COMPLIANCE_AUTOMATION', 'ENTERPRISE_SSO', 'TOKENIZATION', 'FULL_AUTONOMY',
    'GOVERNANCE_ENGINE', 'REVENUE_SHARE',
  ],
};

export const TIER_PRICING: Record<LicenseTier, { monthly: number; currency: string; label: string }> = {
  OPEN_SOURCE: { monthly: 0, currency: 'ZAR', label: 'Free / Apache 2.0' },
  PRO: { monthly: 5000, currency: 'ZAR', label: 'R5,000/mo' },
  ENTERPRISE: { monthly: 25000, currency: 'ZAR', label: 'R25,000/mo' },
  GOVERNANCE: { monthly: 100000, currency: 'ZAR', label: 'R100k+/mo' },
};

export const ALL_FEATURES = Array.from(
  new Set(Object.values(TIER_FEATURES).flat()),
).sort();

/**
 * Tiers that bypass the REA consent prompt (founder + governance).
 * Founder = the operator running the dashboard for development.
 * Governance = the highest commercial tier, where the customer IS the auditor.
 */
export const CONSENT_BYPASS_TIERS: LicenseTier[] = ['GOVERNANCE'];
