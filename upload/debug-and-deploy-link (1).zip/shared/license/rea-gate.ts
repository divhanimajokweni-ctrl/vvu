/**
 * @license
 * VVU EARTH TECH ⚙ - REA Consent Gate
 * Copyright (c) 2026 Venture Vision Ubuntu
 *
 * LICENSE: Apache-2.0 (Open Source) OR Commercial (Enterprise)
 *
 * The REA (Reverse-Engineering Agent) plugin is observe-only — it never
 * writes into product runtime (I5 separation invariant). But before any
 * scan is allowed to run, this gate enforces:
 *   1. REA_ENABLED feature flag is true on the license.
 *   2. The consent log is intact (no tampering).
 *   3. Either the tier bypasses consent (GOVERNANCE), or the target has
 *      an explicit granted consent entry.
 *
 * The gate is pure — no side effects. The caller is responsible for
 * appending the audit-log entry on block, and for re-signing the license
 * after consent is recorded.
 */

import type { SignedLicense, LicenseTier } from './license-schema';
import {
  validateConsentLog,
  checkConsent,
  isConsentBypassTier,
  createConsentEntry,
  type ConsentEntry,
} from './validator';

export type GateResult =
  | { allowed: true; autoConsented: boolean; reason: 'founder-bypass' | 'consent-on-file' }
  | {
      allowed: false;
      reason: 'rea-disabled' | 'no-consent' | 'consent-denied' | 'consent-log-tampered';
      corruptedIndices?: number[];
    };

/**
 * Master gate for REA invocations. Call before every scan.
 *
 * @param signedLicense The licensee's signed license (verified upstream).
 * @param target        The scan target — file path, URL, or binary identifier.
 * @returns GateResult — either allowed with reason, or blocked with reason.
 */
export function gateREA(signedLicense: SignedLicense, target: string): GateResult {
  const { payload } = signedLicense;

  // 1. Feature flag — if REA is disabled, hard block.
  if (!payload.REA_ENABLED) {
    return { allowed: false, reason: 'rea-disabled' };
  }

  // 2. Consent log integrity — if any entry's hash doesn't verify, block.
  const corrupted = validateConsentLog(payload.consentLog);
  if (corrupted.length > 0) {
    return { allowed: false, reason: 'consent-log-tampered', corruptedIndices: corrupted };
  }

  // 3. Tier bypass — GOVERNANCE tier skips the per-target prompt.
  if (isConsentBypassTier(payload.tier)) {
    return { allowed: true, autoConsented: true, reason: 'founder-bypass' };
  }

  // 4. Per-target consent check.
  const existing = checkConsent(payload.consentLog, target);
  if (existing === null) {
    return { allowed: false, reason: 'no-consent' };
  }
  if (!existing.granted) {
    return { allowed: false, reason: 'consent-denied' };
  }

  return { allowed: true, autoConsented: false, reason: 'consent-on-file' };
}

/**
 * Append a consent decision to the payload and return a NEW payload.
 * The caller MUST re-sign the license with signLicense() afterwards —
 * the signature covers consentLog, so an unsigned append is invalid.
 */
export function recordConsent(
  payload: SignedLicense['payload'],
  target: string,
  granted: boolean,
  ip?: string,
): { payload: SignedLicense['payload']; entry: ConsentEntry } {
  const entry = createConsentEntry(target, granted, ip);
  return {
    payload: {
      ...payload,
      consentLog: [...(payload.consentLog ?? []), entry],
    },
    entry,
  };
}

/**
 * Convenience: returns true if the license tier would bypass consent
 * for ANY target (used to decide whether to show the consent prompt UI).
 */
export function wouldBypassConsent(tier: LicenseTier): boolean {
  return isConsentBypassTier(tier);
}
