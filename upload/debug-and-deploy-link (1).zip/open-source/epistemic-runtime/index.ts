/**
 * @license
 * VVU EARTH TECH ⚙ - Epistemic Runtime
 * Copyright (c) 2026 Venture Vision Ubuntu
 *
 * LICENSE: Apache-2.0 (Open Source) OR Commercial (Enterprise)
 * See LICENSE and COMMERCIAL_LICENSE.md for details.
 *
 * This file is part of the VVU EARTH TECH horizontal infrastructure.
 * It contains no product-specific logic (Golden Rule).
 */

// Epistemic Runtime — Fact, Proof, Policy, Projection (horizontal infrastructure)
export const EPISTEMIC_RUNTIME_VERSION = "1.0.0";

export { validateEpd } from "../../../src/lib/epd";
export type { ValidationResult, PolicyNode, InvariantNode } from "../../../src/lib/epd/ast";
