/**
 * @license
 * VVU EARTH TECH ⚙ - Safe-Krypte Basic
 * Copyright (c) 2026 Venture Vision Ubuntu
 *
 * LICENSE: Apache-2.0 (Open Source) OR Commercial (Enterprise)
 */

// Safe-Krypte Basic — ED25519 primitives (horizontal infrastructure)
export const SAFE_KRYPTE_VERSION = "1.0.0";

export { LicenseValidator, signLicense } from "../../shared/license/validator";
export { TIER_FEATURES, ALL_FEATURES } from "../../shared/license/license-schema";
export type { LicensePayload, SignedLicense, LicenseTier } from "../../shared/license/license-schema";
