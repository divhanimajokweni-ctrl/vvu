/**
 * @license
 * VVU EARTH TECH ⚙ - Safe-Liner Basic
 * Copyright (c) 2026 Venture Vision Ubuntu
 *
 * LICENSE: Apache-2.0 (Open Source) OR Commercial (Enterprise)
 */

// Safe-Liner Basic — DPI proxy (horizontal infrastructure)
export const SAFE_LINER_VERSION = "1.0.0";

export interface DPIPacket {
  id: string;
  protocol: string;
  size: number;
  inspected: boolean;
}

export function inspectPacket(packet: DPIPacket): DPIPacket {
  return { ...packet, inspected: true };
}
