# VVU · Venture Vision Ubuntu

**100% Founder-Owned** · CIPC 2026/259053/07 · Gqeberha, South Africa

A unified control plane for trusted-decision infrastructure: evidence chains, verification, governance, and field operations — built for the people who use it, not the developers who build it.

## Quick Start

```bash
bun install
bun run dev          # http://localhost:3000
```

## Architecture

- **Framework:** Next.js 16.1.3 (Turbopack), hash-based routing
- **Dashboard:** 30+ workspace surfaces via `#/` hash routes (Ctrl+1 through Ctrl+0)
- **VVU Studio:** `src/components/vvu-studio/` — 33 components, 18 views
- **Skylantern Map:** `#/skylantern` — fullscreen maplibre-gl 3D map
- **Surfaces:** `public/surfaces/` — 17 standalone HTML environments
- **Mini-services:** vault-bridge, vvu-field-onboard, safegrid, telemetry, mesh-demo, wildfire-mesh
- **Guardian:** `.zscripts/guardian.py` — daemon heartbeat

## Surfaces

| Surface | URL |
|---------|-----|
| Unified Command Center | `/surfaces/unified-command-center.html` |
| Canonical Command Center | `/surfaces/canonical-command-center.html` |
| Command Center | `/surfaces/command-center.html` |
| ProofBridge | `/surfaces/proofbridge.html` |
| SEARM1 Pipeline | `/surfaces/searm1-pipeline.html` |
| Epistemic Runtime | `/surfaces/epistemic-runtime.html` |
| Field OS Pin | `/surfaces/field-os-pin.html` |
| Field OS Spreadsheet | `/surfaces/spreadsheet.html` |
| Media Reader | `/surfaces/media-reader.html` |
| Plugin Creator Studio | `/surfaces/plugin-creator-studio.html` |
| Study Framework | `/surfaces/study-framework.html` |
| Keyboard Map | `/surfaces/keyboard-map.html` |
| Four-Layer Stack | `/surfaces/four-layer-stack.html` |
| Ubuntu Pools | `/surfaces/ubuntu-pools.html` |
| Water Infrastructure | `/surfaces/water-infrastructure.html` |
| Domains & Key Rule | `/surfaces/domains-key-rule.html` |
| Runtime Overview | `/surfaces/runtime-overview.html` |

## Keyboard Shortcuts

| Key | Route | Surface |
|-----|-------|---------|
| Ctrl+1 | `#/ive` | Spatial Intelligence |
| Ctrl+2 | `#/evidence` | Bridge (evidence chain) |
| Ctrl+3 | `#/terminal` | Terminal |
| Ctrl+4 | `#/mission` | Analytics (mission control) |
| Ctrl+5 | `#/twin` | Municipal Twin |
| Ctrl+6 | `#/watchdog` | Watchdog (rail health) |
| Ctrl+7 | `#/receipts` | Receipts |
| Ctrl+8 | `#/pools` | Ubuntu Pools |
| Ctrl+9 | `#/bridges` | Field (device pairing) |
| Ctrl+0 | `#/settings` | Settings |
| Ctrl+K | — | Command Palette |

## Deployment

- **Vercel:** `vercel.json` forces Next.js framework, `bun run build`
- **Push to main:** auto-deploys
- **Build:** `bun run build` → `.next`

## CI Gates

1. Lint (eslint) — 0 errors required
2. Golden Rule AST check
3. Dashboard panel validator
4. Enforce boundaries (4 checks)
5. TypeScript type-check (tsc --noEmit)
6. CF-INT interoperability conformance (42/42)

## Guardian Setup

```bash
python3 .zscripts/daemonize.py -- python3 .zscripts/guardian.py
```

## License

Apache 2.0 (open-source core) + Commercial (enterprise modules). See `LICENSE` and `COMMERCIAL_LICENSE.md`.
