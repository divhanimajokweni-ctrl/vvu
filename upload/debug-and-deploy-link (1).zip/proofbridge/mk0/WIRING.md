# Mk 0 Pocket Node — Build & Wiring Guide

**STATUS: DESIGN — DEVICE NOT BUILT.** This guide describes hardware that
does not exist yet. Nothing below has been assembled, powered, or
physically verified, and there are no photos (none may be fabricated).
The firmware (`mk0.py`) is written and its chain format is proven
byte-compatible with the main stack **in software** (see
`CROSS-VERIFY-RESULT.txt`); everything in this file is the plan for the
physical build that would prove it on hardware.

Target budget: ~R490 (South African Rand, prices as quoted in the
ProofBridge work order; check current supplier pricing before ordering).

---

## 1. Parts list

| # | Part | Qty | Est. price | Supplier (South Africa) |
|---|------|-----|-----------|--------------------------|
| 1 | Raspberry Pi Zero 2 W (single-board computer, 2.4 GHz WiFi, micro-USB power) | 1 | ~R300 | Micro Robotics |
| 2 | microSD card 16 GB, A1-class (the chain lives here — chain.jsonl + OS) | 1 | ~R90 | Micro Robotics / Takealot |
| 3 | PSU 5 V 2.5 A, micro-USB | 1 | ~R80 | Micro Robotics / Takealot |
| 4 | 5 mm LED, green | 1 | ~R5 | Micro Robotics |
| 5 | 5 mm LED, amber | 1 | ~R5 | Micro Robotics |
| 6 | 5 mm LED, red | 1 | ~R5 | Micro Robotics |
| 7 | Resistor 330 Ω ¼ W (one per LED) | 3 | ~R5 | Micro Robotics |
| 8 | Tactile push button (momentary, 2 legs used) | 1 | ~R1 | Micro Robotics |

Total at list prices: **≈ R491 (~R490 as budgeted)**. Optional but useful:
header pins soldered to the Pi Zero 2 W (or a pre-soldered board), jumper
wires (female–female), a small breadboard — these make assembly far easier
but are not required if you solder directly.

## 2. Wiring

LED circuit per channel (GPIO → LED anode → LED cathode → 330 Ω → GND).
The resistor can sit on either side of the LED; it limits current to
≈ (3.3 V − Vf) / 330 Ω ≈ 4 mA per LED, well within the Pi's limits.

| Component | GPIO | Physical pin (40-pin header) | Connection |
|-----------|------|------------------------------|------------|
| Green LED | GPIO 22 | pin 15 | pin 15 → LED anode; LED cathode → 330 Ω → any GND pin |
| Amber LED | GPIO 23 | pin 16 | pin 16 → LED anode; LED cathode → 330 Ω → any GND pin |
| Red LED   | GPIO 24 | pin 18 | pin 18 → LED anode; LED cathode → 330 Ω → any GND pin |
| Tactile switch | GPIO 17 | pin 11 | pin 11 → switch → GND (e.g. pin 9). No external resistor: gpiozero's `Button(17)` enables the internal pull-up; pressed = pin pulled LOW |
| Power | micro-USB port | — | 5 V 2.5 A PSU (do **not** feed 5 V through the GPIO header) |

GND pins available: 6, 9, 14, 20, 25, 30, 34, 39. Double-check the header
orientation (pin 1 is nearest the SD card slot, odd pins on that column).

**Wiring sanity check before power-on:** with everything unpowered, meter
each GPIO pin to GND — there must be no short. LEDs: longer leg (anode) to
the GPIO side.

## 3. LED behaviour (what the firmware does)

| Situation | Green (GPIO 22) | Amber (GPIO 23) | Red (GPIO 24) |
|-----------|-----------------|-----------------|---------------|
| Boot: chain on SD verifies | on (steady) | off | off |
| First boot: chain file created (genesis record) | brief flash, then on | on during write | off |
| Button pressed: processing | off | on | off |
| Event appended, whole chain re-verified OK | flashes ~3×, then steady on | off | off |
| Chain verify FAILS (tamper / torn write) | off | off | **solid on** — appends refused |
| `cryptography` missing at boot (unsigned mode) | normal chain behaviour; warning on console | — | — |

## 4. Flashing the SD card (on your workstation)

1. Install **Raspberry Pi Imager** (raspberrypi.com/software).
2. Choose device: **Raspberry Pi Zero 2 W**.
3. OS: **Raspberry Pi OS Lite (64-bit)** — headless; no desktop needed.
4. SD card: the 16 GB A1 card.
5. In the Imager's gear/next-screen settings:
   - hostname: `mk0`
   - enable **SSH** (password or public key — record it)
   - set username (e.g. `pi`) and password
   - configure **WiFi**: your SSID + password + country (`ZA`)
   - locale: en-ZA (timezone Africa/Johannesburg)
6. Write. Then put the card in the Pi Zero 2 W and power it via the
   micro-USB PSU. First boot takes a couple of minutes (filesystem
   expansion + WiFi join).

## 5. First-boot setup (over SSH)

```sh
# from this folder on your workstation:
ssh pi@mk0.local         # or the Pi's IP from your router

# on the Pi:
sudo mkdir -p /home/pi/mk0
exit

# copy the firmware up:
scp mk0.py pi@mk0.local:/home/pi/mk0/mk0.py

# back on the Pi — dependencies:
#   gpiozero SHIPS with Raspberry Pi OS (nothing to install).
#   cryptography: EITHER the apt package (cleanest on Bookworm) ...
sudo apt update && sudo apt install -y python3-cryptography
#   ... OR, if you must use pip (Bookworm is PEP 668 externally managed):
#   pip3 install --break-system-packages cryptography
```

### systemd unit — `/etc/systemd/system/mk0.service`

```ini
[Unit]
Description=ProofBridge Mk 0 Pocket Node
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart=/usr/bin/python3 /home/pi/mk0/mk0.py
WorkingDirectory=/home/pi/mk0
User=pi
Restart=on-failure
RestartSec=5

[Install]
WantedBy=multi-user.target
```

```sh
sudo systemctl daemon-reload
sudo systemctl enable --now mk0.service
systemctl status mk0        # should be active (running); LEDs: green on
journalctl -u mk0 -f        # follow the device log (real logs, real dates)
```

### Status page

Browse to **`http://<pi-ip>:8080/`** (or `http://mk0.local:8080/`). It is a
deliberately plain `<pre>` page showing: device id, chain file, record
count, chain validity, the **current root hash recomputed live from the
file on every request** (never cached), and the node's Ed25519 public key.

### Try it

Press the button: amber lights while the event is sealed, signed, appended
(fsync) and the whole chain re-verified; green flashes then stays on.
Press it a few times and watch the record count and root change on the
status page.

## 6. SD-removal persistence test (the point of a Pocket Node)

1. With the node running, press the button once; note the **record count**
   and **root hash** shown on `http://<pi-ip>:8080/`.
2. `sudo poweroff` (clean shutdown).
3. Remove the microSD card. The chain file (`/home/pi/mk0/chain.jsonl`)
   and the node's Ed25519 key (`/home/pi/mk0/ed25519.key`, mode 0600)
   travel with the card — that is the whole design.
4. Optional, and a strong proof: put the card in a USB reader on your
   workstation, copy `chain.jsonl` off it, and verify the copy on any
   machine with Python 3.12:
   `python3 mk0.py --verify-only /path/to/chain.jsonl`
   → must print `MAIN→MK0: VALID root=<the same root>`.
   (Bun/node available? `bun run cross-verify.ts <lib-root> <chain.jsonl>`
   does the same check with the main stack's own verifier.)
5. Reinsert the card in the Pi, power on, check the status page: same
   record count, same root, VALID. The node's identity (same pubkey in the
   genesis record) persisted because the key file came back with the card.

## 7. Power notes

- Use a real 5 V / 2.5 A micro-USB PSU, not a laptop USB port: the Zero 2 W
  plus WiFi spikes can brown out on 500 mA, and brownouts during an SD
  write can corrupt the card.
- `mk0.py` fsyncs after every record append, so a hard power cut can only
  lose the record being written — never an already-acknowledged one (the
  green flash comes after fsync + full re-verify).
- Known failure mode, handled honestly: a power cut in the middle of a
  write can leave a torn final line, which reads as a broken chain at next
  boot (red LED). Recovery is manual by design (auto-truncating could hide
  real tampering): inspect the tail of `chain.jsonl`, delete the incomplete
  line if that is clearly what it is, re-run
  `python3 mk0.py --verify-only /home/pi/mk0/chain.jsonl`, then restart the
  service.
- Clean shutdown before unplugging: `sudo poweroff`.

## 8. What this build, if executed, would physically demonstrate

- The ~R490 node captures button events, seals them into the
  main-stack-compatible hash chain, Ed25519-signs them, and appends them
  to the SD card (green = valid, red = tamper).
- The chain survives power loss and SD card moves, and verifies against
  the main stack's TypeScript verifier (the software half of that is
  already proven in `CROSS-VERIFY-RESULT.txt`; the hardware half is what
  this build adds).

Until the parts are bought and assembled, all of the above remains a
**design** — DEVICE NOT BUILT, NO PHYSICAL VERIFICATION PERFORMED.
