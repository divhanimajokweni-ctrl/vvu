# ProofBridge Mk 0 — Pocket Node

A ~R490 Raspberry Pi Zero 2 W node that captures button events, seals them
into a hash chain byte-compatible with the main ProofBridge stack
(SHA-256 links + canonical JSON, genesis anchor `PROOFBRIDGE_GENESIS_v1`),
Ed25519-signs each record, appends to a chain file on the microSD card, and
serves a minimal HTTP status page over WiFi. The point: a cheap physical
device whose evidence chain the main stack can verify directly — and whose
chain file survives power loss and SD card moves.

## STATUS

```
FIRMWARE WRITTEN        — mk0.py (single file, 3 modes; see below)
CHAIN COMPATIBILITY     — PROVEN IN SOFTWARE (see CROSS-VERIFY-RESULT.txt,
                          both directions, real dated runs: 2026-09-14)
DEVICE                  — NOT BUILT. No parts purchased, no hardware
                          assembled, no physical verification performed.
PHOTO                   — NO PHOTO EXISTS (none may be fabricated).
DEVICE LOGS             — NO DEVICE LOGS EXIST (none may be fabricated).
```

Everything in this folder is design + firmware + software proof. The only
executed outputs are the simulated cross-verification runs, captured
verbatim (and clearly labelled SIMULATED — fake timestamps built from the
sequence number) in `CROSS-VERIFY-RESULT.txt`.

## Files in this folder

| File | What it is |
|------|-----------|
| `mk0.py` | The firmware (single Python file). `--simulate N` (deterministic, no GPIO, any machine), `--verify-only PATH` (verify a chain with the Python port — works on chains from either stack), no args = device mode (gpiozero LEDs/Button + HTTP status page; needs the physical Pi). Honesty label in the header. |
| `cross-verify.ts` | bun script that imports the main stack's **own** `sealChain`/`verifyChain`/`canonicalJson` and proves both compatibility directions, plus verifies mk0.py's Ed25519 signatures with node:crypto. Usage: `bun run proofbridge/mk0/cross-verify.ts <lib-root> [chain.jsonl] [out]` (default lib root: `/home/z/my-project/.publish/proofbridge-krypte`). |
| `CROSS-VERIFY-RESULT.txt` | The real, dated, verbatim outputs of the cross-verification runs + verdicts + the canonicalJson discrepancy found & fixed. |
| `chain.jsonl` | The 5-event deterministic chain produced by `python3 mk0.py --simulate 5` (6 records incl. genesis; fully reproducible: same command → same bytes). SIMULATED data — self-labelled via `"mode":"simulate"` in the genesis record. |
| `ts-chain.jsonl` | The 3-record chain sealed by the main stack's TypeScript `sealChain` during the MAIN→MK0 half of the proof (also the tamper-test fixture base). |
| `WIRING.md` | The complete build guide: parts, GPIO wiring, flashing, systemd unit, LED behaviour, persistence test, power notes. STATUS: DESIGN — DEVICE NOT BUILT. |
| `README.md` | This file. |

## Parts list (~R490, South Africa)

Raspberry Pi Zero 2 W (~R300, Micro Robotics) · 16 GB microSD A1 (~R90,
Micro Robotics / Takealot) · micro-USB 5 V 2.5 A PSU (~R80) · 3× 5 mm LEDs
green/amber/red (~R15) · 3× 330 Ω resistors (~R5) · tactile switch (~R1).
Full table + wiring: `WIRING.md`.

## Compatibility proof — summary

The chain rule on both sides: `hash_i = sha256(prev_i + tag_i +
canonicalJson(payload_i))` with `prev_1 = "PROOFBRIDGE_GENESIS_v1"` and
`prev_{i+1} = hash_i`; canonical JSON = sorted keys, no whitespace, JS
number formatting. `mk0.py` ports `format.ts`/`harness.ts` rule-for-rule
(each rule cites its TS line), and `cross-verify.ts` exercises the main
stack's real functions:

1. **MK0→MAIN**: `python3 mk0.py --simulate 5` → root
   `576516a3165f451d14f8d35e966f19637e44a9d5e92805b8f09d4adf21a6777c`;
   the main stack's `verifyChain` says **VALID, same root** (with and
   without mk0's extra `sig`/`pub` fields — the TS verifier is structural,
   so the extra fields ride along harmlessly). Bonus: the 6 Python
   Ed25519 signatures verify with node:crypto.
2. **MAIN→MK0**: the main stack's `sealChain` seals a 3-record stress
   chain (floats, the `toFixed(10)` tie value `2**-11`, unicode,
   nested objects, mixed-case keys) → root
   `7672de9259ef8ef5b3ccf2657e740bd9ea38e0b72ab93f4c9179885b3f4acb3f`;
   `python3 mk0.py --verify-only ts-chain.jsonl` says **VALID, same root**.

One real discrepancy was found and fixed (this is why the cross-test
exists): JS `toFixed(10)` rounds exact ties **away from zero**
(`2**-11 = 0.00048828125 → "0.0004882813"`), while Python's
`format(x, ".10f")` rounds half-even (`→ "0.0004882812"`) — one byte that
would break every subsequent hash. `mk0.py` encodes floats via
`Decimal(exact double).quantize(1e-10, ROUND_HALF_UP)`. Keys are sorted by
UTF-16 code-unit order (not Python code-point order) to match JS
`Array#sort`. Full detail + verbatim runs: `CROSS-VERIFY-RESULT.txt`.

Re-run the proof yourself:

```sh
cd proofbridge/mk0
python3 mk0.py --simulate 5
bun run cross-verify.ts /path/to/lib-root   # folder containing src/lib/validation/
python3 mk0.py --verify-only ts-chain.jsonl
```

Ed25519 dependency status: satisfied in this environment — Python
`cryptography` 44.0.3 (import guarded; simulate mode uses the deterministic
seed `sha256(b"mk0-simulate-seed-v1")`, device mode creates/loads
`/home/pi/mk0/ed25519.key`, 0600, persistent across boots). If `cryptography`
is ever unavailable, records are written unsigned with a loud report —
never a faked signature.

## §8 — First successful physical record

**NOT YET — device not built as of 2026-09-14.**

No button has ever been pressed on a Mk 0 node; there is no photo of the
device and no status-page screenshot from real hardware. (This README is
the Mk 0 §8 the work order references. The original design document it
mentions does not exist in this workspace — noted for the record, so
nobody hunts for a file that was never here.) When the node is built and
its first physical record is captured, this section flips to past tense
with the real date, the real record's hash, a real photo and a real
status-page screenshot.

## Pending external actions (nothing below has happened yet)

1. **Buy the parts** (~R490: Micro Robotics / Takealot, South Africa).
2. **Assemble** per `WIRING.md` (LEDs on GPIO 22/23/24, button on GPIO 17).
3. **Flash** the SD card (Raspberry Pi Imager, Pi OS Lite 64-bit, SSH+WiFi).
4. **Deploy & run** `mk0.py` under the `mk0.service` systemd unit.
5. **Capture the evidence**: photo of the assembled node + status-page
   screenshot showing a real button-press record (real timestamp), and the
   SD-removal persistence test result.
6. **Flip §8 above to past tense** with the real date and record hash.

## Licence / provenance

Part of the ProofBridge work order deliverables. The main-stack
validation library this firmware is cross-verified against lives at
`src/lib/validation/` (harness.ts / format.ts / types.ts) — the reference
implementation for the chain format; `mk0.py` cites it rule-by-rule.
