#!/usr/bin/env bun
/**
 * ProofBridge Mk 0 ⇄ main-stack chain CROSS-VERIFICATION (bun script).
 *
 * STATUS: SOFTWARE-ONLY PROOF — NO DEVICE INVOLVED. The physical Mk 0 node
 * does not exist and is not built; this script proves BYTE-COMPATIBILITY of
 * the chain format between mk0.py (Python) and the main stack's TypeScript
 * validation library, in BOTH directions:
 *
 *   (a) MK0→MAIN — the chain written by `python3 mk0.py --simulate N` is
 *       read here, each line mapped to {tag, payload, prev, hash} (+ sig/pub
 *       left in place on a second pass), and verified with the MAIN STACK's
 *       own verifyChain. Must return valid:true with the same root mk0.py
 *       printed.
 *   (b) MAIN→MK0 — a 3-record chain is sealed here with the MAIN STACK's
 *       own sealChain over payloads chosen to stress canonicalJson (floats,
 *       the toFixed(10) tie case, negative floats, ints, unicode strings,
 *       nested objects, mixed-case keys), written to ts-chain.jsonl, and the
 *       root printed. `python3 mk0.py --verify-only ts-chain.jsonl` must then
 *       print the SAME root.
 *
 * Bonus: (c) the Ed25519 signatures mk0.py wrote are verified HERE with
 * node:crypto — the main-stack runtime verifying the Python signatures over
 * the exact canonical bytes. Reported, never faked, if unavailable.
 *
 * Usage:
 *   bun run proofbridge/mk0/cross-verify.ts <krypte-lib-root> [mk0-chain.jsonl] [out-ts-chain.jsonl]
 *
 *   <krypte-lib-root>  folder containing src/lib/validation/ (harness.ts,
 *                      format.ts, types.ts). DEFAULT:
 *                      /home/z/my-project/.publish/proofbridge-krypte
 *   [mk0-chain.jsonl]  the chain mk0.py --simulate wrote. DEFAULT:
 *                      proofbridge/mk0/chain.jsonl
 *   [out]              where the MAIN→MK0 chain is written. DEFAULT:
 *                      proofbridge/mk0/ts-chain.jsonl
 */

import { readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { pathToFileURL } from "node:url";
import { createPublicKey, verify as cryptoVerify } from "node:crypto";

const libRoot = process.argv[2] ?? "/home/z/my-project/.publish/proofbridge-krypte";
const mk0ChainPath = process.argv[3] ?? "proofbridge/mk0/chain.jsonl";
const outPath = process.argv[4] ?? "proofbridge/mk0/ts-chain.jsonl";

// Import the MAIN STACK's own code (dynamic, from the given lib root).
const harnessUrl = pathToFileURL(join(libRoot, "src/lib/validation/harness.ts")).href;
const formatUrl = pathToFileURL(join(libRoot, "src/lib/validation/format.ts")).href;
const { sealChain, verifyChain, GENESIS_TAG } = await import(harnessUrl);
const { canonicalJson } = await import(formatUrl);

let failed = false;

// ---------------------------------------------------------------------------
// (a) MK0 → MAIN: verify the Python-written chain with the TS verifier.
// ---------------------------------------------------------------------------
console.log(`MK0→MAIN: reading ${mk0ChainPath} (written by python3 mk0.py --simulate)`);
const lines = readFileSync(mk0ChainPath, "utf8").split("\n").filter((l) => l.trim() !== "");
const asIs: any[] = lines.map((l) => JSON.parse(l)); // sig/pub kept in place
const minimal = asIs.map((r) => ({ tag: r.tag, payload: r.payload, prev: r.prev, hash: r.hash }));

const vMinimal = verifyChain(minimal, GENESIS_TAG);
console.log(
  `MK0→MAIN: ${minimal.length} records mapped to {tag,payload,prev,hash}; ` +
  `verifyChain(genesis "${GENESIS_TAG}") -> valid=${vMinimal.valid}`,
);

// Second pass with sig/pub still attached — the main stack's verifyChain reads
// only tag/payload/prev/hash (types.ts:185-194), so Mk 0's extra fields must
// not break it. THIS is the "record written by Mk 0 verifies against the main
// stack's verifier" claim, exercised exactly as the records are on disk.
const vAsIs = verifyChain(asIs, GENESIS_TAG);
console.log(
  `MK0→MAIN: same records WITH sig/pub fields attached -> valid=${vAsIs.valid}`,
);

if (!vMinimal.valid || !vAsIs.valid || vMinimal.root !== vAsIs.root) {
  console.error(`MK0→MAIN: INVALID (minimal=${vMinimal.valid} as-is=${vAsIs.valid})`);
  process.exit(1);
}
console.log(`MK0→MAIN: VALID root=${vMinimal.root}`);

// ---------------------------------------------------------------------------
// (c) Ed25519: verify mk0.py's signatures over the canonical bytes with
// node:crypto — the other stack confirming the Python signatures.
// ---------------------------------------------------------------------------
function verifyEd25519(pubHex: string, sigHex: string, msg: string): boolean {
  const jwk = {
    kty: "OKP",
    crv: "Ed25519",
    x: Buffer.from(pubHex, "hex").toString("base64url"),
  };
  const pub = createPublicKey({ key: jwk, format: "jwk" } as any);
  return cryptoVerify(null, Buffer.from(msg, "utf8"), pub, Buffer.from(sigHex, "hex"));
}

const signed = asIs.filter((r) => typeof r.sig === "string" && typeof r.pub === "string");
if (signed.length === 0) {
  console.log("ED25519: no signed records in the Mk 0 chain (mk0.py reported the cryptography blocker) — signature cross-check SKIPPED, not faked");
} else {
  try {
    let ok = 0;
    for (const r of signed) {
      // the signature covers the exact byte string the SHA-256 hash covers:
      // prev + tag + canonicalJson(payload), UTF-8 (harness.ts:60-62,72)
      const msg = r.prev + r.tag + canonicalJson(r.payload);
      if (verifyEd25519(r.pub, r.sig, msg)) ok++;
    }
    if (ok === signed.length) {
      console.log(`ED25519: ${ok}/${signed.length} Python signatures VERIFY with node:crypto over the canonical bytes`);
    } else {
      console.error(`ED25519: only ${ok}/${signed.length} signatures verify — FAILURE`);
      failed = true;
    }
  } catch (e) {
    // Bun/node:crypto could not build the Ed25519 key from JWK — report, never fake.
    console.log(`ED25519: signature cross-check unavailable in this runtime (${(e as Error).message}) — reported, not faked`);
  }
}

// ---------------------------------------------------------------------------
// (b) MAIN → MK0: seal a 3-record chain with the TS sealChain over payloads
// chosen to stress canonicalJson, write ts-chain.jsonl, print the root.
// ---------------------------------------------------------------------------
const records = [
  {
    tag: "pb.tx.v1",
    payload: { id: "tx-0001", cur: "ZAR", qty: 3, amount: 12.5, note: "" },
  },
  {
    tag: "pb.tx.v1",
    payload: {
      id: "tx-0002",
      unicode: "café ☕ \"quoted\" back\\slash\nline",
      neg: -2.675,
      nested: {
        tie: 0.00048828125, // 2**-11: EXACT toFixed(10) tie — JS rounds away
        big: 1e14,          // from zero; naive Python .10f rounds half-even.
        tiny: 1e-7,         // This value exists to catch that discrepancy.
        z: -0.125,
        arr: [1, 2.25, "x", true, null, 0.5],
      },
    },
  },
  {
    tag: "pb.tx.v1",
    payload: {
      id: "tx-0003",
      cleared: true,
      meta: null,
      ratios: [0.1, 0.25, 1.5, 7.0],
      mix: { b: 2, a: 1, A: "case", _z: 0, z9: 9.0000000001 }, // mixed-case key sort
    },
  },
];

const sealedOut = sealChain(records, GENESIS_TAG);
writeFileSync(outPath, sealedOut.map((r) => JSON.stringify(r)).join("\n") + "\n");
const vOut = verifyChain(sealedOut, GENESIS_TAG);

console.log(`MAIN→MK0: sealed 3 records with the main stack's sealChain -> ${outPath}`);
console.log("MAIN→MK0: canonicalJson samples (byte-level evidence):");
for (const r of records) console.log(`  canonical(${r.tag}) = ${canonicalJson(r.payload)}`);
console.log(`MAIN→MK0: root=${vOut.root} valid=${vOut.valid}`);
console.log(
  `NEXT: python3 mk0.py --verify-only ${outPath}  must print MAIN→MK0: VALID root=${vOut.root}`,
);

if (failed || !vOut.valid) process.exit(1);
