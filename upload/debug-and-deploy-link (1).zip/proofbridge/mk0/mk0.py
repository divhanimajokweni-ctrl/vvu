#!/usr/bin/env python3
# =============================================================================
# ProofBridge Mk 0 "Pocket Node" — single-file firmware.
#
# STATUS: DESIGN/FIRMWARE STATE — DEVICE NOT BUILT.
#   No hardware has been assembled. No physical verification has been
#   performed. No photos or device logs exist, and none may be fabricated.
#   Simulate mode proves CHAIN-FORMAT COMPATIBILITY IN SOFTWARE ONLY: a
#   chain written by this file verifies against the main stack's TypeScript
#   verifier (src/lib/validation/harness.ts) and vice versa — the real,
#   dated run outputs are in CROSS-VERIFY-RESULT.txt next to this file.
#
# Modes:
#   python3 mk0.py --simulate N [--chain PATH]
#       No GPIO. Writes N deterministic event records (plus a genesis
#       record) to the chain file (default ./chain.jsonl — the file is
#       REWRITTEN from scratch so the output is fully deterministic),
#       re-verifies the whole chain, prints the root hash. Runs on any
#       machine with Python 3.12 + the `cryptography` package.
#   python3 mk0.py --verify-only PATH
#       Reads a JSONL chain (written by this file OR by the main stack's
#       TypeScript sealChain), re-verifies it with the Python port of the
#       chain rules, prints the root. Also verifies Ed25519 signatures
#       when the records carry sig+pub and the `cryptography` package is
#       importable (reported, never faked, when it is not).
#   python3 mk0.py [--chain PATH] [--port 8080]
#       DEVICE MODE: gpiozero LEDs/Button + HTTP status page. Requires a
#       Raspberry Pi Zero 2 W with the wiring in WIRING.md. This sandbox
#       has no hardware, so this mode cannot be executed here — the code
#       is written and reviewed, NOT hardware-tested. DEVICE NOT BUILT.
#
# Python 3.12. Third-party deps:
#   - `cryptography` (Ed25519) — guarded import; see Ed25519 section.
#   - `gpiozero` — device mode only; ships with Raspberry Pi OS.
# =============================================================================

import argparse
import hashlib
import json
import math
import os
import sys
import threading
import uuid
from datetime import datetime, timezone
from decimal import Decimal, ROUND_HALF_UP, localcontext

# -----------------------------------------------------------------------------
# Chain constants — mirror harness.ts:56-58 (GENESIS_TAG / GENESIS_RECORD_TAG /
# TX_TAG) so the Mk 0 chain anchors to the SAME genesis string as the main stack.
# -----------------------------------------------------------------------------

GENESIS_ANCHOR = "PROOFBRIDGE_GENESIS_v1"   # harness.ts:56 — prev_1 anchor string
GENESIS_RECORD_TAG = "pb.genesis.v1"        # harness.ts:57 — tag of record 1
TX_TAG = "pb.tx.v1"                         # harness.ts:58 — main stack per-tx tag
MK0_EVENT_TAG = "pb.mk0.event.v1"           # Mk 0 button event tag (this file)

DEVICE_DIR = "/home/pi/mk0"                 # device-mode data dir (chain + key)
DEVICE_KEY_PATH = DEVICE_DIR + "/ed25519.key"
DEVICE_CHAIN_PATH = DEVICE_DIR + "/chain.jsonl"
HTTP_PORT_DEFAULT = 8080

# Simulate-mode determinism (documented FAKE time — format testing only):
# pseudo-time is built ONLY from seq: SIM_BASE_EPOCH + seq*37. These are not
# real timestamps and must never be presented as device activity.
SIM_BASE_EPOCH = 1700000000
SIM_TIME_STEP = 37
SIM_SEED = b"mk0-simulate-seed-v1"          # deterministic Ed25519 seed material


def sha256_hex(s: str) -> str:
    # harness.ts:60-62 — createHash("sha256").update(s, "utf8").digest("hex").
    return hashlib.sha256(s.encode("utf-8")).hexdigest()


# =============================================================================
# canonicalJson — Python port of src/lib/validation/format.ts (encode, lines
# 68-91). Every rule below cites the TS line it replicates. The number
# encoding is the one place a naive port diverges from JS; see
# _encode_number.
# =============================================================================

class CanonicalJsonError(ValueError):
    pass


def canonical_json(v):
    """Byte-exact port of format.ts:64-91 canonicalJson."""
    return _encode(v)


def _encode(v):
    # format.ts:69 — null (and undefined, which Python JSON never produces)
    # encode as "null". Python has no undefined; json.loads can never yield
    # one, and this file never puts one in a payload: rule N/A by construction.
    if v is None:
        return "null"
    # format.ts:71 — booleans as true/false. MUST be tested before numbers:
    # Python bool is a subclass of int, but JS typeof true is "boolean".
    if isinstance(v, bool):
        return "true" if v else "false"
    # format.ts:70 — numbers via encodeNumber (see _encode_number).
    if isinstance(v, (int, float)):
        return _encode_number(v)
    # format.ts:72 — strings with JS JSON.stringify semantics.
    # json.dumps(s, ensure_ascii=False) escapes exactly ", \ and control
    # characters (short forms \b \t \n \f \r, else \u00xx) and leaves
    # non-ASCII raw — matching JSON.stringify for well-formed text.
    # (Known out-of-scope edge: lone surrogates. JS well-formed stringify
    # escapes them; Python would emit them raw. Chain payloads on both
    # stacks are well-formed text, so this never triggers; noted honestly
    # rather than silently ignored.)
    if isinstance(v, str):
        return json.dumps(v, ensure_ascii=False)
    # format.ts:73 — arrays in order, elements encoded, joined with ",".
    if isinstance(v, list):
        return "[" + ",".join(_encode(x) for x in v) + "]"
    # format.ts:74-78 — objects: keys sorted, undefined values dropped
    # (N/A in Python — see above), "key":"value" joined with ",", no spaces.
    if isinstance(v, dict):
        keys = sorted(v.keys(), key=_utf16_sort_key)
        parts = []
        for k in keys:
            if not isinstance(k, str):
                raise CanonicalJsonError(
                    "canonicalJson: object keys must be strings")
            parts.append(json.dumps(k, ensure_ascii=False) + ":" + _encode(v[k]))
        return "{" + ",".join(parts) + "}"
    # format.ts:80-81 — functions/symbols/bigints never appear in payloads.
    raise CanonicalJsonError("canonicalJson: unsupported value " + str(type(v)))


def _utf16_sort_key(k: str):
    # format.ts:76-77 — Object.keys(...).sort() is a JS Array#sort, which
    # orders strings by UTF-16 CODE UNIT. Python sorted() orders by Unicode
    # code point, which differs once astral characters (> U+FFFF, encoded as
    # surrogate pairs 0xD800-0xDFFF) mix with BMP characters above 0xDFFF.
    # Sorting by the UTF-16-BE byte encoding reproduces code-unit order
    # exactly (surrogatepass lets lone surrogates through, which Python
    # sorted() would otherwise misplace — belt and braces).
    return k.encode("utf-16-be", "surrogatepass")


def _encode_number(x):
    # format.ts:84-91 — encodeNumber. The four rules:
    #   (1) line 85: non-finite -> hard error.
    #   (2) line 86: Number.isInteger(x) && |x| < 1e15 -> String(x).
    #   (3) line 88: otherwise x.toFixed(10) — on the EXACT binary double,
    #       with ES toFixed tie-breaking ("pick the larger n" after the spec
    #       strips the sign = ties away from zero in magnitude).
    #   (4) lines 89-90: trim trailing zeros then a trailing "."; "-0" -> "0".
    if isinstance(x, bool):  # unreachable (bool checked first) — paranoia
        raise CanonicalJsonError("canonicalJson: bool reached encodeNumber")
    if isinstance(x, int):
        # JSON integer literal (json.loads yields exact ints). JS numbers
        # are doubles; an integral double with |x| < 1e15 hits rule (2).
        if -10**15 < x < 10**15:  # strict <, matching Math.abs(x) < 1e15
            return str(x)         # JS String(int): same digits (no -0 for int)
        # |x| >= 1e15: JS would hold a double and take the toFixed path —
        # fall through by converting (matches JSON round-trip on the TS side).
        x = float(x)
    if not math.isfinite(x):  # rule (1) — format.ts:85
        raise CanonicalJsonError("canonicalJson: non-finite number")
    # rule (2): integral doubles count as integers in JS (Number.isInteger),
    # including 5.0 and -0.0. JS String(-0) === "0"; str(int(-0.0)) === "0".
    if float(x).is_integer() and -1e15 < x < 1e15:
        return str(int(x))
    # rule (3): toFixed(10) on the exact double. Python's f"{x:.10f}" is
    # round-half-EVEN; JS toFixed is ties-AWAY-FROM-ZERO on the exact binary
    # value. They disagree exactly on ties whose decimal expansion ends at
    # the 11th place with a 5, e.g. 2**-11 = 0.00048828125 (JS: "0.0004882813",
    # naive Python: "0.0004882812"). Decimal(x) is the exact binary value of
    # the double (no shortest-repr drift) and ROUND_HALF_UP is
    # ties-away-from-zero — the JS semantics. This case is deliberately
    # included in the cross-verification payloads; see CROSS-VERIFY-RESULT.txt.
    s = _to_fixed_10(x)
    # rule (4): format.ts:89 — trim trailing zeros, then a trailing ".".
    if "." in s:
        s = s.rstrip("0").rstrip(".")
    # format.ts:90 — "-0" normalises to "0" (tiny negatives rounded to zero).
    return "0" if s == "-0" else s


_QUANT_10 = Decimal(1).scaleb(-10)  # 1e-10


def _to_fixed_10(x: float) -> str:
    """JS Number.prototype.toFixed(10) for finite doubles (format.ts:88).

    ES spec: strip the sign, pick the integer n closest to |x|*10^10 with
    ties going to the LARGER n (= away from zero in magnitude), re-attach
    the sign, render with exactly 10 fraction digits. (Values >= 1e21 would
    take JS's exponential path; neither chain carries such magnitudes —
    payloads on both stacks stay far below, and Decimal handles the rest.)
    """
    d = Decimal(x)  # exact binary value of the double
    with localcontext() as ctx:
        ctx.prec = 80  # headroom for large magnitudes (payloads are << 1e69)
        q = d.quantize(_QUANT_10, rounding=ROUND_HALF_UP)  # ties away from zero
    return format(q, "f")  # exactly 10 fraction digits, sign preserved


# =============================================================================
# Chain seal/verify — Python port of src/lib/validation/harness.ts:68-94.
# =============================================================================

def seal_chain(records, genesis_tag=GENESIS_ANCHOR):
    """harness.ts:68-77 sealChain.

    hash_i = SHA-256(prev_i + tag_i + canonicalJson(payload_i)) — plain
    string concatenation, UTF-8 bytes (harness.ts:60-62 sha256Hex).
    prev_1 = the genesis anchor string; prev_{i+1} = hash_i.
    Returns [{tag, payload, prev, hash}, ...] (extra fields like sig/pub are
    added by the caller, NOT here, mirroring the main stack's shape).
    """
    prev = genesis_tag
    out = []
    for r in records:
        h = sha256_hex(prev + r["tag"] + canonical_json(r["payload"]))
        out.append({"tag": r["tag"], "payload": r["payload"], "prev": prev, "hash": h})
        prev = h
    return out


def verify_chain(sealed, genesis_tag=GENESIS_ANCHOR):
    """harness.ts:83-94 verifyChain.

    Recompute every hash from the genesis anchor and check BOTH the
    recomputed hash AND the stored prev link; the walk continues on the
    STORED hash (harness.ts:91 `prev = r.hash`), so tampering propagates.
    root = the RECOMPUTED hash of the LAST record (""); an empty chain is
    valid with an empty root, exactly as in the TS original. Extra fields
    (sig/pub) are ignored — the TS verifier structurally reads only
    tag/payload/prev/hash (types.ts:185-194), so Mk 0 records with
    signatures verify against it unchanged.
    """
    prev = genesis_tag
    valid = True
    root = ""
    for r in sealed:
        h = sha256_hex(prev + r["tag"] + canonical_json(r["payload"]))
        if h != r["hash"] or r["prev"] != prev:
            valid = False
        root = h
        prev = r["hash"]
    return {"valid": valid, "root": root}


def first_bad_index(sealed, genesis_tag=GENESIS_ANCHOR):
    """Diagnostic helper: index of the first record that fails verification
    (or -1). Used only for honest failure reporting in --verify-only."""
    prev = genesis_tag
    for i, r in enumerate(sealed):
        h = sha256_hex(prev + r["tag"] + canonical_json(r["payload"]))
        if h != r["hash"] or r["prev"] != prev:
            return i
        prev = r["hash"]
    return -1


# =============================================================================
# Ed25519 — signing for Mk 0 records. Import is GUARDED: the chain hashing
# needs no third-party code; only signing/verifying signatures does.
# =============================================================================

def _crypto_ok():
    try:
        import cryptography  # noqa: F401
        return True
    except ImportError:
        return False


def simulate_signing_key():
    """Deterministic key for simulate mode: private bytes are exactly
    sha256(b"mk0-simulate-seed-v1"), so every run on every machine produces
    byte-identical signatures. NEVER used for a real device key."""
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    seed = hashlib.sha256(SIM_SEED).digest()  # 32 bytes
    return Ed25519PrivateKey.from_private_bytes(seed)


def load_or_create_device_key(key_path=DEVICE_KEY_PATH):
    """Device mode: load /home/pi/mk0/ed25519.key (32 raw bytes, mode 0600)
    or create it once with os.urandom so the node's identity persists across
    boots and SD card moves. Raises on malformed keys — never regenerates
    silently (that would break the identity the genesis record published)."""
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    if os.path.exists(key_path):
        with open(key_path, "rb") as f:
            data = f.read()
        if len(data) != 32:
            raise RuntimeError(f"malformed key file {key_path} ({len(data)} bytes, want 32)")
        return Ed25519PrivateKey.from_private_bytes(data)
    data = os.urandom(32)
    key = Ed25519PrivateKey.from_private_bytes(data)
    fd = os.open(key_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    try:
        os.write(fd, data)
    finally:
        os.close(fd)
    os.chmod(key_path, 0o600)
    return key


def public_hex(key):
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
    pub = key.public_key()
    if isinstance(pub, Ed25519PublicKey):
        raw = pub.public_bytes(
            serialization.Encoding.Raw, serialization.PublicFormat.Raw)
        return raw.hex()
    raise RuntimeError("unexpected public key type")


def sign_message(key, message: bytes) -> str:
    """Ed25519 signature (64 bytes) as hex."""
    return key.sign(message).hex()


def verify_signature(pub_hex: str, sig_hex: str, message: bytes) -> bool:
    from cryptography.hazmat.primitives.asymmetric.ed25519 import (
        Ed25519PublicKey, InvalidSignature)
    try:
        Ed25519PublicKey.from_public_bytes(bytes.fromhex(pub_hex)).verify(
            bytes.fromhex(sig_hex), message)
        return True
    except InvalidSignature:
        return False


# =============================================================================
# Record + chain-file I/O. Line shape (JSONL, one object per line):
#   {"tag": "...", "payload": {...}, "prev": "...", "hash": "...",
#    "sig": "<hex>", "pub": "<hex>"}
# sig is an Ed25519 signature over the exact byte string the SHA-256 hash
# covers — the UTF-8 bytes of prev + tag + canonicalJson(payload) — so a
# signature verifies against the SAME canonical bytes the chain hashed.
# "pub" is the raw 32-byte Ed25519 public key as hex. The main stack's
# verifyChain ignores extra fields (types.ts:185-194), so sig/pub ride along
# without breaking byte-compatibility.
# =============================================================================

def signing_message(prev: str, tag: str, payload) -> bytes:
    return (prev + tag + canonical_json(payload)).encode("utf-8")


def sealed_line(sealed, key):
    """One JSONL line from a sealed {tag,payload,prev,hash} record.
    If key is None (cryptography unavailable) the sig/pub fields are OMITTED
    — never faked — and the caller must report that loudly."""
    rec = {
        "tag": sealed["tag"],
        "payload": sealed["payload"],
        "prev": sealed["prev"],
        "hash": sealed["hash"],
    }
    if key is not None:
        msg = signing_message(sealed["prev"], sealed["tag"], sealed["payload"])
        rec["sig"] = sign_message(key, msg)
        rec["pub"] = public_hex(key)
    return rec


def write_chain_file(path, records, lines):
    """Atomically-ish write the whole chain (simulate mode rewrites from
    scratch so output is deterministic). fsync before rename."""
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        for line in lines:
            f.write(json.dumps(line, ensure_ascii=False, separators=(",", ":")) + "\n")
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)


def append_line(path, line):
    """Device mode: append one record, flush + fsync so a power cut after
    the green flash cannot silently lose the record."""
    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(line, ensure_ascii=False, separators=(",", ":")) + "\n")
        f.flush()
        os.fsync(f.fileno())


def read_chain(path):
    """Read a JSONL chain file into a list of record dicts. Raises ValueError
    on a malformed/torn line (a torn final line after a power cut reads as
    malformed — surfaced as a verify failure, never auto-truncated, because
    auto-truncation could hide real tampering)."""
    records = []
    with open(path, "r", encoding="utf-8") as f:
        for lineno, raw in enumerate(f, 1):
            raw = raw.strip()
            if not raw:
                continue
            try:
                r = json.loads(raw)
            except json.JSONDecodeError as e:
                raise ValueError(f"chain file {path} line {lineno}: malformed JSON ({e})")
            for field in ("tag", "payload", "prev", "hash"):
                if field not in r:
                    raise ValueError(f"chain file {path} line {lineno}: missing field {field!r}")
            records.append(r)
    return records


def seal_next(prev_hash, tag, payload):
    h = sha256_hex(prev_hash + tag + canonical_json(payload))
    return {"tag": tag, "payload": payload, "prev": prev_hash, "hash": h}


def sim_utc(seq: int) -> str:
    """FAKE deterministic timestamp for simulate mode: base epoch 1700000000
    plus seq*37 seconds. Built ONLY from seq — no wall clock anywhere. These
    timestamps are synthetic and exist purely so event payloads exercise the
    string encoding in canonicalJson. They must never be presented as real
    device activity (this run is software-only; DEVICE NOT BUILT)."""
    return datetime.fromtimestamp(
        SIM_BASE_EPOCH + seq * SIM_TIME_STEP, tz=timezone.utc).isoformat()


# =============================================================================
# Mode: --simulate N
# =============================================================================

def run_simulate(args) -> int:
    n = args.simulate
    if n < 0:
        print("MK0 SIMULATE: N must be >= 0", file=sys.stderr)
        return 2
    path = args.chain or "./chain.jsonl"

    key = None
    if _crypto_ok():
        key = simulate_signing_key()
        key_note = "Ed25519 deterministic simulate key: seed=sha256(b\"mk0-simulate-seed-v1\")"
    else:
        # HONESTY RULE: never fake a signature. Records are written WITHOUT
        # sig/pub and this is reported loudly.
        key_note = ("Ed25519 UNAVAILABLE: `cryptography` is not installed "
                    "(pip3 install cryptography). Records are written WITHOUT "
                    "sig/pub fields — unsigned is NOT faked. This is a blocker "
                    "to report, not to paper over.")

    # Genesis record — tag pb.genesis.v1 like the main stack's genesis
    # (harness.ts:828-835); payload carries the same anchor string under
    # "genesis", plus Mk 0 identity. Simulate mode keeps every field
    # deterministic (no boot id, no real time — those are device-mode only).
    genesis_payload = {
        "genesis": GENESIS_ANCHOR,
        "device": "mk0",
        "mode": "simulate",
    }
    records = [{"tag": GENESIS_RECORD_TAG, "payload": genesis_payload}]
    for seq in range(1, n + 1):
        records.append({
            "tag": MK0_EVENT_TAG,
            "payload": {"seq": seq, "kind": "button", "utc": sim_utc(seq), "note": ""},
        })

    sealed = seal_chain(records, GENESIS_ANCHOR)
    lines = [sealed_line(s, key) for s in sealed]
    write_chain_file(path, records, lines)

    v = verify_chain(read_chain(path), GENESIS_ANCHOR)
    with open(path, "rb") as f:
        file_digest = hashlib.sha256(f.read()).hexdigest()

    print(f"MK0 SIMULATE — DETERMINISTIC SOFTWARE RUN (no GPIO, no hardware; "
          f"timestamps are FAKE: base {SIM_BASE_EPOCH} + seq*{SIM_TIME_STEP})")
    print(f"  key      : {key_note}")
    print(f"  chain    : {path} ({len(lines)} records = 1 genesis + {n} events; "
          f"file rewritten from scratch for determinism)")
    print(f"  file     : sha256={file_digest}")
    if v["valid"]:
        print(f"MK0 SIMULATE: VALID root={v['root']} records={len(lines)}")
        return 0
    print(f"MK0 SIMULATE: INVALID — chain failed self-verification")
    return 1


# =============================================================================
# Mode: --verify-only PATH
# =============================================================================

def run_verify_only(args) -> int:
    path = args.verify_only
    try:
        records = read_chain(path)
    except (OSError, ValueError) as e:
        print(f"MK0 VERIFY-ONLY: cannot read chain: {e}", file=sys.stderr)
        return 2

    v = verify_chain(records, GENESIS_ANCHOR)

    # Bonus honesty check: verify Ed25519 sigs when sig+pub are present AND
    # the cryptography package is importable. Records without sig/pub (e.g.
    # chains sealed by the main stack's sealChain) are simply skipped.
    n_signed = n_sig_ok = 0
    crypto_note = None
    signed_records = [r for r in records if "sig" in r and "pub" in r]
    if signed_records:
        if _crypto_ok():
            for r in signed_records:
                n_signed += 1
                msg = signing_message(r["prev"], r["tag"], r["payload"])
                if verify_signature(r["pub"], r["sig"], msg):
                    n_sig_ok += 1
        else:
            crypto_note = ("cryptography not importable — sig fields present but "
                           "NOT verified (reported, never faked)")
    n_unsigned = len(records) - len(signed_records)

    print(f"MK0 PYTHON VERIFIER: {path} — {len(records)} records "
          f"({len([r for r in records if r['tag'] == GENESIS_RECORD_TAG])} genesis, "
          f"{len([r for r in records if r['tag'] == MK0_EVENT_TAG])} pb.mk0.event.v1, "
          f"{len([r for r in records if r['tag'] not in (GENESIS_RECORD_TAG, MK0_EVENT_TAG)])} other tags; "
          f"{n_signed} signed / {n_unsigned} unsigned)")
    if signed_records and _crypto_ok():
        print(f"  ed25519  : {n_sig_ok}/{n_signed} signatures verify "
              f"({'all OK' if n_sig_ok == n_signed else 'FAILURES PRESENT'})")
    if crypto_note:
        print(f"  ed25519  : {crypto_note}")
    if v["valid"]:
        # Label defaults to the MAIN→MK0 direction (the file under test was
        # sealed by the main stack's TypeScript sealChain): the Python port
        # of the chain rules accepts it and recomputes the SAME root.
        print(f"MAIN→MK0: VALID root={v['root']}")
        return 0
    bad = first_bad_index(records, GENESIS_ANCHOR)
    print(f"MAIN→MK0: INVALID (first failing record index {bad} of {len(records) - 1}; "
          f"recomputed hash/prev link does not match the stored one)")
    return 1


# =============================================================================
# Mode: DEVICE MODE (gpiozero + HTTP status page). NOT runnable in this
# sandbox — no Raspberry Pi exists here. Code written and reviewed only;
# DEVICE NOT BUILT. Wiring per WIRING.md:
#   Green LED  -> GPIO 22 (330 ohm -> GND)
#   Amber LED  -> GPIO 23 (330 ohm -> GND)
#   Red LED    -> GPIO 24 (330 ohm -> GND)
#   Button     -> GPIO 17 -> GND (internal pull-up, pressed = LOW)
# =============================================================================

def run_device(args) -> int:
    try:
        from gpiozero import LED, Button
    except ImportError as e:
        print("DEVICE MODE requires gpiozero (ships with Raspberry Pi OS) and "
              "a Raspberry Pi Zero 2 W wired per WIRING.md. This machine has "
              "neither — the physical Mk 0 node DOES NOT EXIST and is not "
              f"built. Use --simulate / --verify-only. (import error: {e})",
              file=sys.stderr)
        return 2
    try:
        import http.server
    except ImportError:
        print("DEVICE MODE requires http.server (stdlib)", file=sys.stderr)
        return 2

    chain_path = args.chain or DEVICE_CHAIN_PATH
    port = args.port
    os.makedirs(os.path.dirname(chain_path) or ".", exist_ok=True)

    if _crypto_ok():
        key = load_or_create_device_key(DEVICE_KEY_PATH)
    else:
        # HONESTY RULE: run unsigned rather than fake a signature — and say so.
        key = None
        print("WARNING: `cryptography` unavailable on this device — records "
              "will be written WITHOUT sig/pub (unsigned, never faked). "
              "Install with: sudo apt install python3-cryptography",
              file=sys.stderr)

    pub_hex_s = public_hex(key) if key is not None else "(unsigned build)"
    device_id = "mk0-" + pub_hex_s[:8] if key is not None else "mk0-unsigned"

    green = LED(22)
    amber = LED(23)
    red = LED(24)
    button = Button(17)  # tactile switch to GND; gpiozero default pull_up=True
    chain_lock = threading.Lock()
    state = {"tampered": False, "boot_ok": False, "events": 0}

    def all_off():
        green.off(); amber.off(); red.off()

    # ---- boot: verify the existing chain, or create the genesis record ----
    def boot():
        all_off()
        amber.on()  # processing while we read + verify the SD card
        try:
            if not os.path.exists(chain_path) or os.path.getsize(chain_path) == 0:
                boot_id = uuid.uuid4().hex
                # Device-mode genesis: deterministic anchor + REAL identity
                # fields (pubkey hex + boot id) — published once, on first boot.
                payload = {
                    "genesis": GENESIS_ANCHOR,
                    "device": "mk0",
                    "pub": pub_hex_s if key is not None else "(unsigned)",
                    "boot": boot_id,
                }
                first = seal_next(GENESIS_ANCHOR, GENESIS_RECORD_TAG, payload)
                line = sealed_line(first, key)
                append_line(chain_path, line)
        finally:
            amber.off()
        records = read_chain(chain_path)
        v = verify_chain(records, GENESIS_ANCHOR)
        state["events"] = sum(1 for r in records if r["tag"] == MK0_EVENT_TAG)
        if v["valid"]:
            state["boot_ok"] = True
            green.on()  # green LED on: chain valid
        else:
            state["tampered"] = True
            red.on()   # red LED solid: tamper / broken chain — refuse appends

    # ---- button press: capture, seal, sign, append, re-verify ----
    def on_press():
        if state["tampered"]:
            red.on()
            return
        amber.on()   # amber while processing
        green.off()
        ok = False
        try:
            with chain_lock:
                records = read_chain(chain_path)
                v = verify_chain(records, GENESIS_ANCHOR)
                if not v["valid"]:
                    state["tampered"] = True
                    return
                prev_hash = records[-1]["hash"] if records else GENESIS_ANCHOR
                seq = state["events"] + 1
                payload = {
                    "seq": seq,
                    "kind": "button",
                    "utc": datetime.now(timezone.utc).isoformat(),  # real time
                    "note": "",
                }
                sealed = seal_next(prev_hash, MK0_EVENT_TAG, payload)
                line = sealed_line(sealed, key)
                append_line(chain_path, line)
                # re-verify the WHOLE chain after the append (device rule)
                v2 = verify_chain(read_chain(chain_path), GENESIS_ANCHOR)
                ok = v2["valid"]
                if ok:
                    state["events"] = seq
        finally:
            amber.off()
        if ok:
            # green flash on valid append, then back to steady green
            green.blink(on_time=0.2, off_time=0.2, n=3, background=True)
            threading.Timer(1.4, lambda: green.on() if not state["tampered"] else None).start()
        else:
            state["tampered"] = True
            green.off()
            red.on()  # red solid: the append (or the chain) failed verification

    # ---- HTTP status page: root recomputed live from the file, never cached ----
    class StatusHandler(http.server.BaseHTTPRequestHandler):
        server_version = "Mk0PocketNode/0.1"

        def do_GET(self):
            if self.path != "/":
                self.send_error(404)
                return
            try:
                with chain_lock:
                    records = read_chain(chain_path)
                    v = verify_chain(records, GENESIS_ANCHOR)
                n_events = sum(1 for r in records if r["tag"] == MK0_EVENT_TAG)
                text = (
                    "PROOFBRIDGE MK0 POCKET NODE — STATUS\n"
                    f"device-id : {device_id}\n"
                    f"chain     : {chain_path}\n"
                    f"records   : {len(records)} total "
                    f"({n_events} pb.mk0.event.v1 + genesis)\n"
                    f"chain-ok  : {'VALID' if v['valid'] else 'BROKEN (tamper?)'}\n"
                    f"root      : {v['root']}\n"
                    f"identity  : pubkey {pub_hex_s}\n"
                    "note      : this page recomputes the whole chain from the "
                    "file on every request — nothing is cached\n"
                )
            except Exception as e:  # unreadable/torn chain -> say so, never fake
                text = (f"PROOFBRIDGE MK0 POCKET NODE — STATUS\n"
                        f"chain     : {chain_path}\n"
                        f"chain-ok  : UNREADABLE ({e})\n")
            body = "<pre>" + text.replace("&", "&amp;").replace("<", "&lt;") + "</pre>\n"
            data = body.encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

        def log_message(self, fmt, *a):
            sys.stderr.write("%s - %s\n" % (self.address_string(), fmt % a))

    boot()
    button.when_pressed = on_press
    print(f"MK0 DEVICE MODE: serving status on http://0.0.0.0:{port}/ "
          f"(find the Pi's IP: `ip addr` or http://mk0.local:{port}/)")
    print(f"MK0 DEVICE MODE: chain={chain_path} events={state['events']} "
          f"tampered={state['tampered']}")
    srv = http.server.ThreadingHTTPServer(("0.0.0.0", port), StatusHandler)
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        srv.server_close()
    return 0


# =============================================================================
# CLI
# =============================================================================

def main(argv=None) -> int:
    p = argparse.ArgumentParser(
        prog="mk0.py",
        description="ProofBridge Mk 0 Pocket Node firmware. "
                    "STATUS: DESIGN/FIRMWARE STATE — DEVICE NOT BUILT. "
                    "Simulate mode proves chain-format compatibility in software only.")
    p.add_argument("--simulate", metavar="N", type=int, default=None,
                   help="software-only deterministic run: write N event records "
                        "+ genesis, verify, print root (no GPIO)")
    p.add_argument("--verify-only", metavar="PATH", default=None,
                   help="verify a chain JSONL with the Python port (works on "
                        "chains written by mk0.py AND by the main stack's "
                        "TypeScript sealChain)")
    p.add_argument("--chain", metavar="PATH", default=None,
                   help="chain file override (default: ./chain.jsonl in simulate "
                        "mode, /home/pi/mk0/chain.jsonl in device mode)")
    p.add_argument("--port", type=int, default=HTTP_PORT_DEFAULT,
                   help="HTTP status page port in device mode (default 8080)")
    args = p.parse_args(argv)

    if args.simulate is not None:
        return run_simulate(args)
    if args.verify_only:
        return run_verify_only(args)
    return run_device(args)


if __name__ == "__main__":
    sys.exit(main())
