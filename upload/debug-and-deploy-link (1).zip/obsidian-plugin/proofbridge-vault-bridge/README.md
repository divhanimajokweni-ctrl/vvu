# ProofBridge Vault Bridge

Phone-side Obsidian agent for the ProofBridge dashboard's `#/bridge` projection
(mini-service `:3004`). QR pairing is the only per-device setup step; every op
returns a hash-chained receipt (SHA-256). The vault never leaves the phone.

- Install steps: see `INSTALL.md`.
- Security contract: see `SECURITY_LOCK.md` (verbatim §1–§8 of the template).
- **Governing spec: `ProofBridge/TEMPLATE_QR_BRIDGE.md` v1.1.0** — read it in
  full before touching `main.js`. §17 is the line to remember:
  *QR = reference. Server = authority. Receipt = truth. Nothing else.*

Catalogue status (§3 vocabulary): **UNVERIFIED** — prototype; adversarial test
evidence and provenance hashes for this plugin pre-date the v1.1.0 template and
have not been re-run against it. Do not relabel VERIFIED without the §13
provenance set attached.
