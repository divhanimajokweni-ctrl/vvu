# ProofBridge Vault Bridge — install (the ONE manual step)

**BRIDGE STATUS: PROTOTYPE — UNVERIFIED ON REAL ANDROID.**
Protocol tested ≠ mobile client tested ≠ live bridge tested.

## What this is

`proofbridge-vault-bridge` is the phone-side agent for the ProofBridge
dashboard's `#/bridge` projection (mini-service `:3004`). QR pairing is the
ONLY per-device setup action — after the one-time plugin install below, no
manual steps: scan the QR, the plugin pairs, connects, authenticates, and
relays search/read/write ops against THIS live vault. Every op returns a
hash-chained receipt (SHA-256). The vault never leaves the phone — only op
results transit.

## One-time install (once per phone)

1. Copy this folder (`proofbridge-vault-bridge/`) into the vault's
   `.obsidian/plugins/` directory on the phone.
2. Obsidian → Settings → Community plugins → turn OFF *Restricted mode* →
   enable **ProofBridge Vault Bridge**.

## Pair (per device, seconds)

1. Open the dashboard `#/bridge` projection (the live origin).
2. The QR encodes `obsidian://proofbridge-pair?origin=…&pid=…&token=…` with a
   single-use 10-minute token — the origin is the LIVE dashboard origin
   (never invented).
3. Scan it with the phone **camera** — Obsidian opens, the plugin exchanges
   the token for a device secret (HMAC-SHA256 challenge/response thereafter),
   and enters the long-poll command loop. Status bar shows `ProofBridge ●`.
4. The `#/bridge` projection flips **LIVE VAULT LINKED** — search, read,
   write the real vault; every op returns a receipt.

## Ops relayed

| op    | args                     | result                          |
|-------|--------------------------|---------------------------------|
| list  | —                        | up to 500 files `{path,size,mtime}` |
| search| `{query}` 1..128 chars   | ≤50 hits `{path,line,snippet}` over md/txt/json/csv/canvas ≤1MB |
| read  | `{path}` vault-relative  | `{path,content}` (path-traversal guarded) |
| write | `{path,content}` ≤256KB  | `{path,bytes}` (creates folders) |

## Security notes (honest)

- Pilot-grade symmetric device secret delivered over the gateway's TLS — NOT
  hardware Ed25519 (Mk-node lineage work).
- The device credential lives in plugin data ON THE PHONE. Obsidian mobile
  has no SecretStorage API — pilot-grade storage, noted, not hidden.
- Files never leave the phone: only op results and receipts transit.
- Unpair forgets the device identity; dashboard receipts are immutable.
