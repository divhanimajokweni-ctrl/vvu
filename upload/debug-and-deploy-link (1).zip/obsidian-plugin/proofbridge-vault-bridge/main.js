// ProofBridge Vault Bridge — Obsidian plugin (phone-side agent). Plain JS,
// zero dependencies, CommonJS (Obsidian provides the 'obsidian' module).
//
// PAIRING: scan the dashboard's QR with the phone camera → Obsidian opens
// via obsidian://proofbridge-pair?origin=…&pid=…&token=… → this plugin
// exchanges the single-use token for a device secret (HMAC) and connects.
// From then on it auto-connects + authenticates whenever Obsidian is open.
//
// CHANNEL: plain HTTPS fetch to the dashboard origin (the bridge rides
// behind it on ?XTransformPort=3004). Commands arrive by long-poll; ops
// execute against THIS vault through the Obsidian API — the vault files
// never leave the phone, only op results (and their receipts) transit.
//
// HONESTY: pilot-grade symmetric secret. No third party sees the vault.
//
// TASK 40 §6 (one-run go-live lock) — WRITE SAFETY PROTOCOL:
//   WRITE = READ → HASH BEFORE → COMPARE → WRITE → READ BACK → HASH AFTER.
//   · MODIFY requires hashBefore (64-hex, the sha256 of what the caller last
//     READ). Mismatch → SOURCE_CHANGED — fail closed, no overwrite.
//   · CREATE requires hashBefore = null (new file, nothing to compare).
//   · Blind overwrite of an existing file is REFUSED.
//   · The result carries { created, hashBefore, hashAfter } so the receipt
//     chain can evidence the read-back verification.
//
// REBUILD NOTE (Task 38): rebuilt byte-equivalent after the platform
// sandbox rollback destroyed the Task 36/37 files; evidence regenerated.

'use strict';

const { Plugin, PluginSettingTab, Setting, Notice, TFile, TFolder } = require('obsidian');

const PORT_QUERY = 'XTransformPort=3004';
const POLL_MS = 25000; // server holds up to 25s
const RESULT_TIMEOUT_MS = 30000;

const DEFAULT_SETTINGS = {
  origin: '',
  deviceId: '',
  secret: '',
  deviceName: 'obsidian-android',
};

function safePath(p) {
  if (typeof p !== 'string' || p.length === 0 || p.length > 512) return null;
  if (p.startsWith('/') || p.includes('..') || p.includes('\\') || p.includes('\0')) return null;
  return p;
}

function url(origin, path) {
  const base = String(origin || '').replace(/\/+$/, '');
  return `${base}${path}${path.includes('?') ? '&' : '?'}${PORT_QUERY}`;
}

async function hmacHex(secretHex, msg) {
  const key = await crypto.subtle.importKey(
    'raw',
    Uint8Array.from(secretHex.match(/.{2}/g).map((h) => parseInt(h, 16))),
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['sign']
  );
  const sig = await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(msg));
  return Array.from(new Uint8Array(sig)).map((b) => b.toString(16).padStart(2, '0')).join('');
}

// Task 40 §6 — content hashing for the write-safety protocol
async function sha256Hex(s) {
  const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(s));
  return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, '0')).join('');
}

async function post(origin, path, body, timeoutMs) {
  const ctl = new AbortController();
  const t = setTimeout(() => ctl.abort(), timeoutMs || RESULT_TIMEOUT_MS);
  try {
    const res = await fetch(url(origin, path), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body || {}),
      signal: ctl.signal,
    });
    const data = await res.json().catch(() => ({}));
    return { status: res.status, ok: res.ok, data };
  } finally {
    clearTimeout(t);
  }
}

class ProofBridgeVaultBridgePlugin extends Plugin {
  async onload() {
    this.settings = Object.assign({}, DEFAULT_SETTINGS, await this.loadData());

    // ── QR entry point: obsidian://proofbridge-pair?origin=…&pid=…&token=… ──
    this.registerObsidianProtocolHandler('proofbridge-pair', (data) => {
      this.pairFromUri(data).catch((e) => new Notice(`ProofBridge pair failed: ${e.message}`));
    });

    this.addCommand({
      id: 'proofbridge-pair-now',
      name: 'Pair with ProofBridge dashboard (paste URI)',
      callback: () => this.promptForPairUri(),
    });

    this.addRibbonIcon('orbit', 'ProofBridge Vault Bridge', () => {
      new Notice(this.linked()
        ? `ProofBridge LINKED · ${this.settings.deviceId} → ${this.settings.origin}`
        : 'ProofBridge: not paired — scan the dashboard QR, or run the pair command.');
    });

    this.statusBarItem = this.addStatusBarItem();
    this.setBadge('○');
    this.registerEvent(this.app.workspace.on('active-leaf-change', () => this.ensureLoop()));

    this.addSettingTab(new BridgeSettingTab(this.app, this));

    // auto-connect if previously paired
    if (this.linked()) this.ensureLoop();
  }

  linked() {
    return Boolean(this.settings.origin && this.settings.deviceId && this.settings.secret);
  }

  setBadge(b) {
    if (this.statusBarItem) this.statusBarItem.setText(` ProofBridge ${b}`);
  }

  // ── pairing ────────────────────────────────────────────────────────────────
  async pairFromUri(data) {
    const { origin, pid, token } = data || {};
    if (!origin || !pid || !token) throw new Error('incomplete pairing URI');
    const r = await post(origin, '/agent/pair', { pairingId: pid, token, deviceName: this.settings.deviceName });
    if (!r.ok) throw new Error(r.data && r.data.error ? r.data.error : `HTTP ${r.status}`);
    this.settings.origin = origin;
    this.settings.deviceId = r.data.deviceId;
    this.settings.secret = r.data.secret;
    await this.saveData(this.settings);
    new Notice(`ProofBridge PAIRED · device ${r.data.deviceId}`);
    this.ensureLoop();
  }

  async promptForPairUri() {
    const uri = await new Promise((resolve) => {
      const modal = document.createElement('div');
      // simple native prompt — no extra modal machinery needed
      const v = window.prompt('Paste the obsidian://proofbridge-pair… URI from the dashboard:');
      resolve(v || '');
    });
    if (!uri) return;
    try {
      const u = new URL(uri.replace('obsidian://', 'https://pair.local/'));
      await this.pairFromUri({
        origin: u.searchParams.get('origin') || '',
        pid: u.searchParams.get('pid') || '',
        token: u.searchParams.get('token') || '',
      });
    } catch (e) {
      new Notice(`Bad pairing URI: ${e.message}`);
    }
  }

  async unpair() {
    this.stopping = true;
    this.settings.origin = '';
    this.settings.deviceId = '';
    this.settings.secret = '';
    await this.saveData(this.settings);
    this.setBadge('○');
    new Notice('ProofBridge unpaired.');
  }

  // ── auth + command loop ───────────────────────────────────────────────────
  async ensureLoop() {
    if (this.loopRunning || !this.linked()) return;
    this.loopRunning = true;
    this.setBadge('…');
    try {
      const ok = await this.authenticate();
      if (!ok) { this.setBadge('×'); this.loopRunning = false; this.scheduleRetry(); return; }
      await this.pollLoop();
    } finally {
      this.loopRunning = false;
    }
  }

  scheduleRetry() {
    clearTimeout(this.retryTimer);
    this.retryTimer = setTimeout(() => this.ensureLoop(), 15000);
  }

  async authenticate() {
    try {
      const h = await post(this.settings.origin, '/agent/hello', { deviceId: this.settings.deviceId });
      if (!h.ok) return false;
      const sig = await hmacHex(this.settings.secret, h.data.nonce);
      const a = await post(this.settings.origin, '/agent/auth', { deviceId: this.settings.deviceId, nonce: h.data.nonce, hmac: sig });
      return a.ok;
    } catch {
      return false;
    }
  }

  async pollLoop() {
    this.stopping = false;
    while (!this.stopping && this.linked()) {
      this.setBadge('●');
      try {
        const r = await post(this.settings.origin, '/agent/poll', { deviceId: this.settings.deviceId }, POLL_MS + 10000);
        if (r.status === 401) { this.setBadge('×'); return this.scheduleRetry(); }
        const commands = (r.data && r.data.commands) || [];
        for (const cmd of commands) {
          let ok = true, data = null, error = null;
          try { data = await this.execute(cmd.op, cmd.args || {}); }
          catch (e) { ok = false; error = e.message; }
          await post(this.settings.origin, '/agent/result', { deviceId: this.settings.deviceId, commandId: cmd.id, ok, data, error }, 15000);
        }
      } catch (e) {
        this.setBadge('○');
        return this.scheduleRetry();
      }
    }
    this.setBadge('○');
  }

  // ── vault ops (the ONLY code that touches vault files) ─────────────────────
  async execute(op, args) {
    if (op === 'list') {
      const files = this.app.vault.getFiles().slice(0, 500);
      return { count: files.length, files: files.map((f) => ({ path: f.path, size: f.stat.size, mtime: f.stat.mtime })) };
    }
    if (op === 'read') {
      const p = safePath(args.path);
      if (!p) throw new Error('invalid path');
      const f = this.app.vault.getAbstractFileByPath(p);
      if (f instanceof TFile) {
        return { path: p, content: await this.app.vault.read(f) };
      }
      const exists = await this.app.vault.adapter.exists(p);
      if (!exists) throw new Error('not found');
      return { path: p, content: await this.app.vault.adapter.read(p) };
    }
    if (op === 'search') {
      const q = String(args.query || '').toLowerCase();
      if (q.length < 1 || q.length > 128) throw new Error('bad query');
      const results = [];
      let scanned = 0;
      for (const f of this.app.vault.getFiles()) {
        if (results.length >= 50) break;
        if (!/\.(md|txt|json|csv|canvas)$/i.test(f.path)) continue;
        if (f.stat.size > 1024 * 1024) continue;
        scanned += 1;
        let content;
        try { content = await this.app.vault.read(f); } catch { continue; }
        const lines = content.split('\n');
        for (let i = 0; i < lines.length && results.length < 50; i++) {
          const idx = lines[i].toLowerCase().indexOf(q);
          if (idx !== -1) {
            results.push({
              path: f.path,
              line: i + 1,
              snippet: lines[i].trim().slice(0, 140),
            });
          }
        }
      }
      return { query: q, scanned, results };
    }
    if (op === 'write') {
      const p = safePath(args.path);
      if (!p || typeof args.content !== 'string' || args.content.length > 256000) throw new Error('invalid path or content');
      // Task 40 §6 — hashBefore: 64-hex (MODIFY) | null/absent (CREATE).
      const hashBefore = args.hashBefore === undefined || args.hashBefore === null ? null : String(args.hashBefore);
      if (hashBefore !== null && !/^[0-9a-f]{64}$/.test(hashBefore)) throw new Error('hashBefore must be 64-hex or null');
      const existing = this.app.vault.getAbstractFileByPath(p);
      const existsAsFile = existing instanceof TFile;
      const exists = existsAsFile ? true : await this.app.vault.adapter.exists(p);
      if (exists) {
        if (hashBefore === null) {
          throw new Error('HASH_BEFORE REQUIRED — refusing blind overwrite (read the file first, pass its sha256)');
        }
        // READ → HASH → COMPARE — if the source changed since the caller's
        // last read, FAIL CLOSED (no write, no silent overwrite).
        const current = existsAsFile ? await this.app.vault.read(existing) : await this.app.vault.adapter.read(p);
        const actual = await sha256Hex(current);
        if (actual !== hashBefore) {
          throw new Error(`SOURCE_CHANGED — expected ${hashBefore.slice(0, 12)}… got ${actual.slice(0, 12)}… (no write; re-read and retry)`);
        }
        if (existsAsFile) { await this.app.vault.modify(existing, args.content); }
        else { await this.app.vault.adapter.write(p, args.content); }
      } else {
        if (hashBefore !== null) {
          throw new Error('FILE DOES NOT EXIST — refusing hashBefore on create (pass null)');
        }
        await this.app.vault.create(p, args.content); // creates parent folders
      }
      // READ BACK → HASH AFTER — the write is only reported OK if the
      // read-back hash exists (partial/interrupted writes surface here).
      const writtenFile = this.app.vault.getAbstractFileByPath(p);
      const readBack = writtenFile instanceof TFile
        ? await this.app.vault.read(writtenFile)
        : await this.app.vault.adapter.read(p);
      const hashAfter = await sha256Hex(readBack);
      return { path: p, bytes: readBack.length, created: !exists, hashBefore, hashAfter };
    }
    throw new Error(`unknown op '${op}'`);
  }
}

// ── Settings tab ──────────────────────────────────────────────────────────────

class BridgeSettingTab extends PluginSettingTab {
  constructor(app, plugin) {
    super(app, plugin);
    this.plugin = plugin;
  }

  display() {
    const { containerEl } = this;
    containerEl.empty();

    containerEl.createEl('h2', { text: 'ProofBridge Vault Bridge' });

    new Setting(containerEl)
      .setName('Dashboard origin')
      .setDesc('Set automatically by QR pairing (the obsidian:// URI).')
      .addText((t) => t.setValue(this.plugin.settings.origin).onChange(async (v) => {
        this.plugin.settings.origin = v.trim();
        await this.plugin.saveData(this.plugin.settings);
      }));

    new Setting(containerEl)
      .setName('Device name')
      .addText((t) => t.setValue(this.plugin.settings.deviceName).onChange(async (v) => {
        this.plugin.settings.deviceName = v.slice(0, 64);
        await this.plugin.saveData(this.plugin.settings);
      }));

    new Setting(containerEl)
      .setName('Status')
      .setDesc(this.plugin.linked()
        ? `PAIRED · device ${this.plugin.settings.deviceId} · ${this.plugin.settings.origin}`
        : 'NOT PAIRED — scan the dashboard QR on the #/bridge projection.');

    new Setting(containerEl)
      .setName('Pair now')
      .setDesc('Scan the QR (camera) or paste the obsidian://proofbridge-pair URI here.')
      .addButton((b) => b.setButtonText('Paste pairing URI').onClick(() => this.plugin.promptForPairUri()));

    new Setting(containerEl)
      .setName('Unpair')
      .setDesc('Forget this device identity (the dashboard forgets nothing — receipts are immutable).')
      .addButton((b) => b.setButtonText('Unpair').setWarning().onClick(() => this.plugin.unpair()));
  }
}

module.exports = ProofBridgeVaultBridgePlugin;
