# ProofBridge Field Bridge

VVU FIELD ONBOARDING agent — pairs this device to the ProofBridge field node
(FIELD-09, mini-service `:3005`) by QR (`obsidian://vvu-onboard`). Nonce →
device keypair → HMAC challenge/response → paired credential → field ops →
hash-chained receipts.

- Install steps: see `INSTALL.md`.
- Security contract: see `SECURITY_LOCK.md` (verbatim §1–§8 of the template).
- **Governing spec: `ProofBridge/TEMPLATE_QR_BRIDGE.md` v1.1.0** — read it in
  full before touching `main.js`. §17 is the line to remember:
  *QR = reference. Server = authority. Receipt = truth. Nothing else.*

Catalogue status (§3 vocabulary): **UNVERIFIED** — prototype; protocol tested
but not verified on a real Android field device. Do not relabel VERIFIED
without the §13 provenance set attached.
