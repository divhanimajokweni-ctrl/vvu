# ProofBridge Field Bridge — install (the ONE manual step)

**STATUS: PROTOTYPE — REUSING PAYMENT RAIL, UNVERIFIED ON FIELD DEVICE.**
Protocol tested ≠ mobile client tested ≠ live bridge tested.
No new runner. No vault upload. QR pairing is the only per-device setup action.

## What this is

`proofbridge-field-bridge` is the VVU FIELD ONBOARDING phone agent. It reuses
the **exact verified loop** of `proofbridge-vault-bridge` (Task 36, 20/20
adversarial tests PASS on :3004): `pair → hello → HMAC auth → 25s long-poll →
execute → result`, rebranded for field node **FIELD-09**, protocol
**VVU-FIELD-ONBOARD-2026**, service **:3005**.

## One-time install (once per phone)

1. Copy this folder (`proofbridge-field-bridge/`) into the vault's
   `.obsidian/plugins/` directory on the phone.
2. Obsidian → Settings → Community plugins → turn OFF *Restricted mode* →
   enable **ProofBridge Field Bridge**.

That is the only manual step. Everything after is QR pairing.

## Pair (per device, seconds)

1. Open the dashboard `#/field` projection (the live origin).
2. Press **RE-MINT** — a QR appears (fresh one-time nonce, 300s window).
3. Scan it with the phone **camera** — Obsidian opens via
   `obsidian://vvu-onboard?payload=…` and the plugin:
   - decodes `{endpoint, nonce, expiry, node, protocol}` (QR = bootstrap, NOT the secret),
   - generates a device keypair (Ed25519 via WebCrypto when supported; phones
     without it fall back to `HMAC-ONLY-FIELD-DEVICE`),
   - binds the public key at `/agent/pair` (single-use nonce → device secret),
   - authenticates by challenge/response (HMAC-SHA256) and enters the
     long-poll command loop. Status bar shows `VVU-FIELD ●`.
4. The `#/field` projection flips **AGENT ONLINE** — search / read / write the
   live field store; every op returns a hash-chained receipt.

## Security notes (honest)

- QR is **bootstrap only**: one-time nonce, single-use, dead after pairing —
  replay gets 401. The "SECRET: VVUACTIVATIONKEY" poster label is **display
  only**; the real auth underneath is nonce + device keypair + HMAC.
- The device credential lives in plugin data **on the phone**. Obsidian mobile
  has no SecretStorage API — pilot-grade storage, noted, not hidden.
- Session auth is pilot-grade symmetric HMAC over the gateway's TLS — NOT
  hardware Ed25519 signing (that is Mk-node lineage work).
- Files never leave the phone: only op results and receipts transit.
- **Unpair/revocation**: settings tab → *Unpair* proves possession of the
  device secret and the node drops the field_device (receipts immutable).

## Ops relayed

| op    | args                     | result                          |
|-------|--------------------------|---------------------------------|
| list  | —                        | up to 500 files `{path,size,mtime}` |
| search| `{query}` 1..128 chars   | ≤50 hits `{path,line,snippet}` over md/txt/json/csv/canvas ≤1MB |
| read  | `{path}` vault-relative  | `{path,content}` (path-traversal guarded) |
| write | `{path,content}` ≤256KB  | `{path,bytes}` (creates folders) |
