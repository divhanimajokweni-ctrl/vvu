# SECURITY_LOCK — ProofBridge QR Bridge

Verbatim copy of §1–§8 of `ProofBridge/TEMPLATE_QR_BRIDGE.md` (v1.1.0), as mandated by §12 of that template. This file is the security contract for this build. It travels with the code. It does not get paraphrased, shortened, or "improved."

---

## 1. The one rule that overrides every other rule

The QR is not a secret. The QR is a reference to a secret the server holds.

If you find yourself putting any of these into the QR payload — stop:

· an API key
· a payment token
· an activation key
· a bearer token
· a private key
· a password
· a shared TOTP secret
· a Vercel secret
· a database credential
· a permanent device identity

The QR carries five things and only five things:

```
{
  "v": 2,
  "type": "proofbridge_ephemeral_pairing_ref",
  "ref": "<opaque server-generated ID>",
  "op":  "<operation the token authorizes>",
  "iat": <issued-at unix seconds>,
  "exp": <expiry unix seconds>,
  "single_use": true,
  "scoped_to": "<allowed operation>",
  "tier": "<product/access tier>"
}
```

Nothing else. Ever.

---

## 2. The six-state lifecycle

Every pairing reference moves through these states, on the server, not on the client:

```
UNPAID → PENDING → PAID → AUTHORIZED → REDEEMED
                                   ↘ EXPIRED
                                   ↘ REVOKED
                                   ↘ FAILED
```

The client never declares a state. The server decides. If the client posts {"paid": true}, the server ignores it. The payment rail is authoritative. This is the only line in this document that must survive any code review, refactor, or rewrite.

---

## 3. The seven allowed catalogue statuses

If you are labelling a surface (a page, a plugin, a rail), you use exactly one of these words and no other:

```
ASSEMBLY READY
DOCUMENTED
DEMONSTRATION
VERIFIED
PILOT AVAILABLE
UNVERIFIED
BLOCKED
```

Do not use VERIFIED or QUALITY PASS unless there is a hash, a commit SHA, or a signed receipt attached. If the evidence is missing, the status is UNVERIFIED or BLOCKED. Not "almost done." Not "basically ready." Those two phrases are forbidden in this build.

---

## 4. The onboarding flow — one path, no shortcuts

```
1. Client (operator UI) requests a new pairing token:
     POST /pairing-token
     { operation, tier }
   Server responds:
     { ref, op, iat, exp, ttl_seconds, single_use }
   Server writes a WORM event:
     event_type: "pairing.token.issued"
     payload: { ref_hash, operation, tier, exp }

2. Client renders QR from the payload.

3. Phone scans QR → opens deep link → sends to server:
     POST /pairing-redeem
     { ref, device_pubkey, device_label }

4. Server:
     a. Validates ref exists, not expired, not already redeemed, not revoked.
     b. Checks payment/access state for the tier.
     c. Checks the requesting device is not already bound.
     d. Binds device_pubkey to the ref's operation.
     e. Issues a device-scoped session credential.
     f. Writes WORM events:
          "pairing.token.validated"
          "device.credential.issued"
          "onboarding.receipt"
     g. Returns the receipt.

5. Client displays receipt to the user.
```

There is no sixth step. There is no "trust me" path. There is no "skip validation in dev."

---

## 5. The receipt

Every successful onboarding returns one receipt. It contains exactly these fields and no others:

```
{
  "operation_id": "...",
  "timestamp": "...",
  "product_or_access_tier": "...",
  "payment_or_access_decision": "AUTHORIZED",
  "device_identity": "<pubkey fingerprint>",
  "verification_state": "VERIFIED",
  "receipt_hash": "<sha256 of the canonical receipt body>"
}
```

No payment credentials. No secret values. No bearer tokens. No PII beyond the device fingerprint.

The receipt is the only thing the user takes away. Everything else dies at redemption.

---

## 6. Expiry and single-use — non-negotiable

· TTL: between 30 seconds and 300 seconds. Never longer.
· Single-use: after REDEEMED, the ref is dead. Replay attempts return REPLAY_REJECTED. Not "invalid token." The exact reason.
· Revocation: the operator can revoke any outstanding ref at any time. Revocation writes a WORM event.
· No re-issue of an existing ref. Every pairing is a new ref. Every time.

---

## 7. The device binding

· The phone generates its own keypair. Ed25519 preferred. WebCrypto when available.
· The public key is sent to the server only during redemption.
· The server binds device_pubkey → operation + tier + expiry.
· The private key never leaves the phone.
· If a phone has no WebCrypto (older Android browser), the plugin labels the device HMAC-ONLY-DEVICE and the server treats it at a lower trust tier. It is not refused. It is labelled.
· FIELD-09 is not a shared secret. If it appears as a device label, the server generates a fresh device identity and binds the credential to that. Never use FIELD-09 as a password.

---

## 8. What the QR must never do

· It must not grant unrestricted payment access.
· It must not survive across devices.
· It must not be re-scannable after redemption.
· It must not be photographed and reused.
· It must not encode a web URL that auto-fetches from a third-party service at render time.

If your implementation uses api.qrserver.com or any external QR renderer at runtime — stop. Render the QR locally. The QR contains a reference; the render call must not leak the reference to a third party.
