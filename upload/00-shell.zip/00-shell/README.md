# 00 · Shell (Fused Twin cockpit)

The Next.js shell that fuses all 9 rooms into one mobile-first cockpit.

## What's in here
- `src/app/page.tsx` — the shell (VIEW/DATA toggle, 9 tabs, fail-closed monitor)
- `src/lib/worm.ts` — canonical SHA-256 + RFC-8785 JCS hash chain
- `src/app/api/verify-chain/route.ts` — offline chain verifier (no API key)
- `src/app/layout.tsx` + `src/app/globals.css` — the app shell

## The three invariants this enforces
1. Render is deterministic from StateVector; sensor dead → red wireframe, no carry-forward
2. Every transition (including ABSENT) is appended to the hash chain
3. User can recompute the chain independently; receipt is a Merkle root

## To run
Drop into a Next.js 16 project, `bun install`, `bun run dev`. Each room
(surface) goes in `public/surfaces/`. The pilot is a native component
(see `08-pilot.zip`).

