/**
 * VVU · WORM chain — canonical SEARM implementation
 * ─────────────────────────────────────────────────
 * Implements the spec from `searm-worm-chain`:
 *   • RFC 8785 JCS canonicalisation (via the `canonicalize` package)
 *   • SHA-256 source_hash + chain_hash with domain separation
 *   • seq encoded as 8-byte big-endian unsigned integer
 *   • GENESIS = SHA256(DOMAIN_CHAIN + 'GENESIS')
 *   • verifyChain() — genesis, sequence continuity, source hash, chain link
 *
 * This lib is isomorphic: it runs in the browser (Web Crypto) and in the
 * Next.js server runtime (Web Crypto via the Edge/Node crypto.subtle).
 * It has ZERO network dependencies. The verifier needs no API key.
 *
 * Signatures (Ed25519) and TSA anchoring (RFC 3161) are part of the full
 * spec but are intentionally not enforced here: this shell aggregates
 * *display* events from embedded surfaces, not authoritative physical-state
 * receipts. The entry carries `meta.signature` (empty) + `meta.sig_scheme`
 * so the verifier can warn (not fail) when signatures are absent — the same
 * posture the spec takes for a missing TSA anchor.
 */
import canonicalize from 'canonicalize'

/* ── Domain separation (versioned, per spec) ──────────────────────────── */
export const DOMAIN_SOURCE = 'VVU-SOURCE-v1'
export const DOMAIN_CHAIN = 'VVU-CHAIN-v1'
export const GENESIS = 'GENESIS'

/* ── Receipt-type vocabulary (searm-vertical-vocabulary) ──────────────── */
export const RECEIPT = {
  TELEMETRY: 'TELEMETRY',
  ABSENCE_RECEIPT: 'ABSENCE_RECEIPT',
  HEARTBEAT: 'HEARTBEAT',
  LEAK_ACTIVE: 'LEAK_ACTIVE',
  BREAKER_TRIPPED: 'BREAKER_TRIPPED',
  SENSOR_ABSENT: 'SENSOR_ABSENT',
  FAIL_CLOSED: 'FAIL_CLOSED',
  NODE_UNREACHABLE: 'NODE_UNREACHABLE',
  TSA_ANCHOR: 'TSA_ANCHOR',
} as const

/* ── Surface mode (No-Primitives Law: three-layer tagging) ───────────── */
export type SurfaceMode = 'LIVE' | 'SIM' | 'DEMO' | 'GAME'

export interface ChainEntry {
  seq: number
  type: string // a RECEIPT.* value, or a surface event name
  timestamp: string // ISO 8601
  source: string // surface id or 'SHELL'
  mode: SurfaceMode // LIVE / SIM / DEMO / GAME — tags the provenance
  details: string
  source_hash: string // SHA256(DOMAIN_SOURCE + canonicalize(payload))
  chain_hash: string // SHA256(DOMAIN_CHAIN + prev + source_hash + seqBE)
  meta: {
    signature: string // base64 Ed25519 sig, or '' if unsigned
    sig_scheme: 'ed25519' | 'none'
    signed_at: string
  }
}

export interface Chain {
  genesis: string
  entries: ChainEntry[]
}

export interface VerifyResult {
  ok: boolean
  verified: number
  head: string
  genesis: string
  error?: string
  errorSeq?: number
  warnings: string[]
}

/* ── SHA-256 (Web Crypto — works in browser + Node/Edge runtime) ──────── */
export async function sha256Hex(text: string): Promise<string> {
  const data = new TextEncoder().encode(text)
  const buf = await crypto.subtle.digest('SHA-256', data)
  return Array.from(new Uint8Array(buf))
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('')
}

/* ── seq as 8-byte big-endian ──────────────────────────────────────────── */
function seqToBytes(seq: number): string {
  const buf = new ArrayBuffer(8)
  const view = new DataView(buf)
  view.setBigUint64(0, BigInt(seq), false) // false = big-endian
  return Array.from(new Uint8Array(buf))
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('')
}

/* ── Genesis hash (computed once, cached) ──────────────────────────────── */
let _genesisCache: string | null = null
export async function genesisHash(): Promise<string> {
  if (_genesisCache) return _genesisCache
  _genesisCache = await sha256Hex(DOMAIN_CHAIN + GENESIS)
  return _genesisCache
}

/* ── Build a payload (entry minus hash/seq/meta fields) for hashing ───── */
function payloadOf(entry: Omit<ChainEntry, 'source_hash' | 'chain_hash' | 'meta'>) {
  // The payload is the entry WITHOUT source_hash, chain_hash, seq, meta
  // (seq is included in the chain_hash separately, not in source_hash).
  // Per spec: source_hash = SHA256(DOMAIN_SOURCE + canonicalize(payload))
  // where payload = entry with source_hash, chain_hash, seq, meta stripped.
  const payload: Record<string, unknown> = {
    type: entry.type,
    timestamp: entry.timestamp,
    source: entry.source,
    mode: entry.mode,
    details: entry.details,
  }
  return payload
}

/* ── Append an entry to the chain ──────────────────────────────────────── */
export async function buildEntry(
  partial: Omit<ChainEntry, 'source_hash' | 'chain_hash' | 'meta'>,
  prevChainHash: string,
): Promise<ChainEntry> {
  const payload = payloadOf(partial)
  const canon = canonicalize(payload)
  if (!canon) throw new Error('JCS canonicalisation failed (non-finite values?)')
  const sourceHash = await sha256Hex(DOMAIN_SOURCE + canon)
  const chainHash = await sha256Hex(
    DOMAIN_CHAIN + prevChainHash + sourceHash + seqToBytes(partial.seq),
  )
  return {
    ...partial,
    source_hash: sourceHash,
    chain_hash: chainHash,
    meta: {
      signature: '',
      sig_scheme: 'none',
      signed_at: new Date().toISOString(),
    },
  }
}

/* ── Create an empty chain (with correct genesis) ──────────────────────── */
export async function createChain(): Promise<Chain> {
  return { genesis: await genesisHash(), entries: [] }
}

/* ── Verifier (canonical, offline, no API key) ───────────────────────────
 * Performs, in order:
 *   1. Genesis check
 *   2. Sequence continuity (SEQ_GAP)
 *   3. Source hash (SOURCE_HASH_MISMATCH)
 *   4. Chain link (CHAIN_LINK_BROKEN)
 *   5. Signature presence (SIG_UNSUPPORTED warning, not failure)
 *   6. Liveness warnings (gaps > 5 min, no TSA anchor)
 * Returns { ok, verified, head, warnings } or { ok:false, error, errorSeq }.
 */
export async function verifyChain(chain: Chain): Promise<VerifyResult> {
  const warnings: string[] = []

  // 1. Genesis
  const expectedGenesis = await genesisHash()
  if (chain.genesis !== expectedGenesis) {
    return {
      ok: false,
      verified: 0,
      head: '',
      genesis: chain.genesis,
      error: 'GENESIS_MISMATCH',
      warnings: ['Chain genesis does not match SHA256(VVU-CHAIN-v1 + GENESIS)'],
    }
  }

  let prevHash = expectedGenesis
  let lastTs: number | null = null

  for (let i = 0; i < chain.entries.length; i++) {
    const entry = chain.entries[i]

    // 2. Sequence continuity
    if (entry.seq !== i) {
      return {
        ok: false,
        verified: i,
        head: prevHash,
        genesis: chain.genesis,
        error: 'SEQ_GAP',
        errorSeq: i,
        warnings,
      }
    }

    // 3. Source hash
    const payload = payloadOf(entry)
    const canon = canonicalize(payload)
    if (!canon) {
      return {
        ok: false,
        verified: i,
        head: prevHash,
        genesis: chain.genesis,
        error: 'SOURCE_HASH_MISMATCH',
        errorSeq: i,
        warnings: [...warnings, `canonicalisation failed at seq ${i}`],
      }
    }
    const expectedSourceHash = await sha256Hex(DOMAIN_SOURCE + canon)
    if (entry.source_hash !== expectedSourceHash) {
      return {
        ok: false,
        verified: i,
        head: prevHash,
        genesis: chain.genesis,
        error: 'SOURCE_HASH_MISMATCH',
        errorSeq: i,
        warnings,
      }
    }

    // 4. Chain link
    const expectedChainHash = await sha256Hex(
      DOMAIN_CHAIN + prevHash + entry.source_hash + seqToBytes(entry.seq),
    )
    if (entry.chain_hash !== expectedChainHash) {
      return {
        ok: false,
        verified: i,
        head: prevHash,
        genesis: chain.genesis,
        error: 'CHAIN_LINK_BROKEN',
        errorSeq: i,
        warnings,
      }
    }

    // 5. Signature (warning only — this shell's chain is unsigned by design)
    if (entry.meta.sig_scheme === 'none' || !entry.meta.signature) {
      // warn once, not per-entry
      if (!warnings.includes('⚠ NO SIGNATURES (chain is unsigned display ledger)')) {
        warnings.push('⚠ NO SIGNATURES (chain is unsigned display ledger)')
      }
    }

    // 6. Liveness warnings
    const ts = Date.parse(entry.timestamp)
    if (!Number.isNaN(ts) && lastTs !== null) {
      const gapMin = (ts - lastTs) / 60000
      if (gapMin > 5) {
        warnings.push(`⚠ GAP: ${gapMin.toFixed(1)} min between seq ${i - 1} and ${i}`)
      }
    }
    if (!Number.isNaN(ts)) lastTs = ts

    prevHash = entry.chain_hash
  }

  // No TSA anchor in this shell — warn once
  if (!warnings.some((w) => w.includes('NO TSA ANCHOR'))) {
    warnings.push('⚠ NO TSA ANCHOR (display ledger; not RFC-3161 timestamped)')
  }

  return {
    ok: true,
    verified: chain.entries.length,
    head: prevHash,
    genesis: chain.genesis,
    warnings,
  }
}
