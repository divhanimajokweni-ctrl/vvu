/**
 * POST /api/verify-chain
 * ────────────────────────
 * Canonical server-side WORM chain verifier (searm-worm-chain skill).
 * Receives a chain JSON, returns the verdict. Runs offline — no network
 * calls during execution, no API key, no DB. Just SHA-256 + JCS.
 *
 * This is the server reference implementation. The shell also verifies
 * client-side (instant, local-first); this route exists so an external
 * auditor with the exported chain.json can verify without running the SPA.
 */
import { NextResponse } from 'next/server'
import { verifyChain, type Chain } from '@/lib/worm'

export const dynamic = 'force-dynamic'
export const runtime = 'nodejs'

export async function POST(req: Request) {
  let body: unknown
  try {
    body = await req.json()
  } catch {
    return NextResponse.json(
      { ok: false, error: 'INVALID_JSON', details: 'Body must be a JSON chain object' },
      { status: 400 },
    )
  }

  const chain = body as Chain
  if (!chain || typeof chain !== 'object' || typeof chain.genesis !== 'string' || !Array.isArray(chain.entries)) {
    return NextResponse.json(
      { ok: false, error: 'INVALID_CHAIN', details: 'Expected { genesis: string, entries: ChainEntry[] }' },
      { status: 400 },
    )
  }

  const result = await verifyChain(chain)

  if (result.ok) {
    return NextResponse.json({
      ok: true,
      verdict: 'CHAIN INTACT',
      verified: result.verified,
      head: result.head,
      genesis: result.genesis,
      warnings: result.warnings,
      message: `✅ CHAIN INTACT: ${result.verified} entries verified`,
    })
  }

  return NextResponse.json({
    ok: false,
    verdict: result.error,
    verified: result.verified,
    head: result.head,
    errorSeq: result.errorSeq,
    warnings: result.warnings,
    message: `❌ ${result.error} at seq ${result.errorSeq}`,
  })
}
