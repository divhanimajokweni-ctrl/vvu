import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "VVU · FUSED TWIN",
  description: "VVU integrated twin cockpit — fuses map+avatar, map3D, photoreal rig, assembly line, lab, SEARM admin, WebXR viewer and the free-city road-run into one lazy-loaded, hash-addressable shell with a shared WORM ticker.",
  keywords: ["VVU", "SEARM", "digital twin", "WORM chain", "MapLibre", "Three.js", "manufacturing", "fail-closed"],
  authors: [{ name: "VVU · Fused Twin" }],
  icons: {
    icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
  },
  openGraph: {
    title: "VVU · FUSED TWIN",
    description: "Integrated twin cockpit · WORM-chained surfaces",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "VVU · FUSED TWIN",
    description: "Integrated twin cockpit · WORM-chained surfaces",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning className="dark">
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased`}
        style={{ background: '#050505', color: '#8fb35a', margin: 0 }}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
