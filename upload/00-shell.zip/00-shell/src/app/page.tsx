'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import dynamic from 'next/dynamic'
import {
  buildEntry,
  createChain,
  genesisHash,
  verifyChain,
  RECEIPT,
  type Chain,
  type ChainEntry,
  type SurfaceMode,
} from '@/lib/worm'
import { generateReceiptPdf, type ReceiptData } from '@/lib/pilot/receipt'

/* ═══════════════════════════════════════════════════════════════════════
   VVU · FUSED TWIN — operational surface shell (SEARM-compliant, mobile-first)
   -----------------------------------------------------------------------
   Two modes, each FULL SCREEN, never competing:
     • VIEW — the active surface (map, rig, factory, pilot, …) fills the
              entire stage. No data panels, no ticker, no log. Just the view.
     • DATA — the WORM ledger, verify, export, history. Fills the entire
              stage. No surface visible.

   Toggle between them with the VIEW/DATA button (or the 'D' key).

   The canonical SHA-256 + RFC-8785-JCS WORM chain still aggregates every
   surface's postMessage events in the background, regardless of which mode
   is on screen. The chain persists to localStorage (local-first) and can be
   verified client-side or via /api/verify-chain (offline, no API key).

   Each surface is mode-tagged (LIVE / SIM / DEMO / GAME) per the
   No-Primitives Law. The active telemetry surface is fail-closed-monitored
   (15s → SENSOR_ABSENT, 60s → FAIL_CLOSED + breaker trip).
   ═══════════════════════════════════════════════════════════════════════ */

/* PilotRoom is a native Three.js component (room 9), loaded dynamically */
const PilotRoom = dynamic(() => import('@/components/pilot/PilotRoom'), { ssr: false })

type TabId = 'avatar' | 'map3d' | 'rig' | 'assembly' | 'lab' | 'admin' | 'viewer' | 'city' | 'pilot'

interface Tab {
  id: TabId
  key: string
  label: string
  src?: string // for iframe surfaces
  native?: boolean // for component surfaces (pilot)
  hint: string
  mode: SurfaceMode
  telemetry: boolean
  heavy?: boolean
}

const TABS: Tab[] = [
  { id: 'avatar',   key: '1', label: 'MAP+AVATAR', src: '/surfaces/map-avatar.html', hint: 'MapLibre + photoreal head · PIP swap · FSM · vitals · ECG', mode: 'SIM',  telemetry: true },
  { id: 'map3d',    key: '2', label: 'MAP 3D',     src: '/surfaces/map-libre.html',  hint: 'MapLibre 3D · GIS spatial truth · node array · FSM console', mode: 'SIM',  telemetry: true },
  { id: 'rig',      key: '3', label: 'RIG',        src: '/surfaces/rig.html',        hint: 'HBK-MkII photoreal manufacturing loop · GLB 6-axis arms', mode: 'SIM',  telemetry: true },
  { id: 'assembly', key: '4', label: 'ASSEMBLY',   src: '/surfaces/assembly.html',   hint: '8-station assembly-line sim · KPIs · fault mode · multi-view', mode: 'SIM',  telemetry: false },
  { id: 'lab',      key: '5', label: 'LAB',        src: '/surfaces/lab.html',        hint: '3D lab workspace · zones · slide deck · spawnable tools', mode: 'DEMO', telemetry: false },
  { id: 'admin',    key: '6', label: 'ADMIN',       src: '/surfaces/admin.html',      hint: 'SEARM command center · disruption switches · beeswarm XAI · ESTOP', mode: 'DEMO', telemetry: false },
  { id: 'viewer',   key: '7', label: 'VIEWER',     src: '/surfaces/viewer.html',     hint: 'WebXR GLB viewer · 6-axis robot · VR-ready · drop-to-load', mode: 'LIVE', telemetry: false },
  { id: 'pilot',    key: '8', label: 'PILOT',      native: true, hint: 'Neave Industrial Park pilot · one room, one sensor, one hash chain', mode: 'SIM', telemetry: true },
  { id: 'city',     key: '9', label: 'FREE CITY',  src: '/surfaces/free-city.html',  hint: 'Road-run game · 3.4 MB · lazy-loaded on first open', mode: 'GAME', telemetry: false, heavy: true },
]

const HASH_TO_TAB: Record<string, TabId> = {
  avatar: 'avatar', map: 'avatar', mapavatar: 'avatar',
  map3d: 'map3d', map3: 'map3d', libre: 'map3d',
  rig: 'rig', manufacturing: 'rig',
  assembly: 'assembly', line: 'assembly',
  lab: 'lab', workspace: 'lab',
  admin: 'admin', searm: 'admin', command: 'admin',
  viewer: 'viewer', webxr: 'viewer', glb: 'viewer',
  pilot: 'pilot', room: 'pilot', mvp: 'pilot',
  city: 'city', freecity: 'city', game: 'city',
}

const CHAIN_STORAGE_KEY = 'vvu-fused-twin-chain-v1'
const FAIL_CLOSED_MS = 15000
const HEARTBEAT_MS = 60000
const RENDER_CAP = 120
const PERSIST_CAP = 1000

type SurfaceState = 'LIVE' | 'SENSOR_ABSENT' | 'FAIL_CLOSED'
type ViewMode = 'view' | 'data'

/* ── Pilot state (room 9 drives its own state + posts to the chain) ────── */
interface PilotState {
  status: 'PRESENT' | 'ABSENT'
  x: number
  z: number
  alert: 'ALERT_TRIGGERED' | 'OBSERVATION_MISSING' | null
}

export default function Home() {
  const [active, setActive] = useState<TabId>('avatar')
  const [loaded, setLoaded] = useState<Set<TabId>>(new Set(['avatar']))
  const [entries, setEntries] = useState<ChainEntry[]>([])
  const [clock, setClock] = useState('SIM 00:00')
  const [viewMode, setViewMode] = useState<ViewMode>('view')
  const [surfaceState, setSurfaceState] = useState<SurfaceState>('LIVE')
  const [breakerTripped, setBreakerTripped] = useState(false)
  const [verifyResult, setVerifyResult] = useState<string | null>(null)
  const [verifying, setVerifying] = useState(false)
  const [pilotState, setPilotState] = useState<PilotState>({ status: 'ABSENT', x: 0, z: 0, alert: null })

  const chainRef = useRef<Chain | null>(null)
  const logQueue = useRef<Promise<void>>(Promise.resolve())
  const bootRef = useRef(false)
  const lastEventAt = useRef<Record<string, number>>({})
  const lastHeartbeatAt = useRef<number>(Date.now())
  const absentEmitted = useRef<Set<string>>(new Set())
  const failClosedEmitted = useRef<Set<string>>(new Set())
  const framesRef = useRef<Record<string, HTMLIFrameElement | null>>({})
  const originRef = useRef<string>('')

  /* ── Persist chain to localStorage ──────────────────────────────────── */
  const persist = useCallback(() => {
    if (!chainRef.current) return
    try {
      const toStore: Chain = {
        genesis: chainRef.current.genesis,
        entries: chainRef.current.entries.slice(-PERSIST_CAP),
      }
      localStorage.setItem(CHAIN_STORAGE_KEY, JSON.stringify(toStore))
    } catch {
      /* quota or private mode */
    }
  }, [])

  /* ── Append a WORM entry (serialized to preserve chain order) ──────── */
  const log = useCallback(
    (type: string, details: string, source: string, mode: SurfaceMode) => {
      logQueue.current = logQueue.current.then(async () => {
        const chain = chainRef.current
        if (!chain) return
        const seq = chain.entries.length
        const prevHash = chain.entries.at(-1)?.chain_hash ?? chain.genesis
        const entry = await buildEntry(
          { seq, type, timestamp: new Date().toISOString(), source, mode, details: String(details || '') },
          prevHash,
        )
        chain.entries.push(entry)
        if (chain.entries.length > PERSIST_CAP) {
          chain.entries = chain.entries.slice(-PERSIST_CAP)
        }
        persist()
        setEntries([...chain.entries].reverse().slice(0, RENDER_CAP))
      })
    },
    [persist],
  )

  /* ── Boot: load or create chain, emit boot receipts ─────────────────── */
  const boot = useCallback(async () => {
    if (bootRef.current) return
    bootRef.current = true
    originRef.current = window.location.origin

    let chain: Chain | null = null
    try {
      const raw = localStorage.getItem(CHAIN_STORAGE_KEY)
      if (raw) {
        const parsed = JSON.parse(raw) as Chain
        const genesis = await genesisHash()
        if (parsed.genesis === genesis && Array.isArray(parsed.entries)) {
          chain = parsed
        }
      }
    } catch {
      /* corrupt storage */
    }
    if (!chain) chain = await createChain()
    chainRef.current = chain
    setEntries([...chain.entries].reverse().slice(0, RENDER_CAP))

    log(RECEIPT.HEARTBEAT, `SHELL_BOOT · ${TABS.length} rooms registered · chain ${chain.entries.length > 0 ? 'resumed' : 'live'}`, 'SHELL', 'LIVE')
    log('FSM_BOOT', 'STEADY_LOCKED · awaiting sensor events', 'SHELL', 'LIVE')
  }, [log])

  useEffect(() => {
    void boot()
  }, [boot])

  /* ── Clock ──────────────────────────────────────────────────────────── */
  useEffect(() => {
    const t0 = Date.now()
    const id = setInterval(() => {
      const s = Math.floor((Date.now() - t0) / 1000)
      setClock(
        'SIM ' + String(Math.floor(s / 60)).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0'),
      )
    }, 1000)
    return () => clearInterval(id)
  }, [])

  /* ── Aggregate postMessage events (origin-validated, mode-tagged) ───── */
  useEffect(() => {
    const onMessage = (ev: MessageEvent) => {
      if (ev.origin !== originRef.current && ev.origin !== 'null') return
      const d = ev.data
      if (!d || typeof d !== 'object' || d.type !== 'worm') return
      const tab = TABS.find((t) => t.src !== '')!
      const mode = tab.mode
      const source = String(d.source || active).toUpperCase()
      log(String(d.event || 'EVENT'), String(d.details || ''), source, mode)
      lastEventAt.current[source] = Date.now()
      absentEmitted.current.delete(source)
      failClosedEmitted.current.delete(source)
    }
    window.addEventListener('message', onMessage)
    return () => window.removeEventListener('message', onMessage)
  }, [log, active])

  /* ── Fail-closed monitor + heartbeat (1s tick) ─────────────────────── */
  useEffect(() => {
    const id = setInterval(() => {
      const now = Date.now()
      if (now - lastHeartbeatAt.current > HEARTBEAT_MS) {
        lastHeartbeatAt.current = now
        log(RECEIPT.HEARTBEAT, `liveness · chain head ${chainRef.current?.entries.at(-1)?.chain_hash.slice(-8) ?? 'genesis'}`, 'SHELL', 'LIVE')
      }
      const activeTab = TABS.find((t) => t.id === active)
      if (!activeTab || !activeTab.telemetry) {
        setSurfaceState('LIVE')
        return
      }
      const key = active.toUpperCase()
      if (!(key in lastEventAt.current) && bootRef.current) {
        lastEventAt.current[key] = now
      }
      const silence = now - (lastEventAt.current[key] ?? now)
      if (silence > FAIL_CLOSED_MS && !absentEmitted.current.has(key)) {
        absentEmitted.current.add(key)
        log(RECEIPT.SENSOR_ABSENT, `${key} silent ${Math.round(silence / 1000)}s`, key, activeTab.mode)
        setSurfaceState('SENSOR_ABSENT')
      }
      if (silence > HEARTBEAT_MS && !failClosedEmitted.current.has(key)) {
        failClosedEmitted.current.add(key)
        log(RECEIPT.FAIL_CLOSED, `${key} silent ${Math.round(silence / 1000)}s · breaker tripped`, key, activeTab.mode)
        log(RECEIPT.HEARTBEAT, `engine alive · sensor dead · ${key}`, 'SHELL', 'LIVE')
        setSurfaceState('FAIL_CLOSED')
        setBreakerTripped(true)
      }
    }, 1000)
    return () => clearInterval(id)
  }, [active, log])

  /* ── Tab switching ─────────────────────────────────────────────────── */
  const show = useCallback(
    (id: TabId, push = true) => {
      setActive(id)
      setLoaded((prev) => (prev.has(id) ? prev : new Set(prev).add(id)))
      setSurfaceState('LIVE')
      absentEmitted.current.delete(id.toUpperCase())
      failClosedEmitted.current.delete(id.toUpperCase())
      if (push) history.replaceState(null, '', '#' + id)
      const tab = TABS.find((t) => t.id === id)!
      log('VIEW_SWITCH', `${id.toUpperCase()} · ${tab.label} · mode=${tab.mode}`, 'SHELL', 'LIVE')
      requestAnimationFrame(() => {
        const f = framesRef.current[id]
        if (f?.contentWindow) {
          try { f.contentWindow.dispatchEvent(new Event('resize')) } catch { /* */ }
        }
      })
    },
    [log],
  )

  /* ── Keyboard 1-9 + D (view/data toggle) + V (verify) ─────────────── */
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return
      const tab = TABS.find((t) => t.key === e.key)
      if (tab) {
        e.preventDefault()
        show(tab.id, true)
        setViewMode('view')
      } else if (e.key.toLowerCase() === 'd') {
        setViewMode((v) => (v === 'view' ? 'data' : 'view'))
      } else if (e.key.toLowerCase() === 'v') {
        void doVerify(false)
      }
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [show])

  /* ── Initial tab from URL hash ────────────────────────────────────── */
  useEffect(() => {
    const h = window.location.hash.slice(1).toLowerCase()
    const id = HASH_TO_TAB[h]
    if (id && id !== 'avatar') show(id, false)
  }, [])

  /* ── Verify the chain ──────────────────────────────────────────────── */
  const doVerify = useCallback(async (useServer: boolean) => {
    if (!chainRef.current) return
    setVerifying(true)
    setVerifyResult(null)
    try {
      if (useServer) {
        const res = await fetch('/api/verify-chain', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(chainRef.current),
        })
        const data = await res.json()
        setVerifyResult(data.message || JSON.stringify(data))
      } else {
        const result = await verifyChain(chainRef.current)
        if (result.ok) {
          setVerifyResult(`✅ CHAIN INTACT: ${result.verified} entries · head ${result.head.slice(-8)}${result.warnings.length ? ' · ' + result.warnings[0] : ''}`)
        } else {
          setVerifyResult(`❌ ${result.error} at seq ${result.errorSeq}`)
        }
      }
    } catch (err) {
      setVerifyResult(`❌ VERIFY FAILED: ${err instanceof Error ? err.message : String(err)}`)
    } finally {
      setVerifying(false)
    }
  }, [])

  /* ── Reset breaker ────────────────────────────────────────────────── */
  const resetBreaker = useCallback(() => {
    setBreakerTripped(false)
    setSurfaceState('LIVE')
    absentEmitted.current.clear()
    failClosedEmitted.current.clear()
    if (chainRef.current) log('BREAKER_RESET', 'operator acknowledged · fail-cleared', 'SHELL', 'LIVE')
  }, [log])

  /* ── Export chain ─────────────────────────────────────────────────── */
  const exportChain = useCallback(() => {
    if (!chainRef.current) return
    const blob = new Blob([JSON.stringify(chainRef.current, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = 'chain.json'
    a.click()
    URL.revokeObjectURL(url)
  }, [])

  /* ── Download PDF receipt (Invariant 3: Merkle root over the chain) ── */
  const downloadPdfReceipt = useCallback(async () => {
    setVerifying(true)
    setVerifyResult(null)
    try {
      // Verify the server ledger (the authoritative sensor-data chain)
      const res = await fetch('/api/pilot/verify')
      const data = await res.json()
      if (!data.ok) {
        setVerifyResult(`❌ ${data.verdict} at seq ${data.errorSeq} · cannot generate receipt`)
        return
      }
      // Generate the PDF receipt with the Merkle root
      const receiptData: ReceiptData = {
        verdict: 'CHAIN_INTACT',
        ok: true,
        entryCount: data.entryCount,
        merkleRoot: data.merkleRoot,
        head: data.head,
        recent: (data.recent ?? []).map((e: { seq: number; event_type: string; hash: string; timestamp: string }) => ({
          seq: e.seq,
          event_type: e.event_type,
          hash: e.hash,
          timestamp: e.timestamp,
        })),
      }
      const { blob, sha256 } = await generateReceiptPdf(receiptData)
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `vvu-receipt-${Date.now()}.pdf`
      a.click()
      URL.revokeObjectURL(url)
      setVerifyResult(`✅ CHAIN INTACT: ${data.entryCount} entries · Merkle root ${data.merkleRoot.slice(0, 16)}… · PDF receipt downloaded (SHA-256 ${sha256.slice(0, 16)}…)`)
    } catch (err) {
      setVerifyResult(`❌ RECEIPT FAILED: ${err instanceof Error ? err.message : String(err)}`)
    } finally {
      setVerifying(false)
    }
  }, [])

  const entryCount = chainRef.current?.entries.length ?? entries.length
  const activeTab = TABS.find((t) => t.id === active)!

  const modeColor: Record<SurfaceMode, string> = {
    LIVE: '#c8ff00',
    SIM: '#ffaa00',
    DEMO: '#e5484d',
    GAME: '#00e0ff',
  }

  return (
    <div style={{
      display: 'flex', flexDirection: 'column',
      height: '100dvh', minHeight: '100dvh', maxHeight: '100dvh',
      background: '#050505', color: '#8fb35a',
      fontFamily: "'SF Mono','JetBrains Mono',ui-monospace,Menlo,monospace",
      fontSize: 'clamp(10px, 2.5vw, 12px)',
      overflow: 'hidden',
      // mobile safe areas
      paddingTop: 'env(safe-area-inset-top, 0px)',
      paddingBottom: 'env(safe-area-inset-bottom, 0px)',
    }}>
      {/* ═══ HEADER (sticky, mobile-first) ═══ */}
      <header style={{
        flexShrink: 0,
        display: 'flex',
        alignItems: 'center',
        gap: 'clamp(4px, 1.5vw, 8px)',
        padding: '0 clamp(6px, 2vw, 12px)',
        height: 'clamp(44px, 7vh, 48px)',
        background: '#080a08',
        borderBottom: '1px solid rgba(200,255,0,.22)',
        zIndex: 20,
      }}>
        <span style={{
          color: '#c8ff00', fontWeight: 700, letterSpacing: '.12em',
          fontSize: 'clamp(9px, 2.5vw, 11px)', whiteSpace: 'nowrap', flexShrink: 0,
        }}>
          VVU
        </span>

        {/* Tab scroller — horizontal scroll on all sizes, ≥44px touch targets */}
        <div role="tablist" aria-label="Twin rooms"
          style={{
            display: 'flex', alignItems: 'center', gap: 'clamp(3px, 1vw, 5px)',
            overflowX: 'auto', flex: 1, scrollbarWidth: 'thin',
            WebkitOverflowScrolling: 'touch',
            // hide scrollbar on mobile for cleaner look
          }}
        >
          {TABS.map((t) => {
            const on = t.id === active && viewMode === 'view'
            return (
              <button
                key={t.id}
                role="tab"
                aria-selected={on}
                title={t.hint}
                onClick={() => { show(t.id, true); setViewMode('view') }}
                style={{
                  flexShrink: 0,
                  display: 'inline-flex', alignItems: 'center', gap: 'clamp(3px, 1vw, 6px)',
                  background: on ? 'rgba(200,255,0,.12)' : 'transparent',
                  border: `1px solid ${on ? '#c8ff00' : 'rgba(200,255,0,.22)'}`,
                  color: on ? '#c8ff00' : '#8fb35a',
                  fontFamily: 'inherit',
                  fontSize: 'clamp(8px, 2vw, 10px)', fontWeight: 700, letterSpacing: '.08em',
                  padding: 'clamp(6px, 1.5vh, 8px) clamp(7px, 2vw, 12px)',
                  minHeight: 36, // touch target (36px min, scales up)
                  cursor: 'pointer', borderRadius: 3, whiteSpace: 'nowrap', transition: 'all .15s',
                }}
              >
                <span style={{ color: '#5a6a50', marginRight: 1 }}>{t.key}</span>
                {t.label}
                <span style={{
                  color: modeColor[t.mode], fontSize: 'clamp(6px, 1.5vw, 7px)',
                  border: `1px solid ${modeColor[t.mode]}55`, padding: '1px 3px', borderRadius: 2, fontWeight: 700,
                }}>{t.mode}</span>
                {t.heavy && !loaded.has(t.id) && (
                  <span style={{ color: '#5a6a50', fontSize: 6, border: '1px solid rgba(200,255,0,.2)', padding: '1px 2px', borderRadius: 2 }}>LAZY</span>
                )}
              </button>
            )
          })}
        </div>

        {/* VIEW / DATA toggle — the key architectural control */}
        <button
          onClick={() => setViewMode((v) => (v === 'view' ? 'data' : 'view'))}
          title="Toggle between VIEW and DATA screens (D)"
          style={{
            flexShrink: 0,
            display: 'flex', alignItems: 'center', gap: 4,
            background: viewMode === 'data' ? 'rgba(200,255,0,.12)' : 'transparent',
            border: `1px solid ${viewMode === 'data' ? '#c8ff00' : 'rgba(200,255,0,.4)'}`,
            color: viewMode === 'data' ? '#c8ff00' : '#8fb35a',
            fontFamily: 'inherit',
            fontSize: 'clamp(8px, 2vw, 10px)', fontWeight: 700, letterSpacing: '.1em',
            padding: 'clamp(6px, 1.5vh, 8px) clamp(8px, 2vw, 12px)',
            minHeight: 36, cursor: 'pointer', borderRadius: 3, whiteSpace: 'nowrap',
          }}
        >
          {viewMode === 'data' ? '◀ VIEW' : 'DATA ▶'}
        </button>
      </header>

      {/* ═══ STAGE — full screen, one thing at a time ═══ */}
      <main style={{ flex: 1, minHeight: 0, position: 'relative', background: '#050505' }}>
        {/* ── VIEW MODE: the active surface, full screen ── */}
        {viewMode === 'view' && (
          <>
            {/* iframe surfaces */}
            {TABS.filter((t) => t.src).map((t) => {
              const isVisible = t.id === active
              const isLoaded = loaded.has(t.id)
              if (!isLoaded) return null
              return (
                <iframe
                  key={t.id}
                  ref={(el) => { framesRef.current[t.id] = el }}
                  title={t.label}
                  src={t.src}
                  loading={t.heavy ? 'lazy' : 'eager'}
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; vr; xr-spatial-tracking; fullscreen"
                  style={{
                    position: 'absolute', inset: 0, width: '100%', height: '100%',
                    border: 0, background: '#050505',
                    display: isVisible ? 'block' : 'none',
                    filter: breakerTripped && isVisible ? 'grayscale(0.7) blur(1px)' : 'none',
                    transition: 'filter .3s',
                  }}
                />
              )
            })}

            {/* native pilot room (room 9) */}
            {loaded.has('pilot') && (
              <div style={{
                position: 'absolute', inset: 0,
                display: active === 'pilot' ? 'block' : 'none',
                filter: breakerTripped ? 'grayscale(0.7) blur(1px)' : 'none',
                transition: 'filter .3s',
              }}>
                <PilotRoom state={pilotState} onStateChange={setPilotState} onLog={log} />
              </div>
            )}

            {/* Fail-closed overlay */}
            {breakerTripped && (
              <div role="alert" style={{
                position: 'absolute', inset: 0, zIndex: 30,
                display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
                background: 'rgba(5,5,5,.82)', pointerEvents: 'none',
              }}>
                <div style={{ color: '#e5484d', fontSize: 'clamp(18px, 5vw, 24px)', fontWeight: 700, letterSpacing: '.2em', textShadow: '0 0 18px rgba(229,72,77,.5)' }}>
                  FAIL CLOSED
                </div>
                <div style={{ color: '#e5484d', opacity: 0.7, fontSize: 'clamp(8px, 2vw, 10px)', letterSpacing: '.12em', marginTop: 4, textAlign: 'center', padding: '0 16px' }}>
                  SENSOR ABSENT · BREAKER TRIPPED · AUTH REVOKED
                </div>
                <button onClick={resetBreaker} style={{
                  marginTop: 14, pointerEvents: 'auto',
                  background: 'rgba(229,72,77,.1)', border: '1px solid #e5484d', color: '#e5484d',
                  fontFamily: 'inherit', fontSize: 'clamp(9px, 2.5vw, 10px)', fontWeight: 700, letterSpacing: '.1em',
                  padding: 'clamp(8px, 2vh, 10px) clamp(12px, 3vw, 16px)',
                  minHeight: 44, cursor: 'pointer', borderRadius: 3,
                }}>
                  RESET (ack)
                </button>
              </div>
            )}

            {/* SENSOR_ABSENT banner (non-blocking) */}
            {surfaceState === 'SENSOR_ABSENT' && !breakerTripped && activeTab.telemetry && (
              <div style={{
                position: 'absolute', top: 'clamp(8px, 2vh, 12px)', left: '50%', transform: 'translateX(-50%)', zIndex: 12,
                background: 'rgba(255,170,0,.12)', border: '1px solid #ffaa00', color: '#ffaa00',
                padding: 'clamp(4px, 1vh, 6px) clamp(10px, 3vw, 16px)',
                fontSize: 'clamp(9px, 2vw, 10px)', letterSpacing: '.1em', fontWeight: 600, borderRadius: 4, pointerEvents: 'none',
              }}>
                ⚠ SENSOR_ABSENT · {active.toUpperCase()}
              </div>
            )}
          </>
        )}

        {/* ── DATA MODE: full-screen ledger, no surface ── */}
        {viewMode === 'data' && (
          <DataScreen
            entries={entries}
            entryCount={entryCount}
            modeColor={modeColor}
            verifying={verifying}
            verifyResult={verifyResult}
            onVerify={() => void doVerify(false)}
            onVerifyApi={() => void doVerify(true)}
            onExport={exportChain}
            onPdf={() => void downloadPdfReceipt()}
            clock={clock}
            breakerTripped={breakerTripped}
          />
        )}
      </main>

      {/* ═══ Minimal status bar (NOT a data ticker — just a hint) ═══ */}
      <footer style={{
        flexShrink: 0,
        display: 'flex', alignItems: 'center', gap: 'clamp(6px, 2vw, 12px)',
        padding: '0 clamp(8px, 2vw, 12px)',
        height: 'clamp(28px, 4vh, 32px)',
        background: '#080a08', borderTop: '1px solid rgba(200,255,0,.22)', zIndex: 20,
      }}>
        <span style={{
          color: breakerTripped ? '#e5484d' : '#10b981', fontWeight: 700, fontSize: 'clamp(8px, 2vw, 9px)',
          letterSpacing: '.1em', flexShrink: 0,
        }}>
          {breakerTripped ? '● TRIPPED' : '● CLOSED'}
        </span>
        <span style={{ color: '#5a6a50', fontSize: 'clamp(8px, 2vw, 9px)', fontVariantNumeric: 'tabular-nums', flexShrink: 0 }}>
          {clock}
        </span>
        {viewMode === 'view' && (
          <span style={{ color: '#5a6a50', fontSize: 'clamp(8px, 2vw, 9px)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', flex: 1, minWidth: 0 }}>
            {activeTab.label} · <span style={{ color: modeColor[activeTab.mode] }}>{activeTab.mode}</span>
          </span>
        )}
        {viewMode === 'view' && entryCount > 0 && (
          <button onClick={() => setViewMode('data')} style={{
            background: 'transparent', border: '1px solid rgba(200,255,0,.25)', color: '#5a6a50',
            fontFamily: 'inherit', fontSize: 'clamp(7px, 1.8vw, 8px)', fontWeight: 700, letterSpacing: '.1em',
            padding: '2px clamp(6px, 1.5vw, 8px)', cursor: 'pointer', borderRadius: 2, whiteSpace: 'nowrap',
            minHeight: 24,
          }}>
            {entryCount} entries →
          </button>
        )}
      </footer>

      <style>{`
        header [role="tablist"]::-webkit-scrollbar { height: 3px }
        header [role="tablist"]::-webkit-scrollbar-thumb { background: rgba(200,255,0,.25); border-radius: 2px }
        header [role="tablist"]::-webkit-scrollbar-track { background: transparent }
        .data-scroll::-webkit-scrollbar { width: 6px }
        .data-scroll::-webkit-scrollbar-thumb { background: rgba(200,255,0,.25); border-radius: 3px }
        iframe { color-scheme: dark }
        @media (max-width: 640px) {
          header [role="tablist"]::-webkit-scrollbar { display: none }
        }
      `}</style>
    </div>
  )
}

/* ═══ DATA SCREEN — full-screen ledger, its own dedicated page ══════════ */
function DataScreen({
  entries, entryCount, modeColor, verifying, verifyResult,
  onVerify, onVerifyApi, onExport, onPdf, clock, breakerTripped,
}: {
  entries: ChainEntry[]
  entryCount: number
  modeColor: Record<SurfaceMode, string>
  verifying: boolean
  verifyResult: string | null
  onVerify: () => void
  onVerifyApi: () => void
  onExport: () => void
  onPdf: () => void
  clock: string
  breakerTripped: boolean
}) {
  return (
    <div style={{
      position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column',
      background: '#050505', overflow: 'hidden',
    }}>
      {/* Data header */}
      <div style={{
        flexShrink: 0, display: 'flex', alignItems: 'center', gap: 'clamp(6px, 2vw, 12px)',
        padding: 'clamp(8px, 2vh, 12px) clamp(10px, 3vw, 16px)',
        borderBottom: '1px solid rgba(200,255,0,.15)',
        flexWrap: 'wrap',
      }}>
        <span style={{ color: '#c8ff00', fontWeight: 700, letterSpacing: '.12em', fontSize: 'clamp(10px, 2.5vw, 13px)' }}>
          WORM LEDGER
        </span>
        <span style={{ color: '#5a6a50', fontSize: 'clamp(8px, 2vw, 10px)' }}>
          {entryCount} entries · {clock}
        </span>
        <span style={{
          color: breakerTripped ? '#e5484d' : '#10b981', fontSize: 'clamp(8px, 2vw, 9px)', fontWeight: 700,
        }}>
          {breakerTripped ? '● TRIPPED' : '● CLOSED'}
        </span>

        <div style={{ marginLeft: 'auto', display: 'flex', gap: 'clamp(4px, 1vw, 6px)', flexWrap: 'wrap' }}>
          <button onClick={onVerify} disabled={verifying}
            style={dataBtnStyle(verifying, 'rgba(200,255,0,.4)', '#c8ff00')}>
            {verifying ? '…' : 'VERIFY [V]'}
          </button>
          <button onClick={onVerifyApi} disabled={verifying}
            style={dataBtnStyle(verifying, 'rgba(200,255,0,.25)', '#8fb35a')}>
            API
          </button>
          <button onClick={onPdf} disabled={verifying}
            style={dataBtnStyle(verifying, 'rgba(16,185,129,.4)', '#10b981')}>
            {verifying ? '…' : '⬇ PDF'}
          </button>
          <button onClick={onExport}
            style={dataBtnStyle(false, 'rgba(200,255,0,.25)', '#8fb35a')}>
            ⇩ JSON
          </button>
        </div>
      </div>

      {/* Verify result */}
      {verifyResult && (
        <div style={{
          padding: 'clamp(6px, 1.5vh, 8px) clamp(10px, 3vw, 16px)',
          background: verifyResult.startsWith('✅') ? 'rgba(16,185,129,.06)' : 'rgba(229,72,77,.06)',
          borderBottom: `1px solid ${verifyResult.startsWith('✅') ? 'rgba(16,185,129,.3)' : 'rgba(229,72,77,.3)'}`,
          fontSize: 'clamp(9px, 2vw, 10px)',
          color: verifyResult.startsWith('✅') ? '#10b981' : '#e5484d',
          fontVariantNumeric: 'tabular-nums', wordBreak: 'break-all',
        }}>
          {verifyResult}
        </div>
      )}

      {/* Full-screen scrollable ledger */}
      <div className="data-scroll" style={{
        flex: 1, overflowY: 'auto', padding: 'clamp(4px, 1vh, 8px) clamp(8px, 2vw, 12px)',
      }}>
        {entries.length === 0 ? (
          <div style={{ padding: '24px', color: '#5a6a50', fontSize: 'clamp(10px, 2.5vw, 12px)', textAlign: 'center' }}>
            No WORM entries yet. Switch to VIEW and open a room.
          </div>
        ) : (
          entries.map((e) => (
            <div key={e.seq} style={{
              display: 'grid',
              gridTemplateColumns: 'clamp(28px, 8vw, 40px) clamp(80px, 25vw, 130px) clamp(36px, 10vw, 50px) clamp(56px, 18vw, 70px) 1fr',
              gap: 'clamp(4px, 1.5vw, 8px)',
              padding: 'clamp(3px, 1vh, 4px) 0',
              fontSize: 'clamp(9px, 2.2vw, 10px)',
              borderBottom: '1px solid rgba(143,179,90,.06)',
              fontVariantNumeric: 'tabular-nums',
            }}>
              <span style={{ color: '#5a6a50' }}>#{String(e.seq).padStart(3, '0')}</span>
              <span style={{ color: '#c8ff00', fontWeight: 700, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{e.type}</span>
              <span style={{ color: modeColor[e.mode], fontWeight: 700 }}>{e.mode}</span>
              <span style={{ color: '#5a6a50', overflow: 'hidden', textOverflow: 'ellipsis' }}>{e.chain_hash.slice(-8)}</span>
              <span style={{
                color: '#8fb35a', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
                display: 'none',
                // on wider screens, show details
                ...(typeof window !== 'undefined' && window.innerWidth > 640 ? { display: 'block' } : {}),
              }}>
                {e.details}
              </span>
            </div>
          ))
        )}
      </div>

      {/* Legend */}
      <div style={{
        flexShrink: 0, padding: 'clamp(6px, 1.5vh, 8px) clamp(10px, 3vw, 16px)',
        borderTop: '1px solid rgba(200,255,0,.1)', display: 'flex', gap: 'clamp(8px, 2vw, 16px)',
        flexWrap: 'wrap', fontSize: 'clamp(7px, 1.8vw, 8px)', color: '#5a6a50',
      }}>
        <span>SHA-256 + RFC 8785 JCS</span>
        <span>local-first · localStorage</span>
        <span>verify offline · no API key</span>
      </div>
    </div>
  )
}

function dataBtnStyle(disabled: boolean, border: string, color: string): React.CSSProperties {
  return {
    background: 'transparent', border: `1px solid ${border}`, color: disabled ? '#5a6a50' : color,
    fontFamily: 'inherit', fontSize: 'clamp(8px, 2vw, 9px)', fontWeight: 700, letterSpacing: '.1em',
    padding: 'clamp(5px, 1.2vh, 6px) clamp(8px, 2vw, 10px)', minHeight: 32,
    cursor: disabled ? 'wait' : 'pointer', borderRadius: 2, whiteSpace: 'nowrap',
    opacity: disabled ? 0.5 : 1,
  }
}
