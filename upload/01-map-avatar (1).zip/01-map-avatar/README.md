# 01 · MAP + AVATAR

MapLibre 3D + photoreal head (Lee Perry Smith GLB from Three.js CDN).
PIP swap between map centre-stage and avatar centre-stage. FSM console
with leak detection. Vitals + ECG phosphor sweep.

**Mode:** SIM (avatar vitals are Math.random()-derived, labelled SIM TWIN)

## Run standalone
Open `map-avatar.html` in a browser over HTTPS or localhost (geolocation
needs a secure context). No build step required.

