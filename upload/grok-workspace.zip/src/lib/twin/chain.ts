import { STATIONS } from "@/lib/twin/data";
import { useTwin } from "@/lib/twin/store";

let prev = "0".repeat(64);
let seq = 0;
let queue: Promise<void> = Promise.resolve();
let lastBeat = Date.now();
let booted = false;

export function lastBeatAt() {
  return lastBeat;
}

export function noteBeat() {
  lastBeat = Date.now();
}

async function sha256(text: string) {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
  return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

export function emit(
  stationId: string,
  metric: string,
  value: string,
  absent = false,
) {
  if (!absent) noteBeat();
  const station = STATIONS.find((s) => s.id === stationId);
  const sensor = station?.sensor ?? "S-LINE-00";
  queue = queue.then(async () => {
    seq += 1;
    const ts = Date.now();
    const body = `${seq}|${ts}|${stationId}|${metric}|${value}|${sensor}|${prev}`;
    const hash = await sha256(body);
    prev = hash;
    useTwin.getState().pushReceipt({
      seq,
      ts,
      station: stationId,
      metric,
      value,
      sensor,
      hash,
      absent,
    });
  });
}

export function bootChain() {
  if (booted) return;
  booted = true;
  noteBeat();
  emit("line", "ANCHOR", "SUNDAY-WORLD-2026-10-06");
}

export function failClosed() {
  const state = useTwin.getState();
  if (state.feed === "absent") return;
  state.setFeed("absent");
  state.setRunning(false);
  for (const station of STATIONS) {
    emit(station.id, "SENSOR", "ABSENT", true);
  }
}

export function restoreFeed() {
  const state = useTwin.getState();
  if (state.feed === "live") return;
  noteBeat();
  state.setFeed("live");
  state.setRunning(true);
  emit("line", "LINK", "RESTORED");
}
