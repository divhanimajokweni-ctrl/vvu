import { create } from "zustand";

export type LayerId = "solid" | "skeleton" | "energy" | "thermal";
export type Feed = "live" | "absent";

export type Receipt = {
  seq: number;
  ts: number;
  station: string;
  metric: string;
  value: string;
  sensor: string;
  hash: string;
  absent: boolean;
};

type TwinState = {
  layer: LayerId;
  feed: Feed;
  running: boolean;
  trace: boolean;
  receipts: Receipt[];
  head: string;
  selected: string | null;
  activeBay: number;
  vehicleId: string;
  modelReady: boolean;
  fps: number;
  specOpen: boolean;
  setLayer: (layer: LayerId) => void;
  setFeed: (feed: Feed) => void;
  setRunning: (running: boolean) => void;
  setTrace: (trace: boolean) => void;
  setSelected: (selected: string | null) => void;
  setActiveBay: (activeBay: number) => void;
  setVehicleId: (vehicleId: string) => void;
  setModelReady: (modelReady: boolean) => void;
  setFps: (fps: number) => void;
  setSpecOpen: (specOpen: boolean) => void;
  pushReceipt: (receipt: Receipt) => void;
};

export const useTwin = create<TwinState>((set) => ({
  layer: "solid",
  feed: "live",
  running: true,
  trace: true,
  receipts: [],
  head: "",
  selected: null,
  activeBay: 0,
  vehicleId: "DX-4821",
  modelReady: false,
  fps: 0,
  specOpen: false,
  setLayer: (layer) => set({ layer }),
  setFeed: (feed) => set({ feed }),
  setRunning: (running) => set({ running }),
  setTrace: (trace) => set({ trace }),
  setSelected: (selected) => set({ selected }),
  setActiveBay: (activeBay) => set({ activeBay }),
  setVehicleId: (vehicleId) => set({ vehicleId }),
  setModelReady: (modelReady) => set({ modelReady }),
  setFps: (fps) => set({ fps }),
  setSpecOpen: (specOpen) => set({ specOpen }),
  pushReceipt: (receipt) =>
    set((state) => ({
      receipts: [...state.receipts.slice(-47), receipt],
      head: receipt.hash,
    })),
}));
