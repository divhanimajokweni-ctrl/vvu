export const BAY_X = [-16, -8, 0, 8, 16] as const;
export const LINE_SPEED = 3.5;

export type Station = {
  id: string;
  index: string;
  name: string;
  short: string;
  sensor: string;
  article: string;
  receiptMetric: string;
  receiptValue: string;
  metrics: [string, string][];
};

/** Facts as stated for the Oct 2026 Struandale upgrade. No invented torques. */
export const STATIONS: Station[] = [
  {
    id: "chassis",
    index: "01",
    name: "Chassis line",
    short: "CHASSIS",
    sensor: "S-CH-01",
    article: "Line extended. Added stations, updated tooling, optimised layout.",
    receiptMetric: "LINE",
    receiptValue: "EXTENDED",
    metrics: [
      ["LINE", "EXTENDED"],
      ["STATIONS", "ADDED"],
      ["TOOLING", "UPGRADED"],
      ["LAYOUT", "OPTIMISED"],
    ],
  },
  {
    id: "engine",
    index: "02",
    name: "Engine sub-assembly",
    short: "ENGINE",
    sensor: "S-EN-02",
    article: "Engine-dress process upgraded. Tooling and layout revised.",
    receiptMetric: "DRESS",
    receiptValue: "UPGRADED",
    metrics: [
      ["DRESS", "UPGRADED"],
      ["TOOLING", "REVISED"],
      ["LAYOUT", "OPTIMISED"],
    ],
  },
  {
    id: "cab",
    index: "03",
    name: "Cab marriage",
    short: "CAB",
    sensor: "S-CB-03",
    article: "Cab-marriage hoist joins the cab to the chassis.",
    receiptMetric: "HOIST",
    receiptValue: "OPERATIONAL",
    metrics: [
      ["HOIST", "OPERATIONAL"],
      ["JOIN", "CAB-TO-CHASSIS"],
    ],
  },
  {
    id: "fuel",
    index: "04",
    name: "Fuel tank + lift-assist",
    short: "FUEL",
    sensor: "S-FT-04",
    article: "New fuel-tank gripper. Lift-assist at multiple stations.",
    receiptMetric: "GRIPPER",
    receiptValue: "NEW",
    metrics: [
      ["GRIPPER", "NEW"],
      ["LIFT-ASSIST", "MULTI-POINT"],
    ],
  },
  {
    id: "torque",
    index: "05",
    name: "Electronic torque",
    short: "TORQUE",
    sensor: "S-TQ-05",
    article: "Electronic torque tools replace manual tools.",
    receiptMetric: "TOOL",
    receiptValue: "ELECTRONIC",
    metrics: [
      ["TOOL", "ELECTRONIC"],
      ["REPLACES", "MANUAL"],
      ["TRACE", "ALONG THE LINE"],
    ],
  },
];

export const PRODUCTION = [
  ["FY2026", "31,200+ vehicles"],
  ["D-Max", "27,400"],
  ["Trucks", "3,800+"],
  ["N-Series", "November 2026"],
  ["F-Series", "Early 2027"],
  ["Upgrade", "R30 million"],
] as const;
