import { BAY_X } from "@/lib/twin/data";

export const pose = {
  x: BAY_X[0] as number,
  y: 0,
  roll: 0,
};

export const sim = {
  phase: "dwell" as "dwell" | "move" | "wrap",
  bay: 0,
  dwell: 1.15,
  emitted: -1,
};

export const reduceMotion =
  typeof window !== "undefined" &&
  window.matchMedia("(prefers-reduced-motion: reduce)").matches;
