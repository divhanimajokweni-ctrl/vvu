import { createFileRoute } from "@tanstack/react-router";
import { IndustrialTwin } from "@/components/twin/IndustrialTwin";

export const Route = createFileRoute("/")({
  component: IndustrialTwin,
});
