import { useEffect, useRef, useState } from "react";
import { clsx } from "clsx";
import { Box, Flame, Pause, Play, Scan, Unplug, Zap } from "lucide-react";
import { STATIONS, PRODUCTION } from "@/lib/twin/data";
import { bootChain, emit, failClosed, lastBeatAt, restoreFeed } from "@/lib/twin/chain";
import { useTwin, type LayerId, type Receipt } from "@/lib/twin/store";

const LAYERS: { id: LayerId; label: string; icon: typeof Box }[] = [
  { id: "solid", label: "Solid", icon: Box },
  { id: "skeleton", label: "Skeleton", icon: Scan },
  { id: "energy", label: "Energy", icon: Zap },
  { id: "thermal", label: "Thermal", icon: Flame },
];

function clock(ts: number) {
  return new Date(ts).toLocaleTimeString("en-ZA", {
    hour12: false,
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  });
}

function useViewport() {
  const [Viewport, setViewport] = useState<React.ComponentType | null>(null);
  const [failed, setFailed] = useState(false);
  useEffect(() => {
    let live = true;
    import("./TwinViewport")
      .then((mod) => {
        if (live) setViewport(() => mod.TwinViewport);
      })
      .catch(() => {
        if (live) setFailed(true);
      });
    return () => {
      live = false;
    };
  }, []);
  return { Viewport, failed };
}

export function IndustrialTwin() {
  const { Viewport, failed } = useViewport();
  const feed = useTwin((s) => s.feed);
  const modelReady = useTwin((s) => s.modelReady);

  useEffect(() => {
    bootChain();
    const beat = window.setInterval(() => {
      const state = useTwin.getState();
      if (state.feed !== "live") return;
      const station = STATIONS[Math.floor(Math.random() * STATIONS.length)];
      if (!station) return;
      const metric = station.metrics[Math.floor(Math.random() * station.metrics.length)];
      if (!metric) return;
      emit(station.id, metric[0], metric[1]);
    }, 2800);
    const watch = window.setInterval(() => {
      const state = useTwin.getState();
      if (state.feed === "live" && Date.now() - lastBeatAt() > 12000) failClosed();
    }, 400);
    return () => {
      window.clearInterval(beat);
      window.clearInterval(watch);
    };
  }, []);

  return (
    <div className="fixed inset-0 flex flex-col bg-bg text-ink">
      <Header />
      <div className="flex min-h-0 flex-1 flex-col lg:flex-row">
        <div className="relative min-h-0 min-w-0 flex-1">
          <div
            className={clsx(
              "absolute inset-0 transition-[filter] duration-300",
              feed === "absent" && "grayscale brightness-75",
            )}
          >
            {failed ? (
              <div className="flex h-full items-center justify-center px-6 text-center text-sm text-fail">
                This view needs WebGL. The receipt chain still runs in the dock.
              </div>
            ) : Viewport ? (
              <Viewport />
            ) : (
              <Binding message="BINDING VIEWPORT" />
            )}
          </div>
          {Viewport && !modelReady && !failed && (
            <div className="pointer-events-none absolute inset-0 z-10">
              <Binding message="BINDING ISUZU D-MAX" />
            </div>
          )}
          <FailVeil />
          <StationStrip />
          <ReceiptCard />
        </div>
        <aside className="hidden w-80 shrink-0 flex-col border-l border-line bg-panel lg:flex">
          <RailBody />
        </aside>
      </div>
      <Worm />
      <Dock />
      <SpecSheet />
    </div>
  );
}

function Binding({ message }: { message: string }) {
  return (
    <div className="flex h-full flex-col items-center justify-center gap-3 bg-bg">
      <span className="vvu-pulse h-2 w-2 rounded-full bg-lime" />
      <p className="font-display text-lg tracking-[0.22em] text-lime">{message}</p>
      <p className="text-micro text-dim">Struandale · commercial vehicle line</p>
    </div>
  );
}

function Header() {
  const feed = useTwin((s) => s.feed);
  const head = useTwin((s) => s.head);
  const fps = useTwin((s) => s.fps);
  return (
    <header className="z-30 flex h-14 shrink-0 items-center justify-between gap-3 border-b border-line bg-panel px-3 sm:px-4">
      <div className="min-w-0">
        <div className="flex items-baseline gap-2">
          <span className="font-display text-xl font-semibold tracking-[0.16em] text-lime">VVU</span>
          <span className="truncate font-display text-base tracking-[0.14em] text-ink">
            INDUSTRIAL TWIN
          </span>
        </div>
        <p className="truncate text-micro text-dim">Isuzu Gqeberha · Struandale CV line · R30m</p>
      </div>
      <div className="flex shrink-0 items-center gap-2">
        <div className="hidden text-right sm:block">
          <p className="text-micro text-dim">CHAIN HEAD</p>
          <p className="font-mono text-micro tabular-nums text-amber">
            {head ? `∎${head.slice(0, 8)}` : "∎————————"}
          </p>
        </div>
        <div
          role="status"
          className={clsx(
            "flex h-11 items-center gap-2 border px-3 text-micro font-medium tracking-wide",
            feed === "live" ? "border-lime text-lime" : "border-fail text-fail",
          )}
        >
          <span
            className={clsx(
              "h-1.5 w-1.5 rounded-full",
              feed === "live" ? "vvu-pulse bg-lime" : "bg-fail",
            )}
          />
          {feed === "live" ? "FEED LIVE" : "FAIL CLOSED"}
          <span className="hidden text-dim sm:inline">{fps > 0 ? `${fps} FPS` : ""}</span>
        </div>
      </div>
    </header>
  );
}

function StationStrip() {
  const activeBay = useTwin((s) => s.activeBay);
  const selected = useTwin((s) => s.selected);
  const setSelected = useTwin((s) => s.setSelected);
  const feed = useTwin((s) => s.feed);
  return (
    <div className="pointer-events-none absolute inset-x-0 top-0 z-20 p-2">
      <div className="pointer-events-auto flex gap-1 overflow-x-auto">
        {STATIONS.map((station, index) => {
          const on = selected === station.id;
          const here = activeBay === index;
          return (
            <button
              key={station.id}
              type="button"
              onClick={() => setSelected(on ? null : station.id)}
              className={clsx(
                "min-h-11 shrink-0 border bg-bg/85 px-3 text-left backdrop-blur-sm",
                on ? "border-amber text-amber" : "border-line text-ink",
              )}
              aria-pressed={on}
            >
              <span className="flex items-center gap-2 text-micro font-medium tracking-wide">
                <span className={clsx("h-1.5 w-1.5 rounded-full", here && feed === "live" ? "bg-lime" : "bg-dim")} />
                {station.index} {station.short}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}

function ReceiptCard() {
  const selected = useTwin((s) => s.selected);
  const receipts = useTwin((s) => s.receipts);
  const setSelected = useTwin((s) => s.setSelected);
  const station = STATIONS.find((s) => s.id === selected);
  if (!station) return null;
  const latest = [...receipts].reverse().find((r) => r.station === station.id);
  return (
    <div className="absolute bottom-3 left-3 right-3 z-20 max-w-md border border-line bg-panel/95 p-3 backdrop-blur-md sm:left-3 sm:right-auto">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="text-micro tracking-[0.16em] text-dim">STATION {station.index}</p>
          <h2 className="font-display text-2xl leading-none tracking-wide text-ink">{station.name}</h2>
        </div>
        <button
          type="button"
          onClick={() => setSelected(null)}
          className="min-h-11 shrink-0 px-2 text-micro text-muted"
        >
          CLOSE
        </button>
      </div>
      <p className="mt-2 text-micro text-muted">{station.article}</p>
      <dl className="mt-3 grid grid-cols-2 gap-x-3 gap-y-1">
        {station.metrics.map(([k, v]) => (
          <div key={k} className="flex items-baseline justify-between gap-2 border-b border-line/70 py-1">
            <dt className="text-micro text-dim">{k}</dt>
            <dd className="text-micro text-lime">{v}</dd>
          </div>
        ))}
      </dl>
      <p className="mt-3 text-micro text-dim">SENSOR {station.sensor}</p>
      {latest ? (
        <p className={clsx("mt-1 text-micro", latest.absent ? "text-fail" : "text-amber")}>
          #{String(latest.seq).padStart(3, "0")} {latest.metric}={latest.value} ∎{latest.hash.slice(0, 8)}
        </p>
      ) : (
        <p className="mt-1 text-micro text-dim">No receipt for this station yet.</p>
      )}
    </div>
  );
}

function FailVeil() {
  const feed = useTwin((s) => s.feed);
  return (
    <div
      className={clsx(
        "pointer-events-none absolute inset-0 z-10 flex flex-col items-center justify-center bg-bg/55 transition-opacity duration-200",
        feed === "absent" ? "opacity-100" : "opacity-0",
      )}
      role="status"
    >
      <p className="font-display text-4xl tracking-[0.18em] text-fail sm:text-5xl">SENSOR ABSENT</p>
      <p className="mt-2 text-micro tracking-[0.22em] text-fail">FAIL CLOSED · NO GUESSED STATE</p>
    </div>
  );
}

function RailBody() {
  const feed = useTwin((s) => s.feed);
  const vehicleId = useTwin((s) => s.vehicleId);
  const activeBay = useTwin((s) => s.activeBay);
  const trace = useTwin((s) => s.trace);
  const setTrace = useTwin((s) => s.setTrace);
  const setSelected = useTwin((s) => s.setSelected);
  const selected = useTwin((s) => s.selected);
  const bay = STATIONS[activeBay];

  return (
    <div className="flex min-h-0 flex-1 flex-col overflow-y-auto">
      <section className="border-b border-line px-4 py-3">
        <p className="text-micro tracking-[0.18em] text-dim">LINE STATE</p>
        <ul className="mt-2">
          {STATIONS.map((station, index) => (
            <li key={station.id}>
              <button
                type="button"
                onClick={() => setSelected(station.id)}
                className={clsx(
                  "flex min-h-11 w-full items-center justify-between gap-2 text-left",
                  selected === station.id ? "text-amber" : "text-ink",
                )}
              >
                <span className="text-sm">
                  <span className="text-dim">{station.index}</span> {station.short}
                </span>
                <span className={clsx("text-micro", feed === "live" ? "text-lime" : "text-fail")}>
                  {feed === "live" ? (index === activeBay ? "IN BAY" : station.sensor) : "ABSENT"}
                </span>
              </button>
            </li>
          ))}
        </ul>
      </section>
      <section className="border-b border-line px-4 py-3">
        <p className="text-micro tracking-[0.18em] text-dim">THIS PASS</p>
        <div className="mt-2 flex items-baseline justify-between">
          <span className="font-display text-3xl tracking-wide text-lime">
            {feed === "absent" ? "ABSENT" : vehicleId}
          </span>
        </div>
        <p className="mt-1 text-micro text-muted">
          {feed === "absent" ? "Identity withheld. The chain records absence." : `In ${bay?.name ?? "bay"}`}
        </p>
        <button
          type="button"
          onClick={() => setTrace(!trace)}
          aria-pressed={trace}
          className={clsx(
            "mt-3 min-h-11 border px-3 text-micro",
            trace ? "border-lime text-lime" : "border-line text-muted",
          )}
        >
          TRACE ID {trace ? "ON" : "OFF"}
        </button>
      </section>
      <section className="border-b border-line px-4 py-3">
        <p className="text-micro tracking-[0.18em] text-dim">PUBLISHED VOLUME</p>
        <dl className="mt-2">
          {PRODUCTION.map(([k, v]) => (
            <div key={k} className="flex items-baseline justify-between gap-3 py-1">
              <dt className="text-micro text-dim">{k}</dt>
              <dd className="text-right text-sm text-ink">{v}</dd>
            </div>
          ))}
        </dl>
      </section>
      <section className="px-4 py-3 text-micro text-muted">
        <p className="tracking-[0.18em] text-dim">SOURCE</p>
        <p className="mt-2 text-pretty">
          Sunday World, 6 October 2026. “Isuzu pumps R30m into Gqeberha truck plant.” Johan Vermeulen, EVP
          Manufacturing & Product Engineering, from September 2026.
        </p>
        <p className="mt-2 text-pretty">
          Receipts are a demonstration feed of that published spec, SHA-256 chained in this session. They are
          not a live Struandale PLC. Twelve seconds without a receipt fail-closes the twin.
        </p>
        <p className="mt-3 text-pretty">
          Vehicle model “4x4 ISUZU DMAX OFFROAD” by Şevki ÜNAL,{" "}
          <a
            className="text-amber underline-offset-2 hover:underline"
            href="https://creativecommons.org/licenses/by/4.0/"
            target="_blank"
            rel="noreferrer"
          >
            CC-BY-4.0
          </a>
          , via{" "}
          <a
            className="text-amber underline-offset-2 hover:underline"
            href="https://sketchfab.com/3d-models/4x4-isuzu-dmax-offroad-442d44cb2b83421787fd5a3e5b1e6dd0"
            target="_blank"
            rel="noreferrer"
          >
            Sketchfab
          </a>
          .
        </p>
      </section>
    </div>
  );
}

function SpecSheet() {
  const open = useTwin((s) => s.specOpen);
  const setOpen = useTwin((s) => s.setSpecOpen);
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-40 flex flex-col bg-bg lg:hidden">
      <div className="flex h-14 items-center justify-between border-b border-line px-3">
        <p className="font-display text-xl tracking-[0.14em] text-lime">LINE SPEC</p>
        <button type="button" onClick={() => setOpen(false)} className="min-h-11 px-3 text-sm text-ink">
          CLOSE
        </button>
      </div>
      <RailBody />
    </div>
  );
}

function Worm() {
  const receipts = useTwin((s) => s.receipts);
  const scroller = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const el = scroller.current;
    if (!el) return;
    el.scrollTop = el.scrollHeight;
  }, [receipts]);

  return (
    <div className="z-30 h-24 shrink-0 border-t border-line bg-bg" role="log" aria-live="polite" aria-label="WORM receipt chain">
      <div className="flex h-7 items-center justify-between border-b border-line px-3">
        <span className="text-micro tracking-[0.16em] text-lime">WORM · APPEND ONLY</span>
        <span className="text-micro tabular-nums text-dim">
          {receipts.length > 0 ? `EVT/${receipts[receipts.length - 1]?.seq}` : "EVT/—"}
        </span>
      </div>
      <div ref={scroller} className="worm-scroll h-[4.25rem] overflow-y-auto px-3 py-1">
        {receipts.length === 0 ? (
          <p className="text-micro text-dim">Chain cold. Waiting for the first receipt.</p>
        ) : (
          receipts.slice(-12).map((receipt) => <WormLine key={receipt.seq} receipt={receipt} />)
        )}
      </div>
    </div>
  );
}

function WormLine({ receipt }: { receipt: Receipt }) {
  const label = receipt.station === "line" ? "LINE" : receipt.station.toUpperCase();
  return (
    <p className={clsx("truncate text-micro tabular-nums", receipt.absent ? "text-fail" : "text-lime")}>
      <span className="text-dim">{clock(receipt.ts)}</span> #{String(receipt.seq).padStart(3, "0")} {label}{" "}
      {receipt.metric}={receipt.value} <span className="text-amber">∎{receipt.hash.slice(0, 8)}</span>
    </p>
  );
}

function Dock() {
  const layer = useTwin((s) => s.layer);
  const setLayer = useTwin((s) => s.setLayer);
  const running = useTwin((s) => s.running);
  const setRunning = useTwin((s) => s.setRunning);
  const feed = useTwin((s) => s.feed);
  const setSpecOpen = useTwin((s) => s.setSpecOpen);
  const specOpen = useTwin((s) => s.specOpen);

  return (
    <div className="dock z-30 shrink-0 border-t border-line bg-panel px-2 py-2">
      <div className="flex flex-wrap items-center gap-1">
        <div className="flex flex-1 gap-1" role="tablist" aria-label="Projection">
          {LAYERS.map((item) => {
            const Icon = item.icon;
            const on = layer === item.id;
            return (
              <button
                key={item.id}
                type="button"
                role="tab"
                aria-selected={on}
                onClick={() => setLayer(item.id)}
                className={clsx(
                  "flex min-h-11 flex-1 items-center justify-center gap-1 border px-2 text-micro",
                  on ? "border-lime bg-lime/10 text-lime" : "border-line text-muted",
                )}
              >
                <Icon className="h-4 w-4" aria-hidden />
                <span className="hidden sm:inline">{item.label}</span>
              </button>
            );
          })}
        </div>
        <button
          type="button"
          onClick={() => setRunning(!running)}
          disabled={feed === "absent"}
          className="flex min-h-11 items-center gap-1 border border-line px-3 text-micro text-ink disabled:opacity-40"
        >
          {running && feed === "live" ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
          {running && feed === "live" ? "HOLD" : "RUN"}
        </button>
        <button
          type="button"
          onClick={() => (feed === "live" ? failClosed() : restoreFeed())}
          className={clsx(
            "flex min-h-11 items-center gap-1 border px-3 text-micro",
            feed === "live" ? "border-fail text-fail" : "border-lime text-lime",
          )}
        >
          <Unplug className="h-4 w-4" aria-hidden />
          {feed === "live" ? "CUT FEED" : "RESTORE"}
        </button>
        <button
          type="button"
          onClick={() => setSpecOpen(!specOpen)}
          aria-expanded={specOpen}
          className="flex min-h-11 items-center border border-line px-3 text-micro text-amber lg:hidden"
        >
          SPEC
        </button>
      </div>
    </div>
  );
}
