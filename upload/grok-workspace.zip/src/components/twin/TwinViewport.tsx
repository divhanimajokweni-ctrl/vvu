import { useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { Grid, Html, OrbitControls, useGLTF } from "@react-three/drei";
import * as THREE from "three";
import { BAY_X, LINE_SPEED, STATIONS } from "@/lib/twin/data";
import { emit } from "@/lib/twin/chain";
import { pose, reduceMotion, sim } from "@/lib/twin/pose";
import { useTwin } from "@/lib/twin/store";

const MODEL_URL = "/models/isuzu-dmax.glb";

const conveyorVert = /* glsl */ `
  varying vec2 vUv;
  void main() {
    vUv = uv;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
  }
`;

const conveyorFrag = /* glsl */ `
  uniform float uTime;
  uniform float uLive;
  varying vec2 vUv;
  void main() {
    float x = vUv.x * 46.0 - uTime * 1.6;
    float chev = abs(fract(x) - 0.5);
    float mark = smoothstep(0.34, 0.36, chev);
    float lane = smoothstep(0.08, 0.02, abs(vUv.y - 0.5));
    float alpha = mark * lane * (uLive > 0.5 ? 0.7 : 0.12);
    vec3 col = uLive > 0.5 ? vec3(0.784, 1.0, 0.0) : vec3(0.30, 0.28, 0.22);
    gl_FragColor = vec4(col, alpha);
  }
`;

function parentOrigin(root: THREE.Object3D) {
  const origin = new THREE.Vector3();
  if (root.parent) {
    root.parent.updateWorldMatrix(true, false);
    root.parent.getWorldPosition(origin);
  }
  return origin;
}

function localBox(root: THREE.Object3D) {
  const box = new THREE.Box3().setFromObject(root);
  const origin = parentOrigin(root);
  box.min.sub(origin);
  box.max.sub(origin);
  return box;
}

function fitModel(root: THREE.Object3D) {
  root.position.set(0, 0, 0);
  root.rotation.set(0, 0, 0);
  root.scale.set(1, 1, 1);
  root.updateMatrixWorld(true);
  let box = localBox(root);
  let size = box.getSize(new THREE.Vector3());
  if (size.z > size.x) {
    root.rotation.y = Math.PI / 2;
    root.updateMatrixWorld(true);
    box = localBox(root);
    size = box.getSize(new THREE.Vector3());
  }
  root.scale.setScalar(5.3 / Math.max(size.x, 0.001));
  root.updateMatrixWorld(true);
  box = localBox(root);
  const center = box.getCenter(new THREE.Vector3());
  root.position.x -= center.x;
  root.position.z -= center.z;
  root.position.y -= box.min.y;
  root.updateMatrixWorld(true);
}

function Simulator() {
  const acc = useRef(0);
  const frames = useRef(0);

  useFrame((_, delta) => {
    const dt = Math.min(delta, 0.1);
    acc.current += dt;
    frames.current += 1;
    if (acc.current >= 0.5) {
      useTwin.getState().setFps(Math.round(frames.current / acc.current));
      acc.current = 0;
      frames.current = 0;
    }
    if (document.hidden) return;

    const { running, feed } = useTwin.getState();
    const live = feed === "live";
    const moving = running && live && sim.phase !== "dwell";

    if (sim.phase === "dwell") {
      if (live && sim.emitted !== sim.bay) {
        sim.emitted = sim.bay;
        const station = STATIONS[sim.bay];
        if (station) {
          emit(station.id, station.receiptMetric, station.receiptValue);
          if (sim.bay === 0) {
            const id = `DX-${String(1000 + Math.floor(Math.random() * 9000))}`;
            useTwin.getState().setVehicleId(id);
            emit("chassis", "VEHICLE_ID", id);
          }
          useTwin.getState().setActiveBay(sim.bay);
        }
      }
      if (running && live) sim.dwell -= dt;
      if (sim.dwell <= 0) {
        const leaving = sim.bay;
        sim.bay = (sim.bay + 1) % STATIONS.length;
        sim.dwell = 2.15;
        sim.phase = leaving === STATIONS.length - 1 ? "wrap" : "move";
      }
    } else if (sim.phase === "move" && running && live) {
      const target = BAY_X[sim.bay] ?? 0;
      const dx = target - pose.x;
      const step = LINE_SPEED * dt;
      if (Math.abs(dx) <= step) {
        pose.x = target;
        sim.phase = "dwell";
      } else {
        pose.x += Math.sign(dx) * step;
      }
    } else if (sim.phase === "wrap" && running && live) {
      pose.x += LINE_SPEED * dt;
      const end = BAY_X[BAY_X.length - 1] ?? 16;
      const start = BAY_X[0] ?? -16;
      if (pose.x > end + 6) {
        pose.x = start - 6;
        sim.phase = "move";
      }
    }

    if (moving && !reduceMotion) {
      const t = performance.now() / 1000;
      pose.y = Math.sin(t * 10.5) * 0.012 + Math.sin(t * 17.3) * 0.004;
      pose.roll = Math.sin(t * 10.5) * 0.008;
    } else {
      pose.y += (0 - pose.y) * Math.min(1, dt * 6);
      pose.roll += (0 - pose.roll) * Math.min(1, dt * 6);
    }
  });

  return null;
}

function RigLights() {
  const key = useRef<THREE.DirectionalLight>(null);
  const rim = useRef<THREE.DirectionalLight>(null);
  const fill = useRef<THREE.DirectionalLight>(null);

  useFrame(() => {
    const live = useTwin.getState().feed === "live";
    if (key.current) key.current.intensity = live ? 2.5 : 0.28;
    if (rim.current) rim.current.intensity = live ? 1.45 : 0;
    if (fill.current) fill.current.intensity = live ? 0.85 : 0.15;
  });

  return (
    <>
      <ambientLight intensity={0.28} />
      <hemisphereLight args={["#d5e2c4", "#090b09", 0.4]} />
      <directionalLight ref={key} position={[14, 18, 9]} intensity={2.5} color="#fff6ea" />
      <directionalLight ref={fill} position={[-4, 6, 12]} intensity={0.85} color="#e7f0dc" />
      <directionalLight ref={rim} position={[-10, 7, -8]} intensity={1.45} color="#c8ff00" />
    </>
  );
}

function Bays() {
  const mats = useMemo(
    () =>
      BAY_X.map(
        () =>
          new THREE.MeshStandardMaterial({
            color: "#121812",
            roughness: 0.94,
            metalness: 0,
            emissive: new THREE.Color("#c8ff00"),
            emissiveIntensity: 0,
          }),
      ),
    [],
  );

  useFrame(() => {
    const { activeBay, feed } = useTwin.getState();
    mats.forEach((mat, index) => {
      const hot = feed === "live" && index === activeBay;
      mat.emissiveIntensity = hot ? 0.22 : 0;
    });
  });

  return (
    <group>
      {BAY_X.map((x, index) => (
        <group key={x} position={[x, 0, 0]}>
          <mesh rotation-x={-Math.PI / 2} position={[0, 0.012, 0]} material={mats[index]}>
            <planeGeometry args={[6.6, 10.5]} />
          </mesh>
          {[-4.4, 4.4].map((z) => (
            <mesh key={z} position={[0, 1.9, z]}>
              <boxGeometry args={[0.16, 3.8, 0.16]} />
              <meshStandardMaterial color="#1a221a" roughness={0.8} />
            </mesh>
          ))}
          <mesh position={[0, 3.78, 0]}>
            <boxGeometry args={[0.16, 0.12, 9]} />
            <meshStandardMaterial
              color="#243024"
              emissive="#c8ff00"
              emissiveIntensity={0.15}
              roughness={0.6}
            />
          </mesh>
        </group>
      ))}
    </group>
  );
}

function Conveyor() {
  const mat = useMemo(
    () =>
      new THREE.ShaderMaterial({
        transparent: true,
        depthWrite: false,
        uniforms: {
          uTime: { value: 0 },
          uLive: { value: 1 },
        },
        vertexShader: conveyorVert,
        fragmentShader: conveyorFrag,
      }),
    [],
  );

  useFrame(({ clock }) => {
    const { feed, running } = useTwin.getState();
    mat.uniforms.uLive!.value = feed === "live" ? 1 : 0;
    if (feed === "live" && running && !reduceMotion) {
      mat.uniforms.uTime!.value = clock.elapsedTime;
    }
  });

  return (
    <mesh rotation-x={-Math.PI / 2} position={[0, 0.03, 0]} material={mat}>
      <planeGeometry args={[48, 2.15]} />
    </mesh>
  );
}

function Hoist() {
  const carriage = useRef<THREE.Group>(null);
  const drop = useRef(0);

  useFrame((_, delta) => {
    const dt = Math.min(delta, 0.1);
    const live = useTwin.getState().feed === "live";
    const near = live && Math.abs(pose.x - (BAY_X[2] ?? 0)) < 2.5 && sim.phase === "dwell" && sim.bay === 2;
    const target = near ? 1 : 0;
    drop.current += (target - drop.current) * Math.min(1, dt * (near ? 1.6 : 2.4));
    if (carriage.current) {
      carriage.current.position.y = 3.15 - drop.current * 1.25;
    }
  });

  const x = BAY_X[2] ?? 0;
  return (
    <group position={[x, 0, 0]}>
      {[-0.7, 0.7].map((z) => (
        <mesh key={z} position={[0, 2.7, z]}>
          <boxGeometry args={[0.06, 2.2, 0.06]} />
          <meshStandardMaterial color="#c8ff00" emissive="#c8ff00" emissiveIntensity={0.35} />
        </mesh>
      ))}
      <group ref={carriage} position={[0, 3.15, 0]}>
        <mesh>
          <boxGeometry args={[1.7, 0.08, 1.7]} />
          <meshStandardMaterial color="#d7e2cc" metalness={0.45} roughness={0.35} />
        </mesh>
        <mesh position={[0, -0.45, 0]}>
          <boxGeometry args={[1.35, 0.55, 1.2]} />
          <meshStandardMaterial color="#1c241c" roughness={0.55} metalness={0.15} />
        </mesh>
      </group>
    </group>
  );
}

function TorqueLamps() {
  const mats = useRef<THREE.MeshBasicMaterial[]>([]);

  useFrame(({ clock }) => {
    const live = useTwin.getState().feed === "live";
    const near = live && Math.abs(pose.x - (BAY_X[4] ?? 16)) < 2.6;
    const step = Math.floor(clock.elapsedTime * 3) % 4;
    mats.current.forEach((mat, index) => {
      mat.opacity = near && index === step ? 1 : 0.16;
    });
  });

  return (
    <group position={[BAY_X[4] ?? 16, 0.045, 1.55]}>
      {[0, 1, 2, 3].map((index) => (
        <mesh key={index} position={[(index - 1.5) * 0.42, 0, 0]} rotation-x={-Math.PI / 2}>
          <ringGeometry args={[0.07, 0.12, 20]} />
          <meshBasicMaterial
            ref={(mat) => {
              if (mat) mats.current[index] = mat;
            }}
            color="#f3e38a"
            transparent
            opacity={0.16}
            depthWrite={false}
            side={THREE.DoubleSide}
          />
        </mesh>
      ))}
    </group>
  );
}

function EnergyRibbon() {
  const layer = useTwin((s) => s.layer);
  const mat = useMemo(
    () =>
      new THREE.ShaderMaterial({
        transparent: true,
        depthWrite: false,
        blending: THREE.AdditiveBlending,
        uniforms: {
          uTime: { value: 0 },
          uLive: { value: 1 },
        },
        vertexShader: conveyorVert,
        fragmentShader: /* glsl */ `
          uniform float uTime;
          uniform float uLive;
          varying vec2 vUv;
          void main() {
            float flow = fract(vUv.x * 3.0 - uTime * 0.35);
            float head = smoothstep(0.0, 0.15, flow) * smoothstep(0.45, 0.15, flow);
            float core = smoothstep(0.18, 0.0, abs(vUv.y - 0.5));
            float alpha = (0.12 + head) * core * (uLive > 0.5 ? 1.0 : 0.25);
            gl_FragColor = vec4(0.784, 1.0, 0.0, alpha);
          }
        `,
      }),
    [],
  );

  useFrame(({ clock }) => {
    mat.uniforms.uTime!.value = reduceMotion ? 0 : clock.elapsedTime;
    mat.uniforms.uLive!.value = useTwin.getState().feed === "live" ? 1 : 0;
  });

  if (layer !== "energy") return null;
  return (
    <mesh rotation-x={-Math.PI / 2} position={[0, 0.05, 2.35]} material={mat}>
      <planeGeometry args={[46, 0.28]} />
    </mesh>
  );
}

function ThermalLamp() {
  const layer = useTwin((s) => s.layer);
  const light = useRef<THREE.PointLight>(null);
  const orb = useRef<THREE.Mesh>(null);

  useFrame(({ clock }) => {
    const live = useTwin.getState().feed === "live";
    const on = layer === "thermal" && live;
    const pulse = 0.75 + Math.sin(clock.elapsedTime * 6) * 0.25;
    if (light.current) {
      light.current.position.set(pose.x + 1.55, 0.95, 0.15);
      light.current.intensity = on ? 14 * pulse : 0;
    }
    if (orb.current) {
      orb.current.position.set(pose.x + 1.55, 0.95, 0.15);
      orb.current.visible = on;
      const s = 0.18 + pulse * 0.06;
      orb.current.scale.setScalar(s);
    }
  });

  return (
    <>
      <pointLight ref={light} color="#f3e38a" distance={5.5} decay={2} intensity={0} />
      <mesh ref={orb} visible={false}>
        <sphereGeometry args={[1, 16, 16]} />
        <meshBasicMaterial color="#f3e38a" transparent opacity={0.85} />
      </mesh>
    </>
  );
}

function sideColumns() {
  const mesh = new THREE.InstancedMesh(
    new THREE.BoxGeometry(0.32, 4.4, 0.32),
    new THREE.MeshStandardMaterial({ color: "#141b14", roughness: 0.86 }),
    12,
  );
  const dummy = new THREE.Object3D();
  let i = 0;
  for (const x of [-20, -12, -4, 4, 12, 20]) {
    for (const z of [-7.2, 7.2]) {
      dummy.position.set(x, 2.2, z);
      dummy.updateMatrix();
      mesh.setMatrixAt(i, dummy.matrix);
      i += 1;
    }
  }
  mesh.count = i;
  mesh.instanceMatrix.needsUpdate = true;
  return mesh;
}

const columns = sideColumns();

type Slot = {
  mesh: THREE.Mesh;
  orig: THREE.Material | THREE.Material[];
};

const wireMat = new THREE.MeshBasicMaterial({
  color: "#c8ff00",
  wireframe: true,
  transparent: true,
  opacity: 0.85,
});

const deadMat = new THREE.MeshStandardMaterial({
  color: "#2a3128",
  roughness: 1,
  metalness: 0,
});

function applyLook(slots: Slot[], layer: string, feed: string) {
  for (const slot of slots) {
    const origList = Array.isArray(slot.orig) ? slot.orig : [slot.orig];
    if (feed === "absent") {
      slot.mesh.material = deadMat;
      continue;
    }
    if (layer === "skeleton") {
      slot.mesh.material = wireMat;
      continue;
    }
    slot.mesh.material = slot.orig;
    for (const mat of origList) {
      const standard = mat as THREE.MeshStandardMaterial;
      if (!standard.emissive) continue;
      if (layer === "energy") {
        standard.emissive.set("#c8ff00");
        standard.emissiveIntensity = 0.55;
      } else if (layer === "thermal") {
        standard.emissive.set("#f3e38a");
        standard.emissiveIntensity = 0.28;
      } else {
        standard.emissive.set("#000000");
        standard.emissiveIntensity = 1;
      }
    }
  }
}

function Marker({
  id,
  position,
}: {
  id: string;
  position: [number, number, number];
}) {
  const mesh = useRef<THREE.Mesh>(null);
  const selected = useTwin((s) => s.selected === id);
  const feed = useTwin((s) => s.feed);

  useFrame(({ clock }) => {
    if (!mesh.current || reduceMotion) return;
    const pulse = 1 + Math.sin(clock.elapsedTime * 3 + position[0]) * 0.16;
    mesh.current.scale.setScalar(feed === "live" ? pulse : 1);
  });

  const pick = (event: { stopPropagation: () => void }) => {
    event.stopPropagation();
    useTwin.getState().setSelected(id);
  };

  return (
    <group position={position}>
      <mesh ref={mesh} onClick={pick}>
        <sphereGeometry args={[0.09, 16, 16]} />
        <meshBasicMaterial color={feed === "absent" ? "#5c6b52" : selected ? "#f3e38a" : "#c8ff00"} />
      </mesh>
      <mesh onClick={pick}>
        <sphereGeometry args={[0.46, 10, 10]} />
        <meshBasicMaterial transparent opacity={0} depthWrite={false} />
      </mesh>
    </group>
  );
}

function FittedTruck() {
  const { scene } = useGLTF(MODEL_URL);
  const slots = useRef<Slot[]>([]);
  const [spots, setSpots] = useState<{ id: string; position: [number, number, number] }[]>([]);
  const layer = useTwin((s) => s.layer);
  const feed = useTwin((s) => s.feed);
  const shell = useRef<THREE.Group>(null);

  useLayoutEffect(() => {
    if (!scene.userData.vvuFit) {
      fitModel(scene);
      scene.userData.vvuFit = true;
    }
    const found: Slot[] = [];
    scene.traverse((obj) => {
      const mesh = obj as THREE.Mesh;
      if (!mesh.isMesh) return;
      mesh.castShadow = false;
      mesh.receiveShadow = false;
      if (!mesh.userData.vvuOrig) {
        mesh.userData.vvuOrig = mesh.material;
      }
      found.push({ mesh, orig: mesh.userData.vvuOrig as THREE.Material | THREE.Material[] });
    });
    slots.current = found;

    const group = shell.current;
    if (!group) return;
    const box = new THREE.Box3().setFromObject(scene);
    const min = group.worldToLocal(box.min.clone());
    const max = group.worldToLocal(box.max.clone());
    const span = (t: number, a: number, b: number) => a + (b - a) * t;
    setSpots([
      { id: "chassis", position: [span(0.5, min.x, max.x), span(0.22, min.y, max.y), span(0.5, min.z, max.z)] },
      { id: "engine", position: [span(0.82, min.x, max.x), span(0.46, min.y, max.y), span(0.5, min.z, max.z)] },
      { id: "cab", position: [span(0.46, min.x, max.x), span(0.74, min.y, max.y), span(0.5, min.z, max.z)] },
      { id: "fuel", position: [span(0.38, min.x, max.x), span(0.32, min.y, max.y), span(0.82, min.z, max.z)] },
      { id: "torque", position: [span(0.78, min.x, max.x), span(0.18, min.y, max.y), span(0.16, min.z, max.z)] },
    ]);
    useTwin.getState().setModelReady(true);
  }, [scene]);

  useEffect(() => {
    applyLook(slots.current, layer, feed);
  }, [layer, feed, spots]);

  return (
    <group ref={shell}>
      <primitive object={scene} />
      {spots.map((spot) => (
        <Marker key={spot.id} id={spot.id} position={spot.position} />
      ))}
    </group>
  );
}

function TruckRig() {
  const ref = useRef<THREE.Group>(null);
  useFrame(() => {
    const group = ref.current;
    if (!group) return;
    group.position.x = pose.x;
    group.position.y = pose.y;
    group.rotation.z = pose.roll;
  });
  return (
    <group ref={ref} position={[pose.x, 0, 0]}>
      <FittedTruck />
      <mesh rotation-x={-Math.PI / 2} position={[0, 0.04, 0]}>
        <circleGeometry args={[1.7, 32]} />
        <meshBasicMaterial color="#050705" transparent opacity={0.45} depthWrite={false} />
      </mesh>
    </group>
  );
}

function IdPlate() {
  const trace = useTwin((s) => s.trace);
  const id = useTwin((s) => s.vehicleId);
  const feed = useTwin((s) => s.feed);
  const anchor = useRef<THREE.Group>(null);

  useFrame(() => {
    if (!anchor.current) return;
    anchor.current.position.set(pose.x, 2.45 + pose.y, 0);
  });

  if (!trace) return null;
  return (
    <group ref={anchor}>
      <Html center distanceFactor={11} zIndexRange={[12, 0]} style={{ pointerEvents: "none" }}>
        <div className="whitespace-nowrap border border-lime/70 bg-bg/90 px-2 py-1 font-mono text-micro font-medium tracking-wide text-lime">
          {feed === "absent" ? "ID ABSENT" : id}
        </div>
      </Html>
    </group>
  );
}

function Scene() {
  return (
    <>
      <color attach="background" args={["#070a08"]} />
      <fog attach="fog" args={["#070a08", 22, 58]} />
      <RigLights />
      <Simulator />
      <mesh rotation-x={-Math.PI / 2} position={[0, 0, 0]}>
        <planeGeometry args={[90, 40]} />
        <meshStandardMaterial color="#0c100d" roughness={1} metalness={0} />
      </mesh>
      <Grid
        args={[80, 36]}
        position={[0, 0.008, 0]}
        cellSize={1}
        cellThickness={0.6}
        cellColor="#1c2a1c"
        sectionSize={4}
        sectionThickness={1.1}
        sectionColor="#314232"
        fadeDistance={48}
        fadeStrength={1.5}
        infiniteGrid={false}
      />
      <primitive object={columns} />
      <Bays />
      <Conveyor />
      <Hoist />
      <TorqueLamps />
      <EnergyRibbon />
      <ThermalLamp />
      <TruckRig />
      <IdPlate />
      <OrbitControls
        makeDefault
        enableDamping
        dampingFactor={0.08}
        maxPolarAngle={Math.PI / 2 - 0.06}
        minDistance={3.2}
        maxDistance={36}
        target={[0, 1.1, 0]}
      />
    </>
  );
}

function useCoarse() {
  const [coarse, setCoarse] = useState(false);
  useEffect(() => {
    setCoarse(window.matchMedia("(pointer: coarse)").matches);
  }, []);
  return coarse;
}

export function TwinViewport() {
  const coarse = useCoarse();
  return (
    <Canvas
      className="h-full w-full touch-none"
      camera={{ position: [12, 6.4, 14], fov: 38, near: 0.1, far: 140 }}
      dpr={coarse ? 1 : [1, 1.5]}
      gl={{
        antialias: !coarse,
        powerPreference: "high-performance",
        toneMapping: THREE.ACESFilmicToneMapping,
      }}
      onCreated={({ gl }) => {
        gl.toneMappingExposure = 1.08;
      }}
    >
      <Scene />
    </Canvas>
  );
}

useGLTF.preload(MODEL_URL);
