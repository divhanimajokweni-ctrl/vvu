import { i as __toESM } from "../_runtime.mjs";
import { b as require_react, y as require_jsx_runtime } from "../_libs/@react-three/drei+[...].mjs";
import { t as create } from "../_libs/zustand.mjs";
import { a as Play, c as Box, i as Scan, n as Unplug, o as Pause, s as Flame, t as Zap } from "../_libs/lucide-react.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CGT1QY6L.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var BAY_X = [
	-16,
	-8,
	0,
	8,
	16
];
var LINE_SPEED = 3.5;
/** Facts as stated for the Oct 2026 Struandale upgrade. No invented torques. */
var STATIONS = [
	{
		id: "chassis",
		index: "01",
		name: "Chassis line",
		short: "CHASSIS",
		sensor: "S-CH-01",
		article: "Line extended. Added stations, updated tooling, optimised layout.",
		receiptMetric: "LINE",
		receiptValue: "EXTENDED",
		metrics: [
			["LINE", "EXTENDED"],
			["STATIONS", "ADDED"],
			["TOOLING", "UPGRADED"],
			["LAYOUT", "OPTIMISED"]
		]
	},
	{
		id: "engine",
		index: "02",
		name: "Engine sub-assembly",
		short: "ENGINE",
		sensor: "S-EN-02",
		article: "Engine-dress process upgraded. Tooling and layout revised.",
		receiptMetric: "DRESS",
		receiptValue: "UPGRADED",
		metrics: [
			["DRESS", "UPGRADED"],
			["TOOLING", "REVISED"],
			["LAYOUT", "OPTIMISED"]
		]
	},
	{
		id: "cab",
		index: "03",
		name: "Cab marriage",
		short: "CAB",
		sensor: "S-CB-03",
		article: "Cab-marriage hoist joins the cab to the chassis.",
		receiptMetric: "HOIST",
		receiptValue: "OPERATIONAL",
		metrics: [["HOIST", "OPERATIONAL"], ["JOIN", "CAB-TO-CHASSIS"]]
	},
	{
		id: "fuel",
		index: "04",
		name: "Fuel tank + lift-assist",
		short: "FUEL",
		sensor: "S-FT-04",
		article: "New fuel-tank gripper. Lift-assist at multiple stations.",
		receiptMetric: "GRIPPER",
		receiptValue: "NEW",
		metrics: [["GRIPPER", "NEW"], ["LIFT-ASSIST", "MULTI-POINT"]]
	},
	{
		id: "torque",
		index: "05",
		name: "Electronic torque",
		short: "TORQUE",
		sensor: "S-TQ-05",
		article: "Electronic torque tools replace manual tools.",
		receiptMetric: "TOOL",
		receiptValue: "ELECTRONIC",
		metrics: [
			["TOOL", "ELECTRONIC"],
			["REPLACES", "MANUAL"],
			["TRACE", "ALONG THE LINE"]
		]
	}
];
var PRODUCTION = [
	["FY2026", "31,200+ vehicles"],
	["D-Max", "27,400"],
	["Trucks", "3,800+"],
	["N-Series", "November 2026"],
	["F-Series", "Early 2027"],
	["Upgrade", "R30 million"]
];
var useTwin = create((set) => ({
	layer: "solid",
	feed: "live",
	running: true,
	trace: true,
	receipts: [],
	head: "",
	selected: null,
	activeBay: 0,
	vehicleId: "DX-4821",
	modelReady: false,
	fps: 0,
	specOpen: false,
	setLayer: (layer) => set({ layer }),
	setFeed: (feed) => set({ feed }),
	setRunning: (running) => set({ running }),
	setTrace: (trace) => set({ trace }),
	setSelected: (selected) => set({ selected }),
	setActiveBay: (activeBay) => set({ activeBay }),
	setVehicleId: (vehicleId) => set({ vehicleId }),
	setModelReady: (modelReady) => set({ modelReady }),
	setFps: (fps) => set({ fps }),
	setSpecOpen: (specOpen) => set({ specOpen }),
	pushReceipt: (receipt) => set((state) => ({
		receipts: [...state.receipts.slice(-47), receipt],
		head: receipt.hash
	}))
}));
var prev = "0".repeat(64);
var seq = 0;
var queue = Promise.resolve();
var lastBeat = Date.now();
var booted = false;
function lastBeatAt() {
	return lastBeat;
}
function noteBeat() {
	lastBeat = Date.now();
}
async function sha256(text) {
	const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
	return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");
}
function emit(stationId, metric, value, absent = false) {
	if (!absent) noteBeat();
	const sensor = STATIONS.find((s) => s.id === stationId)?.sensor ?? "S-LINE-00";
	queue = queue.then(async () => {
		seq += 1;
		const ts = Date.now();
		const hash = await sha256(`${seq}|${ts}|${stationId}|${metric}|${value}|${sensor}|${prev}`);
		prev = hash;
		useTwin.getState().pushReceipt({
			seq,
			ts,
			station: stationId,
			metric,
			value,
			sensor,
			hash,
			absent
		});
	});
}
function bootChain() {
	if (booted) return;
	booted = true;
	noteBeat();
	emit("line", "ANCHOR", "SUNDAY-WORLD-2026-10-06");
}
function failClosed() {
	const state = useTwin.getState();
	if (state.feed === "absent") return;
	state.setFeed("absent");
	state.setRunning(false);
	for (const station of STATIONS) emit(station.id, "SENSOR", "ABSENT", true);
}
function restoreFeed() {
	const state = useTwin.getState();
	if (state.feed === "live") return;
	noteBeat();
	state.setFeed("live");
	state.setRunning(true);
	emit("line", "LINK", "RESTORED");
}
var LAYERS = [
	{
		id: "solid",
		label: "Solid",
		icon: Box
	},
	{
		id: "skeleton",
		label: "Skeleton",
		icon: Scan
	},
	{
		id: "energy",
		label: "Energy",
		icon: Zap
	},
	{
		id: "thermal",
		label: "Thermal",
		icon: Flame
	}
];
function clock(ts) {
	return new Date(ts).toLocaleTimeString("en-ZA", {
		hour12: false,
		hour: "2-digit",
		minute: "2-digit",
		second: "2-digit"
	});
}
function useViewport() {
	const [Viewport, setViewport] = (0, import_react.useState)(null);
	const [failed, setFailed] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		let live = true;
		import("./TwinViewport-D6BHlFaw.mjs").then((mod) => {
			if (live) setViewport(() => mod.TwinViewport);
		}).catch(() => {
			if (live) setFailed(true);
		});
		return () => {
			live = false;
		};
	}, []);
	return {
		Viewport,
		failed
	};
}
function IndustrialTwin() {
	const { Viewport, failed } = useViewport();
	const feed = useTwin((s) => s.feed);
	const modelReady = useTwin((s) => s.modelReady);
	(0, import_react.useEffect)(() => {
		bootChain();
		const beat = window.setInterval(() => {
			if (useTwin.getState().feed !== "live") return;
			const station = STATIONS[Math.floor(Math.random() * STATIONS.length)];
			if (!station) return;
			const metric = station.metrics[Math.floor(Math.random() * station.metrics.length)];
			if (!metric) return;
			emit(station.id, metric[0], metric[1]);
		}, 2800);
		const watch = window.setInterval(() => {
			if (useTwin.getState().feed === "live" && Date.now() - lastBeatAt() > 12e3) failClosed();
		}, 400);
		return () => {
			window.clearInterval(beat);
			window.clearInterval(watch);
		};
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-0 flex flex-col bg-bg text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Header, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-h-0 flex-1 flex-col lg:flex-row",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative min-h-0 min-w-0 flex-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: clsx("absolute inset-0 transition-[filter] duration-300", feed === "absent" && "grayscale brightness-75"),
							children: failed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex h-full items-center justify-center px-6 text-center text-sm text-fail",
								children: "This view needs WebGL. The receipt chain still runs in the dock."
							}) : Viewport ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Viewport, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Binding, { message: "BINDING VIEWPORT" })
						}),
						Viewport && !modelReady && !failed && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "pointer-events-none absolute inset-0 z-10",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Binding, { message: "BINDING ISUZU D-MAX" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FailVeil, {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StationStrip, {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReceiptCard, {})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
					className: "hidden w-80 shrink-0 flex-col border-l border-line bg-panel lg:flex",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RailBody, {})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Worm, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dock, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SpecSheet, {})
		]
	});
}
function Binding({ message }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full flex-col items-center justify-center gap-3 bg-bg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "vvu-pulse h-2 w-2 rounded-full bg-lime" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-lg tracking-[0.22em] text-lime",
				children: message
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-micro text-dim",
				children: "Struandale · commercial vehicle line"
			})
		]
	});
}
function Header() {
	const feed = useTwin((s) => s.feed);
	const head = useTwin((s) => s.head);
	const fps = useTwin((s) => s.fps);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "z-30 flex h-14 shrink-0 items-center justify-between gap-3 border-b border-line bg-panel px-3 sm:px-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-baseline gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-display text-xl font-semibold tracking-[0.16em] text-lime",
					children: "VVU"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "truncate font-display text-base tracking-[0.14em] text-ink",
					children: "INDUSTRIAL TWIN"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "truncate text-micro text-dim",
				children: "Isuzu Gqeberha · Struandale CV line · R30m"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex shrink-0 items-center gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "hidden text-right sm:block",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-micro text-dim",
					children: "CHAIN HEAD"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-micro tabular-nums text-amber",
					children: head ? `∎${head.slice(0, 8)}` : "∎————————"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				role: "status",
				className: clsx("flex h-11 items-center gap-2 border px-3 text-micro font-medium tracking-wide", feed === "live" ? "border-lime text-lime" : "border-fail text-fail"),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: clsx("h-1.5 w-1.5 rounded-full", feed === "live" ? "vvu-pulse bg-lime" : "bg-fail") }),
					feed === "live" ? "FEED LIVE" : "FAIL CLOSED",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "hidden text-dim sm:inline",
						children: fps > 0 ? `${fps} FPS` : ""
					})
				]
			})]
		})]
	});
}
function StationStrip() {
	const activeBay = useTwin((s) => s.activeBay);
	const selected = useTwin((s) => s.selected);
	const setSelected = useTwin((s) => s.setSelected);
	const feed = useTwin((s) => s.feed);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "pointer-events-none absolute inset-x-0 top-0 z-20 p-2",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "pointer-events-auto flex gap-1 overflow-x-auto",
			children: STATIONS.map((station, index) => {
				const on = selected === station.id;
				const here = activeBay === index;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setSelected(on ? null : station.id),
					className: clsx("min-h-11 shrink-0 border bg-bg/85 px-3 text-left backdrop-blur-sm", on ? "border-amber text-amber" : "border-line text-ink"),
					"aria-pressed": on,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex items-center gap-2 text-micro font-medium tracking-wide",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: clsx("h-1.5 w-1.5 rounded-full", here && feed === "live" ? "bg-lime" : "bg-dim") }),
							station.index,
							" ",
							station.short
						]
					})
				}, station.id);
			})
		})
	});
}
function ReceiptCard() {
	const selected = useTwin((s) => s.selected);
	const receipts = useTwin((s) => s.receipts);
	const setSelected = useTwin((s) => s.setSelected);
	const station = STATIONS.find((s) => s.id === selected);
	if (!station) return null;
	const latest = [...receipts].reverse().find((r) => r.station === station.id);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "absolute bottom-3 left-3 right-3 z-20 max-w-md border border-line bg-panel/95 p-3 backdrop-blur-md sm:left-3 sm:right-auto",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-micro tracking-[0.16em] text-dim",
						children: ["STATION ", station.index]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl leading-none tracking-wide text-ink",
						children: station.name
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setSelected(null),
					className: "min-h-11 shrink-0 px-2 text-micro text-muted",
					children: "CLOSE"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-micro text-muted",
				children: station.article
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
				className: "mt-3 grid grid-cols-2 gap-x-3 gap-y-1",
				children: station.metrics.map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-baseline justify-between gap-2 border-b border-line/70 py-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-micro text-dim",
						children: k
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "text-micro text-lime",
						children: v
					})]
				}, k))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 text-micro text-dim",
				children: ["SENSOR ", station.sensor]
			}),
			latest ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: clsx("mt-1 text-micro", latest.absent ? "text-fail" : "text-amber"),
				children: [
					"#",
					String(latest.seq).padStart(3, "0"),
					" ",
					latest.metric,
					"=",
					latest.value,
					" ∎",
					latest.hash.slice(0, 8)
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-micro text-dim",
				children: "No receipt for this station yet."
			})
		]
	});
}
function FailVeil() {
	const feed = useTwin((s) => s.feed);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: clsx("pointer-events-none absolute inset-0 z-10 flex flex-col items-center justify-center bg-bg/55 transition-opacity duration-200", feed === "absent" ? "opacity-100" : "opacity-0"),
		role: "status",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-4xl tracking-[0.18em] text-fail sm:text-5xl",
			children: "SENSOR ABSENT"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-micro tracking-[0.22em] text-fail",
			children: "FAIL CLOSED · NO GUESSED STATE"
		})]
	});
}
function RailBody() {
	const feed = useTwin((s) => s.feed);
	const vehicleId = useTwin((s) => s.vehicleId);
	const activeBay = useTwin((s) => s.activeBay);
	const trace = useTwin((s) => s.trace);
	const setTrace = useTwin((s) => s.setTrace);
	const setSelected = useTwin((s) => s.setSelected);
	const selected = useTwin((s) => s.selected);
	const bay = STATIONS[activeBay];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-0 flex-1 flex-col overflow-y-auto",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "border-b border-line px-4 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-micro tracking-[0.18em] text-dim",
					children: "LINE STATE"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-2",
					children: STATIONS.map((station, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setSelected(station.id),
						className: clsx("flex min-h-11 w-full items-center justify-between gap-2 text-left", selected === station.id ? "text-amber" : "text-ink"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-dim",
									children: station.index
								}),
								" ",
								station.short
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: clsx("text-micro", feed === "live" ? "text-lime" : "text-fail"),
							children: feed === "live" ? index === activeBay ? "IN BAY" : station.sensor : "ABSENT"
						})]
					}) }, station.id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "border-b border-line px-4 py-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-micro tracking-[0.18em] text-dim",
						children: "THIS PASS"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-2 flex items-baseline justify-between",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-display text-3xl tracking-wide text-lime",
							children: feed === "absent" ? "ABSENT" : vehicleId
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-micro text-muted",
						children: feed === "absent" ? "Identity withheld. The chain records absence." : `In ${bay?.name ?? "bay"}`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setTrace(!trace),
						"aria-pressed": trace,
						className: clsx("mt-3 min-h-11 border px-3 text-micro", trace ? "border-lime text-lime" : "border-line text-muted"),
						children: ["TRACE ID ", trace ? "ON" : "OFF"]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "border-b border-line px-4 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-micro tracking-[0.18em] text-dim",
					children: "PUBLISHED VOLUME"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
					className: "mt-2",
					children: PRODUCTION.map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-baseline justify-between gap-3 py-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-micro text-dim",
							children: k
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "text-right text-sm text-ink",
							children: v
						})]
					}, k))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "px-4 py-3 text-micro text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "tracking-[0.18em] text-dim",
						children: "SOURCE"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-pretty",
						children: "Sunday World, 6 October 2026. “Isuzu pumps R30m into Gqeberha truck plant.” Johan Vermeulen, EVP Manufacturing & Product Engineering, from September 2026."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-pretty",
						children: "Receipts are a demonstration feed of that published spec, SHA-256 chained in this session. They are not a live Struandale PLC. Twelve seconds without a receipt fail-closes the twin."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 text-pretty",
						children: [
							"Vehicle model “4x4 ISUZU DMAX OFFROAD” by Şevki ÜNAL,",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								className: "text-amber underline-offset-2 hover:underline",
								href: "https://creativecommons.org/licenses/by/4.0/",
								target: "_blank",
								rel: "noreferrer",
								children: "CC-BY-4.0"
							}),
							", via",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								className: "text-amber underline-offset-2 hover:underline",
								href: "https://sketchfab.com/3d-models/4x4-isuzu-dmax-offroad-442d44cb2b83421787fd5a3e5b1e6dd0",
								target: "_blank",
								rel: "noreferrer",
								children: "Sketchfab"
							}),
							"."
						]
					})
				]
			})
		]
	});
}
function SpecSheet() {
	const open = useTwin((s) => s.specOpen);
	const setOpen = useTwin((s) => s.setSpecOpen);
	if (!open) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-0 z-40 flex flex-col bg-bg lg:hidden",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex h-14 items-center justify-between border-b border-line px-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-xl tracking-[0.14em] text-lime",
				children: "LINE SPEC"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setOpen(false),
				className: "min-h-11 px-3 text-sm text-ink",
				children: "CLOSE"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RailBody, {})]
	});
}
function Worm() {
	const receipts = useTwin((s) => s.receipts);
	const scroller = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const el = scroller.current;
		if (!el) return;
		el.scrollTop = el.scrollHeight;
	}, [receipts]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "z-30 h-24 shrink-0 border-t border-line bg-bg",
		role: "log",
		"aria-live": "polite",
		"aria-label": "WORM receipt chain",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex h-7 items-center justify-between border-b border-line px-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-micro tracking-[0.16em] text-lime",
				children: "WORM · APPEND ONLY"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-micro tabular-nums text-dim",
				children: receipts.length > 0 ? `EVT/${receipts[receipts.length - 1]?.seq}` : "EVT/—"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			ref: scroller,
			className: "worm-scroll h-[4.25rem] overflow-y-auto px-3 py-1",
			children: receipts.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-micro text-dim",
				children: "Chain cold. Waiting for the first receipt."
			}) : receipts.slice(-12).map((receipt) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WormLine, { receipt }, receipt.seq))
		})]
	});
}
function WormLine({ receipt }) {
	const label = receipt.station === "line" ? "LINE" : receipt.station.toUpperCase();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: clsx("truncate text-micro tabular-nums", receipt.absent ? "text-fail" : "text-lime"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-dim",
				children: clock(receipt.ts)
			}),
			" #",
			String(receipt.seq).padStart(3, "0"),
			" ",
			label,
			" ",
			receipt.metric,
			"=",
			receipt.value,
			" ",
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "text-amber",
				children: ["∎", receipt.hash.slice(0, 8)]
			})
		]
	});
}
function Dock() {
	const layer = useTwin((s) => s.layer);
	const setLayer = useTwin((s) => s.setLayer);
	const running = useTwin((s) => s.running);
	const setRunning = useTwin((s) => s.setRunning);
	const feed = useTwin((s) => s.feed);
	const setSpecOpen = useTwin((s) => s.setSpecOpen);
	const specOpen = useTwin((s) => s.specOpen);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "dock z-30 shrink-0 border-t border-line bg-panel px-2 py-2",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-center gap-1",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-1 gap-1",
					role: "tablist",
					"aria-label": "Projection",
					children: LAYERS.map((item) => {
						const Icon = item.icon;
						const on = layer === item.id;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							role: "tab",
							"aria-selected": on,
							onClick: () => setLayer(item.id),
							className: clsx("flex min-h-11 flex-1 items-center justify-center gap-1 border px-2 text-micro", on ? "border-lime bg-lime/10 text-lime" : "border-line text-muted"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
								className: "h-4 w-4",
								"aria-hidden": true
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "hidden sm:inline",
								children: item.label
							})]
						}, item.id);
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setRunning(!running),
					disabled: feed === "absent",
					className: "flex min-h-11 items-center gap-1 border border-line px-3 text-micro text-ink disabled:opacity-40",
					children: [running && feed === "live" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "h-4 w-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "h-4 w-4" }), running && feed === "live" ? "HOLD" : "RUN"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => feed === "live" ? failClosed() : restoreFeed(),
					className: clsx("flex min-h-11 items-center gap-1 border px-3 text-micro", feed === "live" ? "border-fail text-fail" : "border-lime text-lime"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Unplug, {
						className: "h-4 w-4",
						"aria-hidden": true
					}), feed === "live" ? "CUT FEED" : "RESTORE"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setSpecOpen(!specOpen),
					"aria-expanded": specOpen,
					className: "flex min-h-11 items-center border border-line px-3 text-micro text-amber lg:hidden",
					children: "SPEC"
				})
			]
		})
	});
}
var routes_exports = /* @__PURE__ */ __exportAll({ component: () => SplitComponent });
var SplitComponent = IndustrialTwin;
//#endregion
export { LINE_SPEED as a, BAY_X as i, emit as n, STATIONS as o, useTwin as r, routes_exports as t };
