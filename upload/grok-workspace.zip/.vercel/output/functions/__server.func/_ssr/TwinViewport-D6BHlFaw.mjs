import { i as __toESM } from "../_runtime.mjs";
import { _ as Vector3, b as require_react, d as Color, f as InstancedMesh, g as ShaderMaterial, h as Object3D, i as Html, l as Box3, m as MeshStandardMaterial, n as OrbitControls, o as Canvas, p as MeshBasicMaterial, r as useGLTF, s as useFrame, t as Grid, u as BoxGeometry, y as require_jsx_runtime } from "../_libs/@react-three/drei+[...].mjs";
import { a as LINE_SPEED, i as BAY_X, n as emit, o as STATIONS, r as useTwin } from "./routes-CGT1QY6L.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/TwinViewport-D6BHlFaw.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var pose = {
	x: BAY_X[0],
	y: 0,
	roll: 0
};
var sim = {
	phase: "dwell",
	bay: 0,
	dwell: 1.15,
	emitted: -1
};
var reduceMotion = typeof window !== "undefined" && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
var MODEL_URL = "/models/isuzu-dmax.glb";
var conveyorVert = `
  varying vec2 vUv;
  void main() {
    vUv = uv;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
  }
`;
var conveyorFrag = `
  uniform float uTime;
  uniform float uLive;
  varying vec2 vUv;
  void main() {
    float x = vUv.x * 46.0 - uTime * 1.6;
    float chev = abs(fract(x) - 0.5);
    float mark = smoothstep(0.34, 0.36, chev);
    float lane = smoothstep(0.08, 0.02, abs(vUv.y - 0.5));
    float alpha = mark * lane * (uLive > 0.5 ? 0.7 : 0.12);
    vec3 col = uLive > 0.5 ? vec3(0.784, 1.0, 0.0) : vec3(0.30, 0.28, 0.22);
    gl_FragColor = vec4(col, alpha);
  }
`;
function parentOrigin(root) {
	const origin = new Vector3();
	if (root.parent) {
		root.parent.updateWorldMatrix(true, false);
		root.parent.getWorldPosition(origin);
	}
	return origin;
}
function localBox(root) {
	const box = new Box3().setFromObject(root);
	const origin = parentOrigin(root);
	box.min.sub(origin);
	box.max.sub(origin);
	return box;
}
function fitModel(root) {
	root.position.set(0, 0, 0);
	root.rotation.set(0, 0, 0);
	root.scale.set(1, 1, 1);
	root.updateMatrixWorld(true);
	let box = localBox(root);
	let size = box.getSize(new Vector3());
	if (size.z > size.x) {
		root.rotation.y = Math.PI / 2;
		root.updateMatrixWorld(true);
		box = localBox(root);
		size = box.getSize(new Vector3());
	}
	root.scale.setScalar(5.3 / Math.max(size.x, .001));
	root.updateMatrixWorld(true);
	box = localBox(root);
	const center = box.getCenter(new Vector3());
	root.position.x -= center.x;
	root.position.z -= center.z;
	root.position.y -= box.min.y;
	root.updateMatrixWorld(true);
}
function Simulator() {
	const acc = (0, import_react.useRef)(0);
	const frames = (0, import_react.useRef)(0);
	useFrame((_, delta) => {
		const dt = Math.min(delta, .1);
		acc.current += dt;
		frames.current += 1;
		if (acc.current >= .5) {
			useTwin.getState().setFps(Math.round(frames.current / acc.current));
			acc.current = 0;
			frames.current = 0;
		}
		if (document.hidden) return;
		const { running, feed } = useTwin.getState();
		const live = feed === "live";
		const moving = running && live && sim.phase !== "dwell";
		if (sim.phase === "dwell") {
			if (live && sim.emitted !== sim.bay) {
				sim.emitted = sim.bay;
				const station = STATIONS[sim.bay];
				if (station) {
					emit(station.id, station.receiptMetric, station.receiptValue);
					if (sim.bay === 0) {
						const id = `DX-${String(1e3 + Math.floor(Math.random() * 9e3))}`;
						useTwin.getState().setVehicleId(id);
						emit("chassis", "VEHICLE_ID", id);
					}
					useTwin.getState().setActiveBay(sim.bay);
				}
			}
			if (running && live) sim.dwell -= dt;
			if (sim.dwell <= 0) {
				const leaving = sim.bay;
				sim.bay = (sim.bay + 1) % STATIONS.length;
				sim.dwell = 2.15;
				sim.phase = leaving === STATIONS.length - 1 ? "wrap" : "move";
			}
		} else if (sim.phase === "move" && running && live) {
			const target = BAY_X[sim.bay] ?? 0;
			const dx = target - pose.x;
			const step = LINE_SPEED * dt;
			if (Math.abs(dx) <= step) {
				pose.x = target;
				sim.phase = "dwell";
			} else pose.x += Math.sign(dx) * step;
		} else if (sim.phase === "wrap" && running && live) {
			pose.x += LINE_SPEED * dt;
			const end = BAY_X[BAY_X.length - 1] ?? 16;
			const start = BAY_X[0] ?? -16;
			if (pose.x > end + 6) {
				pose.x = start - 6;
				sim.phase = "move";
			}
		}
		if (moving && !reduceMotion) {
			const t = performance.now() / 1e3;
			pose.y = Math.sin(t * 10.5) * .012 + Math.sin(t * 17.3) * .004;
			pose.roll = Math.sin(t * 10.5) * .008;
		} else {
			pose.y += (0 - pose.y) * Math.min(1, dt * 6);
			pose.roll += (0 - pose.roll) * Math.min(1, dt * 6);
		}
	});
	return null;
}
function RigLights() {
	const key = (0, import_react.useRef)(null);
	const rim = (0, import_react.useRef)(null);
	const fill = (0, import_react.useRef)(null);
	useFrame(() => {
		const live = useTwin.getState().feed === "live";
		if (key.current) key.current.intensity = live ? 2.5 : .28;
		if (rim.current) rim.current.intensity = live ? 1.45 : 0;
		if (fill.current) fill.current.intensity = live ? .85 : .15;
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ambientLight", { intensity: .28 }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("hemisphereLight", { args: [
			"#d5e2c4",
			"#090b09",
			.4
		] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("directionalLight", {
			ref: key,
			position: [
				14,
				18,
				9
			],
			intensity: 2.5,
			color: "#fff6ea"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("directionalLight", {
			ref: fill,
			position: [
				-4,
				6,
				12
			],
			intensity: .85,
			color: "#e7f0dc"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("directionalLight", {
			ref: rim,
			position: [
				-10,
				7,
				-8
			],
			intensity: 1.45,
			color: "#c8ff00"
		})
	] });
}
function Bays() {
	const mats = (0, import_react.useMemo)(() => BAY_X.map(() => new MeshStandardMaterial({
		color: "#121812",
		roughness: .94,
		metalness: 0,
		emissive: new Color("#c8ff00"),
		emissiveIntensity: 0
	})), []);
	useFrame(() => {
		const { activeBay, feed } = useTwin.getState();
		mats.forEach((mat, index) => {
			mat.emissiveIntensity = feed === "live" && index === activeBay ? .22 : 0;
		});
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("group", { children: BAY_X.map((x, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", {
		position: [
			x,
			0,
			0
		],
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("mesh", {
				"rotation-x": -Math.PI / 2,
				position: [
					0,
					.012,
					0
				],
				material: mats[index],
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("planeGeometry", { args: [6.6, 10.5] })
			}),
			[-4.4, 4.4].map((z) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					0,
					1.9,
					z
				],
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
					.16,
					3.8,
					.16
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
					color: "#1a221a",
					roughness: .8
				})]
			}, z)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					0,
					3.78,
					0
				],
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
					.16,
					.12,
					9
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
					color: "#243024",
					emissive: "#c8ff00",
					emissiveIntensity: .15,
					roughness: .6
				})]
			})
		]
	}, x)) });
}
function Conveyor() {
	const mat = (0, import_react.useMemo)(() => new ShaderMaterial({
		transparent: true,
		depthWrite: false,
		uniforms: {
			uTime: { value: 0 },
			uLive: { value: 1 }
		},
		vertexShader: conveyorVert,
		fragmentShader: conveyorFrag
	}), []);
	useFrame(({ clock }) => {
		const { feed, running } = useTwin.getState();
		mat.uniforms.uLive.value = feed === "live" ? 1 : 0;
		if (feed === "live" && running && !reduceMotion) mat.uniforms.uTime.value = clock.elapsedTime;
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("mesh", {
		"rotation-x": -Math.PI / 2,
		position: [
			0,
			.03,
			0
		],
		material: mat,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("planeGeometry", { args: [48, 2.15] })
	});
}
function Hoist() {
	const carriage = (0, import_react.useRef)(null);
	const drop = (0, import_react.useRef)(0);
	useFrame((_, delta) => {
		const dt = Math.min(delta, .1);
		const near = useTwin.getState().feed === "live" && Math.abs(pose.x - (BAY_X[2] ?? 0)) < 2.5 && sim.phase === "dwell" && sim.bay === 2;
		drop.current += ((near ? 1 : 0) - drop.current) * Math.min(1, dt * (near ? 1.6 : 2.4));
		if (carriage.current) carriage.current.position.y = 3.15 - drop.current * 1.25;
	});
	const x = BAY_X[2] ?? 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", {
		position: [
			x,
			0,
			0
		],
		children: [[-.7, .7].map((z) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				0,
				2.7,
				z
			],
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
				.06,
				2.2,
				.06
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
				color: "#c8ff00",
				emissive: "#c8ff00",
				emissiveIntensity: .35
			})]
		}, z)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", {
			ref: carriage,
			position: [
				0,
				3.15,
				0
			],
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
				1.7,
				.08,
				1.7
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
				color: "#d7e2cc",
				metalness: .45,
				roughness: .35
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					0,
					-.45,
					0
				],
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
					1.35,
					.55,
					1.2
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
					color: "#1c241c",
					roughness: .55,
					metalness: .15
				})]
			})]
		})]
	});
}
function TorqueLamps() {
	const mats = (0, import_react.useRef)([]);
	useFrame(({ clock }) => {
		const near = useTwin.getState().feed === "live" && Math.abs(pose.x - (BAY_X[4] ?? 16)) < 2.6;
		const step = Math.floor(clock.elapsedTime * 3) % 4;
		mats.current.forEach((mat, index) => {
			mat.opacity = near && index === step ? 1 : .16;
		});
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("group", {
		position: [
			BAY_X[4] ?? 16,
			.045,
			1.55
		],
		children: [
			0,
			1,
			2,
			3
		].map((index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				(index - 1.5) * .42,
				0,
				0
			],
			"rotation-x": -Math.PI / 2,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ringGeometry", { args: [
				.07,
				.12,
				20
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshBasicMaterial", {
				ref: (mat) => {
					if (mat) mats.current[index] = mat;
				},
				color: "#f3e38a",
				transparent: true,
				opacity: .16,
				depthWrite: false,
				side: 2
			})]
		}, index))
	});
}
function EnergyRibbon() {
	const layer = useTwin((s) => s.layer);
	const mat = (0, import_react.useMemo)(() => new ShaderMaterial({
		transparent: true,
		depthWrite: false,
		blending: 2,
		uniforms: {
			uTime: { value: 0 },
			uLive: { value: 1 }
		},
		vertexShader: conveyorVert,
		fragmentShader: `
          uniform float uTime;
          uniform float uLive;
          varying vec2 vUv;
          void main() {
            float flow = fract(vUv.x * 3.0 - uTime * 0.35);
            float head = smoothstep(0.0, 0.15, flow) * smoothstep(0.45, 0.15, flow);
            float core = smoothstep(0.18, 0.0, abs(vUv.y - 0.5));
            float alpha = (0.12 + head) * core * (uLive > 0.5 ? 1.0 : 0.25);
            gl_FragColor = vec4(0.784, 1.0, 0.0, alpha);
          }
        `
	}), []);
	useFrame(({ clock }) => {
		mat.uniforms.uTime.value = reduceMotion ? 0 : clock.elapsedTime;
		mat.uniforms.uLive.value = useTwin.getState().feed === "live" ? 1 : 0;
	});
	if (layer !== "energy") return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("mesh", {
		"rotation-x": -Math.PI / 2,
		position: [
			0,
			.05,
			2.35
		],
		material: mat,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("planeGeometry", { args: [46, .28] })
	});
}
function ThermalLamp() {
	const layer = useTwin((s) => s.layer);
	const light = (0, import_react.useRef)(null);
	const orb = (0, import_react.useRef)(null);
	useFrame(({ clock }) => {
		const live = useTwin.getState().feed === "live";
		const on = layer === "thermal" && live;
		const pulse = .75 + Math.sin(clock.elapsedTime * 6) * .25;
		if (light.current) {
			light.current.position.set(pose.x + 1.55, .95, .15);
			light.current.intensity = on ? 14 * pulse : 0;
		}
		if (orb.current) {
			orb.current.position.set(pose.x + 1.55, .95, .15);
			orb.current.visible = on;
			const s = .18 + pulse * .06;
			orb.current.scale.setScalar(s);
		}
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pointLight", {
		ref: light,
		color: "#f3e38a",
		distance: 5.5,
		decay: 2,
		intensity: 0
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
		ref: orb,
		visible: false,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
			1,
			16,
			16
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshBasicMaterial", {
			color: "#f3e38a",
			transparent: true,
			opacity: .85
		})]
	})] });
}
function sideColumns() {
	const mesh = new InstancedMesh(new BoxGeometry(.32, 4.4, .32), new MeshStandardMaterial({
		color: "#141b14",
		roughness: .86
	}), 12);
	const dummy = new Object3D();
	let i = 0;
	for (const x of [
		-20,
		-12,
		-4,
		4,
		12,
		20
	]) for (const z of [-7.2, 7.2]) {
		dummy.position.set(x, 2.2, z);
		dummy.updateMatrix();
		mesh.setMatrixAt(i, dummy.matrix);
		i += 1;
	}
	mesh.count = i;
	mesh.instanceMatrix.needsUpdate = true;
	return mesh;
}
var columns = sideColumns();
var wireMat = new MeshBasicMaterial({
	color: "#c8ff00",
	wireframe: true,
	transparent: true,
	opacity: .85
});
var deadMat = new MeshStandardMaterial({
	color: "#2a3128",
	roughness: 1,
	metalness: 0
});
function applyLook(slots, layer, feed) {
	for (const slot of slots) {
		const origList = Array.isArray(slot.orig) ? slot.orig : [slot.orig];
		if (feed === "absent") {
			slot.mesh.material = deadMat;
			continue;
		}
		if (layer === "skeleton") {
			slot.mesh.material = wireMat;
			continue;
		}
		slot.mesh.material = slot.orig;
		for (const mat of origList) {
			const standard = mat;
			if (!standard.emissive) continue;
			if (layer === "energy") {
				standard.emissive.set("#c8ff00");
				standard.emissiveIntensity = .55;
			} else if (layer === "thermal") {
				standard.emissive.set("#f3e38a");
				standard.emissiveIntensity = .28;
			} else {
				standard.emissive.set("#000000");
				standard.emissiveIntensity = 1;
			}
		}
	}
}
function Marker({ id, position }) {
	const mesh = (0, import_react.useRef)(null);
	const selected = useTwin((s) => s.selected === id);
	const feed = useTwin((s) => s.feed);
	useFrame(({ clock }) => {
		if (!mesh.current || reduceMotion) return;
		const pulse = 1 + Math.sin(clock.elapsedTime * 3 + position[0]) * .16;
		mesh.current.scale.setScalar(feed === "live" ? pulse : 1);
	});
	const pick = (event) => {
		event.stopPropagation();
		useTwin.getState().setSelected(id);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", {
		position,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			ref: mesh,
			onClick: pick,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
				.09,
				16,
				16
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshBasicMaterial", { color: feed === "absent" ? "#5c6b52" : selected ? "#f3e38a" : "#c8ff00" })]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			onClick: pick,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
				.46,
				10,
				10
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshBasicMaterial", {
				transparent: true,
				opacity: 0,
				depthWrite: false
			})]
		})]
	});
}
function FittedTruck() {
	const { scene } = useGLTF(MODEL_URL);
	const slots = (0, import_react.useRef)([]);
	const [spots, setSpots] = (0, import_react.useState)([]);
	const layer = useTwin((s) => s.layer);
	const feed = useTwin((s) => s.feed);
	const shell = (0, import_react.useRef)(null);
	(0, import_react.useLayoutEffect)(() => {
		if (!scene.userData.vvuFit) {
			fitModel(scene);
			scene.userData.vvuFit = true;
		}
		const found = [];
		scene.traverse((obj) => {
			const mesh = obj;
			if (!mesh.isMesh) return;
			mesh.castShadow = false;
			mesh.receiveShadow = false;
			if (!mesh.userData.vvuOrig) mesh.userData.vvuOrig = mesh.material;
			found.push({
				mesh,
				orig: mesh.userData.vvuOrig
			});
		});
		slots.current = found;
		const group = shell.current;
		if (!group) return;
		const box = new Box3().setFromObject(scene);
		const min = group.worldToLocal(box.min.clone());
		const max = group.worldToLocal(box.max.clone());
		const span = (t, a, b) => a + (b - a) * t;
		setSpots([
			{
				id: "chassis",
				position: [
					span(.5, min.x, max.x),
					span(.22, min.y, max.y),
					span(.5, min.z, max.z)
				]
			},
			{
				id: "engine",
				position: [
					span(.82, min.x, max.x),
					span(.46, min.y, max.y),
					span(.5, min.z, max.z)
				]
			},
			{
				id: "cab",
				position: [
					span(.46, min.x, max.x),
					span(.74, min.y, max.y),
					span(.5, min.z, max.z)
				]
			},
			{
				id: "fuel",
				position: [
					span(.38, min.x, max.x),
					span(.32, min.y, max.y),
					span(.82, min.z, max.z)
				]
			},
			{
				id: "torque",
				position: [
					span(.78, min.x, max.x),
					span(.18, min.y, max.y),
					span(.16, min.z, max.z)
				]
			}
		]);
		useTwin.getState().setModelReady(true);
	}, [scene]);
	(0, import_react.useEffect)(() => {
		applyLook(slots.current, layer, feed);
	}, [
		layer,
		feed,
		spots
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", {
		ref: shell,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("primitive", { object: scene }), spots.map((spot) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Marker, {
			id: spot.id,
			position: spot.position
		}, spot.id))]
	});
}
function TruckRig() {
	const ref = (0, import_react.useRef)(null);
	useFrame(() => {
		const group = ref.current;
		if (!group) return;
		group.position.x = pose.x;
		group.position.y = pose.y;
		group.rotation.z = pose.roll;
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", {
		ref,
		position: [
			pose.x,
			0,
			0
		],
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FittedTruck, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			"rotation-x": -Math.PI / 2,
			position: [
				0,
				.04,
				0
			],
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circleGeometry", { args: [1.7, 32] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshBasicMaterial", {
				color: "#050705",
				transparent: true,
				opacity: .45,
				depthWrite: false
			})]
		})]
	});
}
function IdPlate() {
	const trace = useTwin((s) => s.trace);
	const id = useTwin((s) => s.vehicleId);
	const feed = useTwin((s) => s.feed);
	const anchor = (0, import_react.useRef)(null);
	useFrame(() => {
		if (!anchor.current) return;
		anchor.current.position.set(pose.x, 2.45 + pose.y, 0);
	});
	if (!trace) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("group", {
		ref: anchor,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Html, {
			center: true,
			distanceFactor: 11,
			zIndexRange: [12, 0],
			style: { pointerEvents: "none" },
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "whitespace-nowrap border border-lime/70 bg-bg/90 px-2 py-1 font-mono text-micro font-medium tracking-wide text-lime",
				children: feed === "absent" ? "ID ABSENT" : id
			})
		})
	});
}
function Scene() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("color", {
			attach: "background",
			args: ["#070a08"]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("fog", {
			attach: "fog",
			args: [
				"#070a08",
				22,
				58
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RigLights, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Simulator, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			"rotation-x": -Math.PI / 2,
			position: [
				0,
				0,
				0
			],
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("planeGeometry", { args: [90, 40] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
				color: "#0c100d",
				roughness: 1,
				metalness: 0
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Grid, {
			args: [80, 36],
			position: [
				0,
				.008,
				0
			],
			cellSize: 1,
			cellThickness: .6,
			cellColor: "#1c2a1c",
			sectionSize: 4,
			sectionThickness: 1.1,
			sectionColor: "#314232",
			fadeDistance: 48,
			fadeStrength: 1.5,
			infiniteGrid: false
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("primitive", { object: columns }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bays, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Conveyor, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hoist, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TorqueLamps, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EnergyRibbon, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThermalLamp, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TruckRig, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IdPlate, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrbitControls, {
			makeDefault: true,
			enableDamping: true,
			dampingFactor: .08,
			maxPolarAngle: Math.PI / 2 - .06,
			minDistance: 3.2,
			maxDistance: 36,
			target: [
				0,
				1.1,
				0
			]
		})
	] });
}
function useCoarse() {
	const [coarse, setCoarse] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		setCoarse(window.matchMedia("(pointer: coarse)").matches);
	}, []);
	return coarse;
}
function TwinViewport() {
	const coarse = useCoarse();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Canvas, {
		className: "h-full w-full touch-none",
		camera: {
			position: [
				12,
				6.4,
				14
			],
			fov: 38,
			near: .1,
			far: 140
		},
		dpr: coarse ? 1 : [1, 1.5],
		gl: {
			antialias: !coarse,
			powerPreference: "high-performance",
			toneMapping: 4
		},
		onCreated: ({ gl }) => {
			gl.toneMappingExposure = 1.08;
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scene, {})
	});
}
useGLTF.preload(MODEL_URL);
//#endregion
export { TwinViewport };
