//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CIVCpxGX.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-CqDNf1O-.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CqDNf1O-.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BHujttA8.js"]
	}
} });
//#endregion
export { tsrStartManifest };
