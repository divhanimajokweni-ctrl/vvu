# Evidence — pilot MVP

The evidence note for the pilot MVP: exact commands, the hash chain spec,
the verify output, the 90-second demo script, and the honest limits.

