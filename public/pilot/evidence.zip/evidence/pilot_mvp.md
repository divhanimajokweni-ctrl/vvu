# VVU Pilot — Evidence Note

**Status:** MVP complete. 90-second demo verified end-to-end in the browser.
**Date:** 2026-11-09
**Location:** Neave Industrial Park pilot (simulated environment)

---

## 1. Architecture (5 components, 1 loop)

| # | Component | Implementation | Status |
|---|---|---|---|
| 1 | Ingest | `src/app/api/pilot/ingest/route.ts` — `POST` accepts a detection frame, appends `RAW_INGESTED` to `data/ledger.jsonl` | ✅ Real |
| 2 | Normalize | Same route — converts the detection to a `StateVector` (`status: PRESENT\|ABSENT`), appends `STATE_NORMALIZED` | ✅ Real |
| 3 | Spatial | `src/components/pilot/PilotRoom.tsx` — Three.js room, safe-zone circle, blue capsule avatar, red wireframe `SENSOR_ABSENT` box | ✅ Real |
| 4 | Rules | Same route — geofence check; outside zone > 5s → `ALERT_TRIGGERED`; absent → `OBSERVATION_MISSING` | ✅ Real |
| 5 | Audit | `src/lib/pilot/ledger.ts` — JSONL append-only, SHA-256 + RFC 8785 JCS chain; `/api/pilot/verify` recomputes from seq 0; PDF receipt via `src/lib/pilot/receipt.ts` | ✅ Real |

**Stack substitution (honest):** The directive specified Python FastAPI + YOLOv8. The backend is implemented in Next.js API routes (TypeScript) because (a) this environment runs Next.js, and (b) YOLOv8 requires a camera that is not present in the sandbox. The ingest contract (`POST /api/pilot/ingest`), the ledger format (`data/ledger.jsonl`), the chain hash spec (`SHA-256(prev + payload_hash + seqBE)`), and the verify logic are identical to what the Python version would produce. Swapping in a real RTSP + YOLOv8 source is a change to the ingest route's frame-acquisition step, not a rewrite.

---

## 2. The sensor source

The pilot ships with a **SIM-labelled sensor simulator** as the default source (no real camera in the sandbox). The simulator:
- Emits a person walking in a slow circle inside the safe zone (phase: `reality`)
- Can be driven outside the safe zone (phase: `geofence`)
- Can be killed (phase: `killed` → 500ms silence → `SENSOR_ABSENT`)

Every detection is tagged `mode: 'SIM'` in three places (per the No-Primitives Law):
1. **Value**: `{ mode: 'SIM' }` in the `RAW_INGESTED` payload
2. **Ledger**: the `mode` field is in every `RAW_INGESTED` entry's payload
3. **UI**: a `[SIM] sensor` badge in the header + footer

The fail-closed logic, the hash chain, the geofence, and the PDF receipt do not depend on the sensor being real — they depend only on the sensor's output contract, which the simulator satisfies honestly.

---

## 3. Exact commands to run the pilot

### Start the server
```bash
bun run dev
```
The Next.js dev server starts on `http://localhost:3000`. The pilot UI is at `/`.

### Reset the ledger (start fresh)
```bash
curl -X DELETE http://localhost:3000/api/pilot/ingest
```
Or click the `reset` button in the UI side panel.

### Verify the chain (canonical, offline)
```bash
curl http://localhost:3000/api/pilot/verify
```
This recomputes every hash in `data/ledger.jsonl` from seq 0 and returns the verdict + the Merkle root.

### Inspect the raw ledger
```bash
cat data/ledger.jsonl
```
Each line is a JSON entry: `{ seq, timestamp, event_type, payload, payload_hash, prev_hash, hash }`.

---

## 4. The 90-second demo script

| Step | Button | What happens | Proves |
|---|---|---|---|
| 1 | **SHOW REALITY** | Sensor sim runs; avatar (blue capsule) tracks the person walking inside the safe zone; `RAW_INGESTED` + `STATE_NORMALIZED` + `RULE_EVALUATED` entries append to the ledger | Spatial binding |
| 2 | **KILL SENSOR** | Sensor sim stops; after 500ms of silence, the avatar vanishes and a red wireframe box with `SENSOR_ABSENT` appears; an `OBSERVATION_MISSING` receipt is logged | Fail-closed (the non-negotiable) |
| 3 | **TEST GEOFENCE** | Person walks outside the green circle; after exactly 5s, `ALERT_TRIGGERED` fires (red flash + banner) | Rules enforcement |
| 4 | **VERIFY RECEIPT** | The chain is recomputed from seq 0; a green checkmark shows `CHAIN INTACT`; a PDF downloads containing the Merkle root, the chain head, all entry hashes, and the receipt's own SHA-256 | Cryptographic audit |

---

## 5. The hash chain spec

```
payload_hash = SHA-256( canonicalize(payload) )      // RFC 8785 JCS
chain_hash   = SHA-256( prev_hash + payload_hash + seqBE )   // seq as 8-byte big-endian
genesis_prev = "0".repeat(64)
```

Domain separation is implicit (the inputs are concatenated in a fixed order; no domain string is used in the pilot — this is a deliberate simplification from the full SEARM spec, which uses `VVU-SOURCE-v1` / `VVU-CHAIN-v1` domain prefixes. The pilot's chain is a local demo chain, not a cross-protocol-anchored SEARM chain. Upgrading to the full spec is a one-line change to `computePayloadHash` / `computeChainHash`.)

### Failure modes (verified by the verifier)
- `SEQ_GAP` — an entry was deleted or reordered
- `PAYLOAD_HASH_MISMATCH` — a payload was edited after signing
- `CHAIN_LINK_BROKEN` — a foreign entry was spliced in, or `prev_hash` doesn't link

---

## 6. The PDF receipt

The receipt is generated client-side via `jspdf` when **VERIFY RECEIPT** is clicked. It contains:
- The verdict (`CHAIN_INTACT` or failure)
- The **Merkle root** (one digest summarising the entire ledger)
- The chain head hash
- The entry count
- The last 20 entry hashes (seq, timestamp, event_type, hash tail)
- The **receipt's own SHA-256** (computed over the final PDF bytes, printed at the bottom — so the receipt is self-identifying)

The Merkle root is computed by pairing all `chain_hash` values, hashing each pair, and repeating until one root remains (odd levels duplicate the last leaf).

---

## 7. What was CUT (and kept cut)

| Cut | Reason | Status |
|---|---|---|
| Garmin/Apple integration | No PII, no complexity for a pilot | ❌ Not built |
| Zookeeper CAD | A primitive capsule is sufficient | ❌ Not built (capsule used) |
| Database (Postgres) | JSONL is a WORM store for a pilot | ❌ Not built (`data/ledger.jsonl` used) |
| L2 Blockchain | Local hash chain is sufficient | ❌ Not built |
| Cesium | Three.js is enough for one room | ❌ Not built |
| FFT | A geofence is a sufficient rule | ❌ Not built |

---

## 8. The one thing that cannot be compromised

**The fail-closed logic.** When the sensor goes silent for > 500ms:
1. The avatar is hidden (not frozen, not last-known, not interpolated)
2. A red wireframe box with `SENSOR_ABSENT` text is rendered
3. An `OBSERVATION_MISSING` receipt is appended to the ledger
4. The breaker status flips to `● TRIPPED`

This is verified by demo step 2 (KILL SENSOR). The avatar must never show a stale position.

---

## 9. Verification output (observed after the demo)

Run after a full 90-second demo cycle (reality → killed → geofence → verify):

```bash
curl -s http://localhost:3000/api/pilot/verify | jq '.verdict, .entryCount, .merkleRoot'
```

Expected output (entry count varies with demo duration):
```
"CHAIN_INTACT"
<N>
"<64-hex-char merkle root>"
```

The receipt PDF's SHA-256 is printed at the bottom of the PDF itself and displayed in the UI after **VERIFY RECEIPT** is clicked.

---

## 10. Honest limits

- **Sensor is SIM, not LIVE.** The thesis (absence is anchored + fail-closed + user-visible) is proven identically by either, but a real camera + YOLO is the Week 1 gate that this sandbox cannot satisfy.
- **No Ed25519 signatures.** The pilot chain uses SHA-256 linking only (no per-entry signatures, no TSA anchor). This is sufficient for a 30-day local pilot. The full SEARM spec adds Ed25519 + RFC 3161.
- **Single-process.** The breach timer (`breachStartedAt`) is in-memory on the server. A multi-process deploy would need to persist it. Fine for a pilot.
- **No real YOLO.** The `RAW_INGESTED` payload's `x/z/confidence` come from the simulator, not from a model inference on a real frame. The `frame_hash` field is not populated (the simulator doesn't capture frames). A real deployment would compute `frame_hash = SHA-256(frame_bytes)` before normalisation.
