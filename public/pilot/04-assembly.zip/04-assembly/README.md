# 04 · ASSEMBLY (8-station line)

HBK Mk-II Hydro-Gateway assembly-line sim. 8 stations (S1-S8), takt 14s.
KPIs: packed, rejected, first-pass yield, units/hr, WIP, lead time.
Fault mode, 5 camera views (overview, feed, node, test, top).

**Mode:** SIM (header says "sim"; KPIs not tagged at value level — known gap)

## Run standalone
Serve over HTTP (loads Three.js from CDN):
```bash
python3 -m http.server 8000
# open http://localhost:8000/assembly.html
```

