# 08 · PILOT (the 90-second proof)

Neave Industrial Park pilot — the Minimum Viable Loop.

## The three invariants
1. **Render is deterministic from StateVector.** Sensor dead → red
   wireframe SENSOR_ABSENT box (centered, no position carry-forward).
2. **Every transition (including ABSENT) is appended to the hash chain.**
   The ledger logs RAW_INGESTED + STATE_NORMALIZED + RULE_EVALUATED per
   frame, plus OBSERVATION_MISSING / ALERT_TRIGGERED when they fire.
3. **User can recompute the chain independently.** `/api/pilot/verify`
   recomputes every SHA-256 from seq 0. The PDF receipt carries the
   Merkle root.

## The 90-second demo
1. SHOW REALITY — sensor sim runs, avatar tracks the person
2. KILL SENSOR — 500ms silence → red wireframe SENSOR_ABSENT
3. TEST GEOFENCE — person exits circle → 5s → ALERT_TRIGGERED
4. VERIFY RECEIPT (in the shell's DATA screen) — CHAIN INTACT + PDF

## Files
- `src/components/pilot/PilotRoom.tsx` — Three.js room + demo controls
- `src/lib/pilot/ledger.ts` — JSONL append-only chain, SHA-256 + JCS, verify
- `src/lib/pilot/receipt.ts` — PDF receipt generator (jspdf, Merkle root)
- `src/app/api/pilot/ingest/route.ts` — POST detection → 3 ledger entries
- `src/app/api/pilot/verify/route.ts` — GET recomputes the whole chain
- `src/app/api/pilot/state/route.ts` — GET latest state + recent entries

## Honest substitution
The directive specifies Python + YOLOv8. This is TypeScript (Next.js API
routes) because the sandbox runs Next.js and there's no camera. The
ingest contract, ledger format, chain hash spec, and verify logic are
identical to what the Python version would produce.

## Sensor source
SIM-labelled simulator (no camera in the sandbox). Tagged in three places
(value, ledger, UI chrome) per the No-Primitives Law. Swapping in a real
RTSP + YOLOv8 source is a change to the ingest route's frame-acquisition
step, not a rewrite.

