/**
 * VVU Pilot · Ledger — append-only JSONL hash chain
 * ─────────────────────────────────────────────────
 * Each line of `ledger.jsonl` is a JSON entry:
 *   { seq, timestamp, event_type, payload, payload_hash, prev_hash, hash }
 *
 * The chain links are SHA-256:
 *   payload_hash = SHA256(canonicalize(payload))
 *   hash         = SHA256(prev_hash + payload_hash + seqBE)
 *
 * This mirrors the SEARM worm-chain spec but simplified for the pilot:
 * no Ed25519 signatures, no TSA anchor — the local hash chain is
 * sufficient for a 30-day pilot (per the directive: "No L2 Blockchain.
 * The local hash chain is sufficient for the demo").
 *
 * The verify function recomputes every hash from seq 0 and either
 * returns CHAIN_INTACT or the first failure (SEQ_GAP / PAYLOAD_HASH_MISMATCH
 * / CHAIN_LINK_BROKEN).
 *
 * merkleRoot() computes a Merkle root over all chain hashes for the
 * PDF receipt — proving the entire ledger reduces to one digest.
 */
import { promises as fs } from 'node:fs'
import path from 'node:path'
import canonicalize from 'canonicalize'

export const LEDGER_PATH = path.join(process.cwd(), 'data', 'ledger.jsonl')
export const GENESIS_PREV = '0000000000000000000000000000000000000000000000000000000000000000'

export type EventType =
  | 'RAW_INGESTED'
  | 'STATE_NORMALIZED'
  | 'RULE_EVALUATED'
  | 'ALERT_TRIGGERED'
  | 'OBSERVATION_MISSING'

export interface LedgerEntry {
  seq: number
  timestamp: string
  event_type: EventType
  payload: Record<string, unknown>
  payload_hash: string
  prev_hash: string
  hash: string
}

export interface VerifyResult {
  ok: boolean
  entryCount: number
  merkleRoot: string
  head: string
  error?: string
  errorSeq?: number
  warnings: string[]
}

/* ── SHA-256 hex (Node crypto) ─────────────────────────────────────────── */
async function sha256Hex(text: string): Promise<string> {
  const { createHash } = await import('node:crypto')
  return createHash('sha256').update(text, 'utf8').digest('hex')
}

function seqToBytes(seq: number): string {
  const buf = Buffer.alloc(8)
  buf.writeBigUInt64BE(BigInt(seq))
  return buf.toString('hex')
}

/* ── Compute the payload_hash for an entry ────────────────────────────── */
export async function computePayloadHash(payload: Record<string, unknown>): Promise<string> {
  const canon = canonicalize(payload)
  if (!canon) throw new Error('JCS canonicalisation failed')
  return sha256Hex(canon)
}

/* ── Compute the chain hash for an entry ──────────────────────────────── */
export async function computeChainHash(
  prevHash: string,
  payloadHash: string,
  seq: number,
): Promise<string> {
  return sha256Hex(prevHash + payloadHash + seqToBytes(seq))
}

/* ── Append an entry to the JSONL ledger (atomic) ─────────────────────── */
export async function appendEntry(
  eventType: EventType,
  payload: Record<string, unknown>,
): Promise<LedgerEntry> {
  await fs.mkdir(path.dirname(LEDGER_PATH), { recursive: true })

  const entries = await readLedger()
  const seq = entries.length
  const prevHash = entries.at(-1)?.hash ?? GENESIS_PREV

  const payloadHash = await computePayloadHash(payload)
  const hash = await computeChainHash(prevHash, payloadHash, seq)

  const entry: LedgerEntry = {
    seq,
    timestamp: new Date().toISOString(),
    event_type: eventType,
    payload,
    payload_hash: payloadHash,
    prev_hash: prevHash,
    hash,
  }

  await fs.appendFile(LEDGER_PATH, JSON.stringify(entry) + '\n', 'utf8')
  return entry
}

/* ── Read the full ledger as an array of entries ──────────────────────── */
export async function readLedger(): Promise<LedgerEntry[]> {
  try {
    const raw = await fs.readFile(LEDGER_PATH, 'utf8')
    const entries: LedgerEntry[] = []
    for (const line of raw.split('\n')) {
      const trimmed = line.trim()
      if (!trimmed) continue
      try {
        entries.push(JSON.parse(trimmed) as LedgerEntry)
      } catch {
        /* skip corrupt line */
      }
    }
    return entries
  } catch (err) {
    if ((err as NodeJS.ErrnoException).code === 'ENOENT') return []
    throw err
  }
}

/* ── Reset the ledger (for the demo "start fresh") ─────────────────────── */
export async function resetLedger(): Promise<void> {
  try {
    await fs.unlink(LEDGER_PATH)
  } catch (err) {
    if ((err as NodeJS.ErrnoException).code !== 'ENOENT') throw err
  }
}

/* ── Verify the chain: recompute every hash from seq 0 ─────────────────── */
export async function verifyLedger(): Promise<VerifyResult> {
  const entries = await readLedger()
  const warnings: string[] = []
  let prevHash = GENESIS_PREV

  for (let i = 0; i < entries.length; i++) {
    const entry = entries[i]

    if (entry.seq !== i) {
      return {
        ok: false,
        entryCount: i,
        merkleRoot: '',
        head: prevHash,
        error: 'SEQ_GAP',
        errorSeq: i,
        warnings: [`Expected seq ${i}, got ${entry.seq}`],
      }
    }

    const expectedPayloadHash = await computePayloadHash(entry.payload)
    if (entry.payload_hash !== expectedPayloadHash) {
      return {
        ok: false,
        entryCount: i,
        merkleRoot: '',
        head: prevHash,
        error: 'PAYLOAD_HASH_MISMATCH',
        errorSeq: i,
        warnings,
      }
    }

    if (entry.prev_hash !== prevHash) {
      return {
        ok: false,
        entryCount: i,
        merkleRoot: '',
        head: prevHash,
        error: 'CHAIN_LINK_BROKEN',
        errorSeq: i,
        warnings: [`prev_hash mismatch at seq ${i}`],
      }
    }

    const expectedHash = await computeChainHash(prevHash, entry.payload_hash, entry.seq)
    if (entry.hash !== expectedHash) {
      return {
        ok: false,
        entryCount: i,
        merkleRoot: '',
        head: prevHash,
        error: 'CHAIN_LINK_BROKEN',
        errorSeq: i,
        warnings,
      }
    }

    prevHash = entry.hash
  }

  const merkleRoot = await computeMerkleRoot(entries.map((e) => e.hash))

  if (entries.length === 0) {
    warnings.push('Ledger is empty')
  }

  return {
    ok: true,
    entryCount: entries.length,
    merkleRoot,
    head: prevHash,
    warnings,
  }
}

/* ── Merkle root over an array of leaf hashes ────────────────────────────
 * Pairs leaves, hashes each pair, repeats until one root remains.
 * If odd count, the last leaf is promoted (duplicated) to the next level.
 * Empty array → SHA256('').
 */
export async function computeMerkleRoot(leaves: string[]): Promise<string> {
  if (leaves.length === 0) return sha256Hex('')
  let level = [...leaves]
  while (level.length > 1) {
    const next: string[] = []
    for (let i = 0; i < level.length; i += 2) {
      const left = level[i]
      const right = i + 1 < level.length ? level[i + 1] : level[i]
      next.push(await sha256Hex(left + right))
    }
    level = next
  }
  return level[0]
}
