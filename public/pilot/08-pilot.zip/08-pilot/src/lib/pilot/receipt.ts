/**
 * Pilot receipt PDF generator (client-side, jspdf).
 *
 * Generates a one-page receipt containing:
 *  - pilot name + timestamp
 *  - the verify verdict (CHAIN_INTACT or failure)
 *  - the Merkle root (the one digest that summarises the whole ledger)
 *  - the chain head hash
 *  - the entry count
 *  - the last N entry hashes
 *  - the SHA-256 of the PDF itself (printed at the bottom, computed
 *    after generation so the receipt is self-identifying)
 */
import { jsPDF } from 'jspdf'

export interface ReceiptData {
  verdict: string
  ok: boolean
  entryCount: number
  merkleRoot: string
  head: string
  recent: { seq: number; event_type: string; hash: string; timestamp: string }[]
}

export async function generateReceiptPdf(data: ReceiptData): Promise<{ blob: Blob; sha256: string }> {
  const doc = new jsPDF({ unit: 'pt', format: 'a4' })
  const pageW = doc.internal.pageSize.getWidth()
  const margin = 40
  let y = margin

  // Header
  doc.setFont('helvetica', 'bold')
  doc.setFontSize(18)
  doc.setTextColor(20, 20, 20)
  doc.text('VVU Pilot — Cryptographic Receipt', margin, y)
  y += 24

  doc.setFont('helvetica', 'normal')
  doc.setFontSize(9)
  doc.setTextColor(100, 100, 100)
  doc.text(
    `Generated: ${new Date().toISOString()}   ·   Neave Industrial Park pilot   ·   90-second proof`,
    margin,
    y,
  )
  y += 22

  // Verdict box
  const verdictColor: [number, number, number] = data.ok ? [16, 120, 60] : [180, 0, 40]
  doc.setFillColor(verdictColor[0], verdictColor[1], verdictColor[2])
  doc.rect(margin, y, pageW - margin * 2, 32, 'F')
  doc.setTextColor(255, 255, 255)
  doc.setFont('helvetica', 'bold')
  doc.setFontSize(12)
  doc.text(data.verdict, margin + 12, y + 20)
  y += 48

  // Key fields
  doc.setTextColor(20, 20, 20)
  doc.setFontSize(9)
  const fields: [string, string][] = [
    ['Entries verified', String(data.entryCount)],
    ['Merkle root', data.merkleRoot],
    ['Chain head', data.head],
    ['Algorithm', 'SHA-256 + RFC 8785 JCS canonicalisation'],
    ['Ledger format', 'JSONL append-only (data/ledger.jsonl)'],
  ]
  fields.forEach(([k, v]) => {
    doc.setFont('helvetica', 'bold')
    doc.text(k + ':', margin, y)
    doc.setFont('helvetica', 'normal')
    doc.text(v, margin + 130, y, { maxWidth: pageW - margin * 2 - 130 })
    y += 14
  })
  y += 10

  // Recent entries
  doc.setFont('helvetica', 'bold')
  doc.setFontSize(10)
  doc.text('Recent chain entries', margin, y)
  y += 14
  doc.setFont('helvetica', 'normal')
  doc.setFontSize(7)
  doc.setTextColor(60, 60, 60)
  data.recent.slice(0, 20).forEach((e) => {
    const line = `#${String(e.seq).padStart(4, '0')}  ${e.timestamp.slice(11, 19)}  ${e.event_type.padEnd(22)}  ${e.hash.slice(-16)}`
    doc.text(line, margin, y)
    y += 11
  })

  // Footer — the SHA-256 of the PDF content itself (self-identifying)
  y = doc.internal.pageSize.getHeight() - margin - 24
  doc.setDrawColor(200, 200, 200)
  doc.line(margin, y - 8, pageW - margin, y - 8)
  doc.setFontSize(7)
  doc.setTextColor(120, 120, 120)

  // Compute the SHA-256 of the PDF bytes (so the receipt proves its own integrity)
  const pdfBytes = doc.output('arraybuffer')
  const hashBuf = await crypto.subtle.digest('SHA-256', pdfBytes)
  const sha256 = Array.from(new Uint8Array(hashBuf))
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('')

  doc.text(
    `Receipt SHA-256: ${sha256}`,
    margin,
    y,
  )
  doc.text('Verify offline: recompute every hash in ledger.jsonl from seq 0.', margin, y + 12)

  // Re-output with the hash now printed (the hash is of the final bytes)
  const finalBlob = doc.output('blob')
  return { blob: finalBlob, sha256 }
}
