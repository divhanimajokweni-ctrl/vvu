/**
 * GET /api/pilot/verify
 * ─────────────────────
 * Recomputes every hash in the JSONL ledger from seq 0 and returns
 * the verdict + the Merkle root (for the PDF receipt).
 *
 * Offline, no API key, no network calls. Just SHA-256 + JCS.
 */
import { NextResponse } from 'next/server'
import { verifyLedger, readLedger } from '@/lib/pilot/ledger'

export const dynamic = 'force-dynamic'
export const runtime = 'nodejs'

export async function GET() {
  const result = await verifyLedger()
  const entries = await readLedger()

  const recent = entries.slice(-20).map((e) => ({
    seq: e.seq,
    event_type: e.event_type,
    timestamp: e.timestamp,
    hash: e.hash,
    payload_hash: e.payload_hash,
  }))

  if (result.ok) {
    return NextResponse.json({
      ok: true,
      verdict: 'CHAIN_INTACT',
      entryCount: result.entryCount,
      merkleRoot: result.merkleRoot,
      head: result.head,
      message: `✅ CHAIN INTACT: ${result.entryCount} entries verified · Merkle root ${result.merkleRoot.slice(0, 16)}…`,
      recent,
      warnings: result.warnings,
    })
  }

  return NextResponse.json({
    ok: false,
    verdict: result.error,
    entryCount: result.entryCount,
    head: result.head,
    errorSeq: result.errorSeq,
    message: `❌ ${result.error} at seq ${result.errorSeq}`,
    recent,
    warnings: result.warnings,
  })
}
