/**
 * GET /api/pilot/state
 * ────────────────────
 * Returns the current ledger length + the last few entries (for the
 * live status panel). Lightweight — does not recompute the whole chain.
 */
import { NextResponse } from 'next/server'
import { readLedger } from '@/lib/pilot/ledger'

export const dynamic = 'force-dynamic'
export const runtime = 'nodejs'

export async function GET() {
  const entries = await readLedger()
  const last = entries.at(-1)
  const lastState = [...entries].reverse().find((e) => e.event_type === 'STATE_NORMALIZED')
  const lastAlert = [...entries].reverse().find(
    (e) => e.event_type === 'ALERT_TRIGGERED' || e.event_type === 'OBSERVATION_MISSING',
  )

  return NextResponse.json({
    ok: true,
    entryCount: entries.length,
    head: last?.hash ?? '',
    lastState: lastState
      ? {
          status: lastState.payload.status,
          x: lastState.payload.x,
          z: lastState.payload.z,
          at: lastState.timestamp,
        }
      : null,
    lastAlert: lastAlert
      ? { type: lastAlert.event_type, at: lastAlert.timestamp, seq: lastAlert.seq }
      : null,
    recent: entries.slice(-10).map((e) => ({
      seq: e.seq,
      event_type: e.event_type,
      hash: e.hash.slice(-8),
      ts: e.timestamp.slice(11, 19),
    })),
  })
}
