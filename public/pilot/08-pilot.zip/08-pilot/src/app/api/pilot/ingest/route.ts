/**
 * POST /api/pilot/ingest
 * ───────────────────────
 * Accepts a raw detection frame from the sensor (simulated or real),
 * appends RAW_INGESTED + STATE_NORMALIZED + RULE_EVALUATED entries to
 * the JSONL ledger, returns the resulting state vector + any alert.
 *
 * Request body:
 *   { source: string, mode: 'SIM'|'LIVE', x?: number, z?: number, confidence?: number }
 *
 * If x/z/confidence are absent → the sensor is ABSENT (no detection).
 * The normalizer maps that to status: 'ABSENT' and the rules engine
 * fires OBSERVATION_MISSING (not ALERT_TRIGGERED — absence is not an alarm).
 */
import { NextResponse } from 'next/server'
import { appendEntry, type LedgerEntry } from '@/lib/pilot/ledger'

export const dynamic = 'force-dynamic'
export const runtime = 'nodejs'

const SAFE_ZONE_RADIUS = 2.5
const GEOFENCE_BREACH_MS = 5000

// In-memory breach tracker (single-process pilot — fine for the demo)
let breachStartedAt: number | null = null

export async function POST(req: Request) {
  let body: {
    source?: string
    mode?: 'SIM' | 'LIVE'
    x?: number
    z?: number
    confidence?: number
  }
  try {
    body = await req.json()
  } catch {
    return NextResponse.json({ ok: false, error: 'INVALID_JSON' }, { status: 400 })
  }

  const source = String(body.source ?? 'sensor_01')
  const mode = body.mode === 'LIVE' ? 'LIVE' : 'SIM'
  const hasDetection =
    typeof body.x === 'number' &&
    typeof body.z === 'number' &&
    typeof body.confidence === 'number' &&
    body.confidence > 0.4

  // 1. RAW_INGESTED — the empirical anchor
  const rawPayload = {
    source,
    mode,
    ts: new Date().toISOString(),
    x: hasDetection ? body.x : null,
    z: hasDetection ? body.z : null,
    confidence: hasDetection ? body.confidence : null,
  }
  const rawEntry = await appendEntry('RAW_INGESTED', rawPayload)

  // 2. STATE_NORMALIZED — the truth filter
  const status: 'PRESENT' | 'ABSENT' = hasDetection ? 'PRESENT' : 'ABSENT'
  const statePayload = {
    source,
    status,
    x: hasDetection ? body.x! : null,
    z: hasDetection ? body.z! : null,
    confidence: hasDetection ? body.confidence! : null,
    normalized_at: new Date().toISOString(),
  }
  const stateEntry = await appendEntry('STATE_NORMALIZED', statePayload)

  // 3. RULE_EVALUATED — the enforcement
  let alert: 'ALERT_TRIGGERED' | 'OBSERVATION_MISSING' | null = null
  const now = Date.now()

  if (status === 'ABSENT') {
    alert = 'OBSERVATION_MISSING'
    breachStartedAt = null
  } else {
    const dist = Math.sqrt(body.x! * body.x! + body.z! * body.z!)
    const outsideZone = dist > SAFE_ZONE_RADIUS
    if (outsideZone) {
      if (breachStartedAt === null) breachStartedAt = now
      if (now - breachStartedAt > GEOFENCE_BREACH_MS) {
        alert = 'ALERT_TRIGGERED'
      }
    } else {
      breachStartedAt = null
    }
  }

  const rulePayload = {
    source,
    status,
    outside_zone: status === 'PRESENT' && Math.sqrt(body.x! * body.x! + body.z! * body.z!) > SAFE_ZONE_RADIUS,
    breach_ms: breachStartedAt ? now - breachStartedAt : 0,
    threshold_ms: GEOFENCE_BREACH_MS,
    evaluated_at: new Date().toISOString(),
  }
  const ruleEntry = await appendEntry('RULE_EVALUATED', rulePayload)

  // 4. The alert itself (if any) — its own receipt
  let alertEntry: LedgerEntry | null = null
  if (alert) {
    alertEntry = await appendEntry(alert, {
      source,
      reason: alert === 'ALERT_TRIGGERED' ? 'GEOFENCE_BREACH_5S' : 'NO_DETECTION_500MS',
      fired_at: new Date().toISOString(),
    })
  }

  return NextResponse.json({
    ok: true,
    state: statePayload,
    alert,
    entries: {
      raw: { seq: rawEntry.seq, hash: rawEntry.hash },
      state: { seq: stateEntry.seq, hash: stateEntry.hash },
      rule: { seq: ruleEntry.seq, hash: ruleEntry.hash },
      alert: alertEntry ? { seq: alertEntry.seq, hash: alertEntry.hash } : null,
    },
  })
}

/**
 * DELETE /api/pilot/ingest — reset the ledger (start fresh for the demo)
 */
export async function DELETE() {
  const { resetLedger } = await import('@/lib/pilot/ledger')
  await resetLedger()
  breachStartedAt = null
  return NextResponse.json({ ok: true, message: 'Ledger reset' })
}
