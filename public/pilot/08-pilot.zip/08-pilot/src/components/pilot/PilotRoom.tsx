'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import * as THREE from 'three'

/**
 * PilotRoom — the Neave Industrial Park pilot room (room 9 in the fused shell).
 *
 * Self-contained: renders the 3D room AND the demo controls AND runs the
 * sensor sim. Posts detections to /api/pilot/ingest (server ledger.jsonl)
 * and bubbles events to the shell's WORM chain via onLog.
 *
 * The 3D renderer is pure — it only represents the state, never invents it
 * (No-Primitives Law). The sensor is SIM-tagged in three places.
 */

export interface PilotState {
  status: 'PRESENT' | 'ABSENT'
  x: number
  z: number
  alert: 'ALERT_TRIGGERED' | 'OBSERVATION_MISSING' | null
}

type Phase = 'idle' | 'reality' | 'killed' | 'geofence'

const SAFE_ZONE_RADIUS = 2.5
const ROOM_SIZE = 8
const FAIL_CLOSED_MS = 500

interface Props {
  state: PilotState
  onStateChange: (s: PilotState) => void
  onLog: (type: string, details: string, source: string, mode: 'LIVE' | 'SIM' | 'DEMO' | 'GAME') => void
}

export default function PilotRoom({ state, onStateChange, onLog }: Props) {
  const [phase, setPhase] = useState<Phase>('idle')

  const mountRef = useRef<HTMLDivElement | null>(null)
  const avatarRef = useRef<THREE.Group | null>(null)
  const absentBoxRef = useRef<THREE.LineSegments | null>(null)
  const alertFlashRef = useRef<THREE.Mesh | null>(null)
  const stateRef = useRef<PilotState>(state)
  const phaseRef = useRef<Phase>('idle')
  const lastDetectionAt = useRef<number>(0)
  const absentEmitted = useRef<boolean>(false)

  useEffect(() => { stateRef.current = state }, [state])
  useEffect(() => { phaseRef.current = phase }, [phase])

  /* ── Three.js scene init (runs once) ───────────────────────────────── */
  useEffect(() => {
    const mount = mountRef.current
    if (!mount) return

    const width = mount.clientWidth
    const height = mount.clientHeight

    const scene = new THREE.Scene()
    scene.background = new THREE.Color(0x0a0e10)
    scene.fog = new THREE.Fog(0x0a0e10, 10, 30)

    const camera = new THREE.PerspectiveCamera(50, width / height, 0.1, 100)
    camera.position.set(6, 6, 8)
    camera.lookAt(0, 1, 0)

    const renderer = new THREE.WebGLRenderer({ antialias: true })
    renderer.setPixelRatio(Math.min(devicePixelRatio, 2))
    renderer.setSize(width, height)
    renderer.shadowMap.enabled = true
    renderer.shadowMap.type = THREE.PCFSoftShadowMap
    mount.appendChild(renderer.domElement)

    scene.add(new THREE.HemisphereLight(0x88aacc, 0x223322, 0.6))
    const key = new THREE.DirectionalLight(0xffffff, 1.4)
    key.position.set(5, 10, 7)
    key.castShadow = true
    key.shadow.mapSize.set(1024, 1024)
    scene.add(key)

    // Floor
    const floor = new THREE.Mesh(
      new THREE.PlaneGeometry(ROOM_SIZE * 2, ROOM_SIZE * 2),
      new THREE.MeshStandardMaterial({ color: 0x1a1f22, roughness: 0.9 }),
    )
    floor.rotation.x = -Math.PI / 2
    floor.receiveShadow = true
    scene.add(floor)

    const grid = new THREE.GridHelper(ROOM_SIZE * 2, 16, 0x2a3a30, 0x1a2520)
    grid.position.y = 0.01
    scene.add(grid)

    // Safe zone
    const ring = new THREE.Mesh(
      new THREE.RingGeometry(SAFE_ZONE_RADIUS - 0.05, SAFE_ZONE_RADIUS + 0.05, 64),
      new THREE.MeshBasicMaterial({ color: 0x10b981, transparent: true, opacity: 0.8, side: THREE.DoubleSide }),
    )
    ring.rotation.x = -Math.PI / 2
    ring.position.y = 0.02
    scene.add(ring)

    const disk = new THREE.Mesh(
      new THREE.CircleGeometry(SAFE_ZONE_RADIUS, 64),
      new THREE.MeshBasicMaterial({ color: 0x10b981, transparent: true, opacity: 0.08, side: THREE.DoubleSide }),
    )
    disk.rotation.x = -Math.PI / 2
    disk.position.y = 0.015
    scene.add(disk)

    // Walls
    const wallMat = new THREE.MeshStandardMaterial({ color: 0x2a2f30, roughness: 0.8, side: THREE.DoubleSide })
    const half = ROOM_SIZE
    const wallH = 2
    ;[
      { w: half * 2, d: 0.1, x: 0, z: -half },
      { w: half * 2, d: 0.1, x: 0, z: half },
      { w: 0.1, d: half * 2, x: -half, z: 0 },
      { w: 0.1, d: half * 2, x: half, z: 0 },
    ].forEach((w) => {
      const wall = new THREE.Mesh(new THREE.BoxGeometry(w.w, wallH, w.d), wallMat)
      wall.position.set(w.x, wallH / 2, w.z)
      wall.castShadow = true
      scene.add(wall)
    })

    // Avatar (blue capsule)
    const avatar = new THREE.Group()
    const body = new THREE.Mesh(
      new THREE.CapsuleGeometry(0.25, 0.9, 8, 16),
      new THREE.MeshStandardMaterial({ color: 0x3b82f6, metalness: 0.3, roughness: 0.4, emissive: 0x1e3a5f, emissiveIntensity: 0.3 }),
    )
    body.position.y = 0.7
    body.castShadow = true
    avatar.add(body)
    const head = new THREE.Mesh(
      new THREE.SphereGeometry(0.18, 16, 12),
      new THREE.MeshStandardMaterial({ color: 0x60a5fa, roughness: 0.5 }),
    )
    head.position.y = 1.45
    avatar.add(head)
    avatar.visible = false
    scene.add(avatar)
    avatarRef.current = avatar

    // SENSOR_ABSENT wireframe box (red)
    const boxLines = new THREE.LineSegments(
      new THREE.EdgesGeometry(new THREE.BoxGeometry(0.8, 1.6, 0.8)),
      new THREE.LineBasicMaterial({ color: 0xff0044, linewidth: 2 }),
    )
    boxLines.position.y = 0.8
    boxLines.visible = false
    scene.add(boxLines)
    absentBoxRef.current = boxLines

    // Alert flash
    const flash = new THREE.Mesh(
      new THREE.PlaneGeometry(ROOM_SIZE * 2, ROOM_SIZE * 2),
      new THREE.MeshBasicMaterial({ color: 0xff0044, transparent: true, opacity: 0, side: THREE.DoubleSide }),
    )
    flash.rotation.x = -Math.PI / 2
    flash.position.y = 0.03
    scene.add(flash)
    alertFlashRef.current = flash

    let raf = 0
    const animate = () => {
      raf = requestAnimationFrame(animate)
      const s = stateRef.current
      if (s.status === 'PRESENT') {
        avatar.visible = true
        avatar.position.x = s.x
        avatar.position.z = s.z
        boxLines.visible = false
      } else {
        // Invariant 1: when ABSENT, the render must NOT imply a position.
        // The wireframe box is a SYMBOL of absence, centered in the room —
        // not at any "last known" or arbitrary coordinate. The render never
        // carries forward a previous state. (boxLines.position.x/z stay 0 = center)
        avatar.visible = false
        boxLines.visible = true
      }
      if (s.alert === 'ALERT_TRIGGERED') {
        const t = performance.now() / 200
        ;(flash.material as THREE.MeshBasicMaterial).opacity = 0.15 + 0.1 * Math.sin(t)
      } else {
        ;(flash.material as THREE.MeshBasicMaterial).opacity = 0
      }
      renderer.render(scene, camera)
    }
    animate()

    const onResize = () => {
      const w = mount.clientWidth
      const h = mount.clientHeight
      camera.aspect = w / h
      camera.updateProjectionMatrix()
      renderer.setSize(w, h)
    }
    const ro = new ResizeObserver(onResize)
    ro.observe(mount)

    return () => {
      cancelAnimationFrame(raf)
      ro.disconnect()
      renderer.dispose()
      if (renderer.domElement.parentNode === mount) mount.removeChild(renderer.domElement)
    }
  }, [])

  /* ── Post a detection to the server ledger ─────────────────────────── */
  const postDetection = useCallback(
    async (x: number | null, z: number | null, confidence: number | null) => {
      try {
        const res = await fetch('/api/pilot/ingest', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ source: 'sensor_sim_01', mode: 'SIM', x, z, confidence }),
        })
        const data = await res.json()
        if (data.ok) {
          const sv = data.state
          onStateChange({
            status: sv.status,
            x: sv.x ?? 0,
            z: sv.z ?? 0,
            alert: data.alert ?? null,
          })
          if (data.alert === 'ALERT_TRIGGERED') {
            onLog('ALERT_TRIGGERED', 'pilot · geofence breach > 5s', 'PILOT', 'SIM')
          } else if (data.alert === 'OBSERVATION_MISSING') {
            onLog('OBSERVATION_MISSING', 'pilot · sensor absent > 500ms', 'PILOT', 'SIM')
          } else {
            onLog('RAW_INGESTED', `pilot · ${sv.status} · pos (${(sv.x ?? 0).toFixed(1)}, ${(sv.z ?? 0).toFixed(1)})`, 'PILOT', 'SIM')
          }
        }
      } catch {
        /* network error — demo continues */
      }
    },
    [onStateChange, onLog],
  )

  /* ── Sensor sim loop (200ms tick) ──────────────────────────────────── */
  useEffect(() => {
    const id = setInterval(() => {
      const now = Date.now()
      const p = phaseRef.current
      if (p === 'reality') {
        const t = now / 1500
        const x = Math.cos(t) * 1.8
        const z = Math.sin(t) * 1.8
        lastDetectionAt.current = now
        absentEmitted.current = false
        void postDetection(x, z, 0.92)
      } else if (p === 'geofence') {
        const t = now / 1200
        const x = Math.cos(t) * 3.5
        const z = Math.sin(t) * 3.5
        lastDetectionAt.current = now
        absentEmitted.current = false
        void postDetection(x, z, 0.88)
      } else if (p === 'killed') {
        const silence = now - lastDetectionAt.current
        if (silence > FAIL_CLOSED_MS && !absentEmitted.current) {
          absentEmitted.current = true
          void postDetection(null, null, null)
        }
      }
    }, 200)
    return () => clearInterval(id)
  }, [postDetection])

  /* ── Demo controls ────────────────────────────────────────────────── */
  const startReality = useCallback(() => {
    setPhase('reality')
    onStateChange({ ...stateRef.current, alert: null })
  }, [onStateChange])

  const killSensor = useCallback(() => setPhase('killed'), [])

  const testGeofence = useCallback(() => {
    setPhase('geofence')
    onStateChange({ ...stateRef.current, alert: null })
  }, [onStateChange])

  const sensorLive = phase === 'reality' || phase === 'geofence'

  return (
    <div style={{ position: 'absolute', inset: 0, background: '#0a0e10' }}>
      {/* 3D canvas */}
      <div ref={mountRef} style={{ width: '100%', height: '100%', position: 'relative' }} aria-label="Pilot room 3D twin" />

      {/* SENSOR_ABSENT overlay */}
      {state.status === 'ABSENT' && phase !== 'idle' && (
        <div style={{
          position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -50%)',
          color: '#ff0044', fontSize: 'clamp(14px, 4vw, 20px)', fontWeight: 700, letterSpacing: '.2em',
          textShadow: '0 0 12px rgba(255,0,68,.6)', pointerEvents: 'none', zIndex: 5, textAlign: 'center',
        }}>
          SENSOR_ABSENT
          <div style={{ fontSize: 'clamp(8px, 2vw, 10px)', opacity: 0.7, marginTop: 4, letterSpacing: '.1em' }}>
            FAIL-CLOSED · NO PRIMITIVES
          </div>
        </div>
      )}

      {/* Alert banner */}
      {state.alert === 'ALERT_TRIGGERED' && (
        <div style={{
          position: 'absolute', top: 'clamp(8px, 2vh, 16px)', left: '50%', transform: 'translateX(-50%)',
          background: 'rgba(229,72,77,.15)', border: '1px solid #e5484d', color: '#e5484d',
          padding: 'clamp(4px, 1vh, 6px) clamp(10px, 3vw, 16px)',
          fontSize: 'clamp(9px, 2.5vw, 11px)', fontWeight: 700, letterSpacing: '.12em', borderRadius: 4, zIndex: 5,
        }}>
          ⚠ ALERT_TRIGGERED · GEOFENCE BREACH
        </div>
      )}

      {/* Idle hint */}
      {phase === 'idle' && (
        <div style={{
          position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -50%)',
          color: '#5a6a50', fontSize: 'clamp(10px, 3vw, 12px)', textAlign: 'center', zIndex: 5, pointerEvents: 'none',
        }}>
          Press <b style={{ color: '#c8ff00' }}>SHOW REALITY</b> to start
        </div>
      )}

      {/* Phase indicator */}
      <div style={{
        position: 'absolute', bottom: 'clamp(8px, 2vh, 12px)', left: 'clamp(8px, 2vw, 12px)',
        color: '#5a6a50', fontSize: 'clamp(8px, 2vw, 9px)', letterSpacing: '.08em', zIndex: 5,
      }}>
        phase: <b style={{ color: sensorLive ? '#c8ff00' : phase === 'killed' ? '#e5484d' : '#5a6a50' }}>{phase}</b>
        {sensorLive && <> · pos: ({state.x.toFixed(1)}, {state.z.toFixed(1)}) · zone: {Math.sqrt(state.x * state.x + state.z * state.z) > SAFE_ZONE_RADIUS ? 'OUTSIDE' : 'inside'}</>}
      </div>

      {/* Demo controls — overlaid on the 3D view, bottom-right */}
      <div style={{
        position: 'absolute', bottom: 'clamp(8px, 2vh, 12px)', right: 'clamp(8px, 2vw, 12px)',
        display: 'flex', flexDirection: 'column', gap: 'clamp(4px, 1vh, 6px)', zIndex: 6,
        maxWidth: 'clamp(140px, 40vw, 200px)',
      }}>
        <PilotBtn n={1} label="REALITY" onClick={startReality} active={phase === 'reality'} />
        <PilotBtn n={2} label="KILL" onClick={killSensor} active={phase === 'killed'} disabled={phase === 'idle'} />
        <PilotBtn n={3} label="GEOFENCE" onClick={testGeofence} active={phase === 'geofence'} disabled={phase === 'idle'} />
      </div>

      {/* SIM badge — three-layer tagging (UI chrome) */}
      <div style={{
        position: 'absolute', top: 'clamp(8px, 2vh, 12px)', right: 'clamp(8px, 2vw, 12px)',
        color: '#ffaa00', fontSize: 'clamp(7px, 1.8vw, 9px)', fontWeight: 700, letterSpacing: '.1em',
        border: '1px solid #ffaa0055', padding: '2px 6px', borderRadius: 2, zIndex: 5,
      }}>
        [SIM] sensor
      </div>
    </div>
  )
}

function PilotBtn({ n, label, onClick, active, disabled }: {
  n: number; label: string; onClick: () => void; active?: boolean; disabled?: boolean
}) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      style={{
        display: 'flex', alignItems: 'center', gap: 'clamp(4px, 1vw, 6px)',
        padding: 'clamp(6px, 1.5vh, 8px) clamp(8px, 2vw, 10px)',
        background: active ? 'rgba(200,255,0,.12)' : 'rgba(5,5,5,.7)',
        border: `1px solid ${active ? '#c8ff00' : disabled ? 'rgba(200,255,0,.1)' : 'rgba(200,255,0,.3)'}`,
        color: active ? '#c8ff00' : disabled ? '#5a6a50' : '#8fb35a',
        fontFamily: 'inherit', fontSize: 'clamp(8px, 2vw, 10px)', fontWeight: 700, letterSpacing: '.08em',
        borderRadius: 3, cursor: disabled ? 'not-allowed' : 'pointer', opacity: disabled ? 0.4 : 1,
        minHeight: 36, // touch target
        backdropFilter: 'blur(8px)',
      }}
    >
      <span style={{
        flexShrink: 0, width: 16, height: 16, display: 'flex', alignItems: 'center', justifyContent: 'center',
        background: active ? '#c8ff00' : 'rgba(200,255,0,.15)', color: active ? '#000' : '#c8ff00',
        fontSize: 9, fontWeight: 700, borderRadius: 2,
      }}>{n}</span>
      {label}
    </button>
  )
}
