# 05 · LAB (workspace)

3D lab workspace with 3 zones (Presentation Lab, Mechanical Bench,
Calibration Bay). Slide deck (Ireland content — static educational text).
Spawnable tools (gear, pipe, valve, crate). God's-eye view.

**Mode:** DEMO (presentation tool, no estate telemetry — audited CLEAN)

## Run standalone
Open `lab.html` in a browser (loads Three.js r128 from CDN).

