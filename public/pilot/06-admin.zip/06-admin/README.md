# 06 · ADMIN (SEARM command center)

SEARM Geo-Bioteknik command center. Disruption switches (hydraulic,
thermal). Physical topology (5 nodes). Beeswarm XAI asset-integrity plot.
3D twin canvas (N04 CELL 07). Admin approval gate. WORM ledger panel.
E-STOP button.

**Mode:** DEMO (KPIs tagged [DEMO] in chrome; hardcoded node telemetry)

## Run standalone
Open `admin.html` in a browser (loads Three.js r128 from CDN).

