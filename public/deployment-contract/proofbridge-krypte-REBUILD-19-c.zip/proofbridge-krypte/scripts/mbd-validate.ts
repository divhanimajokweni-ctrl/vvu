/**
 * MBD real-data validation runner — ProofBridge work order, Deliverable 1.
 *
 * Reads the sample stream built by proofbridge/adapters/mbd.py (real MBD
 * event sequences + proxy APP-fraud labels) and runs the FULL validation
 * harness against it through `runValidationOnSamples` — the SAME
 * `evaluateWorld` code path used by the synthetic reference world: same
 * deterministic parity split (even-index train / odd holdout over the
 * time-ordered stream), same model ladder, same Tier-0 controls, same
 * calibration, same SHA-256 audit chain construction. Only the data source
 * differs, and the data source's provenance is bound into the genesis
 * record (and therefore into the chain root).
 *
 * Usage:
 *   bun run scripts/mbd-validate.ts <samples.json> <adapter-report.json> <outdir>
 *
 * Outputs (in <outdir>):
 *   validation-results.json   — the full ValidationResults (machine-readable)
 *   run-summary.txt           — the console summary (captured by tee)
 *
 * Determinism: the adapter is deterministic for a pinned dataset revision +
 * fold + client count; this runner adds no randomness beyond the disclosed
 * control seed. A rerun produces the same chain root.
 */

import { readFileSync, writeFileSync, mkdirSync } from "node:fs";
import { resolve } from "node:path";
import { createHash } from "node:crypto";

import { runValidationOnSamples } from "../src/lib/validation/harness";
import { fmt, pad, shortRoot, table } from "../src/lib/validation/format";
import type { Sample, ValidationResults } from "../src/lib/validation/types";

const CONTROL_SEED = 42;

interface AdapterReport {
  dataset: { id: string; url: string; revision: string; note: string };
  selection: { fold: number; clients_selected: number; rule: string; selection_sha256: string };
  counts: Record<string, number>;
  label_rule: Record<string, string>;
  samples_sha256: string;
  samples_rows: number;
}

function main(): void {
  const [samplesPath, reportPath, outDir] = process.argv.slice(2);
  if (!samplesPath || !reportPath || !outDir) {
    console.error("usage: bun run scripts/mbd-validate.ts <samples.json> <adapter-report.json> <outdir>");
    process.exit(2);
  }
  mkdirSync(outDir, { recursive: true });

  console.log(`[mbd-validate] reading ${samplesPath}`);
  const samplesRaw = JSON.parse(readFileSync(samplesPath, "utf8")) as unknown;
  const adapter = JSON.parse(readFileSync(reportPath, "utf8")) as unknown as AdapterReport;

  if (!Array.isArray(samplesRaw) || samplesRaw.length === 0) {
    console.error("[mbd-validate] samples.json is not a non-empty array");
    process.exit(2);
  }
  const samples = samplesRaw as Sample[];
  // contract check: the fields the harness touches
  const s0 = samples[0] as Record<string, unknown>;
  for (const k of ["i", "id", "accountId", "merchantId", "ts", "hour", "channel", "amount", "label", "gapDraw"]) {
    if (!(k in s0)) {
      console.error(`[mbd-validate] samples missing field '${k}'`);
      process.exit(2);
    }
  }

  // re-verify the samples file digest against the adapter's recorded digest
  const fileSha = createHash("sha256").update(readFileSync(samplesPath)).digest("hex");
  const digestMatch = fileSha === adapter.samples_sha256;
  console.log(`[mbd-validate] samples sha256 ${fileSha} (adapter digest ${digestMatch ? "MATCH" : "MISMATCH"})`);

  const provenance: Record<string, unknown> = {
    source: adapter.dataset.id,
    dataset_url: adapter.dataset.url,
    dataset_revision: adapter.dataset.revision,
    fold: adapter.selection.fold,
    clients: adapter.selection.clients_selected,
    selection_rule: adapter.selection.rule,
    selection_sha256: adapter.selection.selection_sha256,
    samples_sha256: adapter.samples_sha256,
    label_rule: "recent-payee-30d AND contact-24h-before AND no-dialog-2h-before (disclosed proxies — see proofbridge/adapters/mbd.py)",
    label_kind: "proxy APP-fraud labels, real event sequences",
    channel_proxy: "constant 'online'",
    control_seed: CONTROL_SEED,
    entry_point: "runValidationOnSamples (same evaluateWorld path as synthetic)",
  };

  console.log(`[mbd-validate] running full harness on ${samples.length} real samples...`);
  const t0 = Date.now();
  const results: ValidationResults = runValidationOnSamples(samples, { seed: CONTROL_SEED, provenance });
  const elapsed = ((Date.now() - t0) / 1000).toFixed(1);
  console.log(`[mbd-validate] harness complete in ${elapsed}s`);

  writeFileSync(resolve(outDir, "validation-results.json"), JSON.stringify(results, null, 2));

  // ---- console summary (captured verbatim as evidence) ----
  const ladderRows = results.ladder.map((e) => [
    e.model,
    fmt(e.auc),
    fmt(e.partialAuc),
    fmt(e.fnrAtFivePctFpr),
  ]);
  const controlRows = results.controls.map((c) => [
    c.control,
    fmt(c.auc),
    fmt(c.delta),
    c.nullDelta !== undefined ? fmt(c.nullDelta) : "—",
  ]);
  const bprime = results.ladder.find((e) => e.model === "bprime")!;
  const flat = results.ladder.find((e) => e.model === "flat")!;
  const temporal = results.ladder.find((e) => e.model === "temporal")!;
  const calibrated = results.ladder.find((e) => e.model === "calibrated")!;
  const orderShuffle = results.controls.find((c) => c.control === "order-shuffle")!;
  const labelShuffle = results.controls.find((c) => c.control === "label-shuffle")!;
  const positive = results.controls.find((c) => c.control === "positive")!;

  console.log("");
  console.log(`MBD REAL-DATA VALIDATION — ${adapter.dataset.id} (fold ${adapter.selection.fold}, ${adapter.selection.clients_selected} clients)`);
  console.log(`samples ${results.n} · positives ${results.fraudCount} (${(results.fraudRate * 100).toFixed(3)}%) · control seed ${CONTROL_SEED}`);
  console.log(`harness entry runValidationOnSamples — same evaluateWorld path as the synthetic reference`);
  console.log("");
  console.log(table(["model", "AUC", "pAUC(0-0.1)", "FNR@5%FPR"], ladderRows));
  console.log("");
  console.log(table(["control", "AUC", "delta", "nullDelta"], controlRows));
  console.log("");
  console.log(`temporal Δ vs flat          ${fmt(temporal.auc - flat.auc)}`);
  console.log(`FN reduction vs B′ @5%FPR   ${fmt(bprime.fnrAtFivePctFpr - temporal.fnrAtFivePctFpr)}  (B′ ${fmt(bprime.fnrAtFivePctFpr)} → temporal ${fmt(temporal.fnrAtFivePctFpr)})`);
  console.log(`positive-control Δ          ${fmt(positive.delta)} (null ${fmt(positive.nullDelta ?? 0)})`);
  console.log(`audit chain                 ${results.chain.count} records, valid ${results.chain.valid}, root ${results.chain.root}`);
  console.log(`digest check                adapter digest ${digestMatch ? "MATCH" : "MISMATCH"}`);
  console.log("");
}

main();
