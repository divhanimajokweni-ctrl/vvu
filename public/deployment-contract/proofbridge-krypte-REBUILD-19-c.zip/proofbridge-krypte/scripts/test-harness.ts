/**
 * ProofBridge Validation Dashboard — labelled rebuild.
 * Headless harness baseline. Zero node_modules required — pure TypeScript
 * + node:crypto, executed directly by Bun.
 *
 *   bun run scripts/test-harness.ts [seed] [n]
 *
 * Prints the full metrics table (model ladder, Tier-0 controls,
 * calibration, distributional diagnostics, P1–P4 behavioural checks,
 * operating point, audit chain), the nine-check verdict derivation, and
 * re-runs the whole validation to prove determinism. Exit code 0 only if
 * the chain re-verifies AND the repeat run is byte-identical AND the
 * overall verdict is not FAIL.
 */

import { deriveChecks } from "../src/lib/brand";
import { fmt, pct, shortRoot, table } from "../src/lib/validation/format";
import { runValidation } from "../src/lib/validation/harness";

const seed = Number(process.argv[2] ?? 42);
const n = Number(process.argv[3] ?? 450);

if (!Number.isInteger(seed) || seed < 0 || !Number.isInteger(n) || n < 1) {
  console.error("usage: bun run scripts/test-harness.ts [seed] [n]");
  process.exit(2);
}

console.log("ProofBridge Validation Dashboard — labelled rebuild");
console.log(`headless harness · seed ${seed} · n ${n}`);

const r = runValidation({ seed, n });
const v = deriveChecks(r);

console.log(
  `\n  samples ${r.n} · positives ${r.fraudCount} (fraud rate ${pct(r.fraudRate, 1)})`,
);

// ---- model ladder ----------------------------------------------------------
console.log("\nMODEL LADDER (holdout)");
console.log(
  table(
    ["model", "AUC", "pAUC 0–0.1", "FNR@5%FPR"],
    r.ladder.map((l) => [l.model, fmt(l.auc), fmt(l.partialAuc), fmt(l.fnrAtFivePctFpr)]),
  ),
);
const temporal = r.ladder.find((l) => l.model === "temporal")!;
const flat = r.ladder.find((l) => l.model === "flat")!;
console.log(
  `  pAUC ratio (temporal ÷ flat) ${fmt(temporal.partialAuc / Math.max(flat.partialAuc, 1e-9), 2)}× — the early-band lift the ladder buys`,
);

// ---- Tier-0 controls --------------------------------------------------------
console.log("\nTIER-0 CONTROLS (each perturbation retrains the temporal model)");
console.log(
  table(
    ["control", "AUC", "Δ vs baseline", "placebo Δ"],
    r.controls.map((c) => [
      c.control,
      fmt(c.auc),
      (c.delta >= 0 ? "+" : "") + fmt(c.delta),
      c.nullDelta === undefined ? "—" : fmt(c.nullDelta),
    ]),
  ),
);

// ---- calibration -------------------------------------------------------------
console.log("\nCALIBRATION (isotonic, fitted on train, applied to holdout)");
console.log(
  table(
    ["metric", "raw → calibrated"],
    [
      ["ECE", `${fmt(r.calibration.eceRaw)} → ${fmt(r.calibration.eceCalibrated)}`],
      ["Brier", `${fmt(r.calibration.brierRaw)} → ${fmt(r.calibration.brierCalibrated)}`],
    ],
  ),
);

// ---- distributional diagnostics ----------------------------------------------
console.log("\nDISTRIBUTIONAL DIAGNOSTICS (holdout temporal scores)");
console.log(
  table(
    ["statistic", "value"],
    [
      ["KS (fraud vs legit)", fmt(r.distribution.ksDistance)],
      ["Wasserstein (fraud vs legit)", fmt(r.distribution.wasserstein)],
      ["Spearman(score, propensity)", fmt(r.distribution.spearman)],
      ["circular R (fraud hours)", fmt(r.distribution.circularConcentrationFraud)],
      ["circular R (clean hours)", fmt(r.distribution.circularConcentrationClean)],
    ],
  ),
);

// ---- behavioural fidelity -------------------------------------------------------
console.log("\nBEHAVIOURAL FIDELITY (P1–P4)");
console.log(
  table(
    ["check", "score"],
    [
      ["P1 burst", fmt(r.behavior.p1Burst, 3)],
      ["P2 velocity", fmt(r.behavior.p2Velocity, 3)],
      ["P3 graph", fmt(r.behavior.p3Graph, 3)],
      ["P4 drift", fmt(r.behavior.p4Drift, 3)],
      ["composite (Σ P1..P4)", fmt(r.behavior.composite, 3)],
    ],
  ),
);

// ---- audit chain ------------------------------------------------------------
console.log("\nAUDIT CHAIN (SHA-256, append-only)");
console.log(
  table(
    ["field", "value"],
    [
      ["genesis", r.chain.genesis],
      ["records", `${r.chain.count} (1 genesis + ${r.n} transactions)`],
      ["chain valid", r.chain.valid ? "true" : "FALSE"],
      ["root", r.chain.root],
    ],
  ),
);

// ---- verdicts ------------------------------------------------------------------
console.log("\nVERDICTS (9 checks, worst-of, two-tier floors)");
console.log(
  table(
    ["verdict", "check", "value", "detail"],
    v.checks.map((c) => [c.verdict, c.name, fmt(c.value), c.detail ?? ""]),
  ),
);
console.log(
  `  OVERALL ${v.overall} — ${v.counts.pass} PASS · ${v.counts.warn} WARN · ${v.counts.fail} FAIL${
    v.escalations.length > 0 ? ` (escalated by hard floors: ${v.escalations.join(", ")})` : ""
  }`,
);

// ---- determinism ------------------------------------------------------------------
console.log("\nDETERMINISM");
const r2 = runValidation({ seed, n });
const match = JSON.stringify(r) === JSON.stringify(r2);
console.log(
  table(
    ["check", "result"],
    [
      ["repeat run", match ? "MATCH" : "MISMATCH"],
      ["detail", match ? "identical metrics + chain root" : "NON-DETERMINISTIC OUTPUT"],
    ],
  ),
);

const ok = r.chain.valid && match && v.overall !== "FAIL";
console.log(`\nHARNESS ${ok ? "OK" : "FAILED"} · overall ${v.overall} · root ${shortRoot(r.chain.root, 16)} · exit ${ok ? 0 : 1}`);
process.exit(ok ? 0 : 1);
