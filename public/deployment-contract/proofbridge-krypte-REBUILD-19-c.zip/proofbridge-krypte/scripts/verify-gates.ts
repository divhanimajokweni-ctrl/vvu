// Substrate gate evidence — Gates A–D. Headless, no server, no node_modules:
//   bun run scripts/verify-gates.ts
//
// LABELLED REBUILD (worklog 22-a). The baseline below is captured from THIS
// tree (seed 42, n 450) — it is the new experiment's own evidence, not the
// lost original's numbers.
//
//   Gate A — reference specimen: the harness reproduces the recorded baseline
//            exactly, the audit chain verifies, determinism holds.
//   Gate B — extraction: the fraud adapter's verdicts are equal to the
//            dashboard's own derivation (src/lib/brand.ts) on live output,
//            across five seeds; overall verdicts agree; the substrate chain
//            seals the harness's own chain root (layered receipt).
//   Gate C — second domain: the hydraulic vertical runs, its chain verifies,
//            it is deterministic, and all 8 checks (4 controls + 4 outcomes)
//            are present.
//   Gate D — proof: mechanical purity scan of the substrate source (no
//            vertical vocabulary in types.ts / substrate.ts), canonical
//            receipt shape for both verticals, and independent chains (each
//            bound to its own genesis — cross-verification with the wrong
//            genesis must fail).

import { readFileSync } from "node:fs";
import { dirname, join } from "node:path";

import { runValidation } from "../src/lib/validation/harness";
import type { ValidationResults } from "../src/lib/validation/types";
import { deriveChecks } from "../src/lib/brand";
import { runVertical, verifyChain } from "../src/lib/verification/substrate";
import type { VerticalRunResult } from "../src/lib/verification/types";
import { fraudVertical } from "../src/lib/verification/verticals/fraud";
import { hydraulicVertical } from "../src/lib/verification/verticals/hydraulic";
import { fmt, shortRoot, table } from "../src/lib/validation/format";

const ROOT = dirname(new URL(import.meta.url).pathname);
const SEED = 42;
const N = 450;
const GATE_SEEDS = [42, 7, 1337, 999, 314];

// Baseline captured from this exact tree (seed 42, n 450).
// RE-BASELINED 2026-09-13: the harness implementation was finalised after the
// first capture — these values are the final tree's numbers (root bd467359…).
// The ORIGINAL artifact's baseline (AUC 0.881, root e36d9b4d…) is historical,
// tied to the lost tree — see README §“LABELLED REBUILD”.
const BASELINE = {
  temporalAuc: 0.8436724565756824,
  flatAuc: 0.7710228839261097,
  partialAucTemporal: 0.054094292803970226,
  partialAucFlat: 0.02619244554728426,
  fnrAtFivePctFpr: 0.41025641025641024,
  labelShuffleAuc: 0.514993608379123,
  orderShuffleAuc: 0.7053106428290821,
  timingNoiseAuc: 0.8538737248414667,
  positiveDelta: 0.47307994131495446,
  positiveNullDelta: -0.02976901293118156,
  eceRaw: 0.1085261964328327,
  eceCalibrated: 0.08306878306878304,
  brierRaw: 0.10199048507552937,
  brierCalibrated: 0.10366309216730417,
  fraudCount: 79,
  chainCount: 451,
  chainRoot: "bd4673596aebfcfbf44e772c20d32266d281e7d4c165dc0b2dcb154843a31f17",
};

const TOL = 1e-9;

interface GateResult {
  gate: string;
  name: string;
  pass: boolean;
  detail: string;
}

const results: GateResult[] = [];

function record(gate: string, name: string, pass: boolean, detail: string): void {
  results.push({ gate, name, pass, detail });
}

function near(a: number, b: number): boolean {
  return Math.abs(a - b) <= TOL;
}

function findControl(r: ValidationResults, name: string) {
  const c = r.controls.find((x) => x.control === name);
  if (!c) throw new Error(`missing control ${name}`);
  return c;
}

// ---------------------------------------------------------------------------
// Gate A — reference specimen
// ---------------------------------------------------------------------------

function gateA(): void {
  const first = runValidation({ seed: SEED, n: N });
  const second = runValidation({ seed: SEED, n: N });
  const deterministic = JSON.stringify(first) === JSON.stringify(second);
  const temporal = first.ladder.find((l) => l.model === "temporal")!;
  const flat = first.ladder.find((l) => l.model === "flat")!;
  const label = findControl(first, "label-shuffle");
  const order = findControl(first, "order-shuffle");
  const timing = findControl(first, "timing-noise");
  const positive = findControl(first, "positive");

  const metricsOk = [
    near(temporal.auc, BASELINE.temporalAuc),
    near(flat.auc, BASELINE.flatAuc),
    near(temporal.partialAuc, BASELINE.partialAucTemporal),
    near(flat.partialAuc, BASELINE.partialAucFlat),
    near(temporal.fnrAtFivePctFpr, BASELINE.fnrAtFivePctFpr),
    near(label.auc, BASELINE.labelShuffleAuc),
    near(order.auc, BASELINE.orderShuffleAuc),
    near(timing.auc, BASELINE.timingNoiseAuc),
    near(positive.delta, BASELINE.positiveDelta),
    near(positive.nullDelta ?? -1, BASELINE.positiveNullDelta),
    near(first.calibration.eceRaw, BASELINE.eceRaw),
    near(first.calibration.eceCalibrated, BASELINE.eceCalibrated),
    near(first.calibration.brierRaw, BASELINE.brierRaw),
    near(first.calibration.brierCalibrated, BASELINE.brierCalibrated),
    first.fraudCount === BASELINE.fraudCount,
  ].every(Boolean);

  record(
    "A",
    "baseline metrics reproduced (seed 42, n 450)",
    metricsOk,
    metricsOk
      ? `temporal AUC ${fmt(temporal.auc, 4)}, FNR@5%FPR ${fmt(temporal.fnrAtFivePctFpr, 4)}, ECE ${fmt(first.calibration.eceRaw, 4)} → ${fmt(first.calibration.eceCalibrated, 4)}`
      : "metric mismatch vs recorded baseline",
  );
  record(
    "A",
    "audit chain verifies",
    first.chain.valid && first.chain.count === BASELINE.chainCount,
    `${first.chain.count} records, valid=${first.chain.valid}, root ${shortRoot(first.chain.root)}`,
  );
  record(
    "A",
    "root hash matches baseline",
    first.chain.root === BASELINE.chainRoot,
    shortRoot(first.chain.root),
  );
  record(
    "A",
    "determinism (re-run byte-identical)",
    deterministic,
    deterministic ? "MATCH" : "DIVERGED",
  );
}

// ---------------------------------------------------------------------------
// Gate B — extraction (adapter ≡ dashboard derivation, five seeds)
// ---------------------------------------------------------------------------

function gateB(): void {
  let allVerdictsEqual = true;
  let allOverallEqual = true;
  let layeredOk = true;
  const lines: string[] = [];

  for (const seed of GATE_SEEDS) {
    const r = runValidation({ seed, n: N });
    const dashboard = deriveChecks(r);
    const run: VerticalRunResult = runVertical(fraudVertical, { seed, n: N });

    // per-check verdict equality on the 7 shared checks
    for (const check of dashboard.checks) {
      const outcome = run.outcomes.find((o) => o.id === check.id);
      if (!outcome) {
        allVerdictsEqual = false;
        lines.push(`seed ${seed}: vertical missing check ${check.id}`);
        continue;
      }
      if (outcome.verdict !== check.verdict) {
        allVerdictsEqual = false;
        lines.push(
          `seed ${seed}: ${check.id} adapter=${outcome.verdict} dashboard=${check.verdict}`,
        );
      }
    }

    // overall verdict equality (dashboard worst-of-7 ≡ vertical worst-of-9)
    if (run.worst !== dashboard.overall) {
      allOverallEqual = false;
      lines.push(`seed ${seed}: overall adapter=${run.worst} dashboard=${dashboard.overall}`);
    }

    // layered receipt: the substrate chain must commit the harness chain root
    const sealedReceipt = run.receipts.find((rec) => rec.tag === "fraud.sealed");
    const sealedRoot =
      sealedReceipt && typeof sealedReceipt.payload === "object" && sealedReceipt.payload !== null
        ? (sealedReceipt.payload as { root?: unknown }).root
        : undefined;
    if (
      !run.sealed ||
      run.sealed.root !== r.chain.root ||
      sealedRoot !== r.chain.root ||
      run.chain.valid !== true
    ) {
      layeredOk = false;
      lines.push(`seed ${seed}: layered receipt broken`);
    }

    lines.push(
      `seed ${seed}: overall ${run.worst} (${run.counts.pass}/${run.outcomes.length}), root ${shortRoot(run.chain.root, 12)}`,
    );
  }

  record("B", "adapter verdicts ≡ dashboard derivation (5 seeds)", allVerdictsEqual,
    allVerdictsEqual ? "35/35 per-check verdicts equal" : lines.filter((l) => l.includes(":")).slice(0, 4).join("; "));
  record("B", "overall verdicts equal (5 seeds)", allOverallEqual,
    allOverallEqual ? "fraud vertical and brand.ts agree everywhere" : "overall verdict mismatch");
  record("B", "layered receipt (harness chain root sealed)", layeredOk,
    layeredOk ? "fraud.sealed commits runValidation's own chain root" : "layering broken");
  record("B", "gate seed detail", true, lines.join(" · "));
}

// ---------------------------------------------------------------------------
// Gate C — second domain (hydraulic)
// ---------------------------------------------------------------------------

function gateC(): void {
  const first = runVertical(hydraulicVertical, { seed: SEED, n: N });
  const second = runVertical(hydraulicVertical, { seed: SEED, n: N });
  const deterministic = JSON.stringify(first) === JSON.stringify(second);
  const controlIds = new Set(
    first.outcomes.filter((o) => o.kind === "control").map((o) => o.id),
  );
  const outcomeIds = new Set(
    first.outcomes.filter((o) => o.kind === "outcome").map((o) => o.id),
  );
  const expected = {
    outcomes: ["min_peak_pressure", "max_velocity", "mass_balance", "night_min_pressure"],
    controls: [
      "control_demand_redistribution",
      "control_null_demand",
      "control_roughness_robustness",
      "control_spike_response",
    ],
  };
  const shapeOk =
    outcomeIds.size === expected.outcomes.length &&
    expected.outcomes.every((id) => outcomeIds.has(id)) &&
    controlIds.size === expected.controls.length &&
    expected.controls.every((id) => controlIds.has(id));

  const minPressure = first.outcomes.find((o) => o.id === "min_peak_pressure")!;
  const maxVelocity = first.outcomes.find((o) => o.id === "max_velocity")!;

  record("C", "hydraulic vertical runs + 8 checks present", shapeOk,
    `${first.outcomes.length} checks (${first.counts.pass} PASS / ${first.counts.warn} WARN / ${first.counts.fail} FAIL), worst ${first.worst}`);
  record("C", "hydraulic chain verifies", first.chain.valid,
    `${first.chain.count} records, root ${shortRoot(first.chain.root)}`);
  record("C", "hydraulic determinism", deterministic,
    deterministic ? "re-run byte-identical" : "DIVERGED");
  record("C", "hydraulic outcome sanity", true,
    `min peak pressure ${fmt(minPressure.value, 2)} m, max velocity ${fmt(maxVelocity.value, 3)} m/s`);
}

// ---------------------------------------------------------------------------
// Gate D — proof (purity, canonical shape, independence)
// ---------------------------------------------------------------------------

const VERTICAL_TOKENS = [
  "fraud",
  "hydraulic",
  "water",
  "demand",
  "pressure",
  "flow",
  "velocity",
  "pipe",
  "reservoir",
  "valve",
  "scada",
  "auc",
  "brier",
  "ece",
  "wasserstein",
  "spearman",
  "label",
  "recall",
];

function scanPurity(): { pass: boolean; detail: string } {
  const files = [
    join(ROOT, "../src/lib/verification/types.ts"),
    join(ROOT, "../src/lib/verification/substrate.ts"),
  ];
  const pattern = new RegExp(`\\b(${VERTICAL_TOKENS.join("|")})\\b`, "i");
  const hits: string[] = [];
  for (const file of files) {
    const source = readFileSync(file, "utf8");
    const lines = source.split("\n");
    lines.forEach((line, i) => {
      if (pattern.test(line)) hits.push(`${file.split("/").pop()}:${i + 1}: ${line.trim()}`);
    });
  }
  return {
    pass: hits.length === 0,
    detail:
      hits.length === 0
        ? `${VERTICAL_TOKENS.length} tokens, word-boundary, case-insensitive — clean`
        : hits.slice(0, 5).join(" | "),
  };
}

function checkCanonicalShape(run: VerticalRunResult): { pass: boolean; detail: string } {
  const id = run.verticalId;
  const tags = run.receipts.map((r) => r.tag);
  const problems: string[] = [];
  if (tags[0] !== `${id}.params`) problems.push("first receipt must be params");
  if (tags[1] !== `${id}.evidence`) problems.push("second receipt must be evidence");
  if (tags[tags.length - 1] !== `${id}.summary`) problems.push("last receipt must be summary");
  const middle = tags.slice(2, tags.length - 1);
  const checkPattern = new RegExp(`^${id}\\.check\\.[a-z0-9_]+$`);
  let sealedSeen = false;
  for (const tag of middle) {
    if (tag === `${id}.sealed`) {
      sealedSeen = true;
      continue;
    }
    if (!checkPattern.test(tag)) problems.push(`bad check tag ${tag}`);
  }
  const checkCount = middle.filter((t) => checkPattern.test(t)).length;
  if (checkCount !== run.outcomes.length) problems.push("one receipt per check expected");
  const sealedOutcomes = run.outcomes.filter((o) => o.floor).length;
  if (sealedOutcomes !== run.outcomes.length) problems.push("floors declared");
  run.receipts.forEach((rec, i) => {
    if (rec.seq !== i) problems.push(`seq ${i} broken`);
  });
  return {
    pass: problems.length === 0,
    detail: problems.length === 0
      ? `${run.receipts.length} receipts: params → evidence${sealedSeen ? " → sealed" : ""} → ${checkCount} checks → summary`
      : problems.slice(0, 4).join("; "),
  };
}

function gateD(): void {
  const fraudRun = runVertical(fraudVertical, { seed: SEED, n: N });
  const hydraulicRun = runVertical(hydraulicVertical, { seed: SEED, n: N });

  const purity = scanPurity();
  record("D", "purity scan (types.ts + substrate.ts)", purity.pass, purity.detail);

  const fraudShape = checkCanonicalShape(fraudRun);
  record("D", "canonical receipt shape (fraud)", fraudShape.pass, fraudShape.detail);
  const hydraulicShape = checkCanonicalShape(hydraulicRun);
  record("D", "canonical receipt shape (hydraulic)", hydraulicShape.pass, hydraulicShape.detail);

  // Independent chains: different roots, and each chain re-verifies ONLY with
  // its own genesis — cross-verification with the wrong genesis must fail.
  const rootsDiffer = fraudRun.chain.root !== hydraulicRun.chain.root;
  const crossFraud = verifyChain(hydraulicVertical.genesis, fraudRun.receipts);
  const crossHydraulic = verifyChain(fraudVertical.genesis, hydraulicRun.receipts);
  const independence =
    rootsDiffer &&
    !crossFraud.valid &&
    !crossHydraulic.valid &&
    fraudVertical.genesis !== hydraulicVertical.genesis;
  record("D", "independent chains (own genesis binding)", independence,
    `roots differ=${rootsDiffer}, cross-verification fails as it must (${crossFraud.valid}, ${crossHydraulic.valid})`);

  const onePath =
    fraudRun.receipts.length === 1 + 1 + 1 + fraudRun.outcomes.length + 1 &&
    hydraulicRun.receipts.length === 1 + 1 + 0 + hydraulicRun.outcomes.length + 1;
  record("D", "one runVertical code path (same receipt plan)", onePath,
    `fraud ${fraudRun.receipts.length} receipts, hydraulic ${hydraulicRun.receipts.length} receipts, both from the same builder`);
}

// ---------------------------------------------------------------------------
// Run everything.
// ---------------------------------------------------------------------------

gateA();
gateB();
gateC();
gateD();

console.log("\nProofBridge Validation Dashboard — labelled rebuild");
console.log("substrate gate evidence (Gates A–D), seed 42 / n 450 unless noted\n");
console.log(
  table(
    ["gate", "assertion", "result", "detail"],
    results.map((r) => [r.gate, r.name, r.pass ? "PASS" : "FAIL", r.detail]),
  ),
);

const failed = results.filter((r) => !r.pass);
if (failed.length > 0) {
  console.error(`\n${failed.length} assertion(s) FAILED`);
  process.exit(1);
}
console.log("\nALL GATES PASSED");
