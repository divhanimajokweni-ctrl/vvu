# ProofBridge Validation Dashboard

A Next.js 16 + TypeScript dashboard that **executes** the ProofBridge
fraud-model validation harness and renders the evidence: model ladder,
Tier-0 controls, behavioural fidelity, calibration, operational band, and a
SHA-256 append-only audit chain.

> **LABELLED REBUILD (REBUILD-19-c, 2026-09-13).** This tree is a **new experiment with new
> roots**, rebuilt from the documented inventory after the original artifact
> (commits `ea7aaa0` + `56c9076`) was destroyed at a session boundary. It is
> **not** the original tree and never claims to be: the original baseline
> roots (`e36d9b4d…`, `b2ee7c31…`, `68694f62…`) are historical, tied to the
> lost tree, and are **not reproducible from this code**. The rebuild carries
> user authorisation ("rebuild whatever you tossed") and is labelled as a
> rebuild everywhere: here, in the commit messages, and in the worklog.

As of the substrate experiment this repo contains **two domains running
through one shared verification substrate** (fraud + hydraulic). The deeper
abstractions — generic Claim / ProofObligation / Evidence types, a formal
TrustState, an IVE runtime — remain **deliberately unbuilt**: they will be
formalised only if they emerge from evidence, not because a diagram says so.
See [Substrate experiment](#substrate-experiment-gates-a--d).

## What is actually implemented

The harness (`src/lib/validation/harness.ts`) is not a mock. It contains
executable, deterministic (seeded) implementations of:

- Model scoring ladder: rules → B′ → flat → temporal → temporal-calibrated
  (full-batch gradient-descent logistic training, seeded split)
- ROC AUC (rank-based, tie-safe) and partial AUC (0–0.1 FPR band)
- FNR @ 5% FPR operating point
- Tier-0 controls: label-shuffle, order-shuffle, timing-noise, positive
  control (each averaged over several independent permutations so the null
  distribution is tight) plus a placebo (null) measurement
- Isotonic-style calibration (pool-adjacent-violators) with ECE / Brier
  evaluation
- KS distance, Wasserstein distance, Spearman correlation, circular statistics
- P1–P4 behavioural checks (burst, velocity, graph, drift)
- SHA-256 audit-chain construction
  (`hash_i = SHA-256(prev ‖ tag ‖ payload)`, genesis anchor
  `PROOFBRIDGE_GENESIS_v1`) with end-to-end chain re-verification
- Deterministic seeded execution (`mulberry32` PRNG — same seed, same numbers)

Pure TypeScript + `node:crypto` only: the headless scripts run with plain
`bun run scripts/…` **without node_modules**.

`POST /api/validate` invokes `runValidation({ seed, n })` for real.
`POST /api/verify` runs either or both verticals through the shared substrate:

```bash
curl -X POST http://localhost:3100/api/verify \
  -H 'content-type: application/json' \
  -d '{"seed":42,"vertical":"hydraulic"}'
```

Returns adjudicated checks, worst-verdict summary, canonical receipts and a
sealed per-vertical SHA-256 chain for each vertical (default: both).

## Run

```bash
bun install
bun run dev          # http://localhost:3100
```

Then in the UI: **Run harness** (seed + n), or directly:

```bash
curl -X POST http://localhost:3100/api/validate \
  -H 'content-type: application/json' -d '{"seed":42,"n":450}'
```

Headless harness baseline (no server, no node_modules):

```bash
bun run scripts/test-harness.ts
```

Substrate gate evidence (Gates A–D, no server, no node_modules):

```bash
bun run scripts/verify-gates.ts
```

## Baseline (seed 42, n 450) — captured from this exact tree

| Metric                     | Value |
| -------------------------- | ----- |
| fraud rate                 | 79 / 450 (17.6%) |
| rules / B′ / flat AUC      | 0.5922 / 0.6792 / 0.7710 |
| temporal AUC               | 0.8437 |
| temporal-calibrated AUC    | 0.8428 |
| temporal FNR @ 5% FPR      | 0.4103 |
| label-shuffle AUC          | 0.5150 (collapses → no label leak) |
| order-shuffle AUC          | 0.7053 (degrades → temporal signal is real) |
| timing-noise AUC           | 0.8539 (robust to clock noise) |
| positive control Δ / null  | 0.4731 / −0.0298 |
| ECE raw → calibrated       | 0.1085 → 0.0831 (the honest calibration WARN) |
| Brier raw → calibrated     | 0.1020 → 0.1037 |
| pAUC temporal vs flat      | 0.0541 vs 0.0262 (2.07×) |
| P1–P4 / composite          | 0.739 / 0.827 / 0.685 / 0.800 / 3.051 |
| audit chain                | 451 records, valid, root `bd4673596aebfcfb…` |
| determinism                | repeat run → byte-identical output + root hash |

## Substrate experiment (Gates A–D)

The five primitives were **not** all encoded up front. The substrate extracts
only what already existed implicitly in `harness.ts`:

```text
VerificationOutcome   — an adjudicated domain check
ControlVerdict        — an adjudicated instrument-sanity check
Receipt               — an append-only, hash-chained evidence record
```

Implementation (TypeScript, in this repo — no second language):

```text
src/lib/verification/
├── types.ts        domain-neutral contracts (CheckSpec band language)
├── substrate.ts    mulberry32 · adjudicate · aggregate · buildChain · runVertical
└── verticals/
    ├── fraud.ts      adapter around the UNTOUCHED harness
    └── hydraulic.ts  deterministic Hazen–Williams water network
```

Gate results (`bun run scripts/verify-gates.ts`):

| Gate | Evidence | Result |
|---|---|---|
| A — reference specimen | baseline reproduced exactly, chain verifies, determinism holds (seed 42 root `bd4673596aeb…`) | **PASS** |
| B — extraction | fraud adapter verdicts ≡ the dashboard's own `brand.ts` verdicts on live output, across 5 seeds (42/7/1337/999/314); overall verdicts equal; harness output untouched; layered receipt seals the harness chain root | **PASS** |
| C — second domain | hydraulic vertical: 4 Tier-0 controls + 4 outcomes, chain verifies, deterministic | **PASS** |
| D — proof | mechanical purity scan (18 vertical tokens, word-boundary, over `types.ts` + `substrate.ts`), canonical receipt shape for both verticals, one `runVertical` code path, independent chains (each bound to its own genesis — cross-verification with the wrong genesis fails) | **PASS** |

Seed-42 snapshot through the substrate:

| Vertical | Verdict | Chain |
|---|---|---|
| fraud | WARN 8/9 (calibration quality — ECE 0.1085 → 0.0831 stays above the WARN band; identical to the dashboard derivation) | 13 records, valid, root `2d8b92751c52…`; seals the harness root `bd467359…` |
| hydraulic | PASS 8/8 (min peak pressure 51.04 m, max velocity 1.50 m/s, mass balance residual 5.6e−17 m³/s, night min pressure 59.53 m) | 11 records, valid, root `bba4ca1f106a…` |

Layering: the fraud adapter commits the harness's own internal chain root
as a receipt, so the substrate chain seals the domain chain — receipts all
the way down.

The substrate was promoted **only because** both verticals ran through it
unchanged. If a third vertical forces domain semantics into `substrate.ts`,
the purity gate will fail and the substrate must be reworked, not decorated.

## Maturity

| Component                  | Status                          |
| -------------------------- | ------------------------------- |
| Fraud verification (TS)    | **Implemented** (labelled rebuild) |
| Tier-0 controls            | **Implemented**                 |
| Model ladder / calibration | **Implemented**                 |
| Audit chain + re-verify    | **Implemented**                 |
| Verdict bands (brand.ts)   | **Implemented** (worst-of, two-tier floors, strict label-shuffle rule) |
| Vertical interface         | **Implemented** (Vertical / VerticalRunResult) |
| Hydraulic vertical         | **Implemented** (deterministic, seeded) |
| Cross-domain substrate     | **Demonstrated** (Gates A–D passing) |
| Generic Claim / Obligation / Evidence | Not formalised — will emerge from evidence or not at all |
| Formal TrustState         | Not formalised — derive from fraud∩hydraulic state needs first |
| IVE runtime               | **Out of scope** for this experiment |

### Next direction (still evidence-first)

1. Keep the fraud harness as the reference specimen — still untouched.
2. Watch whether Claim / Obligation / Evidence naturally emerge from the
   two running verticals; formalise only then.
3. Compare what state the fraud run produces vs what the hydraulic run
   needs; formalise a TrustState only from that intersection.
4. IVE becomes relevant only as an executor/viewer after the substrate has
   earned existence — it is explicitly **not** an acceptance criterion here.

## Provenance

**Labelled rebuild** (worklog 22-a, user-authorised). The original artifact —
`.publish/proofbridge-krypte` with commits `ea7aaa0` (initial sanitized
publish) + `56c9076` (substrate experiment), and the published zip — was
destroyed when a session boundary dropped gitignored paths. This tree was
rebuilt from the surviving documentation (the README preserved in the VVU
workspace + the worklog recipe). It is a **new experiment**: new generator
constants, new roots, new baseline numbers — all recorded above.

Commit structure mirrors the original discipline: commit 1 is the base repo
(validation layer + app + README + config), commit 2 adds **only**
`src/lib/verification/`, `src/app/api/verify/`, and
`scripts/verify-gates.ts` (plus this README's substrate sections).
`src/lib/validation/` (the reference specimen) is byte-identical across both
commits — pure additions in commit 2.

No secrets were present in the source tree; no workspace-local files
(`.env`, local db, agent notes, tool transcripts) are tracked.

## MBD real-data validation (work order Deliverable 1, 2026-09-14)

The fraud specimen's first run against **real event sequences**: 2,000 clients
from `ai-lab/MBD-mini` (pinned revision `4b0d5b4c…`, fold 0), 684,098 real
transactions, proxy APP-fraud labels from the disclosed rule (proxies fully
documented in `proofbridge/adapters/mbd.py`).

Headline (full report + interpretation in `evidence/mbd/MBD-VALIDATION-REPORT.md`):

- temporal AUC **0.6511** vs flat **0.5786** (Δ +0.0724 — suggestive at 222
  positives, ≈1.3σ; not conclusive)
- order-shuffle Δ **0.0100 — near zero**: the temporal advantage survives
  stream re-laying; fine-grained event ordering is weakly supported at best
  under this proxy labeling
- FN reduction vs B′ @ 5% FPR: **0.0526** (0.8772 → 0.8246)
- positive control Δ **0.4784** vs null 0.0074 (instrument works);
  label-shuffle 0.4936 (no leak)
- audit chain: **684,099 records, valid, root `2a6beaf4be6d…`**; a full rerun
  from independently regenerated samples reproduced it byte-identically
- the synthetic reference root `bd467359…` is UNCHANGED after the additive
  `runValidationOnSamples` seam (Gate A stability captured in
  `evidence/mbd/gate-a-stability-after-seam.txt`)

All MBD results are conditional on the disclosed proxy labels; they make no
claim about real-bank fraud performance.
