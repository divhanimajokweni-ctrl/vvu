"use client";

import { useState } from "react";

import { deriveChecks } from "@/lib/brand";
import type { ValidationResults } from "@/lib/validation/types";
import { MODEL_ORDER } from "@/lib/validation/types";
import { fmt, pct, shortRoot } from "@/lib/validation/format";

// Structural mirrors of the substrate contracts (src/lib/verification/types).
// Declared locally so the dashboard is self-contained; the substrate layer
// commits to the same shapes and Gate B/D verify the round-trip.
interface OutcomeView {
  id: string;
  name: string;
  value: number;
  unit?: string;
  direction: string;
  verdict: "PASS" | "WARN" | "FAIL";
  kind?: "control" | "outcome";
  detail?: string;
}

interface VerticalRunView {
  verticalId: string;
  name: string;
  seed: number;
  n: number;
  worst: "PASS" | "WARN" | "FAIL";
  counts: { pass: number; warn: number; fail: number };
  outcomes: OutcomeView[];
  chain: { count: number; valid: boolean; root: string };
  sealed?: { tag: string; root: string; count: number };
}

interface VerifyResponse {
  runs: VerticalRunView[];
}

function Verdict({ v }: { v: string }) {
  return <span className={`verdict ${v}`}>{v}</span>;
}

function VerdictBanner({ v, text }: { v: string; text: string }) {
  return (
    <div className={`verdict-banner ${v}`}>
      {v} — {text}
    </div>
  );
}

function AucBar({ value }: { value: number }) {
  const width = Math.max(0, Math.min(1, value)) * 100;
  return (
    <span className="bar">
      <span style={{ width: `${width.toFixed(1)}%` }} />
    </span>
  );
}

export default function Dashboard() {
  const [seed, setSeed] = useState("42");
  const [n, setN] = useState("450");
  const [running, setRunning] = useState(false);
  const [verifying, setVerifying] = useState(false);
  const [results, setResults] = useState<ValidationResults | null>(null);
  const [verifyRuns, setVerifyRuns] = useState<VerticalRunView[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [verifyError, setVerifyError] = useState<string | null>(null);

  const derivation = results ? deriveChecks(results) : null;

  async function runHarness() {
    setRunning(true);
    setError(null);
    try {
      const res = await fetch("/api/validate", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ seed: Number(seed), n: Number(n) }),
      });
      if (!res.ok) throw new Error(`harness failed: HTTP ${res.status}`);
      const data = (await res.json()) as { results: ValidationResults };
      setResults(data.results);
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setRunning(false);
    }
  }

  async function runVerification() {
    setVerifying(true);
    setVerifyError(null);
    try {
      const res = await fetch("/api/verify", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ seed: Number(seed), n: Number(n) }),
      });
      if (!res.ok) throw new Error(`verification failed: HTTP ${res.status}`);
      const data = (await res.json()) as VerifyResponse;
      setVerifyRuns(data.runs);
    } catch (e) {
      setVerifyError(e instanceof Error ? e.message : String(e));
    } finally {
      setVerifying(false);
    }
  }

  return (
    <>
      <header className="header">
        <h1>
          PROOFBRIDGE VALIDATION DASHBOARD
          <span className="badge">LABELLED REBUILD</span>
        </h1>
        <div className="sub">
          executable fraud-model validation harness · Tier-0 controls · calibration ·
          SHA-256 audit chain · cross-domain verification substrate (fraud + hydraulic)
        </div>
      </header>

      <section className="panel">
        <h2>Run</h2>
        <div className="controls">
          <label>
            seed{" "}
            <input value={seed} onChange={(e) => setSeed(e.target.value)} inputMode="numeric" />
          </label>
          <label>
            n{" "}
            <input value={n} onChange={(e) => setN(e.target.value)} inputMode="numeric" />
          </label>
          <button onClick={runHarness} disabled={running}>
            {running ? "RUNNING…" : "Run harness"}
          </button>
          <button onClick={runVerification} disabled={verifying}>
            {verifying ? "VERIFYING…" : "Run verification substrate"}
          </button>
          {running && <span className="status">executing runValidation…</span>}
        </div>
        {error && <div className="error">{error}</div>}
      </section>

      {results && derivation && (
        <>
          <section className="panel">
            <h2>Verdict — dashboard derivation (worst-of)</h2>
            <VerdictBanner
              v={derivation.overall}
              text={`${derivation.counts.pass} PASS · ${derivation.counts.warn} WARN · ${derivation.counts.fail} FAIL of ${derivation.checks.length} checks — seed ${results.seed}, n ${results.n}, fraud ${results.fraudCount} (${pct(results.fraudRate, 1)})`}
            />
            <table>
              <thead>
                <tr>
                  <th>check</th>
                  <th>value</th>
                  <th>verdict</th>
                  <th>detail</th>
                </tr>
              </thead>
              <tbody>
                {derivation.checks.map((c) => (
                  <tr key={c.id}>
                    <td>{c.name}</td>
                    <td>{fmt(c.value, 4)}</td>
                    <td>
                      <Verdict v={c.verdict} />
                    </td>
                    <td className="muted">{c.detail}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </section>

          <section className="panel">
            <h2>Model scoring ladder (holdout)</h2>
            <table>
              <thead>
                <tr>
                  <th>model</th>
                  <th>AUC</th>
                  <th></th>
                  <th>pAUC (0–0.1 FPR)</th>
                  <th>FNR @ 5% FPR</th>
                </tr>
              </thead>
              <tbody>
                {MODEL_ORDER.map((name) => {
                  const e = results.ladder.find((l) => l.model === name);
                  if (!e) return null;
                  return (
                    <tr key={name}>
                      <td>{name}</td>
                      <td>{fmt(e.auc, 4)}</td>
                      <td>
                        <AucBar value={e.auc} />
                      </td>
                      <td>{fmt(e.partialAuc, 4)}</td>
                      <td>{fmt(e.fnrAtFivePctFpr, 4)}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
            <div className="kv">
              pAUC ratio temporal ÷ flat ={" "}
              <b>
                {fmt(
                  (results.ladder.find((l) => l.model === "temporal")?.partialAuc ?? 0) /
                    Math.max(
                      results.ladder.find((l) => l.model === "flat")?.partialAuc ?? 1,
                      1e-9,
                    ),
                  2,
                )}
                ×
              </b>
            </div>
          </section>

          <section className="panel">
            <h2>Tier-0 controls</h2>
            <table>
              <thead>
                <tr>
                  <th>control</th>
                  <th>AUC</th>
                  <th>delta</th>
                  <th>null delta</th>
                </tr>
              </thead>
              <tbody>
                {results.controls.map((c) => (
                  <tr key={c.control}>
                    <td>{c.control}</td>
                    <td>{fmt(c.auc, 4)}</td>
                    <td>{fmt(c.delta, 4)}</td>
                    <td>{c.nullDelta === undefined ? "—" : fmt(c.nullDelta, 4)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </section>

          <div className="grid-2">
            <section className="panel">
              <h2>Calibration (isotonic)</h2>
              <table>
                <tbody>
                  <tr>
                    <th>ECE raw → calibrated</th>
                    <td>
                      {fmt(results.calibration.eceRaw, 4)} → {fmt(results.calibration.eceCalibrated, 4)}
                    </td>
                  </tr>
                  <tr>
                    <th>Brier raw → calibrated</th>
                    <td>
                      {fmt(results.calibration.brierRaw, 4)} →{" "}
                      {fmt(results.calibration.brierCalibrated, 4)}
                    </td>
                  </tr>
                </tbody>
              </table>
              <h2 style={{ marginTop: 18 }}>Behavioural fidelity (P1–P4)</h2>
              <table>
                <tbody>
                  <tr>
                    <th>P1 burst</th>
                    <td>{fmt(results.behavior.p1Burst, 3)}</td>
                  </tr>
                  <tr>
                    <th>P2 velocity</th>
                    <td>{fmt(results.behavior.p2Velocity, 3)}</td>
                  </tr>
                  <tr>
                    <th>P3 graph</th>
                    <td>{fmt(results.behavior.p3Graph, 3)}</td>
                  </tr>
                  <tr>
                    <th>P4 drift</th>
                    <td>{fmt(results.behavior.p4Drift, 3)}</td>
                  </tr>
                  <tr>
                    <th>composite</th>
                    <td>{fmt(results.behavior.composite, 3)}</td>
                  </tr>
                </tbody>
              </table>
            </section>

            <section className="panel">
              <h2>Distributions (temporal score, holdout)</h2>
              <table>
                <tbody>
                  <tr>
                    <th>KS distance</th>
                    <td>{fmt(results.distribution.ksDistance, 4)}</td>
                  </tr>
                  <tr>
                    <th>Wasserstein</th>
                    <td>{fmt(results.distribution.wasserstein, 4)}</td>
                  </tr>
                  <tr>
                    <th>Spearman(score, latent)</th>
                    <td>{fmt(results.distribution.spearman, 4)}</td>
                  </tr>
                  <tr>
                    <th>circular concentration fraud</th>
                    <td>{fmt(results.distribution.circularConcentrationFraud, 4)}</td>
                  </tr>
                  <tr>
                    <th>circular concentration clean</th>
                    <td>{fmt(results.distribution.circularConcentrationClean, 4)}</td>
                  </tr>
                </tbody>
              </table>
            </section>
          </div>

          <section className="panel">
            <h2>SHA-256 audit chain</h2>
            <div className="kv">
              records <b>{results.chain.count}</b> · valid{" "}
              <b>{results.chain.valid ? "true" : "false"}</b> · genesis{" "}
              <b>PROOFBRIDGE_GENESIS_v1</b>
            </div>
            <div className="root-hash">root {results.chain.root}</div>
          </section>
        </>
      )}

      <section className="panel">
        <h2>Verification substrate (both verticals)</h2>
        {verifyError && <div className="error">{verifyError}</div>}
        {!verifyRuns && !verifyError && (
          <div className="status">
            press “Run verification substrate” — runs the fraud and hydraulic verticals
            through the shared substrate (POST /api/verify)
          </div>
        )}
        {verifyRuns?.map((run) => (
          <div key={run.verticalId} style={{ marginBottom: 24 }}>
            <VerdictBanner
              v={run.worst}
              text={`${run.name} — ${run.counts.pass} PASS · ${run.counts.warn} WARN · ${run.counts.fail} FAIL of ${run.outcomes.length} checks (seed ${run.seed}, n ${run.n})`}
            />
            <table>
              <thead>
                <tr>
                  <th>check</th>
                  <th>value</th>
                  <th>kind</th>
                  <th>verdict</th>
                  <th>detail</th>
                </tr>
              </thead>
              <tbody>
                {run.outcomes.map((o) => (
                  <tr key={o.id}>
                    <td>{o.name}</td>
                    <td>{fmt(o.value, 4)}</td>
                    <td className="muted">{o.kind ?? "outcome"}</td>
                    <td>
                      <Verdict v={o.verdict} />
                    </td>
                    <td className="muted">{o.detail}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            <div className="kv">
              sealed chain: <b>{run.chain.count}</b> records · valid{" "}
              <b>{run.chain.valid ? "true" : "false"}</b> · root{" "}
              <b>{shortRoot(run.chain.root, 16)}</b>
            </div>
            {run.sealed && (
              <div className="kv">
                commits lower chain: <b>{run.sealed.tag}</b> root{" "}
                <b>{shortRoot(run.sealed.root, 16)}</b> ({run.sealed.count} records)
              </div>
            )}
            <div className="root-hash">{run.chain.root}</div>
          </div>
        ))}
      </section>

      <footer className="muted">
        ProofBridge Validation Dashboard — labelled rebuild (new experiment, new roots; the
        original tree was lost at a session boundary). Deterministic: same seed + n → same
        numbers, same chain root.
      </footer>
    </>
  );
}
