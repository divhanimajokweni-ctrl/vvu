import { NextResponse } from "next/server";

import { runValidation } from "@/lib/validation/harness";
import type { ValidationResults } from "@/lib/validation/types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const MAX_N = 5000;

export async function GET() {
  return NextResponse.json({ error: "method not allowed" }, { status: 405 });
}

export async function POST(request: Request) {
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "invalid JSON body" }, { status: 400 });
  }
  const { seed, n } = (body ?? {}) as { seed?: unknown; n?: unknown };
  const seedNum = typeof seed === "number" ? Math.floor(seed) : 42;
  const nNum = typeof n === "number" ? Math.floor(n) : 450;
  if (!Number.isFinite(seedNum) || seedNum < 0 || seedNum > 0x7fffffff) {
    return NextResponse.json({ error: "seed must be an integer in [0, 2^31)" }, { status: 400 });
  }
  if (!Number.isFinite(nNum) || nNum < 50 || nNum > MAX_N) {
    return NextResponse.json({ error: `n must be an integer in [50, ${MAX_N}]` }, { status: 400 });
  }

  const results: ValidationResults = runValidation({ seed: seedNum, n: nNum });
  return NextResponse.json({ results });
}
