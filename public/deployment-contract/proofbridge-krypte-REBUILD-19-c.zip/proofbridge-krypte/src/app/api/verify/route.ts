import { NextResponse } from "next/server";

import { runVertical } from "@/lib/verification/substrate";
import type { VerticalRunResult } from "@/lib/verification/types";
import { fraudVertical } from "@/lib/verification/verticals/fraud";
import { hydraulicVertical } from "@/lib/verification/verticals/hydraulic";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const VERTICALS = { fraud: fraudVertical, hydraulic: hydraulicVertical } as const;
const MAX_N = 5000;

export async function GET() {
  return NextResponse.json({ error: "method not allowed" }, { status: 405 });
}

export async function POST(request: Request) {
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "invalid JSON body" }, { status: 400 });
  }
  const { seed, n, vertical } = (body ?? {}) as {
    seed?: unknown;
    n?: unknown;
    vertical?: unknown;
  };
  const seedNum = typeof seed === "number" ? Math.floor(seed) : 42;
  const nNum = typeof n === "number" ? Math.floor(n) : 450;
  if (!Number.isFinite(seedNum) || seedNum < 0 || seedNum > 0x7fffffff) {
    return NextResponse.json({ error: "seed must be an integer in [0, 2^31)" }, { status: 400 });
  }
  if (!Number.isFinite(nNum) || nNum < 50 || nNum > MAX_N) {
    return NextResponse.json({ error: `n must be an integer in [50, ${MAX_N}]` }, { status: 400 });
  }

  const requested =
    vertical === "fraud" || vertical === "hydraulic"
      ? [vertical]
      : (["fraud", "hydraulic"] as const);
  const params = { seed: seedNum, n: nNum };
  const runs: VerticalRunResult[] = requested.map((id) =>
    runVertical(VERTICALS[id], params),
  );
  return NextResponse.json({ runs });
}
