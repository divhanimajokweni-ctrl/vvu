import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "ProofBridge Validation Dashboard",
  description:
    "Executable fraud-model validation harness — labelled rebuild. Tier-0 controls, calibration, audit chain, cross-domain verification substrate.",
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
