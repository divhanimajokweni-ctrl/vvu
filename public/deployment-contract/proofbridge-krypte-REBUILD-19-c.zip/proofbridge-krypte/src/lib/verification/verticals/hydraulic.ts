// Gate C vertical: a deterministic Hazen–Williams water network.
//
// Second domain through the substrate. Everything here is vertical-local:
// the network, the scenarios, the controls, the permutation helper. The
// substrate (../substrate.ts) is imported only for the seeded PRNG — the
// vertical brings its own domain and its own band judgements.
//
// Network: a reservoir at 140 m head feeds a 2 km trunk (D 500 mm,
// C 120), which feeds n service pipes (seeded lengths 60–200 m, diameters
// from {80, 100, 125, 150} mm, roughness C 100–130), each serving one node
// with a base demand of 0.15–0.65 L/s at a seeded elevation of 35–80 m.
//
// Scenarios: night ×0.4, peak ×1.6, spike ×2.0 (on base demands).
//
// Head loss (Hazen–Williams, SI): h = 10.67 · L · q^1.852 / (C^1.852 · D^4.87)
// with q in m³/s and D in m.
//
// Tier-0 controls mirror the fraud control semantics:
//   demand redistribution → invariance (aggregate outcomes must not move)
//   null demand           → null control (the solver must read exact statics)
//   roughness ±10%        → robustness (outcomes must move only a little)
//   demand spike ×2       → positive control (the system must visibly respond)

import { mulberry32 } from "../substrate";
import type { CheckSpec, Vertical, VerticalEvidence, VerticalParams } from "../types";

// Network constants (fixed by design, not seeded).
const RESERVOIR_HEAD_M = 140;
const TRUNK = { lengthM: 2000, diameterM: 0.5, roughness: 120 };
const SERVICE_DIAMETERS_M = [0.08, 0.1, 0.125, 0.15];
const SCENARIOS = { night: 0.4, base: 1.0, peak: 1.6, spike: 2.0 } as const;

interface ServicePipe {
  lengthM: number;
  diameterM: number;
  roughness: number;
  baseDemandM3s: number;
  elevationM: number;
}

interface Network {
  pipes: ServicePipe[];
}

interface Solved {
  scenario: string;
  multiplier: number;
  reservoirFlowM3s: number;
  minPressureM: number;
  maxVelocityMs: number;
  massResidualM3s: number;
}

/** Deterministic Fisher–Yates permutation, local to this vertical. */
function seededPermute<T>(rng: () => number, items: readonly T[]): T[] {
  const out = items.slice();
  for (let i = out.length - 1; i > 0; i -= 1) {
    const j = Math.floor(rng() * (i + 1));
    const tmp = out[i];
    out[i] = out[j];
    out[j] = tmp;
  }
  return out;
}

function hazenWilliamsHeadLoss(lengthM: number, roughness: number, diameterM: number, qM3s: number): number {
  return (
    (10.67 * lengthM * Math.pow(Math.max(qM3s, 0), 1.852)) /
    (Math.pow(roughness, 1.852) * Math.pow(diameterM, 4.87))
  );
}

function velocity(qM3s: number, diameterM: number): number {
  return qM3s / (Math.PI * (diameterM / 2) ** 2);
}

/** Invert the trunk head-loss relation to recover the flow from the loss. */
function trunkFlowFromHeadLoss(headLossM: number): number {
  const k =
    (Math.pow(TRUNK.roughness, 1.852) * Math.pow(TRUNK.diameterM, 4.87)) /
    (10.67 * TRUNK.lengthM);
  return Math.pow(headLossM * k, 1 / 1.852);
}

function buildNetwork(seed: number, n: number): Network {
  const rng = mulberry32((seed ^ 0x6a7d5c3b) >>> 0);
  const pipes: ServicePipe[] = Array.from({ length: n }, () => ({
    lengthM: 60 + rng() * 140,
    diameterM: SERVICE_DIAMETERS_M[Math.floor(rng() * SERVICE_DIAMETERS_M.length)],
    roughness: 100 + Math.floor(rng() * 31),
    baseDemandM3s: (0.15 + rng() * 0.5) / 1000,
    elevationM: 35 + rng() * 45,
  }));
  return { pipes };
}

interface SolveOptions {
  scenario: string;
  multiplier: number;
  roughnessFactor?: number;
  /** override the per-node demand assignment (redistribution control) */
  demandOverride?: number[];
}

function solve(network: Network, options: SolveOptions): Solved {
  const rf = options.roughnessFactor ?? 1;
  const demands = options.demandOverride ?? network.pipes.map((p) => p.baseDemandM3s);
  const m = options.multiplier;
  const totalDemand = demands.reduce((acc, q) => acc + q * m, 0);

  const trunkHeadLoss = hazenWilliamsHeadLoss(
    TRUNK.lengthM,
    TRUNK.roughness * rf,
    TRUNK.diameterM,
    totalDemand,
  );
  const trunkEndHead = RESERVOIR_HEAD_M - trunkHeadLoss;

  let minPressure = Number.POSITIVE_INFINITY;
  let maxVelocity = velocity(totalDemand, TRUNK.diameterM);
  for (let i = 0; i < network.pipes.length; i += 1) {
    const p = network.pipes[i];
    const q = demands[i] * m;
    const serviceLoss = hazenWilliamsHeadLoss(p.lengthM, p.roughness * rf, p.diameterM, q);
    const pressure = trunkEndHead - serviceLoss - p.elevationM;
    if (pressure < minPressure) minPressure = pressure;
    const v = velocity(q, p.diameterM);
    if (v > maxVelocity) maxVelocity = v;
  }

  // Mass balance: recover the trunk inflow independently by inverting the
  // trunk relation, then compare with the demand total. In a consistent
  // direct solve this is pure floating-point round-off.
  const recoveredFlow = trunkFlowFromHeadLoss(trunkHeadLoss * Math.pow(rf, 1.852));
  const massResidual = Math.abs(recoveredFlow - totalDemand);

  return {
    scenario: options.scenario,
    multiplier: m,
    reservoirFlowM3s: totalDemand,
    minPressureM: minPressure,
    maxVelocityMs: maxVelocity,
    massResidualM3s: massResidual,
  };
}

function round(x: number, d: number): number {
  const f = 10 ** d;
  return Math.round(x * f) / f;
}

function buildEvidence(params: VerticalParams): VerticalEvidence {
  const network = buildNetwork(params.seed, params.n);
  const base = solve(network, { scenario: "base", multiplier: SCENARIOS.base });
  const night = solve(network, { scenario: "night", multiplier: SCENARIOS.night });
  const peak = solve(network, { scenario: "peak", multiplier: SCENARIOS.peak });
  const spike = solve(network, { scenario: "spike", multiplier: SCENARIOS.spike });

  // --- Controls -------------------------------------------------------------
  const rngControl = mulberry32((params.seed ^ 0x3c2a1e0f) >>> 0);

  // demand redistribution: permute which node carries which demand — the
  // aggregate physics (total draw, mass balance) must be invariant, and the
  // extremes must barely move (permutation among similar pipes).
  const permutedDemands = seededPermute(
    rngControl,
    network.pipes.map((p) => p.baseDemandM3s),
  );
  const redistributed = solve(network, {
    scenario: "peak-redistributed",
    multiplier: SCENARIOS.peak,
    demandOverride: permutedDemands,
  });
  const redistributionShift = Math.abs(redistributed.minPressureM - peak.minPressureM);

  // null demand: every draw set to zero — the solver must read exact statics:
  // min pressure = reservoir head − highest elevation, velocity = 0, mass
  // balance exact.
  const zeroDemands = network.pipes.map(() => 0);
  const nullRun = solve(network, {
    scenario: "null",
    multiplier: 1,
    demandOverride: zeroDemands,
  });
  const highestElevation = Math.max(...network.pipes.map((p) => p.elevationM));
  const staticPressureError = Math.abs(
    nullRun.minPressureM - (RESERVOIR_HEAD_M - highestElevation),
  );
  const nullReading =
    Math.max(staticPressureError, nullRun.maxVelocityMs, nullRun.massResidualM3s);

  // roughness robustness: every C scaled ±10% — outcomes must move only a
  // little (the network is not razor-thin on its friction estimates).
  const roughLow = solve(network, {
    scenario: "peak-roughness-90",
    multiplier: SCENARIOS.peak,
    roughnessFactor: 0.9,
  });
  const roughHigh = solve(network, {
    scenario: "peak-roughness-110",
    multiplier: SCENARIOS.peak,
    roughnessFactor: 1.1,
  });
  const roughnessShift = Math.max(
    Math.abs(roughLow.minPressureM - peak.minPressureM),
    Math.abs(roughHigh.minPressureM - peak.minPressureM),
  );

  // positive control: a demand spike must visibly move the system — the peak
  // velocity must rise when the draw doubles.
  const velocityResponse = spike.maxVelocityMs - base.maxVelocityMs;

  // --- Checks ---------------------------------------------------------------
  const outcomes: CheckSpec[] = [
    {
      id: "min_peak_pressure",
      name: "Minimum pressure at peak draw",
      value: peak.minPressureM,
      unit: "m",
      direction: "up",
      passAt: 20,
      warnAt: 15,
      floor: "warn",
      detail: `night scenario min ${night.minPressureM.toFixed(2)} m, spike min ${(spike.minPressureM).toFixed(2)} m`,
    },
    {
      id: "max_velocity",
      name: "Maximum velocity at peak draw",
      value: peak.maxVelocityMs,
      unit: "m/s",
      direction: "down",
      passAt: 2.5,
      warnAt: 3.0,
      floor: "warn",
      detail: `trunk ${velocity(peak.reservoirFlowM3s, TRUNK.diameterM).toFixed(3)} m/s at ${(peak.reservoirFlowM3s * 1000).toFixed(1)} L/s`,
    },
    {
      id: "mass_balance",
      name: "Mass balance residual (peak)",
      value: peak.massResidualM3s,
      unit: "m³/s",
      direction: "down",
      passAt: 1e-6,
      warnAt: 1e-3,
      floor: "warn",
      detail: "inverted trunk relation vs demand total",
    },
    {
      id: "night_min_pressure",
      name: "Minimum pressure at night draw",
      value: night.minPressureM,
      unit: "m",
      direction: "up",
      passAt: 50,
      warnAt: 40,
      floor: "warn",
      detail: `×${SCENARIOS.night} of base demands`,
    },
  ];

  const controls: CheckSpec[] = [
    {
      id: "control_demand_redistribution",
      name: "Demand-redistribution control",
      value: redistributionShift,
      unit: "m",
      direction: "down",
      passAt: 1.5,
      warnAt: 3.0,
      floor: "pass",
      detail: `min pressure moves ${redistributionShift.toFixed(3)} m under a full permutation of the demand assignment`,
    },
    {
      id: "control_null_demand",
      name: "Null-demand control",
      value: nullReading,
      direction: "down",
      passAt: 1e-6,
      warnAt: 1e-3,
      floor: "pass",
      detail: "zero draw must read exact statics (pressure = head − elevation, velocity 0)",
    },
    {
      id: "control_roughness_robustness",
      name: "Roughness-robustness control",
      value: roughnessShift,
      unit: "m",
      direction: "down",
      passAt: 3.0,
      warnAt: 6.0,
      floor: "pass",
      detail: `C ±10% moves the min peak pressure by ${roughnessShift.toFixed(3)} m`,
    },
    {
      id: "control_spike_response",
      name: "Spike-response control (positive)",
      value: velocityResponse,
      unit: "m/s",
      direction: "up",
      passAt: 0.5,
      warnAt: 0.25,
      floor: "pass",
      detail: `max velocity rises ${base.maxVelocityMs.toFixed(3)} → ${spike.maxVelocityMs.toFixed(3)} m/s when draw doubles`,
    },
  ];

  const payload: Record<string, unknown> = {
    seed: params.seed,
    n: params.n,
    reservoirHeadM: RESERVOIR_HEAD_M,
    trunk: TRUNK,
    scenarios: {
      base: {
        reservoirFlowLs: round(base.reservoirFlowM3s * 1000, 3),
        minPressureM: round(base.minPressureM, 4),
        maxVelocityMs: round(base.maxVelocityMs, 6),
        massResidualM3s: round(base.massResidualM3s, 15),
      },
      night: {
        reservoirFlowLs: round(night.reservoirFlowM3s * 1000, 3),
        minPressureM: round(night.minPressureM, 4),
        maxVelocityMs: round(night.maxVelocityMs, 6),
      },
      peak: {
        reservoirFlowLs: round(peak.reservoirFlowM3s * 1000, 3),
        minPressureM: round(peak.minPressureM, 4),
        maxVelocityMs: round(peak.maxVelocityMs, 6),
        massResidualM3s: round(peak.massResidualM3s, 15),
      },
      spike: {
        reservoirFlowLs: round(spike.reservoirFlowM3s * 1000, 3),
        minPressureM: round(spike.minPressureM, 4),
        maxVelocityMs: round(spike.maxVelocityMs, 6),
      },
    },
    controls: {
      redistributionShiftM: round(redistributionShift, 6),
      nullReading: round(nullReading, 15),
      roughnessShiftM: round(roughnessShift, 6),
      velocityResponseMs: round(velocityResponse, 6),
    },
  };

  return { outcomes, controls, payload };
}

export const hydraulicVertical: Vertical = {
  id: "hydraulic",
  name: "Hydraulic network validation",
  genesis: "SUBSTRATE_HYDRAULIC_GENESIS_v1",
  run(params: VerticalParams): VerticalEvidence {
    return buildEvidence(params);
  },
};
