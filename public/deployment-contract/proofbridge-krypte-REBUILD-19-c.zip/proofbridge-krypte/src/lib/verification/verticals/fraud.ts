// Gate B vertical: the fraud adapter.
//
// Wraps the reference specimen (src/lib/validation/harness.ts) UNTOUCHED —
// this file only reads its output and expresses it as CheckSpecs.
//
// The verdict bands and floor policy below mirror src/lib/brand.ts EXACTLY.
// The duplication is deliberate: scripts/verify-gates.ts (Gate B) cross-checks
// this mirror against the dashboard's own derivation across five seeds, so
// any drift between the two implementations is a caught defect, not a silent
// disagreement.
//
// Layering: the evidence carries the harness's own internal audit-chain root
// as a SealedRef, so the substrate chain seals the domain chain — receipts
// all the way down.

import { runValidation } from "../../validation/harness";
import type { ValidationResults } from "../../validation/types";
import type { CheckSpec, Vertical, VerticalEvidence, VerticalParams } from "../types";

const BANDS = {
  temporalAuc: { pass: 0.75, warn: 0.65 },
  paucRatio: { pass: 1.5, warn: 1.2 },
  fnrAtFivePct: { pass: 0.5, warn: 0.75 },
  labelShuffle: { pass: 0.56, warn: 0.6, strict: true },
  orderDegradation: { pass: 0.1, warn: 0.05 },
  timingDrop: { pass: 0.08, warn: 0.15 },
  eceCalibrated: { pass: 0.06, warn: 0.1 },
  positiveSensitivity: { pass: 0.2, warn: 0.1 },
} as const;

function round(x: number, d: number): number {
  const f = 10 ** d;
  return Math.round(x * f) / f;
}

function buildChecks(r: ValidationResults): {
  outcomes: CheckSpec[];
  controls: CheckSpec[];
} {
  const temporal = r.ladder.find((l) => l.model === "temporal");
  const flat = r.ladder.find((l) => l.model === "flat");
  if (!temporal || !flat) throw new Error("ladder incomplete");
  const label = r.controls.find((c) => c.control === "label-shuffle");
  const order = r.controls.find((c) => c.control === "order-shuffle");
  const timing = r.controls.find((c) => c.control === "timing-noise");
  const positive = r.controls.find((c) => c.control === "positive");
  if (!label || !order || !timing || !positive) throw new Error("controls incomplete");
  const ratio = temporal.partialAuc / Math.max(flat.partialAuc, 1e-9);
  const orderDegradation = temporal.auc - order.auc;
  const timingDrop = temporal.auc - timing.auc;
  const positiveSensitivity = positive.delta - (positive.nullDelta ?? 0);

  const outcomes: CheckSpec[] = [
    {
      id: "temporal_discrimination",
      name: "Temporal discrimination",
      value: temporal.auc,
      direction: "up",
      passAt: BANDS.temporalAuc.pass,
      warnAt: BANDS.temporalAuc.warn,
      floor: "warn",
      detail: `holdout AUC ${temporal.auc.toFixed(4)}`,
    },
    {
      id: "early_precision",
      name: "Early-band precision",
      value: ratio,
      direction: "up",
      passAt: BANDS.paucRatio.pass,
      warnAt: BANDS.paucRatio.warn,
      floor: "warn",
      detail: `pAUC(0–0.1 FPR) temporal ${temporal.partialAuc.toFixed(4)} vs flat ${flat.partialAuc.toFixed(4)}`,
    },
    {
      id: "operating_point",
      name: "Operating point (FNR @ 5% FPR)",
      value: temporal.fnrAtFivePctFpr,
      direction: "down",
      passAt: BANDS.fnrAtFivePct.pass,
      warnAt: BANDS.fnrAtFivePct.warn,
      floor: "warn",
      detail: "the honest miss rate at a 5% false-positive budget",
    },
    {
      id: "calibration_quality",
      name: "Calibration quality",
      value: r.calibration.eceCalibrated,
      direction: "down",
      passAt: BANDS.eceCalibrated.pass,
      warnAt: BANDS.eceCalibrated.warn,
      floor: "warn",
      detail: `ECE ${r.calibration.eceRaw.toFixed(4)} → ${r.calibration.eceCalibrated.toFixed(4)} after isotonic`,
    },
    {
      id: "audit_chain",
      name: "Audit chain integrity",
      value: r.chain.valid ? 1 : 0,
      direction: "up",
      passAt: 1,
      warnAt: 0.5,
      floor: "pass",
      detail: `${r.chain.count} records, end-to-end re-verification`,
    },
  ];

  const controls: CheckSpec[] = [
    {
      id: "control_label_shuffle",
      name: "Label-shuffle control",
      value: label.auc,
      direction: "down",
      passAt: BANDS.labelShuffle.pass,
      warnAt: BANDS.labelShuffle.warn,
      strict: true,
      floor: "pass",
      detail: `AUC collapses to ${label.auc.toFixed(4)} → no label leak`,
    },
    {
      id: "control_order_shuffle",
      name: "Order-shuffle control",
      value: orderDegradation,
      direction: "up",
      passAt: BANDS.orderDegradation.pass,
      warnAt: BANDS.orderDegradation.warn,
      floor: "pass",
      detail: `AUC degrades ${temporal.auc.toFixed(4)} → ${order.auc.toFixed(4)} (temporal signal is real)`,
    },
    {
      id: "control_timing_noise",
      name: "Timing-noise control",
      value: timingDrop,
      direction: "down",
      passAt: BANDS.timingDrop.pass,
      warnAt: BANDS.timingDrop.warn,
      floor: "pass",
      detail: `AUC drops only ${temporal.auc.toFixed(4)} → ${timing.auc.toFixed(4)} (robust to clock noise)`,
    },
    {
      id: "control_positive",
      name: "Positive control",
      value: positiveSensitivity,
      direction: "up",
      passAt: BANDS.positiveSensitivity.pass,
      warnAt: BANDS.positiveSensitivity.warn,
      floor: "pass",
      detail: `planted-signal recovery Δ ${positive.delta.toFixed(4)} vs placebo ${(positive.nullDelta ?? 0).toFixed(4)}`,
    },
  ];

  return { outcomes, controls };
}

export const fraudVertical: Vertical = {
  id: "fraud",
  name: "Fraud model validation",
  genesis: "SUBSTRATE_FRAUD_GENESIS_v1",
  run(params: VerticalParams): VerticalEvidence {
    // The reference specimen, UNTOUCHED — this adapter only reads its output.
    const r = runValidation({ seed: params.seed, n: params.n });
    const { outcomes, controls } = buildChecks(r);

    const payload: Record<string, unknown> = {
      seed: r.seed,
      n: r.n,
      fraudCount: r.fraudCount,
      fraudRate: round(r.fraudRate, 6),
      ladder: r.ladder.map((l) => ({
        model: l.model,
        auc: round(l.auc, 6),
        partialAuc: round(l.partialAuc, 6),
        fnrAtFivePctFpr: round(l.fnrAtFivePctFpr, 6),
      })),
      controls: r.controls.map((c) => ({
        control: c.control,
        auc: round(c.auc, 6),
        delta: round(c.delta, 6),
        nullDelta: c.nullDelta === undefined ? null : round(c.nullDelta, 6),
      })),
      calibration: {
        eceRaw: round(r.calibration.eceRaw, 6),
        eceCalibrated: round(r.calibration.eceCalibrated, 6),
        brierRaw: round(r.calibration.brierRaw, 6),
        brierCalibrated: round(r.calibration.brierCalibrated, 6),
      },
      behavior: {
        p1Burst: round(r.behavior.p1Burst, 6),
        p2Velocity: round(r.behavior.p2Velocity, 6),
        p3Graph: round(r.behavior.p3Graph, 6),
        p4Drift: round(r.behavior.p4Drift, 6),
        composite: round(r.behavior.composite, 6),
      },
      domainChain: {
        count: r.chain.count,
        valid: r.chain.valid,
        root: r.chain.root,
      },
    };

    return {
      outcomes,
      controls,
      payload,
      sealed: { tag: "harness.audit.root", root: r.chain.root, count: r.chain.count },
    };
  },
};
