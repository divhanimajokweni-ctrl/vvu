// Cross-domain verification substrate — the shared machinery.
//
// LABELLED REBUILD (worklog 22-a). This module contains ZERO per-vertical
// branching and ZERO domain tokens; Gate D scans it mechanically. Everything
// a vertical needs is expressed through the Vertical contract in types.ts:
//
//   mulberry32   seeded PRNG (deterministic verticals, no wall clock)
//   adjudicate   band semantics for one CheckSpec
//   aggregate    worst-of over adjudicated checks, with two-tier floors
//   buildChain   SHA-256 append-only chain with a parameterised genesis
//   verifyChain  end-to-end re-verification of a chain
//   runVertical  the one code path every vertical takes:
//                  evidence → adjudicate every check → worst verdict →
//                  canonical receipts (params, evidence, [sealed], one per
//                  check, summary) → chain → re-verify

import { createHash } from "node:crypto";

import type {
  Adjudicated,
  AggregateSummary,
  ChainEntry,
  ChainSummary,
  CheckSpec,
  ControlVerdict,
  Receipt,
  Vertical,
  VerticalEvidence,
  VerticalParams,
  VerticalRunResult,
  VerificationOutcome,
} from "./types";

// ---------------------------------------------------------------------------
// Seeded PRNG — same primitive the domain specimen uses, extracted upward.
// ---------------------------------------------------------------------------

/** mulberry32 — 32-bit seeded PRNG returning [0, 1). */
export function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return function next(): number {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// ---------------------------------------------------------------------------
// Band semantics.
// ---------------------------------------------------------------------------

const RANK: Record<string, number> = { PASS: 0, WARN: 1, FAIL: 2 };

/** Adjudicate one declarative check against its bands. */
export function adjudicate(spec: CheckSpec, kind: "outcome" | "control"): Adjudicated {
  const { value, direction, passAt, warnAt, strict } = spec;
  let verdict: "PASS" | "WARN" | "FAIL";
  if (direction === "up") {
    if (strict ? value > passAt : value >= passAt) verdict = "PASS";
    else if (value >= warnAt) verdict = "WARN";
    else verdict = "FAIL";
  } else {
    if (strict ? value < passAt : value <= passAt) verdict = "PASS";
    else if (value <= warnAt) verdict = "WARN";
    else verdict = "FAIL";
  }
  const base = {
    id: spec.id,
    name: spec.name,
    value: spec.value,
    unit: spec.unit,
    direction: spec.direction,
    verdict,
    floor: spec.floor ?? "warn",
    detail: spec.detail,
  };
  return kind === "control"
    ? ({ ...base, kind: "control" } as ControlVerdict)
    : ({ ...base, kind: "outcome" } as VerificationOutcome);
}

/** Worst-of over adjudicated checks, after two-tier floors are applied. */
export function aggregate(outcomes: readonly Adjudicated[]): AggregateSummary {
  let worst: "PASS" | "WARN" | "FAIL" = "PASS";
  const escalations: string[] = [];
  let pass = 0;
  let warn = 0;
  let fail = 0;
  for (const o of outcomes) {
    if (o.verdict === "PASS") pass += 1;
    else if (o.verdict === "WARN") warn += 1;
    else fail += 1;
    let effective = o.verdict;
    if (o.floor === "pass" && o.verdict !== "PASS") {
      escalations.push(o.id);
      effective = "FAIL";
    }
    if (RANK[effective] > RANK[worst]) worst = effective;
  }
  return { worst, counts: { pass, warn, fail }, escalations };
}

// ---------------------------------------------------------------------------
// Append-only SHA-256 chain with a parameterised genesis.
// ---------------------------------------------------------------------------

function sha256Hex(s: string): string {
  return createHash("sha256").update(s, "utf8").digest("hex");
}

function canonical(value: unknown): string {
  return JSON.stringify(value);
}

/** Chain anchor: the genesis string is hashed once and seeds the first link. */
export function chainAnchor(genesis: string): string {
  return sha256Hex(genesis);
}

export function buildChain(genesis: string, entries: readonly ChainEntry[]): Receipt[] {
  const receipts: Receipt[] = [];
  let prev = chainAnchor(genesis);
  entries.forEach((entry, i) => {
    const hash = sha256Hex(prev + entry.tag + canonical(entry.payload));
    receipts.push({ seq: i, tag: entry.tag, payload: entry.payload, prev, hash });
    prev = hash;
  });
  return receipts;
}

/** End-to-end re-verification: recompute every link, check linkage and root. */
export function verifyChain(genesis: string, receipts: readonly Receipt[]): ChainSummary {
  let prev = chainAnchor(genesis);
  let ok = true;
  for (let i = 0; i < receipts.length; i += 1) {
    const r = receipts[i];
    const hash = sha256Hex(prev + r.tag + canonical(r.payload));
    if (r.seq !== i || r.prev !== prev || r.hash !== hash) ok = false;
    prev = hash;
  }
  return { count: receipts.length, valid: ok, root: prev };
}

// ---------------------------------------------------------------------------
// The one code path every vertical takes.
// ---------------------------------------------------------------------------

export function runVertical(
  vertical: Vertical,
  params: VerticalParams,
): VerticalRunResult {
  const evidence: VerticalEvidence = vertical.run(params);

  const outcomes: Adjudicated[] = [
    ...evidence.outcomes.map((spec) => adjudicate(spec, "outcome")),
    ...evidence.controls.map((spec) => adjudicate(spec, "control")),
  ];
  const summary = aggregate(outcomes);

  const entries: ChainEntry[] = [];
  entries.push({
    tag: `${vertical.id}.params`,
    payload: { vertical: vertical.id, seed: params.seed, n: params.n, genesis: vertical.genesis },
  });
  entries.push({ tag: `${vertical.id}.evidence`, payload: evidence.payload });
  if (evidence.sealed !== undefined) {
    entries.push({ tag: `${vertical.id}.sealed`, payload: evidence.sealed });
  }
  for (const o of outcomes) {
    entries.push({
      tag: `${vertical.id}.check.${o.id}`,
      payload: {
        id: o.id,
        name: o.name,
        value: o.value,
        unit: o.unit,
        direction: o.direction,
        verdict: o.verdict,
        floor: o.floor,
        kind: o.kind,
      },
    });
  }
  entries.push({
    tag: `${vertical.id}.summary`,
    payload: {
      worst: summary.worst,
      counts: summary.counts,
      escalations: summary.escalations,
      checks: outcomes.length,
    },
  });

  const receipts = buildChain(vertical.genesis, entries);
  const chain = verifyChain(vertical.genesis, receipts);

  return {
    verticalId: vertical.id,
    name: vertical.name,
    seed: params.seed,
    n: params.n,
    outcomes,
    worst: summary.worst,
    counts: summary.counts,
    escalations: summary.escalations,
    receipts,
    chain,
    sealed: evidence.sealed,
  };
}
