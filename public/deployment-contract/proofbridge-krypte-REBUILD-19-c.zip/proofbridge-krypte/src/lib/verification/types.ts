// Cross-domain verification substrate — domain-neutral contracts.
//
// LABELLED REBUILD (worklog 22-a). These types carry ZERO domain vocabulary
// by construction: scripts/verify-gates.ts (Gate D) enforces this mechanically
// with a word-boundary scan over this file and substrate.ts.
//
// The three primitives that the domain specimen already contained implicitly:
//   VerificationOutcome — an adjudicated domain check
//   ControlVerdict      — an adjudicated instrument-sanity check
//   Receipt             — an append-only, hash-chained evidence record
// plus the declarative CheckSpec band language used to express both.

export type Verdict = "PASS" | "WARN" | "FAIL";

/** "up" = higher is better, "down" = lower is better. */
export type Direction = "up" | "down";

/**
 * Two-tier floor. "pass": the check must reach PASS — anything weaker is
 * escalated to FAIL for the aggregate (a barely-sane instrument is not a
 * usable instrument). "warn": the check may WARN without failing the run
 * (a WARN is a finding, not a broken instrument).
 */
export type Floor = "pass" | "warn";

/**
 * A declarative check:
 *   direction "up":   PASS if value ≥ passAt (strict: > passAt)
 *                     WARN if value ≥ warnAt, else FAIL
 *   direction "down": PASS if value ≤ passAt (strict: < passAt)
 *                     WARN if value ≤ warnAt, else FAIL
 */
export interface CheckSpec {
  id: string;
  name: string;
  value: number;
  unit?: string;
  direction: Direction;
  passAt: number;
  warnAt: number;
  floor?: Floor;
  strict?: boolean;
  detail?: string;
}

/** An adjudicated domain check. */
export interface VerificationOutcome {
  id: string;
  name: string;
  value: number;
  unit?: string;
  direction: Direction;
  verdict: Verdict;
  floor: Floor;
  kind: "outcome";
  detail?: string;
}

/** An adjudicated instrument-sanity check. */
export interface ControlVerdict {
  id: string;
  name: string;
  value: number;
  unit?: string;
  direction: Direction;
  verdict: Verdict;
  floor: Floor;
  kind: "control";
  detail?: string;
}

export type Adjudicated = VerificationOutcome | ControlVerdict;

/** One append-only entry awaiting chaining. Payloads are plain JSON values. */
export interface ChainEntry {
  tag: string;
  payload: unknown;
}

/**
 * A materialised chain link: the anchor is SHA-256 of the genesis string,
 * hash_i = SHA-256(prev_i ‖ tag_i ‖ payload_i), prev_{i+1} = hash_i.
 */
export interface Receipt {
  seq: number;
  tag: string;
  payload: unknown;
  prev: string;
  hash: string;
}

export interface ChainSummary {
  count: number;
  valid: boolean;
  root: string;
}

/** Reference to a lower chain committed by this run (layering). */
export interface SealedRef {
  tag: string;
  root: string;
  count: number;
}

export interface VerticalParams {
  seed: number;
  n: number;
}

/**
 * What a vertical returns from run(): its outcome checks, its instrument
 * checks, an evidence payload to commit, and optionally the root of a lower
 * chain it wants sealed inside this one.
 */
export interface VerticalEvidence {
  outcomes: CheckSpec[];
  controls: CheckSpec[];
  payload: Record<string, unknown>;
  sealed?: SealedRef;
}

/** A domain that runs through the substrate. The substrate knows nothing else. */
export interface Vertical {
  id: string;
  name: string;
  genesis: string;
  run(params: VerticalParams): VerticalEvidence;
}

export interface AggregateSummary {
  worst: Verdict;
  counts: { pass: number; warn: number; fail: number };
  escalations: string[];
}

/** The canonical result of one vertical run through the substrate. */
export interface VerticalRunResult {
  verticalId: string;
  name: string;
  seed: number;
  n: number;
  outcomes: Adjudicated[];
  worst: Verdict;
  counts: { pass: number; warn: number; fail: number };
  escalations: string[];
  receipts: Receipt[];
  chain: ChainSummary;
  sealed?: SealedRef;
}
