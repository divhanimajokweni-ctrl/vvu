/**
 * ProofBridge Validation Dashboard — labelled rebuild.
 *
 * ONE source of truth for verdict semantics: the declarative CheckSpec
 * band language (value / direction / passAt / warnAt / floor / strict),
 * worst-of aggregation with two-tier floors, and the dashboard's own
 * derivation of the nine reportable checks from a harness result.
 *
 *  - PASS / WARN / FAIL bands, worst-of overall verdict.
 *  - Two-tier floors: outcome checks may WARN without failing the run
 *    ("warn" floor — a WARN is a finding, not a broken instrument);
 *    control checks carry a hard "pass" floor — anything weaker than
 *    PASS is escalated to FAIL for the aggregate (a barely-sane
 *    instrument is not a usable instrument).
 *  - Strict-inequality label-shuffle rule: the label-shuffle control
 *    passes only if the shuffled AUC is *strictly* below its pass tier
 *    (value < passAt, never ≤) — a pipeline that merely *equals* the
 *    tier boundary has retained signal and does not pass.
 *
 * This module is deliberately self-contained (pure TypeScript, zero
 * runtime imports, no node:crypto): the dashboard renders verdicts from
 * it client-side, the headless script prints from it, and the phase-2
 * verification substrate re-expresses the same bands for the fraud
 * vertical — scripts/verify-gates.ts (Gate B) cross-checks that mirror
 * against this derivation across five seeds, so any drift between the
 * two implementations is a caught defect, not a silent disagreement.
 */

import type { ValidationResults } from "./validation/types";

export type Verdict = "PASS" | "WARN" | "FAIL";

/** "up" = higher is better, "down" = lower is better. */
export type Direction = "up" | "down";

/**
 * Two-tier floor. "pass": the check must reach PASS — anything weaker is
 * escalated to FAIL for the aggregate. "warn": the check may WARN without
 * failing the run.
 */
export type Floor = "pass" | "warn";

/**
 * A declarative check:
 *   direction "up":   PASS if value ≥ passAt (strict: > passAt)
 *                     WARN if value ≥ warnAt, else FAIL
 *   direction "down": PASS if value ≤ passAt (strict: < passAt)
 *                     WARN if value ≤ warnAt, else FAIL
 */
export interface CheckSpec {
  id: string;
  name: string;
  value: number;
  unit?: string;
  direction: Direction;
  passAt: number;
  warnAt: number;
  floor?: Floor;
  strict?: boolean;
  detail?: string;
}

/** A CheckSpec with its adjudicated verdict. */
export interface CheckView extends CheckSpec {
  verdict: Verdict;
}

/** The dashboard's derivation of one run: nine checks + worst-of. */
export interface Derivation {
  checks: CheckView[];
  counts: { pass: number; warn: number; fail: number };
  /** ids whose control verdicts were escalated by the hard "pass" floor */
  escalations: string[];
  overall: Verdict;
}

const RANK: Record<Verdict, number> = { PASS: 0, WARN: 1, FAIL: 2 };

// ---------------------------------------------------------------------------
// Band evaluation
// ---------------------------------------------------------------------------

/** Adjudicate one declarative check against its bands. */
export function adjudicate(spec: CheckSpec): Verdict {
  const { value, direction, passAt, warnAt, strict } = spec;
  if (direction === "up") {
    if (strict ? value > passAt : value >= passAt) return "PASS";
    if (value >= warnAt) return "WARN";
    return "FAIL";
  }
  if (strict ? value < passAt : value <= passAt) return "PASS";
  if (value <= warnAt) return "WARN";
  return "FAIL";
}

/**
 * Worst-of over adjudicated checks, after two-tier floors are applied.
 * Counts report the raw verdicts; `worst` uses the post-escalation
 * verdicts (a control that only reached WARN fails the aggregate).
 */
export function aggregate(checks: readonly CheckView[]): {
  worst: Verdict;
  counts: { pass: number; warn: number; fail: number };
  escalations: string[];
} {
  let worst: Verdict = "PASS";
  const escalations: string[] = [];
  let pass = 0;
  let warn = 0;
  let fail = 0;
  for (const c of checks) {
    if (c.verdict === "PASS") pass += 1;
    else if (c.verdict === "WARN") warn += 1;
    else fail += 1;
    let effective = c.verdict;
    if ((c.floor ?? "warn") === "pass" && c.verdict !== "PASS") {
      escalations.push(c.id);
      effective = "FAIL";
    }
    if (RANK[effective] > RANK[worst]) worst = effective;
  }
  return { worst, counts: { pass, warn, fail }, escalations };
}

/** Convenience: worst-of over raw verdicts (no floor escalation). */
export function worstOf(...verdicts: Verdict[]): Verdict {
  let worst: Verdict = "PASS";
  for (const v of verdicts) if (RANK[v] > RANK[worst]) worst = v;
  return worst;
}

// ---------------------------------------------------------------------------
// The nine reportable checks (bands mirrored exactly by the fraud vertical
// of the verification substrate — see the note at the top of this file)
// ---------------------------------------------------------------------------

export const BANDS = {
  temporalAuc: { pass: 0.75, warn: 0.65 },
  paucRatio: { pass: 1.5, warn: 1.2 },
  fnrAtFivePct: { pass: 0.5, warn: 0.75 },
  eceCalibrated: { pass: 0.06, warn: 0.1 },
  labelShuffle: { pass: 0.56, warn: 0.6, strict: true },
  orderDegradation: { pass: 0.1, warn: 0.05 },
  timingDrop: { pass: 0.08, warn: 0.15 },
  positiveSensitivity: { pass: 0.2, warn: 0.1 },
} as const;

/**
 * Derive the nine dashboard checks from one harness result:
 * five outcome checks + four instrument-sanity controls.
 */
export function deriveChecks(r: ValidationResults): Derivation {
  const temporal = r.ladder.find((l) => l.model === "temporal");
  const flat = r.ladder.find((l) => l.model === "flat");
  if (!temporal || !flat) throw new Error("ladder incomplete");

  const control = (name: string) => {
    const c = r.controls.find((x) => x.control === name);
    if (!c) throw new Error(`missing control ${name}`);
    return c;
  };
  const label = control("label-shuffle");
  const order = control("order-shuffle");
  const timing = control("timing-noise");
  const positive = control("positive");

  const ratio = temporal.partialAuc / Math.max(flat.partialAuc, 1e-9);
  const orderDegradation = temporal.auc - order.auc;
  const timingDrop = temporal.auc - timing.auc;
  const positiveSensitivity = positive.delta - (positive.nullDelta ?? 0);

  const specs: CheckSpec[] = [
    {
      id: "temporal_discrimination",
      name: "Temporal discrimination",
      value: temporal.auc,
      direction: "up",
      passAt: BANDS.temporalAuc.pass,
      warnAt: BANDS.temporalAuc.warn,
      floor: "warn",
      detail: `holdout AUC ${temporal.auc.toFixed(4)}`,
    },
    {
      id: "early_precision",
      name: "Early-band precision",
      value: ratio,
      direction: "up",
      passAt: BANDS.paucRatio.pass,
      warnAt: BANDS.paucRatio.warn,
      floor: "warn",
      detail: `pAUC(0–0.1 FPR) temporal ${temporal.partialAuc.toFixed(4)} vs flat ${flat.partialAuc.toFixed(4)}`,
    },
    {
      id: "operating_point",
      name: "Operating point (FNR @ 5% FPR)",
      value: temporal.fnrAtFivePctFpr,
      direction: "down",
      passAt: BANDS.fnrAtFivePct.pass,
      warnAt: BANDS.fnrAtFivePct.warn,
      floor: "warn",
      detail: "the honest miss rate at a 5% false-positive budget",
    },
    {
      id: "calibration_quality",
      name: "Calibration quality",
      value: r.calibration.eceCalibrated,
      direction: "down",
      passAt: BANDS.eceCalibrated.pass,
      warnAt: BANDS.eceCalibrated.warn,
      floor: "warn",
      detail: `ECE ${r.calibration.eceRaw.toFixed(4)} → ${r.calibration.eceCalibrated.toFixed(4)} after isotonic`,
    },
    {
      id: "audit_chain",
      name: "Audit chain integrity",
      value: r.chain.valid ? 1 : 0,
      direction: "up",
      passAt: 1,
      warnAt: 0.5,
      floor: "pass",
      detail: `${r.chain.count} records, end-to-end re-verification`,
    },
    {
      id: "control_label_shuffle",
      name: "Label-shuffle control",
      value: label.auc,
      direction: "down",
      passAt: BANDS.labelShuffle.pass,
      warnAt: BANDS.labelShuffle.warn,
      strict: true,
      floor: "pass",
      detail: `AUC collapses to ${label.auc.toFixed(4)} → no label leak`,
    },
    {
      id: "control_order_shuffle",
      name: "Order-shuffle control",
      value: orderDegradation,
      direction: "up",
      passAt: BANDS.orderDegradation.pass,
      warnAt: BANDS.orderDegradation.warn,
      floor: "pass",
      detail: `AUC degrades ${temporal.auc.toFixed(4)} → ${order.auc.toFixed(4)} (temporal signal is real)`,
    },
    {
      id: "control_timing_noise",
      name: "Timing-noise control",
      value: timingDrop,
      direction: "down",
      passAt: BANDS.timingDrop.pass,
      warnAt: BANDS.timingDrop.warn,
      floor: "pass",
      detail: `AUC drops only ${temporal.auc.toFixed(4)} → ${timing.auc.toFixed(4)} (robust to clock noise)`,
    },
    {
      id: "control_positive",
      name: "Positive control",
      value: positiveSensitivity,
      direction: "up",
      passAt: BANDS.positiveSensitivity.pass,
      warnAt: BANDS.positiveSensitivity.warn,
      floor: "pass",
      detail: `planted-signal recovery Δ ${positive.delta.toFixed(4)} vs placebo ${(positive.nullDelta ?? 0).toFixed(4)}`,
    },
  ];

  const checks: CheckView[] = specs.map((spec) => ({ ...spec, verdict: adjudicate(spec) }));
  const summary = aggregate(checks);
  return {
    checks,
    counts: summary.counts,
    escalations: summary.escalations,
    overall: summary.worst,
  };
}
