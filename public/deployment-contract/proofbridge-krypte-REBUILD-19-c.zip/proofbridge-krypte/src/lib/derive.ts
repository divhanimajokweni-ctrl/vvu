/**
 * ProofBridge Validation Dashboard — labelled rebuild.
 *
 * Applies brand.ts (the single source of verdict truth) to harness
 * results: seven report components, worst-of overall verdict.
 *
 * The seven components:
 *   1. model ladder (rules → B′ → flat → temporal, monotone)
 *   2. operating point (FNR @ 5% FPR, pAUC ratio)
 *   3. Tier-0 controls (label-shuffle, order-shuffle, timing-noise, positive, null)
 *   4. calibration (ECE + Brier after isotonic)
 *   5. behavioural fidelity (P1–P4 + composite)
 *   6. distributional sanity (Spearman oracle, circular separation)
 *   7. audit chain (end-to-end re-verification)
 */

import {
  THRESHOLDS,
  bandDown,
  bandUp,
  controlVerdict,
  worstOf,
  type Verdict,
} from "./brand";
import { nullAucSd } from "./validation/harness";
import type { ValidationResults } from "./validation/types";

export interface ComponentVerdict {
  key: string;
  label: string;
  verdict: Verdict;
  detail: string;
}

export interface Verdicts {
  components: ComponentVerdict[];
  overall: Verdict;
  worstKey: string;
}

export function deriveVerdicts(r: ValidationResults): Verdicts {
  const t = THRESHOLDS;
  const components: ComponentVerdict[] = [];

  // 1 — model ladder
  {
    const steps: Array<[string, number, { pass: number; warn: number }]> = [
      ["rules", r.ladder.rules, t.ladder.rules],
      ["B′", r.ladder.bprime, t.ladder.bprime],
      ["flat", r.ladder.flat, t.ladder.flat],
      ["temporal", r.ladder.temporal, t.ladder.temporal],
    ];
    const ladder = steps.map(([name, v, band]) => ({ name, v, verdict: bandUp(v, band) }));
    const tol = t.ladder.monotoneTolerance;
    const monotone =
      r.ladder.rules <= r.ladder.bprime + tol &&
      r.ladder.bprime <= r.ladder.flat + tol &&
      r.ladder.flat <= r.ladder.temporal + tol;
    components.push({
      key: "ladder",
      label: "Model ladder (AUC)",
      verdict: worstOf(...ladder.map((s) => s.verdict), monotone ? "PASS" : "FAIL"),
      detail:
        ladder.map((s) => `${s.name} ${s.v.toFixed(3)}`).join(" · ") +
        (monotone ? " · monotone" : " · NON-MONOTONE"),
    });
  }

  // 2 — operating point
  {
    const fnr = bandDown(r.operating.fnrAt5Fpr, t.operating.fnrAt5Fpr);
    const ratio = bandUp(r.operating.pAucRatio, t.operating.pAucRatio);
    components.push({
      key: "operating",
      label: "Operating point",
      verdict: worstOf(fnr, ratio),
      detail: `FNR@5%FPR ${r.operating.fnrAt5Fpr.toFixed(3)} (${fnr}) · pAUC ratio ${r.operating.pAucRatio.toFixed(2)}× (${ratio})`,
    });
  }

  // 3 — Tier-0 controls
  {
    const neg = r.n - r.positives;
    const nullLimit = t.controls.nullControlSigmas * nullAucSd(r.positives, neg);
    const checks: Array<[string, Verdict, string]> = [
      [
        "label-shuffle",
        controlVerdict(r.controls.labelShuffleAuc, {
          strictBelow: t.controls.labelShuffle.strictBelow,
        }),
        `AUC ${r.controls.labelShuffleAuc.toFixed(3)} — strict < ${t.controls.labelShuffle.strictBelow}`,
      ],
      [
        "order-shuffle",
        controlVerdict(r.ladder.temporal - r.controls.orderShuffleAuc, {
          atLeast: t.controls.orderShuffleDrop.atLeast,
        }),
        `drop ${(r.ladder.temporal - r.controls.orderShuffleAuc).toFixed(3)} ≥ ${t.controls.orderShuffleDrop.atLeast}`,
      ],
      [
        "timing-noise",
        controlVerdict(r.ladder.temporal - r.controls.timingNoiseAuc, {
          absAtMost: t.controls.timingNoiseDrop.absAtMost,
        }),
        `drop ${(r.ladder.temporal - r.controls.timingNoiseAuc).toFixed(3)} ≤ ${t.controls.timingNoiseDrop.absAtMost}`,
      ],
      [
        "positive control",
        controlVerdict(r.controls.positiveControlDelta, {
          atLeast: t.controls.positiveControlDelta.atLeast,
        }),
        `Δ ${r.controls.positiveControlDelta.toFixed(3)} ≥ ${t.controls.positiveControlDelta.atLeast}`,
      ],
      [
        "null control",
        controlVerdict(r.controls.nullControlDelta, { absAtMost: nullLimit }),
        `Δ ${r.controls.nullControlDelta.toFixed(3)} within ±${nullLimit.toFixed(3)} (2σ_null)`,
      ],
    ];
    components.push({
      key: "controls",
      label: "Tier-0 controls",
      verdict: worstOf(...checks.map((c) => c[1])),
      detail: checks.map(([name, v]) => `${name} ${v}`).join(" · "),
    });
  }

  // 4 — calibration
  {
    const ece = bandDown(r.calibration.eceCalibrated, t.calibration.eceCalibrated);
    const brierOk = !t.calibration.brierMustImprove || r.calibration.brierCalibrated <= r.calibration.brierRaw;
    components.push({
      key: "calibration",
      label: "Calibration (isotonic)",
      verdict: worstOf(ece, brierOk ? "PASS" : "FAIL"),
      detail: `ECE ${r.calibration.eceRaw.toFixed(3)} → ${r.calibration.eceCalibrated.toFixed(3)} (${ece}) · Brier ${r.calibration.brierRaw.toFixed(3)} → ${r.calibration.brierCalibrated.toFixed(3)}`,
    });
  }

  // 5 — behavioural fidelity
  {
    const ps: Array<[string, number]> = [
      ["P1 burst", r.behavior.p1Burst],
      ["P2 velocity", r.behavior.p2Velocity],
      ["P3 graph", r.behavior.p3Graph],
      ["P4 drift", r.behavior.p4Drift],
    ];
    const verdicts = ps.map(([, v]) => bandUp(v, t.behavior.p));
    const mean = r.behavior.composite / 4;
    components.push({
      key: "behavior",
      label: "Behavioural fidelity",
      verdict: worstOf(...verdicts, bandUp(mean, t.behavior.p)),
      detail: ps.map(([n, v], k) => `${n} ${v.toFixed(3)} (${verdicts[k]})`).join(" · ") + ` · composite ${r.behavior.composite.toFixed(3)}/4`,
    });
  }

  // 6 — distributional sanity
  {
    const sp = bandUp(r.distributions.spearman, t.distributions.spearman);
    const sep = r.distributions.fraudCircular.r - r.distributions.legitCircular.r;
    const circ = bandUp(sep, t.distributions.circularSeparation);
    components.push({
      key: "distributions",
      label: "Distributional sanity",
      verdict: worstOf(sp, circ),
      detail: `Spearman(score, propensity) ${r.distributions.spearman.toFixed(3)} (${sp}) · circular R separation ${sep.toFixed(3)} (${circ})`,
    });
  }

  // 7 — audit chain
  {
    const ok = r.chain.valid && r.chain.records === r.n;
    components.push({
      key: "chain",
      label: "Audit chain",
      verdict: ok ? "PASS" : "FAIL",
      detail: `${r.chain.records} records · ${ok ? "verified end-to-end" : "INVALID"} · root ${r.chain.root.slice(0, 16)}…`,
    });
  }

  let worstKey = "ladder";
  let worst: Verdict = "PASS";
  for (const c of components) {
    if (c.verdict === "FAIL") {
      return { components, overall: "FAIL", worstKey: c.key };
    }
    if (c.verdict === "WARN") {
      worst = "WARN";
      worstKey = c.key;
    }
  }
  return { components, overall: worst, worstKey };
}
