/**
 * ProofBridge Validation Dashboard — labelled rebuild.
 * Presentation formatting (CLI table alignment, fixed-precision numbers)
 * plus the canonical JSON serialisation used by the audit chain.
 *
 * Everything here is deterministic and dependency-free — safe to import
 * from client components.
 */

/** Fixed-decimal formatting with a stable minus sign. */
export function fmt(x: number, d = 4): string {
  if (!Number.isFinite(x)) return "n/a";
  const s = x.toFixed(d);
  return s === "-0." + "0".repeat(d) ? (0).toFixed(d) : s;
}

/** Percent formatting, e.g. 0.643 → "64.3%". */
export function pct(x: number, d = 1): string {
  return fmt(x * 100, d) + "%";
}

/** Truncated hash display, e.g. "92265b3edcc0…" (default 12 hex chars). */
export function shortRoot(root: string, len = 12): string {
  return root.length <= len ? root : root.slice(0, len) + "…";
}

/** Pad a string to a width; align "l" (left) or "r" (right). */
export function pad(s: string, w: number, align: "l" | "r" = "l"): string {
  if (s.length >= w) return s;
  const fill = " ".repeat(w - s.length);
  return align === "l" ? s + fill : fill + s;
}

/** Render a monospace CLI table: left-aligned columns, rule under header. */
export function table(headers: readonly string[], rows: readonly (readonly string[])[][]): string {
  const nCols = headers.length;
  const widths = new Array<number>(nCols).fill(0);
  const consider = (cells: readonly string[]): void => {
    for (let c = 0; c < nCols; c++) {
      const w = (cells[c] ?? "").length;
      if (w > widths[c]) widths[c] = w;
    }
  };
  consider(headers);
  for (const r of rows) consider(r);

  const render = (cells: readonly string[]): string =>
    cells.slice(0, nCols).map((cell, c) => pad(cell ?? "", widths[c])).join("  ").trimEnd();

  const head = render(headers);
  const rule = widths.map((w) => "-".repeat(w)).join("  ");
  const body = rows.map(render);
  return [head, rule, ...body].join("\n");
}

/**
 * Canonical JSON: object keys sorted recursively, arrays kept in order,
 * numbers rendered deterministically (integers as integers; floats via
 * toFixed(10) with trailing zeros trimmed). No whitespace.
 *
 * This is the serialisation that feeds the SHA-256 audit chain, so it
 * must be byte-stable across runs, platforms and Node/Bun.
 */
export function canonicalJson(v: unknown): string {
  return encode(v);
}

function encode(v: unknown): string {
  if (v === null || v === undefined) return "null";
  if (typeof v === "number") return encodeNumber(v);
  if (typeof v === "boolean") return v ? "true" : "false";
  if (typeof v === "string") return JSON.stringify(v);
  if (Array.isArray(v)) return "[" + v.map(encode).join(",") + "]";
  if (typeof v === "object") {
    const keys = Object.keys(v as Record<string, unknown>)
      .filter((k) => (v as Record<string, unknown>)[k] !== undefined)
      .sort();
    return "{" + keys.map((k) => JSON.stringify(k) + ":" + encode((v as Record<string, unknown>)[k])).join(",") + "}";
  }
  // Functions / symbols / bigints never appear in chain payloads.
  throw new Error("canonicalJson: unsupported value " + String(v));
}

function encodeNumber(x: number): string {
  if (!Number.isFinite(x)) throw new Error("canonicalJson: non-finite number");
  if (Number.isInteger(x) && Math.abs(x) < 1e15) return String(x);
  // toFixed(10) is deterministic; trim trailing zeros to keep payloads short.
  let s = x.toFixed(10);
  if (s.includes(".")) s = s.replace(/0+$/, "").replace(/\.$/, "");
  return s === "-0" ? "0" : s;
}
