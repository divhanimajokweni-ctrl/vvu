/**
 * ProofBridge Validation Dashboard — labelled rebuild.
 * Deterministic sample generation for the fraud-model validation harness.
 *
 * The generator simulates an account/merchant transaction stream with
 * known ground truth (labels + per-session propensity). It is fully
 * seeded: mulberry32 PRNG, no Date.now(), no Math.random().
 *
 * World model (hand-calibrated constants, documented in README.md):
 *  - a fixed slice of accounts is compromised; each compromised-account
 *    session is either an account-takeover burst (long, tight, fraud
 *    label on every transaction) or benign automation (short, slower,
 *    clean label) — the session-fraud probability ramps across the
 *    stream (the P4 drift, by design);
 *  - fraud transactions skew night-hour, cardless, ring merchants,
 *    heavier amounts with a drift ramp across the stream;
 *  - normal accounts transact sparsely with occasional quick double
 *    purchases; a small share of their transactions are "big-ticket"
 *    lookalikes (the honest hard negatives that weaken the low-FPR
 *    operating point).
 */

import type { Rng, Sample, Channel } from "./types";

/** mulberry32 — 32-bit seeded PRNG, returns floats in [0, 1). */
export function mulberry32(seed: number): Rng {
  let a = seed >>> 0;
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** Box–Muller standard normal (no caching — trivially deterministic). */
export function gauss(rng: Rng): number {
  const u1 = Math.max(rng(), 1e-12);
  const u2 = rng();
  return Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2);
}

/** Exponential draw with the given mean. */
export function expDraw(rng: Rng, mean: number): number {
  return -Math.log(Math.max(rng(), 1e-12)) * mean;
}

/** Log-normal draw. */
export function logNormal(rng: Rng, mu: number, sigma: number): number {
  return Math.exp(mu + sigma * gauss(rng));
}

/**
 * Exact von Mises hour-of-day draw (rejection sampling from a uniform
 * proposal on the circle: accept with probability exp(κ·(cos Δ − 1))).
 * mu in hours, kappa = concentration. Returns hours in [0, 24).
 */
export function vonMisesHours(rng: Rng, muHours: number, kappa: number): number {
  const mu = (muHours / 24) * 2 * Math.PI;
  for (let guard = 0; guard < 2000; guard++) {
    const x = rng() * 2 * Math.PI - Math.PI;
    if (rng() <= Math.exp(kappa * (Math.cos(x) - 1))) {
      let h = (((mu + x) / (2 * Math.PI)) * 24) % 24;
      if (h < 0) h += 24;
      return h;
    }
  }
  return muHours;
}

/** Deterministic Fisher–Yates shuffle (returns a new array). */
export function seededShuffle<T>(rng: Rng, arr: readonly T[]): T[] {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    const tmp = a[i];
    a[i] = a[j];
    a[j] = tmp;
  }
  return a;
}

interface CdfEntry<T> {
  value: T;
  p: number;
}

function pickCdf<T>(rng: Rng, table: readonly CdfEntry<T>[]): T {
  const u = rng();
  let acc = 0;
  for (const e of table) {
    acc += e.p;
    if (u < acc) return e.value;
  }
  return table[table.length - 1].value;
}

// ---------------------------------------------------------------------------
// World constants (hand-calibrated; tuning notes live in README.md)
// ---------------------------------------------------------------------------

export const WORLD = {
  accountsPerTx: 7, // nAccounts ≈ n / 7
  compromisedFraction: 0.14,

  // session structure — compromised accounts
  compSessionInter: 7800, // s between compromised-account sessions
  compFraudRamp: [0.07, 0.45] as const, // session-fraud probability ramp (P4 drift, by design)
  fraudSessionMin: 6, // takeover session length k ∈ [6, 10]
  fraudSessionSpan: 6,
  fraudIntraGap: 12, // s between transactions inside a takeover session
  fraudGhostPauseShare: 0.2, // intra-session pauses (fraudster hesitates) — hard positives
  fraudGhostGap: 700, // mean pause length, s
  benignSessionMin: 4, // benign automation length k ∈ [4, 7]
  benignSessionSpan: 4,
  benignIntraGap: 100, // s inside a benign automation session

  // normal accounts
  legitSessionInter: 10800,
  legitPairProb: 0.32, // normal "quick double purchase"
  legitIntraGap: 300, // inside the 600 s burst window — honest hard negatives

  // merchants — compromised accounts keep a preferred ring merchant
  merchantsPerTx: 14, // nMerchants ≈ n / 14
  ringMerchantShare: 0.125,
  fraudRingPref: 0.3, // fraud transaction goes to the account's ring merchant
  legitRingShare: 0.11,

  // amounts — a fat big-ticket legit tail is the honest hard-negative set
  bigLegitShare: 0.22,
  amountFraudMu: Math.log(60),
  amountFraudSigma: 1.05,
  amountLegitMu: Math.log(36),
  amountLegitSigma: 0.8,
  amountBigMu: Math.log(140),
  amountBigSigma: 0.55,
  fraudAmountDrift: 0.4, // ×(1 + 0.4·u) across the stream

  // per-transaction fraud propensity once a session type is drawn
  fraudSessionPropensity: 0.93,
  benignSessionPropensity: 0.03,
  benignNightShare: 0.75, // benign automation mostly runs at night — honest hard negatives
  // normal-account background fraud (per transaction)
  normalPropensity: [0.004, 0.02] as const,

  // hour-of-day
  fraudHour: { mu: 3.5, kappa: 0.4 },
  legitHour: { mu: 13.5, kappa: 0.5, uniformShare: 0.7 },
} as const;

const FRAUD_CHANNEL: readonly CdfEntry<Channel>[] = [
  { value: "cardless", p: 0.26 },
  { value: "online", p: 0.44 },
  { value: "card", p: 0.3 },
];

const LEGIT_CHANNEL: readonly CdfEntry<Channel>[] = [
  { value: "card", p: 0.45 },
  { value: "online", p: 0.38 },
  { value: "cardless", p: 0.17 },
];

// ---------------------------------------------------------------------------
// Generation
// ---------------------------------------------------------------------------

/**
 * Generate `n` transactions for the given seed. Returns samples in stream
 * order with instrumentation already computed.
 */
export function generateSamples(seed: number, n: number): Sample[] {
  const rng = mulberry32(seed);
  const nAccounts = Math.max(24, Math.round(n / WORLD.accountsPerTx));
  const nMerchants = Math.max(12, Math.round(n / WORLD.merchantsPerTx));
  const nRing = Math.max(2, Math.round(nMerchants * WORLD.ringMerchantShare));

  const ringMerchant = new Array<boolean>(nMerchants).fill(false);
  for (let m = 0; m < nRing; m++) ringMerchant[m] = true; // deterministic slice

  // exactly round(fraction · nAccounts) compromised accounts, chosen by
  // a seeded shuffle — stable prevalence across seeds
  const nComp = Math.max(1, Math.round(nAccounts * WORLD.compromisedFraction));
  const accountOrder = seededShuffle(rng, Array.from({ length: nAccounts }, (_, k) => k));
  const compromisedSet = new Set<number>(accountOrder.slice(0, nComp));
  const compromised = new Array<boolean>(nAccounts).fill(false);
  for (const a of compromisedSet) compromised[a] = true;
  // each compromised account keeps one preferred ring merchant
  const compRing = new Array<number>(nAccounts).fill(-1);
  for (let a = 0; a < nAccounts; a++) {
    if (compromised[a]) compRing[a] = Math.floor(rng() * nRing);
  }

  // event clock state
  const nextT = new Array<number>(nAccounts).fill(Infinity);
  const prevT = new Array<number>(nAccounts).fill(0);
  const sessionLeft = new Array<number>(nAccounts).fill(0);
  const sessionLen = new Array<number>(nAccounts).fill(1); // big-ticket legit only in single-tx sessions
  const sessionFraud = new Array<boolean>(nAccounts).fill(false);
  const sessionPropensity = new Array<number>(nAccounts).fill(0);
  for (let a = 0; a < nAccounts; a++) {
    nextT[a] = expDraw(rng, compromised[a] ? WORLD.compSessionInter : WORLD.legitSessionInter);
  }

  const raw: Sample[] = [];

  for (let i = 0; i < n; i++) {
    // account with the earliest next event (ties → lowest account id)
    let a = 0;
    for (let k = 1; k < nAccounts; k++) if (nextT[k] < nextT[a]) a = k;
    const comp = compromised[a];
    const ts = nextT[a];
    const gapDraw = ts - prevT[a];
    const u = i / n; // stream position, drives the drift ramp

    let label: 0 | 1;
    let propensity: number;

    if (sessionLeft[a] === 0) {
      if (comp) {
        // session-level fraud decision on the compromised account:
        // an account-takeover burst or benign automation
        const p =
          WORLD.compFraudRamp[0] +
          (WORLD.compFraudRamp[1] - WORLD.compFraudRamp[0]) * u;
        const isFraud = rng() < p;
        sessionFraud[a] = isFraud;
        sessionPropensity[a] = p;
        sessionLen[a] = isFraud
          ? WORLD.fraudSessionMin + Math.floor(rng() * WORLD.fraudSessionSpan)
          : WORLD.benignSessionMin + Math.floor(rng() * WORLD.benignSessionSpan);
      } else {
        sessionFraud[a] = false;
        sessionLen[a] = 1 + (rng() < WORLD.legitPairProb ? 1 : 0);
      }
      sessionLeft[a] = sessionLen[a];
    }

    if (comp) {
      // per-transaction draw at the session's intensity — the session
      // structure drives the features, the Bernoulli draw keeps honest
      // hard negatives inside takeover sessions
      propensity = sessionFraud[a]
        ? WORLD.fraudSessionPropensity
        : WORLD.benignSessionPropensity;
    } else {
      propensity =
        WORLD.normalPropensity[0] +
        (WORLD.normalPropensity[1] - WORLD.normalPropensity[0]) * rng();
    }
    label = rng() < propensity ? 1 : 0;

    const amount = label
      ? round2(logNormal(rng, WORLD.amountFraudMu, WORLD.amountFraudSigma) * (1 + WORLD.fraudAmountDrift * u))
      : !comp && sessionLen[a] === 1 && rng() < WORLD.bigLegitShare
        ? round2(logNormal(rng, WORLD.amountBigMu, WORLD.amountBigSigma))
        : round2(logNormal(rng, WORLD.amountLegitMu, WORLD.amountLegitSigma));

    // benign automation on compromised accounts runs at night half the
    // time (cron-like) — the honest hard negatives in the night band
    const nightAutomation = !label && comp && !sessionFraud[a] && rng() < WORLD.benignNightShare;
    const hour = label || nightAutomation
      ? vonMisesHours(rng, WORLD.fraudHour.mu, WORLD.fraudHour.kappa)
      : rng() < 1 - WORLD.legitHour.uniformShare
        ? vonMisesHours(rng, WORLD.legitHour.mu, WORLD.legitHour.kappa)
        : rng() * 24;

    const channel = label ? pickCdf(rng, FRAUD_CHANNEL) : pickCdf(rng, LEGIT_CHANNEL);

    let merchantId: number;
    if (label) {
      // fraud: preferred ring merchant, otherwise a uniformly random merchant
      merchantId = rng() < WORLD.fraudRingPref ? compRing[a] : Math.floor(rng() * nMerchants);
    } else {
      merchantId =
        rng() < WORLD.legitRingShare
          ? Math.floor(rng() * nRing)
          : nRing + Math.floor(rng() * (nMerchants - nRing));
    }

    raw.push({
      i,
      id: "tx-" + String(i).padStart(6, "0"),
      accountId: a,
      merchantId,
      ts,
      hour,
      channel,
      amount,
      ringMerchant: ringMerchant[merchantId] ? 1 : 0,
      propensity,
      label,
      gapDraw,
      burst: 0,
      velocity: 0,
      gapSec: 7200,
      merchantDegree: 1,
      merchantTxCount: 1,
    });

    // schedule this account's next event
    prevT[a] = ts;
    sessionLeft[a] -= 1;
    nextT[a] =
      sessionLeft[a] > 0
        ? ts +
          (sessionFraud[a] && rng() < WORLD.fraudGhostPauseShare
            ? expDraw(rng, WORLD.fraudGhostGap)
            : expDraw(rng, sessionFraud[a] ? WORLD.fraudIntraGap : comp ? WORLD.benignIntraGap : WORLD.legitIntraGap))
        : ts + expDraw(rng, comp ? WORLD.compSessionInter : WORLD.legitSessionInter);
  }

  return computeInstrumentation(raw);
}

// ---------------------------------------------------------------------------
// Instrumentation
// ---------------------------------------------------------------------------

const BURST_WINDOW = 600; // s
const VELOCITY_WINDOW = 3600; // s
const GAP_CAP = 7200; // s

/**
 * Recompute the label-free stream instrumentation (burst, velocity, gap,
 * merchant degree) for a sequence of samples, using each sample's `ts`.
 *
 * Used by the generator, the order-shuffle control (re-laid timeline) and
 * the timing-noise control (jittered times). Walking order = array order.
 */
export function computeInstrumentation(samples: readonly Sample[]): Sample[] {
  const out: Sample[] = [];
  const lastTs = new Map<number, number>();
  const history = new Map<number, { ts: number; amount: number }[]>();
  const merchantAccounts = new Map<number, Set<number>>();
  const merchantTxs = new Map<number, number>();

  for (const s of samples) {
    let burst = 0;
    let velocity = 0;
    let gapSec = GAP_CAP;
    let degree = 1;

    const h = history.get(s.accountId);
    if (h) {
      for (const e of h) {
        if (e.ts < s.ts && e.ts > s.ts - VELOCITY_WINDOW) {
          velocity += e.amount;
          if (e.ts > s.ts - BURST_WINDOW) burst++;
        }
      }
      const lt = lastTs.get(s.accountId);
      if (lt !== undefined) gapSec = Math.min(Math.abs(s.ts - lt), GAP_CAP);
    }

    let acc = merchantAccounts.get(s.merchantId);
    if (!acc) {
      acc = new Set<number>();
      merchantAccounts.set(s.merchantId, acc);
    }
    acc.add(s.accountId);
    degree = acc.size;
    const txCount = (merchantTxs.get(s.merchantId) ?? 0) + 1;
    merchantTxs.set(s.merchantId, txCount);

    // record AFTER computing — instrumentation is strictly trailing
    if (!h) history.set(s.accountId, []);
    history.get(s.accountId)!.push({ ts: s.ts, amount: s.amount });
    while (history.get(s.accountId)!.length > 0 && history.get(s.accountId)![0].ts < s.ts - VELOCITY_WINDOW) {
      history.get(s.accountId)!.shift();
    }
    lastTs.set(s.accountId, s.ts);

    out.push({ ...s, burst, velocity, gapSec, merchantDegree: degree, merchantTxCount: txCount });
  }

  return out;
}

function round2(x: number): number {
  return Math.round(x * 100) / 100;
}
