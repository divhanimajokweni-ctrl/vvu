/**
 * ProofBridge Validation Dashboard — labelled rebuild.
 * Shared contracts for the deterministic fraud-model validation harness.
 *
 * Everything here is JSON-serialisable and contains **no wall-clock time**:
 * identical ({seed, n}) inputs must produce byte-identical results,
 * including the audit-chain root hash.
 */

export type Rng = () => number;

export type Channel = "card" | "online" | "cardless";

/**
 * One generated transaction with its ground truth and its label-free
 * stream instrumentation (burst / velocity / gap / merchant degree are
 * computed from the event stream only — never from labels).
 */
export interface Sample {
  /** transaction index in stream order */
  i: number;
  /** canonical id, e.g. "tx-000042" */
  id: string;
  accountId: number;
  merchantId: number;
  /** stream clock, seconds (synthetic — never wall-clock) */
  ts: number;
  /** hour of day [0, 24) — circular feature */
  hour: number;
  channel: Channel;
  amount: number;
  /** 1 if the merchant belongs to the generator's fraud-ring set */
  ringMerchant: 0 | 1;
  /**
   * Generator ground truth: the fraud propensity this transaction was
   * drawn with (compromised accounts: the session's fraud propensity; normal
   * accounts: the per-transaction background rate). Used ONLY by oracle
   * diagnostics (e.g. Spearman fidelity); it is never an input to any
   * model in the ladder.
   */
  propensity: number;
  /** ground-truth label (1 = fraud) */
  label: 0 | 1;
  /**
   * The inter-arrival gap the generator drew for this transaction's
   * arrival at its account (seconds). Kept so the order-shuffle control
   * can re-lay the timeline deterministically.
   */
  gapDraw: number;

  // ---- stream instrumentation (label-free, recomputable) ----
  /** same-account transactions in the trailing 10 minutes */
  burst: number;
  /** same-account amount sum in the trailing hour */
  velocity: number;
  /** seconds since the previous same-account transaction (capped) */
  gapSec: number;
  /** distinct accounts seen at this merchant so far, including this one */
  merchantDegree: number;
  /** transactions seen at this merchant so far, including this one */
  merchantTxCount: number;
}

// ---------------------------------------------------------------------------
// Model ladder
// ---------------------------------------------------------------------------

export type ModelName = "rules" | "bprime" | "flat" | "temporal" | "calibrated";

/** Display/report order of the scoring ladder. */
export const MODEL_ORDER: readonly ModelName[] = [
  "rules",
  "bprime",
  "flat",
  "temporal",
  "calibrated",
];

/** One rung of the ladder, evaluated on the deterministic holdout split. */
export interface LadderEntry {
  model: ModelName;
  /** ROC AUC on the holdout split */
  auc: number;
  /** partial AUC over the 0–0.1 FPR band (unnormalised trapezoid) */
  partialAuc: number;
  /** FNR at the 5% FPR operating point on the holdout split */
  fnrAtFivePctFpr: number;
}

// ---------------------------------------------------------------------------
// Tier-0 controls
// ---------------------------------------------------------------------------

export type ControlName = "label-shuffle" | "order-shuffle" | "timing-noise" | "positive";

/**
 * One instrument-sanity control.
 *
 *  - label-shuffle / order-shuffle / timing-noise: the temporal model is
 *    RETRAINED from scratch on the perturbed world and re-evaluated —
 *    `auc` is the perturbed holdout AUC, `delta` = baseline − auc.
 *  - positive: `auc` is the planted-signal AUC, `delta` = auc − 0.5
 *    (the signal the instrument must detect), `nullDelta` = the placebo
 *    Δ on pure noise (the signal the instrument must NOT hallucinate).
 */
export interface ControlEntry {
  control: ControlName;
  auc: number;
  delta: number;
  nullDelta?: number;
}

// ---------------------------------------------------------------------------
// Report blocks
// ---------------------------------------------------------------------------

export interface CalibrationMetrics {
  eceRaw: number;
  eceCalibrated: number;
  brierRaw: number;
  brierCalibrated: number;
}

export interface BehavioralMetrics {
  /** P1 — burst fidelity: AUC of the trailing-10-min burst index */
  p1Burst: number;
  /** P2 — velocity fidelity: AUC of log trailing-hour amount */
  p2Velocity: number;
  /** P3 — graph fidelity: AUC of merchant shared-account concentration */
  p3Graph: number;
  /** P4 — drift fidelity: (ρ+1)/2 of Spearman(quintile, quintile fraud rate) */
  p4Drift: number;
  /** Σ P1..P4, maximum 4.000 */
  composite: number;
}

export interface DistributionMetrics {
  /** two-sample Kolmogorov–Smirnov distance, fraud vs legit temporal scores */
  ksDistance: number;
  /** 1-D Wasserstein distance, fraud vs legit temporal scores */
  wasserstein: number;
  /** Spearman ρ between the temporal score and true propensity (oracle) */
  spearman: number;
  /** mean resultant length R of fraud transaction hours (night concentration) */
  circularConcentrationFraud: number;
  /** mean resultant length R of legit transaction hours */
  circularConcentrationClean: number;
}

export interface ChainInfo {
  /** genesis anchor string that seeds the first link */
  genesis: string;
  /** sealed record count (1 genesis record + one per transaction) */
  count: number;
  /** end-to-end re-verification result */
  valid: boolean;
  /** hash of the last sealed record */
  root: string;
}

/** The full deterministic result of one runValidation call. */
export interface ValidationResults {
  seed: number;
  n: number;
  fraudCount: number;
  fraudRate: number;
  ladder: LadderEntry[];
  controls: ControlEntry[];
  calibration: CalibrationMetrics;
  behavior: BehavioralMetrics;
  distribution: DistributionMetrics;
  chain: ChainInfo;
}

export interface RunSpec {
  seed: number;
  n: number;
}

// ---------------------------------------------------------------------------
// Audit-chain records
// ---------------------------------------------------------------------------

/** A chain record awaiting its seal. Exactly `{ tag, payload }`. */
export interface ChainRecord {
  tag: string;
  payload: unknown;
}

/** A ChainRecord with its place in the append-only hash chain. */
export interface SealedRecord extends ChainRecord {
  prev: string;
  hash: string;
}
