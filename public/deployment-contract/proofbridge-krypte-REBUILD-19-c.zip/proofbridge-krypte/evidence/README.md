# Evidence — Gates A–D + harness baseline (REBUILD-19-c branch)

All outputs in this directory were captured **verbatim from the actual runs**
on **2026-09-14 (UTC)**, by piping the script's stdout+stderr through `tee`.
No numbers were edited, retyped, or summarised by hand; the files are the raw
console output, byte-for-byte.

| File | Produced by (exact command) | When | What it is |
|---|---|---|---|
| `gate-a-baseline.txt` | `bun run scripts/test-harness.ts 2>&1 \| tee evidence-gate-a.txt` (run at **commit 1**, specimen only, then moved here) | 2026-09-14 02:42 UTC | The fraud-specimen harness baseline at the commit-1 tree: model ladder, Tier-0 controls, calibration, diagnostics, P1–P4, audit chain (451 records, root `bd4673596aebfcfbf44e772c20d32266d281e7d4c165dc0b2dcb154843a31f17`), verdicts (overall WARN 8/9), determinism MATCH. |
| `gates-abcd.txt` | `bun run scripts/verify-gates.ts 2>&1 \| tee evidence/gates-abcd.txt` | 2026-09-14 02:43 UTC | Gates A–D at the full (commit-2) tree: ALL GATES PASSED — Gate A re-asserts the harness baseline + root; Gate B 35/35 verdict equality across 5 seeds; Gate C hydraulic PASS 8/8 (11 records, root `bba4ca1f106aa…`); Gate D purity + canonical receipts + independent chains. |
| `test-harness.txt` | `bun run scripts/test-harness.ts 2>&1 \| tee evidence/test-harness.txt` | 2026-09-14 02:43 UTC | Same harness run repeated at the commit-2 tree — byte-identical to `gate-a-baseline.txt` (the validation layer is unchanged by the substrate commit). |
| `gates-abcd-rerun.txt` | `bun run scripts/verify-gates.ts 2>&1 \| tee evidence/gates-abcd-rerun.txt` | 2026-09-14 02:43 UTC | Determinism re-run: `diff gates-abcd.txt gates-abcd-rerun.txt` is empty. |
| `test-harness-rerun.txt` | `bun run scripts/test-harness.ts 2>\&1 \| tee evidence/test-harness-rerun.txt` | 2026-09-14 02:43 UTC | Determinism re-run: `diff test-harness.txt test-harness-rerun.txt` is empty. |

Full seal roots asserted by the gates (abbreviated in the gate table output):
fraud 13 records, root `2d8b92751c5236a3208391237d0bd7cec1e02135e29afbf754135f419b922aed`
(sealing the harness root `bd467359…` @ 451 records); hydraulic 11 records,
root `bba4ca1f106aa08f6acdbd01758eee6412ebf4216410dbc5a128fd6e68d17187`.
