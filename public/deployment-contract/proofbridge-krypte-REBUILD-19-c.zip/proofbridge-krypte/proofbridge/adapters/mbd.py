#!/usr/bin/env python3
"""
ProofBridge MBD adapter — real-data event sequences + proxy APP-fraud labels.

Work order (ProofBridge Delivery Round, Deliverable 1): build per-client event
sequences from the MBD transaction + dialog + geo tables and generate proxy
APP-fraud labels with the disclosed rule:

    "inbound contact within 24h of payment and no payment_review navigation
     between payee_add and payment = positive; otherwise negative"

HONEST PROVENANCE NOTE (do not remove):
The work order references `proofbridge/adapters/mbd.py` as "already in the
codebase". That file did NOT exist in the surviving workspace (the krypte
artifact survived only as a flat zip with no Python). This adapter was written
fresh this round implementing the disclosed rule. Because MBD's schema is
anonymised (event codes are integer tokens with no public codebook; dialog
rows carry no event types), each rule observable is mapped to a DISCLOSED
proxy below. Every deviation is a proxy, is labelled as a proxy, and all
results downstream are conditional on these mappings.

Disclosed proxy mapping (rule observable -> MBD-expressible proxy):
  payment            -> every trx row of the client (MBD amounts are unsigned
                        and event_type codes are anonymised: direction is NOT
                        expressible; each trx row is a payment event in the
                        client's stream)
  payee_add          -> the payment's counterparty (dst_type11, dst_type12)
                        was first seen for this client within the preceding
                        30 days ("recently-added payee"; the add action itself
                        is not an observable event type in MBD)
  inbound contact    -> any dialog event (customer-bank interaction) in the
                        24h window BEFORE the payment. Dialog rows carry no
                        direction/type, so inbound-vs-outbound is not
                        expressible; "before" is the manipulation-window
                        reading (the call precedes the coached payment).
  payment_review     -> dialog events in the 2h window immediately BEFORE the
  navigation            payment (the pre-payment review-session proxy: a
                        reviewing user opens the app; a coached victim pays
                        without a session). MBD dialogs carry no navigation
                        types, so the between-payee_add-and-payment window
                        collapses to this disclosed quiet-window proxy.

  label = 1 iff: payee first-seen 0..30 days before the payment
               AND dialog in [t-24h, t)
               AND no dialog in [t-2h, t)

Sample-field proxies (for the harness's Sample contract):
  channel    -> constant "online" (MBD carries no channel dimension; constant
                chosen as the neutral middle-risk value; disclosed)
  ringMerchant -> 0 for all (generator ground truth; does not exist in MBD)
  propensity -> label (oracle diagnostic only; never a model input; disclosed)
  gapDraw    -> real seconds since the previous same-client trx (first event
                of a client: 30 days = 2592000 s, disclosed)
  merchantId -> dense code of the (dst_type11, dst_type12) counterparty
  hour       -> native wall-clock hour-of-day (no timezone conversion; MBD
                timestamps are naive datetimes, used as-is)

Dataset: ai-lab/MBD-mini (Sber AI Lab), the official reduced subset of
ai-lab/MBD with identical schema; pinned revision
4b0d5b4c0b014e02af6c2e6b7b27851e6fb0d5c3 (2024-10-28). The full dataset's
detail table is 38 GB; MBD-mini is the manageable path to the same schema.
Geo rows are loaded and counted (the sequences are built from all three
tables) but enter neither labels nor samples — the disclosed rule's
observables are trx+dialog only.

Determinism: same pinned revision + same fold + same client count =>
byte-identical outputs. Client selection = client_split fold=0 ORDER BY
client_id LIMIT N. Event order = (event_time, client index, within-client
tuple order). No wall-clock reads.

Usage:
  python3 mbd.py --data <dir with client_split/ + detail/> --out <outdir> \
                  [--clients 2000] [--fold 0]
Requires: duckdb (pip install duckdb).
"""

import argparse
import hashlib
import json
import sys
from bisect import bisect_left
from datetime import datetime, timedelta

DATASET_ID = "ai-lab/MBD-mini"
DATASET_URL = "https://huggingface.co/datasets/ai-lab/MBD-mini"
DATASET_REVISION = "4b0d5b4c0b014e02af6c2e6b7b27851e6fb0d5c3"
PAYEE_AGE_WINDOW_DAYS = 30
CONTACT_WINDOW = timedelta(hours=24)
REVIEW_WINDOW = timedelta(hours=2)
FIRST_GAP_SEC = 30 * 86400.0  # disclosed: gap for a client's first trx


def epoch_seconds(dt: datetime) -> float:
    """Naive datetime -> epoch seconds (treated as UTC for ordering only)."""
    return (dt - datetime(1970, 1, 1)).total_seconds()


def hour_of_day(dt: datetime) -> float:
    """Fractional hour [0, 24) from the naive wall-clock (no tz conversion)."""
    return dt.hour + dt.minute / 60.0 + dt.second / 3600.0 + dt.microsecond / 3.6e9


def main() -> int:
    ap = argparse.ArgumentParser(description="ProofBridge MBD adapter")
    ap.add_argument("--data", required=True, help="dir containing client_split/ and detail/")
    ap.add_argument("--out", required=True, help="output directory")
    ap.add_argument("--clients", type=int, default=2000)
    ap.add_argument("--fold", type=int, default=0)
    args = ap.parse_args()

    import duckdb  # deferred so --help works without duckdb

    con = duckdb.connect()

    # ---- 1. deterministic client selection --------------------------------
    split_glob = f"'{args.data}/client_split/fold={args.fold}/*.parquet'"
    selected = [
        r[0]
        for r in con.sql(f"SELECT client_id FROM {split_glob} ORDER BY client_id").fetchall()
    ][: args.clients]
    if not selected:
        print("ERROR: no clients selected — wrong --data path?", file=sys.stderr)
        return 1
    selection_sha = hashlib.sha256("\n".join(selected).encode()).hexdigest()

    sel_tbl = ", ".join(f"'{c}'" for c in selected)
    con.execute(f"CREATE TABLE sel AS SELECT unnest([{sel_tbl}]) AS client_id")

    # ---- 2. load the three tables for the selection -----------------------
    trx = con.sql(
        f"""
        SELECT t.client_id, t.event_time, t.amount, t.event_type, t.event_subtype,
               t.dst_type11, t.dst_type12
        FROM '{args.data}/detail/trx/fold={args.fold}/*.parquet' t
        JOIN sel USING (client_id)
        ORDER BY t.client_id, t.event_time
        """
    ).fetchall()
    dlg = con.sql(
        f"""
        SELECT d.client_id, d.event_time
        FROM '{args.data}/detail/dialog/fold={args.fold}/*.parquet' d
        JOIN sel USING (client_id)
        ORDER BY d.client_id, d.event_time
        """
    ).fetchall()
    geo_stats = con.sql(
        f"""
        SELECT count(*) AS geo_rows, count(DISTINCT g.client_id) AS geo_clients,
               count(DISTINCT g.geohash_5) AS geo_cells
        FROM '{args.data}/detail/geo/fold={args.fold}/*.parquet' g
        JOIN sel USING (client_id)
        """
    ).fetchone()

    # ---- 3. per-client dialog lists ---------------------------------------
    dialogs: dict[str, list[datetime]] = {}
    for cid, t in dlg:
        dialogs.setdefault(cid, []).append(t)

    # ---- 4. deterministic global payee code table --------------------------
    payees = sorted({(r[5], r[6]) for r in trx if r[5] is not None and r[6] is not None})
    payee_code = {p: k for k, p in enumerate(payees)}

    # ---- 5. build the stream: per-client pass, then global merge ----------
    client_index = {c: k for k, c in enumerate(selected)}
    first_seen: dict[tuple, datetime] = {}  # keyed (client_id, dst11, dst12) — PER-CLIENT payee first-seen
    prev_ts: dict[str, datetime] = {}
    raw: list[dict] = []

    # stable within-client order: event_time, then full value tuple
    trx.sort(key=lambda r: (r[1], r[3], r[4], r[2] or 0.0, r[5] if r[5] is not None else -1, r[6] if r[6] is not None else -1))

    positives = 0
    positive_clients: set[str] = set()
    missing_dst = 0

    for cid, t, amount, etype, esub, d11, d12 in trx:
        if d11 is None or d12 is None:
            missing_dst += 1
            continue  # counterparty-free rows cannot carry payee semantics
        ts = epoch_seconds(t)
        acct = client_index[cid]
        payee = (d11, d12)
        fp_key = (cid, d11, d12)
        pf = first_seen.get(fp_key)
        if pf is None:
            first_seen[fp_key] = t
            pf = t
        age_days = (t - pf).total_seconds() / 86400.0

        # dialog windows (dialog times strictly before t)
        dlist = dialogs.get(cid, [])
        i_hi = bisect_left(dlist, t)                    # first index >= t
        i_24 = bisect_left(dlist, t - CONTACT_WINDOW)   # first index >= t-24h
        i_2h = bisect_left(dlist, t - REVIEW_WINDOW)    # first index >= t-2h
        contact24 = i_24 < i_hi
        review2h = i_2h < i_hi

        recently_added = 0.0 <= age_days <= PAYEE_AGE_WINDOW_DAYS
        label = 1 if (recently_added and contact24 and not review2h) else 0
        if label:
            positives += 1
            positive_clients.add(cid)

        prev = prev_ts.get(cid)
        gap_draw = FIRST_GAP_SEC if prev is None else (t - prev).total_seconds()
        prev_ts[cid] = t

        raw.append(
            {
                "cid": cid,
                "t": t,
                "ts": ts,
                "acct": acct,
                "merch": payee_code[payee],
                "hour": hour_of_day(t),
                "amount": float(amount),
                "label": label,
                "gap": gap_draw,
            }
        )

    # ---- 6. global stream order: (event_time, client index) ----------------
    raw.sort(key=lambda r: (r["ts"], r["acct"]))

    samples = []
    for i, r in enumerate(raw):
        samples.append(
            {
                "i": i,
                "id": f"mbd-{i:06d}",
                "accountId": r["acct"],
                "merchantId": r["merch"],
                "ts": round(r["ts"], 6),
                "hour": round(r["hour"], 6),
                "channel": "online",
                "amount": r["amount"],
                "ringMerchant": 0,
                "propensity": r["label"],
                "label": r["label"],
                "gapDraw": round(r["gap"], 3),
            }
        )

    # ---- 7. outputs ---------------------------------------------------------
    import os

    os.makedirs(args.out, exist_ok=True)
    samples_path = os.path.join(args.out, "samples.json")
    payload = json.dumps(samples, separators=(",", ":"), ensure_ascii=False)
    with open(samples_path, "w", encoding="utf-8") as f:
        f.write(payload)
    samples_sha = hashlib.sha256(payload.encode("utf-8")).hexdigest()

    report = {
        "adapter": "proofbridge/adapters/mbd.py",
        "work_order": "ProofBridge Delivery Round — Deliverable 1 (real-data fraud validation)",
        "dataset": {
            "id": DATASET_ID,
            "url": DATASET_URL,
            "revision": DATASET_REVISION,
            "note": "official reduced subset of ai-lab/MBD (same schema); full detail table is 38 GB",
            "download": "huggingface resolve URLs, detail.tar.gz 1968727441 bytes",
        },
        "selection": {
            "fold": args.fold,
            "clients_requested": args.clients,
            "clients_selected": len(selected),
            "rule": f"client_split fold={args.fold} ORDER BY client_id LIMIT {args.clients}",
            "selection_sha256": selection_sha,
        },
        "counts": {
            "trx_rows": len(trx),
            "trx_rows_used": len(samples),
            "trx_rows_skipped_no_counterparty": missing_dst,
            "dialog_rows": len(dlg),
            "clients_with_dialogs": len(dialogs),
            "geo_rows": geo_stats[0],
            "clients_with_geo": geo_stats[1],
            "distinct_geohash_5_cells": geo_stats[2],
            "distinct_payees": len(payees),
            "positives": positives,
            "positive_clients": len(positive_clients),
            "positive_rate": positives / max(1, len(samples)),
        },
        "label_rule": {
            "disclosed_rule": "inbound contact within 24h of payment and no payment_review navigation between payee_add and payment = positive",
            "payment": "every trx row (direction not expressible in anonymised MBD schema)",
            "payee_add": f"counterparty (dst_type11,dst_type12) first seen for the client within the preceding {PAYEE_AGE_WINDOW_DAYS} days",
            "inbound_contact": "any dialog event in [t-24h, t) (before-side; direction not expressible)",
            "payment_review": "any dialog event in [t-2h, t) (quiet-window proxy; dialog navigation types not expressible)",
            "positive": "recently-added payee AND contact-24h-before AND no-dialog-2h-before",
        },
        "sample_proxies": {
            "channel": "constant 'online' (no channel dimension in MBD)",
            "ringMerchant": "0 (generator ground truth; absent in MBD)",
            "propensity": "= label (oracle diagnostic only)",
            "gapDraw": "real seconds since previous same-client trx; first event 30d",
            "merchantId": "dense code of (dst_type11, dst_type12)",
            "hour": "native wall-clock hour, no timezone conversion",
        },
        "geo_note": "geo rows are loaded and counted (sequences built from all three tables) but enter neither labels nor samples; the disclosed rule's observables are trx+dialog only",
        "determinism": "pinned revision + fold + client count => byte-identical outputs; no wall-clock reads",
        "samples_file": "samples.json",
        "samples_sha256": samples_sha,
        "samples_rows": len(samples),
    }
    report_path = os.path.join(args.out, "adapter-report.json")
    with open(report_path, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2, ensure_ascii=False)

    print(f"MBD adapter: {len(samples)} samples, {positives} positives "
          f"({len(positive_clients)} clients), {len(payees)} payees, "
          f"{len(dialogs)} clients with dialogs")
    print(f"samples sha256: {samples_sha}")
    print(f"wrote: {samples_path} ({os.path.getsize(samples_path)} bytes)")
    print(f"wrote: {report_path}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
